/*!
 * libav.js v6.5.7.1-61-g823eb97
 * This software is compiled from several sources, the licenses for which are
 * included herein.
 *
 * ---
 *
 * ffmpeg:
 *
 *  Copyright (c) 2000-2023 Fabrice Bellard et al
 *
 *                   GNU LESSER GENERAL PUBLIC LICENSE
 *                        Version 2.1, February 1999
 *
 *  Copyright (C) 1991, 1999 Free Software Foundation, Inc.
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 *  Everyone is permitted to copy and distribute verbatim copies
 *  of this license document, but changing it is not allowed.
 *
 * [This is the first released version of the Lesser GPL.  It also counts
 *  as the successor of the GNU Library Public License, version 2, hence
 *  the version number 2.1.]
 *
 *                             Preamble
 *
 *   The licenses for most software are designed to take away your
 * freedom to share and change it.  By contrast, the GNU General Public
 * Licenses are intended to guarantee your freedom to share and change
 * free software--to make sure the software is free for all its users.
 *
 *   This license, the Lesser General Public License, applies to some
 * specially designated software packages--typically libraries--of the
 * Free Software Foundation and other authors who decide to use it.  You
 * can use it too, but we suggest you first think carefully about whether
 * this license or the ordinary General Public License is the better
 * strategy to use in any particular case, based on the explanations below.
 *
 *   When we speak of free software, we are referring to freedom of use,
 * not price.  Our General Public Licenses are designed to make sure that
 * you have the freedom to distribute copies of free software (and charge
 * for this service if you wish); that you receive source code or can get
 * it if you want it; that you can change the software and use pieces of
 * it in new free programs; and that you are informed that you can do
 * these things.
 *
 *   To protect your rights, we need to make restrictions that forbid
 * distributors to deny you these rights or to ask you to surrender these
 * rights.  These restrictions translate to certain responsibilities for
 * you if you distribute copies of the library or if you modify it.
 *
 *   For example, if you distribute copies of the library, whether gratis
 * or for a fee, you must give the recipients all the rights that we gave
 * you.  You must make sure that they, too, receive or can get the source
 * code.  If you link other code with the library, you must provide
 * complete object files to the recipients, so that they can relink them
 * with the library after making changes to the library and recompiling
 * it.  And you must show them these terms so they know their rights.
 *
 *   We protect your rights with a two-step method: (1) we copyright the
 * library, and (2) we offer you this license, which gives you legal
 * permission to copy, distribute and/or modify the library.
 *
 *   To protect each distributor, we want to make it very clear that
 * there is no warranty for the free library.  Also, if the library is
 * modified by someone else and passed on, the recipients should know
 * that what they have is not the original version, so that the original
 * author's reputation will not be affected by problems that might be
 * introduced by others.
 *
 *   Finally, software patents pose a constant threat to the existence of
 * any free program.  We wish to make sure that a company cannot
 * effectively restrict the users of a free program by obtaining a
 * restrictive license from a patent holder.  Therefore, we insist that
 * any patent license obtained for a version of the library must be
 * consistent with the full freedom of use specified in this license.
 *
 *   Most GNU software, including some libraries, is covered by the
 * ordinary GNU General Public License.  This license, the GNU Lesser
 * General Public License, applies to certain designated libraries, and
 * is quite different from the ordinary General Public License.  We use
 * this license for certain libraries in order to permit linking those
 * libraries into non-free programs.
 *
 *   When a program is linked with a library, whether statically or using
 * a shared library, the combination of the two is legally speaking a
 * combined work, a derivative of the original library.  The ordinary
 * General Public License therefore permits such linking only if the
 * entire combination fits its criteria of freedom.  The Lesser General
 * Public License permits more lax criteria for linking other code with
 * the library.
 *
 *   We call this license the "Lesser" General Public License because it
 * does Less to protect the user's freedom than the ordinary General
 * Public License.  It also provides other free software developers Less
 * of an advantage over competing non-free programs.  These disadvantages
 * are the reason we use the ordinary General Public License for many
 * libraries.  However, the Lesser license provides advantages in certain
 * special circumstances.
 *
 *   For example, on rare occasions, there may be a special need to
 * encourage the widest possible use of a certain library, so that it becomes
 * a de-facto standard.  To achieve this, non-free programs must be
 * allowed to use the library.  A more frequent case is that a free
 * library does the same job as widely used non-free libraries.  In this
 * case, there is little to gain by limiting the free library to free
 * software only, so we use the Lesser General Public License.
 *
 *   In other cases, permission to use a particular library in non-free
 * programs enables a greater number of people to use a large body of
 * free software.  For example, permission to use the GNU C Library in
 * non-free programs enables many more people to use the whole GNU
 * operating system, as well as its variant, the GNU/Linux operating
 * system.
 *
 *   Although the Lesser General Public License is Less protective of the
 * users' freedom, it does ensure that the user of a program that is
 * linked with the Library has the freedom and the wherewithal to run
 * that program using a modified version of the Library.
 *
 *   The precise terms and conditions for copying, distribution and
 * modification follow.  Pay close attention to the difference between a
 * "work based on the library" and a "work that uses the library".  The
 * former contains code derived from the library, whereas the latter must
 * be combined with the library in order to run.
 *
 *                   GNU LESSER GENERAL PUBLIC LICENSE
 *    TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 *   0. This License Agreement applies to any software library or other
 * program which contains a notice placed by the copyright holder or
 * other authorized party saying it may be distributed under the terms of
 * this Lesser General Public License (also called "this License").
 * Each licensee is addressed as "you".
 *
 *   A "library" means a collection of software functions and/or data
 * prepared so as to be conveniently linked with application programs
 * (which use some of those functions and data) to form executables.
 *
 *   The "Library", below, refers to any such software library or work
 * which has been distributed under these terms.  A "work based on the
 * Library" means either the Library or any derivative work under
 * copyright law: that is to say, a work containing the Library or a
 * portion of it, either verbatim or with modifications and/or translated
 * straightforwardly into another language.  (Hereinafter, translation is
 * included without limitation in the term "modification".)
 *
 *   "Source code" for a work means the preferred form of the work for
 * making modifications to it.  For a library, complete source code means
 * all the source code for all modules it contains, plus any associated
 * interface definition files, plus the scripts used to control compilation
 * and installation of the library.
 *
 *   Activities other than copying, distribution and modification are not
 * covered by this License; they are outside its scope.  The act of
 * running a program using the Library is not restricted, and output from
 * such a program is covered only if its contents constitute a work based
 * on the Library (independent of the use of the Library in a tool for
 * writing it).  Whether that is true depends on what the Library does
 * and what the program that uses the Library does.
 *
 *   1. You may copy and distribute verbatim copies of the Library's
 * complete source code as you receive it, in any medium, provided that
 * you conspicuously and appropriately publish on each copy an
 * appropriate copyright notice and disclaimer of warranty; keep intact
 * all the notices that refer to this License and to the absence of any
 * warranty; and distribute a copy of this License along with the
 * Library.
 *
 *   You may charge a fee for the physical act of transferring a copy,
 * and you may at your option offer warranty protection in exchange for a
 * fee.
 *
 *   2. You may modify your copy or copies of the Library or any portion
 * of it, thus forming a work based on the Library, and copy and
 * distribute such modifications or work under the terms of Section 1
 * above, provided that you also meet all of these conditions:
 *
 *     a) The modified work must itself be a software library.
 *
 *     b) You must cause the files modified to carry prominent notices
 *     stating that you changed the files and the date of any change.
 *
 *     c) You must cause the whole of the work to be licensed at no
 *     charge to all third parties under the terms of this License.
 *
 *     d) If a facility in the modified Library refers to a function or a
 *     table of data to be supplied by an application program that uses
 *     the facility, other than as an argument passed when the facility
 *     is invoked, then you must make a good faith effort to ensure that,
 *     in the event an application does not supply such function or
 *     table, the facility still operates, and performs whatever part of
 *     its purpose remains meaningful.
 *
 *     (For example, a function in a library to compute square roots has
 *     a purpose that is entirely well-defined independent of the
 *     application.  Therefore, Subsection 2d requires that any
 *     application-supplied function or table used by this function must
 *     be optional: if the application does not supply it, the square
 *     root function must still compute square roots.)
 *
 * These requirements apply to the modified work as a whole.  If
 * identifiable sections of that work are not derived from the Library,
 * and can be reasonably considered independent and separate works in
 * themselves, then this License, and its terms, do not apply to those
 * sections when you distribute them as separate works.  But when you
 * distribute the same sections as part of a whole which is a work based
 * on the Library, the distribution of the whole must be on the terms of
 * this License, whose permissions for other licensees extend to the
 * entire whole, and thus to each and every part regardless of who wrote
 * it.
 *
 * Thus, it is not the intent of this section to claim rights or contest
 * your rights to work written entirely by you; rather, the intent is to
 * exercise the right to control the distribution of derivative or
 * collective works based on the Library.
 *
 * In addition, mere aggregation of another work not based on the Library
 * with the Library (or with a work based on the Library) on a volume of
 * a storage or distribution medium does not bring the other work under
 * the scope of this License.
 *
 *   3. You may opt to apply the terms of the ordinary GNU General Public
 * License instead of this License to a given copy of the Library.  To do
 * this, you must alter all the notices that refer to this License, so
 * that they refer to the ordinary GNU General Public License, version 2,
 * instead of to this License.  (If a newer version than version 2 of the
 * ordinary GNU General Public License has appeared, then you can specify
 * that version instead if you wish.)  Do not make any other change in
 * these notices.
 *
 *   Once this change is made in a given copy, it is irreversible for
 * that copy, so the ordinary GNU General Public License applies to all
 * subsequent copies and derivative works made from that copy.
 *
 *   This option is useful when you wish to copy part of the code of
 * the Library into a program that is not a library.
 *
 *   4. You may copy and distribute the Library (or a portion or
 * derivative of it, under Section 2) in object code or executable form
 * under the terms of Sections 1 and 2 above provided that you accompany
 * it with the complete corresponding machine-readable source code, which
 * must be distributed under the terms of Sections 1 and 2 above on a
 * medium customarily used for software interchange.
 *
 *   If distribution of object code is made by offering access to copy
 * from a designated place, then offering equivalent access to copy the
 * source code from the same place satisfies the requirement to
 * distribute the source code, even though third parties are not
 * compelled to copy the source along with the object code.
 *
 *   5. A program that contains no derivative of any portion of the
 * Library, but is designed to work with the Library by being compiled or
 * linked with it, is called a "work that uses the Library".  Such a
 * work, in isolation, is not a derivative work of the Library, and
 * therefore falls outside the scope of this License.
 *
 *   However, linking a "work that uses the Library" with the Library
 * creates an executable that is a derivative of the Library (because it
 * contains portions of the Library), rather than a "work that uses the
 * library".  The executable is therefore covered by this License.
 * Section 6 states terms for distribution of such executables.
 *
 *   When a "work that uses the Library" uses material from a header file
 * that is part of the Library, the object code for the work may be a
 * derivative work of the Library even though the source code is not.
 * Whether this is true is especially significant if the work can be
 * linked without the Library, or if the work is itself a library.  The
 * threshold for this to be true is not precisely defined by law.
 *
 *   If such an object file uses only numerical parameters, data
 * structure layouts and accessors, and small macros and small inline
 * functions (ten lines or less in length), then the use of the object
 * file is unrestricted, regardless of whether it is legally a derivative
 * work.  (Executables containing this object code plus portions of the
 * Library will still fall under Section 6.)
 *
 *   Otherwise, if the work is a derivative of the Library, you may
 * distribute the object code for the work under the terms of Section 6.
 * Any executables containing that work also fall under Section 6,
 * whether or not they are linked directly with the Library itself.
 *
 *   6. As an exception to the Sections above, you may also combine or
 * link a "work that uses the Library" with the Library to produce a
 * work containing portions of the Library, and distribute that work
 * under terms of your choice, provided that the terms permit
 * modification of the work for the customer's own use and reverse
 * engineering for debugging such modifications.
 *
 *   You must give prominent notice with each copy of the work that the
 * Library is used in it and that the Library and its use are covered by
 * this License.  You must supply a copy of this License.  If the work
 * during execution displays copyright notices, you must include the
 * copyright notice for the Library among them, as well as a reference
 * directing the user to the copy of this License.  Also, you must do one
 * of these things:
 *
 *     a) Accompany the work with the complete corresponding
 *     machine-readable source code for the Library including whatever
 *     changes were used in the work (which must be distributed under
 *     Sections 1 and 2 above); and, if the work is an executable linked
 *     with the Library, with the complete machine-readable "work that
 *     uses the Library", as object code and/or source code, so that the
 *     user can modify the Library and then relink to produce a modified
 *     executable containing the modified Library.  (It is understood
 *     that the user who changes the contents of definitions files in the
 *     Library will not necessarily be able to recompile the application
 *     to use the modified definitions.)
 *
 *     b) Use a suitable shared library mechanism for linking with the
 *     Library.  A suitable mechanism is one that (1) uses at run time a
 *     copy of the library already present on the user's computer system,
 *     rather than copying library functions into the executable, and (2)
 *     will operate properly with a modified version of the library, if
 *     the user installs one, as long as the modified version is
 *     interface-compatible with the version that the work was made with.
 *
 *     c) Accompany the work with a written offer, valid for at
 *     least three years, to give the same user the materials
 *     specified in Subsection 6a, above, for a charge no more
 *     than the cost of performing this distribution.
 *
 *     d) If distribution of the work is made by offering access to copy
 *     from a designated place, offer equivalent access to copy the above
 *     specified materials from the same place.
 *
 *     e) Verify that the user has already received a copy of these
 *     materials or that you have already sent this user a copy.
 *
 *   For an executable, the required form of the "work that uses the
 * Library" must include any data and utility programs needed for
 * reproducing the executable from it.  However, as a special exception,
 * the materials to be distributed need not include anything that is
 * normally distributed (in either source or binary form) with the major
 * components (compiler, kernel, and so on) of the operating system on
 * which the executable runs, unless that component itself accompanies
 * the executable.
 *
 *   It may happen that this requirement contradicts the license
 * restrictions of other proprietary libraries that do not normally
 * accompany the operating system.  Such a contradiction means you cannot
 * use both them and the Library together in an executable that you
 * distribute.
 *
 *   7. You may place library facilities that are a work based on the
 * Library side-by-side in a single library together with other library
 * facilities not covered by this License, and distribute such a combined
 * library, provided that the separate distribution of the work based on
 * the Library and of the other library facilities is otherwise
 * permitted, and provided that you do these two things:
 *
 *     a) Accompany the combined library with a copy of the same work
 *     based on the Library, uncombined with any other library
 *     facilities.  This must be distributed under the terms of the
 *     Sections above.
 *
 *     b) Give prominent notice with the combined library of the fact
 *     that part of it is a work based on the Library, and explaining
 *     where to find the accompanying uncombined form of the same work.
 *
 *   8. You may not copy, modify, sublicense, link with, or distribute
 * the Library except as expressly provided under this License.  Any
 * attempt otherwise to copy, modify, sublicense, link with, or
 * distribute the Library is void, and will automatically terminate your
 * rights under this License.  However, parties who have received copies,
 * or rights, from you under this License will not have their licenses
 * terminated so long as such parties remain in full compliance.
 *
 *   9. You are not required to accept this License, since you have not
 * signed it.  However, nothing else grants you permission to modify or
 * distribute the Library or its derivative works.  These actions are
 * prohibited by law if you do not accept this License.  Therefore, by
 * modifying or distributing the Library (or any work based on the
 * Library), you indicate your acceptance of this License to do so, and
 * all its terms and conditions for copying, distributing or modifying
 * the Library or works based on it.
 *
 *   10. Each time you redistribute the Library (or any work based on the
 * Library), the recipient automatically receives a license from the
 * original licensor to copy, distribute, link with or modify the Library
 * subject to these terms and conditions.  You may not impose any further
 * restrictions on the recipients' exercise of the rights granted herein.
 * You are not responsible for enforcing compliance by third parties with
 * this License.
 *
 *   11. If, as a consequence of a court judgment or allegation of patent
 * infringement or for any other reason (not limited to patent issues),
 * conditions are imposed on you (whether by court order, agreement or
 * otherwise) that contradict the conditions of this License, they do not
 * excuse you from the conditions of this License.  If you cannot
 * distribute so as to satisfy simultaneously your obligations under this
 * License and any other pertinent obligations, then as a consequence you
 * may not distribute the Library at all.  For example, if a patent
 * license would not permit royalty-free redistribution of the Library by
 * all those who receive copies directly or indirectly through you, then
 * the only way you could satisfy both it and this License would be to
 * refrain entirely from distribution of the Library.
 *
 * If any portion of this section is held invalid or unenforceable under any
 * particular circumstance, the balance of the section is intended to apply,
 * and the section as a whole is intended to apply in other circumstances.
 *
 * It is not the purpose of this section to induce you to infringe any
 * patents or other property right claims or to contest validity of any
 * such claims; this section has the sole purpose of protecting the
 * integrity of the free software distribution system which is
 * implemented by public license practices.  Many people have made
 * generous contributions to the wide range of software distributed
 * through that system in reliance on consistent application of that
 * system; it is up to the author/donor to decide if he or she is willing
 * to distribute software through any other system and a licensee cannot
 * impose that choice.
 *
 * This section is intended to make thoroughly clear what is believed to
 * be a consequence of the rest of this License.
 *
 *   12. If the distribution and/or use of the Library is restricted in
 * certain countries either by patents or by copyrighted interfaces, the
 * original copyright holder who places the Library under this License may add
 * an explicit geographical distribution limitation excluding those countries,
 * so that distribution is permitted only in or among countries not thus
 * excluded.  In such case, this License incorporates the limitation as if
 * written in the body of this License.
 *
 *   13. The Free Software Foundation may publish revised and/or new
 * versions of the Lesser General Public License from time to time.
 * Such new versions will be similar in spirit to the present version,
 * but may differ in detail to address new problems or concerns.
 *
 * Each version is given a distinguishing version number.  If the Library
 * specifies a version number of this License which applies to it and
 * "any later version", you have the option of following the terms and
 * conditions either of that version or of any later version published by
 * the Free Software Foundation.  If the Library does not specify a
 * license version number, you may choose any version ever published by
 * the Free Software Foundation.
 *
 *   14. If you wish to incorporate parts of the Library into other free
 * programs whose distribution conditions are incompatible with these,
 * write to the author to ask for permission.  For software which is
 * copyrighted by the Free Software Foundation, write to the Free
 * Software Foundation; we sometimes make exceptions for this.  Our
 * decision will be guided by the two goals of preserving the free status
 * of all derivatives of our free software and of promoting the sharing
 * and reuse of software generally.
 *
 *                             NO WARRANTY
 *
 *   15. BECAUSE THE LIBRARY IS LICENSED FREE OF CHARGE, THERE IS NO
 * WARRANTY FOR THE LIBRARY, TO THE EXTENT PERMITTED BY APPLICABLE LAW.
 * EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR
 * OTHER PARTIES PROVIDE THE LIBRARY "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE
 * LIBRARY IS WITH YOU.  SHOULD THE LIBRARY PROVE DEFECTIVE, YOU ASSUME
 * THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
 *
 *   16. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN
 * WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY
 * AND/OR REDISTRIBUTE THE LIBRARY AS PERMITTED ABOVE, BE LIABLE TO YOU
 * FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE
 * LIBRARY (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING
 * RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A
 * FAILURE OF THE LIBRARY TO OPERATE WITH ANY OTHER SOFTWARE), EVEN IF
 * SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGES.
 *
 *                      END OF TERMS AND CONDITIONS
 *
 *            How to Apply These Terms to Your New Libraries
 *
 *   If you develop a new library, and you want it to be of the greatest
 * possible use to the public, we recommend making it free software that
 * everyone can redistribute and change.  You can do so by permitting
 * redistribution under these terms (or, alternatively, under the terms of the
 * ordinary General Public License).
 *
 *   To apply these terms, attach the following notices to the library.  It is
 * safest to attach them to the start of each source file to most effectively
 * convey the exclusion of warranty; and each file should have at least the
 * "copyright" line and a pointer to where the full notice is found.
 *
 *     <one line to give the library's name and a brief idea of what it does.>
 *     Copyright (C) <year>  <name of author>
 *
 *     This library is free software; you can redistribute it and/or
 *     modify it under the terms of the GNU Lesser General Public
 *     License as published by the Free Software Foundation; either
 *     version 2.1 of the License, or (at your option) any later version.
 *
 *     This library is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *     Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public
 *     License along with this library; if not, write to the Free Software
 *     Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 *
 * Also add information on how to contact you by electronic and paper mail.
 *
 * You should also get your employer (if you work as a programmer) or your
 * school, if any, to sign a "copyright disclaimer" for the library, if
 * necessary.  Here is a sample; alter the names:
 *
 *   Yoyodyne, Inc., hereby disclaims all copyright interest in the
 *   library `Frob' (a library for tweaking knobs) written by James Random Hacker.
 *
 *   <signature of Ty Coon>, 1 April 1990
 *   Ty Coon, President of Vice
 *
 * That's all there is to it!
 *
 *
 * ---
 *
 * ffmpeg-faandct:
 *
 * Copyright (c) 2003 Michael Niedermayer <michaelni@gmx.at>
 * Copyright (c) 2003 Roman Shaposhnik
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 *
 * ---
 *
 * ffmepg (JPEG components):
 *
 * The authors make NO WARRANTY or representation, either express or implied,
 * with respect to this software, its quality, accuracy, merchantability, or
 * fitness for a particular purpose.  This software is provided "AS IS", and
 * you, its user, assume the entire risk as to its quality and accuracy.
 *
 * This software is copyright (C) 1991, 1992, Thomas G. Lane.
 * All Rights Reserved except as specified below.
 *
 * Permission is hereby granted to use, copy, modify, and distribute this
 * software (or portions thereof) for any purpose, without fee, subject to
 * these conditions:
 * (1) If any part of the source code for this software is distributed, then
 * this README file must be included, with this copyright and no-warranty
 * notice unaltered; and any additions, deletions, or changes to the original
 * files must be clearly indicated in accompanying documentation.
 * (2) If only executable code is distributed, then the accompanying
 * documentation must state that "this software is based in part on the work
 * of the Independent JPEG Group".
 * (3) Permission for use of this software is granted only if the user accepts
 * full responsibility for any undesirable consequences; the authors accept
 * NO LIABILITY for damages of any kind.
 *
 * These conditions apply to any software derived from or based on the IJG
 * code, not just to the unmodified library.  If you use our work, you ought
 * to acknowledge us.
 *
 * Permission is NOT granted for the use of any IJG author's name or company
 * name in advertising or publicity relating to this software or products
 * derived from it.  This software may be referred to only as "the Independent
 * JPEG Group's software".
 *
 * We specifically permit and encourage the use of this software as the basis
 * of commercial products, provided that all warranty or liability claims are
 * assumed by the product vendor.
 *
 *
 * ---
 *
 * ffmpeg-avsscanf:
 *
 * Copyright (c) 2005-2014 Rich Felker, et al.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 *
 * ---
 *
 * libopenh264:
 *
 * Copyright (c) 2013, Cisco Systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 *
 *
 * ---
 *
 * emscripten and musl:
 *
 * Copyright (c) 2010-2023 Emscripten authors, see AUTHORS file.
 * Copyright © 2005-2023 Rich Felker, et al.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * emcc (Emscripten gcc/clang-like replacement + linker emulating GNU ld) 3.1.71 (4171ae200b77a6c266b0e1ebb507d61d1ade3501)
 *
 */ var Wt = (() => {
    var me = import.meta.url;
    return async function (te = {}) {
      var W,
        r = te,
        N,
        ve,
        O = new Promise((e, a) => {
          ((N = e), (ve = a));
        }),
        _e = typeof window == "object",
        le = typeof WorkerGlobalScope < "u",
        L =
          typeof process == "object" &&
          typeof process.versions == "object" &&
          typeof process.versions.node == "string" &&
          process.type != "renderer";
      if (L) {
        const { createRequire: e } = await import("module");
        let a = import.meta.url;
        a.startsWith("data:") && (a = "/");
        var Pe = e(a);
      }
      let ue;
      (typeof ue > "u" &&
        (typeof LibAV == "object" && LibAV && LibAV.base
          ? (ue = LibAV.base + "/libav-6.5.7.1-h264-aac-mp3.wasm.mjs")
          : typeof self == "object" &&
            self &&
            self.location &&
            (ue = self.location.href)),
        typeof requestAnimation < "u" && (r.thisProgram = "./thisProgram"),
        typeof this_program == "string" && (r.thisProgram = this_program),
        (r.printErr = console.log.bind(console)),
        typeof _LOG > "u" && ((r.printErr = () => {}), (r.print = () => {})),
        (r.locateFile = function (e, a) {
          if (
            e.lastIndexOf(".wasm") === e.length - 5 &&
            e.indexOf("libav-") !== -1
          ) {
            if (r.wasmurl) return r.wasmurl;
            if (r.variant)
              return a + "libav-6.5.7.1-" + r.variant + ".wasm.wasm";
          }
          return a + e;
        }));
      var Le = Object.assign({}, r),
        Qr = [],
        cr = "./this.program",
        ir = (e, a) => {
          throw a;
        },
        Z = "";
      function $t(e) {
        return r.locateFile ? r.locateFile(e, Z) : Z + e;
      }
      var He, Ee;
      if (L) {
        var mr = Pe("fs"),
          lr = Pe("path");
        (import.meta.url.startsWith("data:") ||
          (Z = lr.dirname(Pe("url").fileURLToPath(import.meta.url)) + "/"),
          (Ee = (e) => {
            e = $e(e) ? new URL(e) : lr.normalize(e);
            var a = mr.readFileSync(e);
            return a;
          }),
          (He = (e, a = !0) => (
            (e = $e(e) ? new URL(e) : lr.normalize(e)),
            new Promise((t, _) => {
              mr.readFile(e, a ? void 0 : "utf8", (n, i) => {
                n ? _(n) : t(a ? i.buffer : i);
              });
            })
          )),
          !r.thisProgram &&
            process.argv.length > 1 &&
            (cr = process.argv[1].replace(/\\/g, "/")),
          (Qr = process.argv.slice(2)),
          (ir = (e, a) => {
            throw ((process.exitCode = e), a);
          }));
      } else
        (_e || le) &&
          (le
            ? (Z = self.location.href)
            : typeof document < "u" &&
              document.currentScript &&
              (Z = document.currentScript.src),
          ue && (Z = ue),
          Z.startsWith("blob:")
            ? (Z = "")
            : (Z = Z.substr(0, Z.replace(/[?#].*/, "").lastIndexOf("/") + 1)),
          le &&
            (Ee = (e) => {
              var a = new XMLHttpRequest();
              return (
                a.open("GET", e, !1),
                (a.responseType = "arraybuffer"),
                a.send(null),
                new Uint8Array(a.response)
              );
            }),
          (He = (e) =>
            $e(e)
              ? new Promise((a, t) => {
                  var _ = new XMLHttpRequest();
                  (_.open("GET", e, !0),
                    (_.responseType = "arraybuffer"),
                    (_.onload = () => {
                      if (_.status == 200 || (_.status == 0 && _.response)) {
                        a(_.response);
                        return;
                      }
                      t(_.status);
                    }),
                    (_.onerror = t),
                    _.send(null));
                })
              : fetch(e, { credentials: "same-origin" }).then((a) =>
                  a.ok
                    ? a.arrayBuffer()
                    : Promise.reject(new Error(a.status + " : " + a.url)),
                )));
      var ur = r.print || console.log.bind(console),
        ne = r.printErr || console.error.bind(console);
      (Object.assign(r, Le),
        (Le = null),
        r.arguments && (Qr = r.arguments),
        r.thisProgram && (cr = r.thisProgram));
      var Be = r.wasmBinary,
        qe,
        oe = !1,
        pe,
        $,
        Ae,
        Ve,
        Yt,
        V,
        z,
        Jt,
        ea;
      function ra() {
        var e = qe.buffer;
        ((r.HEAP8 = $ = new Int8Array(e)),
          (r.HEAP16 = Ve = new Int16Array(e)),
          (r.HEAPU8 = Ae = new Uint8Array(e)),
          (r.HEAPU16 = Yt = new Uint16Array(e)),
          (r.HEAP32 = V = new Int32Array(e)),
          (r.HEAPU32 = z = new Uint32Array(e)),
          (r.HEAPF32 = Jt = new Float32Array(e)),
          (r.HEAPF64 = ea = new Float64Array(e)));
      }
      var aa = [],
        ta = [],
        _a = [],
        Xt = !1;
      function Gt() {
        if (r.preRun)
          for (
            typeof r.preRun == "function" && (r.preRun = [r.preRun]);
            r.preRun.length;
          )
            Qt(r.preRun.shift());
        pr(aa);
      }
      function Kt() {
        ((Xt = !0),
          !r.noFSInit && !o.initialized && o.init(),
          (o.ignorePermissions = !1),
          ce.init(),
          pr(ta));
      }
      function Zt() {
        if (r.postRun)
          for (
            typeof r.postRun == "function" && (r.postRun = [r.postRun]);
            r.postRun.length;
          )
            r_(r.postRun.shift());
        pr(_a);
      }
      function Qt(e) {
        aa.unshift(e);
      }
      function e_(e) {
        ta.unshift(e);
      }
      function r_(e) {
        _a.unshift(e);
      }
      var de = 0,
        dr = null,
        De = null;
      function Lv(e) {
        return e;
      }
      function fr(e) {
        (de++, r.monitorRunDependencies?.(de));
      }
      function We(e) {
        if (
          (de--,
          r.monitorRunDependencies?.(de),
          de == 0 && (dr !== null && (clearInterval(dr), (dr = null)), De))
        ) {
          var a = De;
          ((De = null), a());
        }
      }
      function se(e) {
        (r.onAbort?.(e),
          (e = "Aborted(" + e + ")"),
          ne(e),
          (oe = !0),
          (e += ". Build with -sASSERTIONS for more info."));
        var a = new WebAssembly.RuntimeError(e);
        throw (ve(a), a);
      }
      var a_ = "data:application/octet-stream;base64,",
        na = (e) => e.startsWith(a_),
        $e = (e) => e.startsWith("file://");
      function t_() {
        if (r.locateFile) {
          var e = "libav-6.5.7.1-h264-aac-mp3.wasm.wasm";
          return na(e) ? e : $t(e);
        }
        return new URL("libav-6.5.7.1-h264-aac-mp3.wasm.wasm", import.meta.url)
          .href;
      }
      var vr;
      function oa(e) {
        if (e == vr && Be) return new Uint8Array(Be);
        if (Ee) return Ee(e);
        throw "both async and sync fetching of the wasm failed";
      }
      function __(e) {
        return Be
          ? Promise.resolve().then(() => oa(e))
          : He(e).then(
              (a) => new Uint8Array(a),
              () => oa(e),
            );
      }
      function sa(e, a, t) {
        return __(e)
          .then((_) => WebAssembly.instantiate(_, a))
          .then(t, (_) => {
            (ne(`failed to asynchronously prepare wasm: ${_}`), se(_));
          });
      }
      function n_(e, a, t, _) {
        return !e &&
          typeof WebAssembly.instantiateStreaming == "function" &&
          !na(a) &&
          !$e(a) &&
          !L &&
          typeof fetch == "function"
          ? fetch(a, { credentials: "same-origin" }).then((n) => {
              var i = WebAssembly.instantiateStreaming(n, t);
              return i.then(_, function (m) {
                return (
                  ne(`wasm streaming compile failed: ${m}`),
                  ne("falling back to ArrayBuffer instantiation"),
                  sa(a, t, _)
                );
              });
            })
          : sa(a, t, _);
      }
      function o_() {
        return { a: Hn };
      }
      function s_() {
        var e = o_();
        function a(_, n) {
          return (
            (s = _.exports),
            (s = h.instrumentWasmExports(s)),
            (qe = s.qa),
            ra(),
            (On = s.Zf),
            e_(s.ra),
            We("wasm-instantiate"),
            s
          );
        }
        fr("wasm-instantiate");
        function t(_) {
          a(_.instance);
        }
        if (r.instantiateWasm)
          try {
            return r.instantiateWasm(e, a);
          } catch (_) {
            (ne(`Module.instantiateWasm callback failed with error: ${_}`),
              ve(_));
          }
        return ((vr ??= t_()), n_(Be, vr, e, t).catch(ve), {});
      }
      var C,
        D,
        c_ = {
          853640: () => {
            X.trampolineRunning = !1;
          },
        };
      function i_() {
        throw new Error("Out of memory");
      }
      function m_(e) {
        return h.handleAsync(function () {
          return new Promise(function (a) {
            var t = r.fdName(e),
              _ = r.ff_reader_dev_waiters[t];
            (_ || (_ = r.ff_reader_dev_waiters[t] = []), _.push(a));
          });
        });
      }
      function l_() {
        r.initialized ||
          ((r.MAX_SIZE_TO_SKIP_ON_READ_FAILURE = 41943040),
          (r.FETCH_TIMEOUT = r.FETCH_TIMEOUT || 3e4),
          (r.READ_TIMEOUT = r.READ_TIMEOUT || 3e4),
          (r.INITIAL_RETRY_DELAY = r.INITIAL_RETRY_DELAY || 250),
          (r.libavjsJSFetch = {
            ctr: 1,
            fetches: {},
            pos: 0,
            read_failures: 0,
          }),
          (r.abortController = new AbortController()),
          (r.readFailureMap = new Map()),
          (r.initialized = !0));
      }
      function u_(e) {
        r.FETCH_TIMEOUT = e;
      }
      function d_(e) {
        r.READ_TIMEOUT = e;
      }
      function f_(e) {
        r.INITIAL_RETRY_DELAY = e;
      }
      function v_() {
        return r.returnCode || 0;
      }
      function p_() {
        const e = r.abortController;
        e
          ? e.abort("Download aborted by user")
          : ((r.abortController = new AbortController()),
            r.abortController.abort("Download aborted by user"));
      }
      function A_(e) {
        const a = r.libavjsJSFetch.fetches[e];
        a && ((a.buf = null), a.abortController.abort());
      }
      function V_(e) {
        r.bypassCache = e;
      }
      function b_(e, a, t, _, n) {
        return h.handleAsync(async function () {
          if (r.abortController.signal.aborted)
            return (console.log("Open aborted."), -1415072069);
          e = fe(e);
          let i = e.startsWith("jsfetch:") ? e.slice(8) : e;
          ((i = MutateUrl(i)),
            (e.endsWith(".m3u8") || e.endsWith(".mpd")) && (n = !1));
          let m = {},
            l;
          t
            ? ((l = a ? fe(a) : void 0), (m.Range = l))
            : n && (m.Range = "bytes=0-");
          const u = new AbortController(),
            f = AbortSignal.any([u.signal, r.abortController.signal]);
          let d;
          if (
            (n &&
              ((d = await FetchWithRetry(
                i,
                m,
                1,
                r.FETCH_TIMEOUT,
                r.INITIAL_RETRY_DELAY,
                r.bypassCache,
                f,
              )),
              d.ok || delete m.Range),
            !n || !d.ok)
          ) {
            if (
              ((d = await FetchWithRetry(
                i,
                m,
                MAX_FETCH_ATTEMPTS,
                r.FETCH_TIMEOUT,
                r.INITIAL_RETRY_DELAY,
                r.bypassCache,
                f,
              )),
              d.aborted)
            )
              return -1415072069;
            if (d.timeout) return ((r.returnCode = 1003), -541478725);
            if (d instanceof Error) return ((r.returnCode = 1001), -541478725);
            if (d.err_status)
              return ((r.returnCode = d.err_status), -541478725);
          }
          const A = _ || r.libavjsJSFetch.ctr++,
            p = (d.headers.get("accept-ranges") || "").toLowerCase(),
            v = d.headers.get("content-range"),
            b = (p && p == "bytes") || (d.status == 206 && v != null),
            y = parseInt(d.headers.get("content-length") || "0", 10);
          let w = 0;
          if (v) {
            const P = v.match(/bytes \d+-\d+\/(\d+)/);
            w = P ? parseInt(P[1]) : 0;
          } else if (y) {
            const P = r.libavjsJSFetch.fetches[A];
            (P ? P.total_size : 0) || (w = y);
          }
          const F = d.body.getReader();
          f.addEventListener("abort", async () => {
            try {
              await F.cancel();
            } catch {}
          });
          const M = l ? Number(l.match(/bytes=(\d+)/)?.[1] ?? 0) : 0;
          return (
            (r.libavjsJSFetch.fetches[A] = {
              abortController: u,
              url: e,
              reader: F,
              support_range: b,
              total_size: w,
              pos: M,
              first_read: !0,
              buf: null,
              rej: null,
            }),
            A
          );
        });
      }
      function h_(e, a, t) {
        return h.handleAsync(async function () {
          const _ = async function () {
            const n = r.libavjsJSFetch.fetches[e];
            if (r.abortController.signal.aborted || !n)
              return (console.log("Read aborted."), -1415072069);
            try {
              if (n.buf && n.buf.value && n.buf.value.length > 0) {
                const v = n.buf.value,
                  b = Math.min(t, v.length);
                return (
                  r.HEAPU8.set(v.subarray(0, b), a),
                  (n.buf.value = v.subarray(b)),
                  n.buf.value.length === 0 && (n.buf = null),
                  (n.pos += b),
                  b
                );
              }
              const i = new AbortController(),
                m = AbortSignal.any([i.signal, r.abortController.signal]),
                l = DoAbortableSleep(r.READ_TIMEOUT, m),
                u = n.reader.read(),
                f = await Promise.race([l, u]);
              if (
                (i.abort(),
                f.timeout_id && clearTimeout(f.timeout_id),
                f.aborted)
              )
                return -1415072069;
              if (f.timed_out)
                throw (
                  await n.reader.cancel(),
                  `Timed out after ${r.READ_TIMEOUT} ms.`
                );
              if (f.done) {
                const v = r.libavjsJSFetch.read_failures >= MAX_READ_ATTEMPTS,
                  b = n.support_range && n.total_size && n.pos < n.total_size;
                return !v && b ? -1e3 : -541478725;
              }
              r.libavjsJSFetch.read_failures = 0;
              let d = f.value;
              const A = r.readFailureMap.get(e);
              if (A > n.pos) {
                const v = A - n.pos;
                if (v >= d.length) return ((n.pos += d.length), _());
                ((d = d.subarray(v)), (n.pos += v), r.readFailureMap.delete(e));
              }
              if (n.first_read) {
                n.first_read = !1;
                const v = FindPngSliceIndex(d);
                v >= 0 && ((d = d.subarray(v)), (n.pos += v));
              }
              const p = Math.min(t, d.length);
              return (
                r.HEAPU8.set(d.subarray(0, p), a),
                d.length > p
                  ? (n.buf = { value: d.subarray(p) })
                  : (n.buf = null),
                (n.pos += p),
                p
              );
            } catch (i) {
              if (
                n.abortController.signal.aborted ||
                r.abortController.signal.aborted
              )
                return (console.log("Read aborted."), -1415072069);
              (console.log("Read error", i), r.libavjsJSFetch.read_failures++);
              const m = n.total_size > r.MAX_SIZE_TO_SKIP_ON_READ_FAILURE;
              if (
                r.libavjsJSFetch.read_failures >= MAX_READ_ATTEMPTS ||
                (!n.support_range && m)
              )
                return (
                  console.log(
                    `Cant retry. read_failures: ${r.libavjsJSFetch.read_failures}, too_big: ${m}`,
                  ),
                  (r.returnCode = 1002),
                  -541478725
                );
              const l =
                Math.pow(2, r.libavjsJSFetch.read_failures) *
                r.INITIAL_RETRY_DELAY;
              console.log(`Retrying read in ${l} ms`);
              const u = AbortSignal.any([
                  n.abortController.signal,
                  r.abortController.signal,
                ]),
                f = await DoAbortableSleep(l, u);
              if ((f.timeout_id && clearTimeout(f.timeout_id), f.aborted))
                return -1415072069;
              if (!n.support_range) {
                console.log(
                  `Retrying without range support, will skip ${n.pos} bytes`,
                );
                const d = r.readFailureMap.get(e) || 0,
                  A = Math.max(d, n.pos);
                return (r.readFailureMap.set(e, A), -1001);
              }
              return (
                console.log(`Retrying with range support from ${n.pos}`),
                -1e3
              );
            }
          };
          return _();
        });
      }
      function C_(e) {
        const a = r.libavjsJSFetch.fetches[e];
        return a && a.support_range ? 1 : 0;
      }
      function w_(e) {
        const a = r.libavjsJSFetch.fetches[e];
        return a ? a.total_size : 0;
      }
      function y_(e) {
        const a = r.libavjsJSFetch.fetches[e];
        return a ? a.pos : 0;
      }
      function g_(e) {
        const a = r.libavjsJSFetch.fetches[e];
        a &&
          (a.reader.cancel().catch((t) => {}),
          a.abortController.abort(),
          delete r.libavjsJSFetch.fetches[e]);
      }
      function x_(e, a, t, _, n) {
        r.HEAPU32[t / 4] = 0;
        var i = _ * 1e3 + n / 1e6 - new Date().getTime();
        return setTimeout(function () {
          ((r.HEAPU32[t / 4] = 1),
            r.ccall(
              "emfiberthreads_timeout_expiry",
              null,
              ["number", "number"],
              [e, a],
            ));
        }, i);
      }
      function k_(e) {
        clearTimeout(e);
      }
      class ca {
        name = "ExitStatus";
        constructor(a) {
          ((this.message = `Program terminated with exit(${a})`),
            (this.status = a));
        }
      }
      var pr = (e) => {
          for (; e.length > 0; ) e.shift()(r);
        },
        F_ = r.noExitRuntime || !0,
        H = (e) => Pa(e),
        B = () => Da(),
        ia = typeof TextDecoder < "u" ? new TextDecoder() : void 0,
        be = (e, a = 0, t = NaN) => {
          for (var _ = a + t, n = a; e[n] && !(n >= _); ) ++n;
          if (n - a > 16 && e.buffer && ia) return ia.decode(e.subarray(a, n));
          for (var i = ""; a < n; ) {
            var m = e[a++];
            if (!(m & 128)) {
              i += String.fromCharCode(m);
              continue;
            }
            var l = e[a++] & 63;
            if ((m & 224) == 192) {
              i += String.fromCharCode(((m & 31) << 6) | l);
              continue;
            }
            var u = e[a++] & 63;
            if (
              ((m & 240) == 224
                ? (m = ((m & 15) << 12) | (l << 6) | u)
                : (m = ((m & 7) << 18) | (l << 12) | (u << 6) | (e[a++] & 63)),
              m < 65536)
            )
              i += String.fromCharCode(m);
            else {
              var f = m - 65536;
              i += String.fromCharCode(55296 | (f >> 10), 56320 | (f & 1023));
            }
          }
          return i;
        },
        fe = (e, a) => (e ? be(Ae, e, a) : ""),
        P_ = (e, a, t, _) => {
          se(
            `Assertion failed: ${fe(e)}, at: ` +
              [
                a ? fe(a) : "unknown filename",
                t,
                _ ? fe(_) : "unknown function",
              ],
          );
        },
        j = {
          isAbs: (e) => e.charAt(0) === "/",
          splitPath: (e) => {
            var a =
              /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
            return a.exec(e).slice(1);
          },
          normalizeArray: (e, a) => {
            for (var t = 0, _ = e.length - 1; _ >= 0; _--) {
              var n = e[_];
              n === "."
                ? e.splice(_, 1)
                : n === ".."
                  ? (e.splice(_, 1), t++)
                  : t && (e.splice(_, 1), t--);
            }
            if (a) for (; t; t--) e.unshift("..");
            return e;
          },
          normalize: (e) => {
            var a = j.isAbs(e),
              t = e.substr(-1) === "/";
            return (
              (e = j
                .normalizeArray(
                  e.split("/").filter((_) => !!_),
                  !a,
                )
                .join("/")),
              !e && !a && (e = "."),
              e && t && (e += "/"),
              (a ? "/" : "") + e
            );
          },
          dirname: (e) => {
            var a = j.splitPath(e),
              t = a[0],
              _ = a[1];
            return !t && !_
              ? "."
              : (_ && (_ = _.substr(0, _.length - 1)), t + _);
          },
          basename: (e) => {
            if (e === "/") return "/";
            ((e = j.normalize(e)), (e = e.replace(/\/$/, "")));
            var a = e.lastIndexOf("/");
            return a === -1 ? e : e.substr(a + 1);
          },
          join: (...e) => j.normalize(e.join("/")),
          join2: (e, a) => j.normalize(e + "/" + a),
        },
        E_ = () => {
          if (
            typeof crypto == "object" &&
            typeof crypto.getRandomValues == "function"
          )
            return (_) => crypto.getRandomValues(_);
          if (L)
            try {
              var e = Pe("crypto"),
                a = e.randomFillSync;
              if (a) return (_) => e.randomFillSync(_);
              var t = e.randomBytes;
              return (_) => (_.set(t(_.byteLength)), _);
            } catch {}
          se("initRandomDevice");
        },
        ma = (e) => (ma = E_())(e),
        re = {
          resolve: (...e) => {
            for (var a = "", t = !1, _ = e.length - 1; _ >= -1 && !t; _--) {
              var n = _ >= 0 ? e[_] : o.cwd();
              if (typeof n != "string")
                throw new TypeError(
                  "Arguments to path.resolve must be strings",
                );
              if (!n) return "";
              ((a = n + "/" + a), (t = j.isAbs(n)));
            }
            return (
              (a = j
                .normalizeArray(
                  a.split("/").filter((i) => !!i),
                  !t,
                )
                .join("/")),
              (t ? "/" : "") + a || "."
            );
          },
          relative: (e, a) => {
            ((e = re.resolve(e).substr(1)), (a = re.resolve(a).substr(1)));
            function t(f) {
              for (var d = 0; d < f.length && f[d] === ""; d++);
              for (var A = f.length - 1; A >= 0 && f[A] === ""; A--);
              return d > A ? [] : f.slice(d, A - d + 1);
            }
            for (
              var _ = t(e.split("/")),
                n = t(a.split("/")),
                i = Math.min(_.length, n.length),
                m = i,
                l = 0;
              l < i;
              l++
            )
              if (_[l] !== n[l]) {
                m = l;
                break;
              }
            for (var u = [], l = m; l < _.length; l++) u.push("..");
            return ((u = u.concat(n.slice(m))), u.join("/"));
          },
        },
        Ar = [],
        Vr = (e) => {
          for (var a = 0, t = 0; t < e.length; ++t) {
            var _ = e.charCodeAt(t);
            _ <= 127
              ? a++
              : _ <= 2047
                ? (a += 2)
                : _ >= 55296 && _ <= 57343
                  ? ((a += 4), ++t)
                  : (a += 3);
          }
          return a;
        },
        br = (e, a, t, _) => {
          if (!(_ > 0)) return 0;
          for (var n = t, i = t + _ - 1, m = 0; m < e.length; ++m) {
            var l = e.charCodeAt(m);
            if (l >= 55296 && l <= 57343) {
              var u = e.charCodeAt(++m);
              l = (65536 + ((l & 1023) << 10)) | (u & 1023);
            }
            if (l <= 127) {
              if (t >= i) break;
              a[t++] = l;
            } else if (l <= 2047) {
              if (t + 1 >= i) break;
              ((a[t++] = 192 | (l >> 6)), (a[t++] = 128 | (l & 63)));
            } else if (l <= 65535) {
              if (t + 2 >= i) break;
              ((a[t++] = 224 | (l >> 12)),
                (a[t++] = 128 | ((l >> 6) & 63)),
                (a[t++] = 128 | (l & 63)));
            } else {
              if (t + 3 >= i) break;
              ((a[t++] = 240 | (l >> 18)),
                (a[t++] = 128 | ((l >> 12) & 63)),
                (a[t++] = 128 | ((l >> 6) & 63)),
                (a[t++] = 128 | (l & 63)));
            }
          }
          return ((a[t] = 0), t - n);
        };
      function la(e, a, t) {
        var _ = t > 0 ? t : Vr(e) + 1,
          n = new Array(_),
          i = br(e, n, 0, n.length);
        return (a && (n.length = i), n);
      }
      var D_ = () => {
          if (!Ar.length) {
            var e = null;
            if (L) {
              var a = 256,
                t = Buffer.alloc(a),
                _ = 0,
                n = process.stdin.fd;
              try {
                _ = mr.readSync(n, t, 0, a);
              } catch (i) {
                if (i.toString().includes("EOF")) _ = 0;
                else throw i;
              }
              _ > 0 && (e = t.slice(0, _).toString("utf-8"));
            } else
              typeof window < "u" &&
                typeof window.prompt == "function" &&
                ((e = window.prompt("Input: ")),
                e !== null &&
                  (e += `
`));
            if (!e) return null;
            Ar = la(e, !0);
          }
          return Ar.shift();
        },
        ce = {
          ttys: [],
          init() {},
          shutdown() {},
          register(e, a) {
            ((ce.ttys[e] = { input: [], output: [], ops: a }),
              o.registerDevice(e, ce.stream_ops));
          },
          stream_ops: {
            open(e) {
              var a = ce.ttys[e.node.rdev];
              if (!a) throw new o.ErrnoError(43);
              ((e.tty = a), (e.seekable = !1));
            },
            close(e) {
              e.tty.ops.fsync(e.tty);
            },
            fsync(e) {
              e.tty.ops.fsync(e.tty);
            },
            read(e, a, t, _, n) {
              if (!e.tty || !e.tty.ops.get_char) throw new o.ErrnoError(60);
              for (var i = 0, m = 0; m < _; m++) {
                var l;
                try {
                  l = e.tty.ops.get_char(e.tty);
                } catch {
                  throw new o.ErrnoError(29);
                }
                if (l === void 0 && i === 0) throw new o.ErrnoError(6);
                if (l == null) break;
                (i++, (a[t + m] = l));
              }
              return (i && (e.node.timestamp = Date.now()), i);
            },
            write(e, a, t, _, n) {
              if (!e.tty || !e.tty.ops.put_char) throw new o.ErrnoError(60);
              try {
                for (var i = 0; i < _; i++) e.tty.ops.put_char(e.tty, a[t + i]);
              } catch {
                throw new o.ErrnoError(29);
              }
              return (_ && (e.node.timestamp = Date.now()), i);
            },
          },
          default_tty_ops: {
            get_char(e) {
              return D_();
            },
            put_char(e, a) {
              a === null || a === 10
                ? (ur(be(e.output)), (e.output = []))
                : a != 0 && e.output.push(a);
            },
            fsync(e) {
              e.output &&
                e.output.length > 0 &&
                (ur(be(e.output)), (e.output = []));
            },
            ioctl_tcgets(e) {
              return {
                c_iflag: 25856,
                c_oflag: 5,
                c_cflag: 191,
                c_lflag: 35387,
                c_cc: [
                  3, 28, 127, 21, 4, 0, 1, 0, 17, 19, 26, 0, 18, 15, 23, 22, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                ],
              };
            },
            ioctl_tcsets(e, a, t) {
              return 0;
            },
            ioctl_tiocgwinsz(e) {
              return [24, 80];
            },
          },
          default_tty1_ops: {
            put_char(e, a) {
              a === null || a === 10
                ? (ne(be(e.output)), (e.output = []))
                : a != 0 && e.output.push(a);
            },
            fsync(e) {
              e.output &&
                e.output.length > 0 &&
                (ne(be(e.output)), (e.output = []));
            },
          },
        },
        S_ = (e, a) => Math.ceil(e / a) * a,
        ua = (e) => {
          se();
        },
        x = {
          ops_table: null,
          mount(e) {
            return x.createNode(null, "/", 16895, 0);
          },
          createNode(e, a, t, _) {
            if (o.isBlkdev(t) || o.isFIFO(t)) throw new o.ErrnoError(63);
            x.ops_table ||= {
              dir: {
                node: {
                  getattr: x.node_ops.getattr,
                  setattr: x.node_ops.setattr,
                  lookup: x.node_ops.lookup,
                  mknod: x.node_ops.mknod,
                  rename: x.node_ops.rename,
                  unlink: x.node_ops.unlink,
                  rmdir: x.node_ops.rmdir,
                  readdir: x.node_ops.readdir,
                  symlink: x.node_ops.symlink,
                },
                stream: { llseek: x.stream_ops.llseek },
              },
              file: {
                node: {
                  getattr: x.node_ops.getattr,
                  setattr: x.node_ops.setattr,
                },
                stream: {
                  llseek: x.stream_ops.llseek,
                  read: x.stream_ops.read,
                  write: x.stream_ops.write,
                  allocate: x.stream_ops.allocate,
                  mmap: x.stream_ops.mmap,
                  msync: x.stream_ops.msync,
                },
              },
              link: {
                node: {
                  getattr: x.node_ops.getattr,
                  setattr: x.node_ops.setattr,
                  readlink: x.node_ops.readlink,
                },
                stream: {},
              },
              chrdev: {
                node: {
                  getattr: x.node_ops.getattr,
                  setattr: x.node_ops.setattr,
                },
                stream: o.chrdev_stream_ops,
              },
            };
            var n = o.createNode(e, a, t, _);
            return (
              o.isDir(n.mode)
                ? ((n.node_ops = x.ops_table.dir.node),
                  (n.stream_ops = x.ops_table.dir.stream),
                  (n.contents = {}))
                : o.isFile(n.mode)
                  ? ((n.node_ops = x.ops_table.file.node),
                    (n.stream_ops = x.ops_table.file.stream),
                    (n.usedBytes = 0),
                    (n.contents = null))
                  : o.isLink(n.mode)
                    ? ((n.node_ops = x.ops_table.link.node),
                      (n.stream_ops = x.ops_table.link.stream))
                    : o.isChrdev(n.mode) &&
                      ((n.node_ops = x.ops_table.chrdev.node),
                      (n.stream_ops = x.ops_table.chrdev.stream)),
              (n.timestamp = Date.now()),
              e && ((e.contents[a] = n), (e.timestamp = n.timestamp)),
              n
            );
          },
          getFileDataAsTypedArray(e) {
            return e.contents
              ? e.contents.subarray
                ? e.contents.subarray(0, e.usedBytes)
                : new Uint8Array(e.contents)
              : new Uint8Array(0);
          },
          expandFileStorage(e, a) {
            var t = e.contents ? e.contents.length : 0;
            if (!(t >= a)) {
              var _ = 1024 * 1024;
              ((a = Math.max(a, (t * (t < _ ? 2 : 1.125)) >>> 0)),
                t != 0 && (a = Math.max(a, 256)));
              var n = e.contents;
              ((e.contents = new Uint8Array(a)),
                e.usedBytes > 0 &&
                  e.contents.set(n.subarray(0, e.usedBytes), 0));
            }
          },
          resizeFileStorage(e, a) {
            if (e.usedBytes != a)
              if (a == 0) ((e.contents = null), (e.usedBytes = 0));
              else {
                var t = e.contents;
                ((e.contents = new Uint8Array(a)),
                  t && e.contents.set(t.subarray(0, Math.min(a, e.usedBytes))),
                  (e.usedBytes = a));
              }
          },
          node_ops: {
            getattr(e) {
              var a = {};
              return (
                (a.dev = o.isChrdev(e.mode) ? e.id : 1),
                (a.ino = e.id),
                (a.mode = e.mode),
                (a.nlink = 1),
                (a.uid = 0),
                (a.gid = 0),
                (a.rdev = e.rdev),
                o.isDir(e.mode)
                  ? (a.size = 4096)
                  : o.isFile(e.mode)
                    ? (a.size = e.usedBytes)
                    : o.isLink(e.mode)
                      ? (a.size = e.link.length)
                      : (a.size = 0),
                (a.atime = new Date(e.timestamp)),
                (a.mtime = new Date(e.timestamp)),
                (a.ctime = new Date(e.timestamp)),
                (a.blksize = 4096),
                (a.blocks = Math.ceil(a.size / a.blksize)),
                a
              );
            },
            setattr(e, a) {
              (a.mode !== void 0 && (e.mode = a.mode),
                a.timestamp !== void 0 && (e.timestamp = a.timestamp),
                a.size !== void 0 && x.resizeFileStorage(e, a.size));
            },
            lookup(e, a) {
              throw o.genericErrors[44];
            },
            mknod(e, a, t, _) {
              return x.createNode(e, a, t, _);
            },
            rename(e, a, t) {
              if (o.isDir(e.mode)) {
                var _;
                try {
                  _ = o.lookupNode(a, t);
                } catch {}
                if (_) for (var n in _.contents) throw new o.ErrnoError(55);
              }
              (delete e.parent.contents[e.name],
                (e.parent.timestamp = Date.now()),
                (e.name = t),
                (a.contents[t] = e),
                (a.timestamp = e.parent.timestamp));
            },
            unlink(e, a) {
              (delete e.contents[a], (e.timestamp = Date.now()));
            },
            rmdir(e, a) {
              var t = o.lookupNode(e, a);
              for (var _ in t.contents) throw new o.ErrnoError(55);
              (delete e.contents[a], (e.timestamp = Date.now()));
            },
            readdir(e) {
              var a = [".", ".."];
              for (var t of Object.keys(e.contents)) a.push(t);
              return a;
            },
            symlink(e, a, t) {
              var _ = x.createNode(e, a, 41471, 0);
              return ((_.link = t), _);
            },
            readlink(e) {
              if (!o.isLink(e.mode)) throw new o.ErrnoError(28);
              return e.link;
            },
          },
          stream_ops: {
            read(e, a, t, _, n) {
              var i = e.node.contents;
              if (n >= e.node.usedBytes) return 0;
              var m = Math.min(e.node.usedBytes - n, _);
              if (m > 8 && i.subarray) a.set(i.subarray(n, n + m), t);
              else for (var l = 0; l < m; l++) a[t + l] = i[n + l];
              return m;
            },
            write(e, a, t, _, n, i) {
              if ((a.buffer === $.buffer && (i = !1), !_)) return 0;
              var m = e.node;
              if (
                ((m.timestamp = Date.now()),
                a.subarray && (!m.contents || m.contents.subarray))
              ) {
                if (i)
                  return (
                    (m.contents = a.subarray(t, t + _)),
                    (m.usedBytes = _),
                    _
                  );
                if (m.usedBytes === 0 && n === 0)
                  return (
                    (m.contents = a.slice(t, t + _)),
                    (m.usedBytes = _),
                    _
                  );
                if (n + _ <= m.usedBytes)
                  return (m.contents.set(a.subarray(t, t + _), n), _);
              }
              if (
                (x.expandFileStorage(m, n + _),
                m.contents.subarray && a.subarray)
              )
                m.contents.set(a.subarray(t, t + _), n);
              else for (var l = 0; l < _; l++) m.contents[n + l] = a[t + l];
              return ((m.usedBytes = Math.max(m.usedBytes, n + _)), _);
            },
            llseek(e, a, t) {
              var _ = a;
              if (
                (t === 1
                  ? (_ += e.position)
                  : t === 2 && o.isFile(e.node.mode) && (_ += e.node.usedBytes),
                _ < 0)
              )
                throw new o.ErrnoError(28);
              return _;
            },
            allocate(e, a, t) {
              (x.expandFileStorage(e.node, a + t),
                (e.node.usedBytes = Math.max(e.node.usedBytes, a + t)));
            },
            mmap(e, a, t, _, n) {
              if (!o.isFile(e.node.mode)) throw new o.ErrnoError(43);
              var i,
                m,
                l = e.node.contents;
              if (!(n & 2) && l && l.buffer === $.buffer)
                ((m = !1), (i = l.byteOffset));
              else {
                if (((m = !0), (i = ua(a)), !i)) throw new o.ErrnoError(48);
                l &&
                  ((t > 0 || t + a < l.length) &&
                    (l.subarray
                      ? (l = l.subarray(t, t + a))
                      : (l = Array.prototype.slice.call(l, t, t + a))),
                  $.set(l, i));
              }
              return { ptr: i, allocated: m };
            },
            msync(e, a, t, _, n) {
              return (x.stream_ops.write(e, a, 0, _, t, !1), 0);
            },
          },
        },
        j_ = (e, a, t, _) => {
          var n = _ ? "" : `al ${e}`;
          (He(e).then(
            (i) => {
              (a(new Uint8Array(i)), n && We(n));
            },
            (i) => {
              if (t) t();
              else throw `Loading data file "${e}" failed.`;
            },
          ),
            n && fr(n));
        },
        T_ = (e, a, t, _, n, i) => {
          o.createDataFile(e, a, t, _, n, i);
        },
        z_ = r.preloadPlugins || [],
        M_ = (e, a, t, _) => {
          typeof Browser < "u" && Browser.init();
          var n = !1;
          return (
            z_.forEach((i) => {
              n || (i.canHandle(a) && (i.handle(e, a, t, _), (n = !0)));
            }),
            n
          );
        },
        R_ = (e, a, t, _, n, i, m, l, u, f) => {
          var d = a ? re.resolve(j.join2(e, a)) : e,
            A = `cp ${d}`;
          function p(v) {
            function b(y) {
              (f?.(), l || T_(e, a, y, _, n, u), i?.(), We(A));
            }
            M_(v, d, b, () => {
              (m?.(), We(A));
            }) || b(v);
          }
          (fr(A), typeof t == "string" ? j_(t, p, m) : p(t));
        },
        I_ = (e) => {
          var a = { r: 0, "r+": 2, w: 577, "w+": 578, a: 1089, "a+": 1090 },
            t = a[e];
          if (typeof t > "u") throw new Error(`Unknown file open mode: ${e}`);
          return t;
        },
        hr = (e, a) => {
          var t = 0;
          return (e && (t |= 365), a && (t |= 146), t);
        },
        o = {
          root: null,
          mounts: [],
          devices: {},
          streams: [],
          nextInode: 1,
          nameTable: null,
          currentPath: "/",
          initialized: !1,
          ignorePermissions: !0,
          ErrnoError: class {
            name = "ErrnoError";
            constructor(e) {
              this.errno = e;
            }
          },
          genericErrors: {},
          filesystems: null,
          syncFSRequests: 0,
          readFiles: {},
          FSStream: class {
            shared = {};
            get object() {
              return this.node;
            }
            set object(e) {
              this.node = e;
            }
            get isRead() {
              return (this.flags & 2097155) !== 1;
            }
            get isWrite() {
              return (this.flags & 2097155) !== 0;
            }
            get isAppend() {
              return this.flags & 1024;
            }
            get flags() {
              return this.shared.flags;
            }
            set flags(e) {
              this.shared.flags = e;
            }
            get position() {
              return this.shared.position;
            }
            set position(e) {
              this.shared.position = e;
            }
          },
          FSNode: class {
            node_ops = {};
            stream_ops = {};
            readMode = 365;
            writeMode = 146;
            mounted = null;
            constructor(e, a, t, _) {
              (e || (e = this),
                (this.parent = e),
                (this.mount = e.mount),
                (this.id = o.nextInode++),
                (this.name = a),
                (this.mode = t),
                (this.rdev = _));
            }
            get read() {
              return (this.mode & this.readMode) === this.readMode;
            }
            set read(e) {
              e ? (this.mode |= this.readMode) : (this.mode &= ~this.readMode);
            }
            get write() {
              return (this.mode & this.writeMode) === this.writeMode;
            }
            set write(e) {
              e
                ? (this.mode |= this.writeMode)
                : (this.mode &= ~this.writeMode);
            }
            get isFolder() {
              return o.isDir(this.mode);
            }
            get isDevice() {
              return o.isChrdev(this.mode);
            }
          },
          lookupPath(e, a = {}) {
            if (((e = re.resolve(e)), !e)) return { path: "", node: null };
            var t = { follow_mount: !0, recurse_count: 0 };
            if (((a = Object.assign(t, a)), a.recurse_count > 8))
              throw new o.ErrnoError(32);
            for (
              var _ = e.split("/").filter((A) => !!A),
                n = o.root,
                i = "/",
                m = 0;
              m < _.length;
              m++
            ) {
              var l = m === _.length - 1;
              if (l && a.parent) break;
              if (
                ((n = o.lookupNode(n, _[m])),
                (i = j.join2(i, _[m])),
                o.isMountpoint(n) &&
                  (!l || (l && a.follow_mount)) &&
                  (n = n.mounted.root),
                !l || a.follow)
              )
                for (var u = 0; o.isLink(n.mode); ) {
                  var f = o.readlink(i);
                  i = re.resolve(j.dirname(i), f);
                  var d = o.lookupPath(i, {
                    recurse_count: a.recurse_count + 1,
                  });
                  if (((n = d.node), u++ > 40)) throw new o.ErrnoError(32);
                }
            }
            return { path: i, node: n };
          },
          getPath(e) {
            for (var a; ; ) {
              if (o.isRoot(e)) {
                var t = e.mount.mountpoint;
                return a ? (t[t.length - 1] !== "/" ? `${t}/${a}` : t + a) : t;
              }
              ((a = a ? `${e.name}/${a}` : e.name), (e = e.parent));
            }
          },
          hashName(e, a) {
            for (var t = 0, _ = 0; _ < a.length; _++)
              t = ((t << 5) - t + a.charCodeAt(_)) | 0;
            return ((e + t) >>> 0) % o.nameTable.length;
          },
          hashAddNode(e) {
            var a = o.hashName(e.parent.id, e.name);
            ((e.name_next = o.nameTable[a]), (o.nameTable[a] = e));
          },
          hashRemoveNode(e) {
            var a = o.hashName(e.parent.id, e.name);
            if (o.nameTable[a] === e) o.nameTable[a] = e.name_next;
            else
              for (var t = o.nameTable[a]; t; ) {
                if (t.name_next === e) {
                  t.name_next = e.name_next;
                  break;
                }
                t = t.name_next;
              }
          },
          lookupNode(e, a) {
            var t = o.mayLookup(e);
            if (t) throw new o.ErrnoError(t);
            for (
              var _ = o.hashName(e.id, a), n = o.nameTable[_];
              n;
              n = n.name_next
            ) {
              var i = n.name;
              if (n.parent.id === e.id && i === a) return n;
            }
            return o.lookup(e, a);
          },
          createNode(e, a, t, _) {
            var n = new o.FSNode(e, a, t, _);
            return (o.hashAddNode(n), n);
          },
          destroyNode(e) {
            o.hashRemoveNode(e);
          },
          isRoot(e) {
            return e === e.parent;
          },
          isMountpoint(e) {
            return !!e.mounted;
          },
          isFile(e) {
            return (e & 61440) === 32768;
          },
          isDir(e) {
            return (e & 61440) === 16384;
          },
          isLink(e) {
            return (e & 61440) === 40960;
          },
          isChrdev(e) {
            return (e & 61440) === 8192;
          },
          isBlkdev(e) {
            return (e & 61440) === 24576;
          },
          isFIFO(e) {
            return (e & 61440) === 4096;
          },
          isSocket(e) {
            return (e & 49152) === 49152;
          },
          flagsToPermissionString(e) {
            var a = ["r", "w", "rw"][e & 3];
            return (e & 512 && (a += "w"), a);
          },
          nodePermissions(e, a) {
            return o.ignorePermissions
              ? 0
              : (a.includes("r") && !(e.mode & 292)) ||
                  (a.includes("w") && !(e.mode & 146)) ||
                  (a.includes("x") && !(e.mode & 73))
                ? 2
                : 0;
          },
          mayLookup(e) {
            if (!o.isDir(e.mode)) return 54;
            var a = o.nodePermissions(e, "x");
            return a || (e.node_ops.lookup ? 0 : 2);
          },
          mayCreate(e, a) {
            try {
              var t = o.lookupNode(e, a);
              return 20;
            } catch {}
            return o.nodePermissions(e, "wx");
          },
          mayDelete(e, a, t) {
            var _;
            try {
              _ = o.lookupNode(e, a);
            } catch (i) {
              return i.errno;
            }
            var n = o.nodePermissions(e, "wx");
            if (n) return n;
            if (t) {
              if (!o.isDir(_.mode)) return 54;
              if (o.isRoot(_) || o.getPath(_) === o.cwd()) return 10;
            } else if (o.isDir(_.mode)) return 31;
            return 0;
          },
          mayOpen(e, a) {
            return e
              ? o.isLink(e.mode)
                ? 32
                : o.isDir(e.mode) &&
                    (o.flagsToPermissionString(a) !== "r" || a & 512)
                  ? 31
                  : o.nodePermissions(e, o.flagsToPermissionString(a))
              : 44;
          },
          MAX_OPEN_FDS: 4096,
          nextfd() {
            for (var e = 0; e <= o.MAX_OPEN_FDS; e++)
              if (!o.streams[e]) return e;
            throw new o.ErrnoError(33);
          },
          getStreamChecked(e) {
            var a = o.getStream(e);
            if (!a) throw new o.ErrnoError(8);
            return a;
          },
          getStream: (e) => o.streams[e],
          createStream(e, a = -1) {
            return (
              (e = Object.assign(new o.FSStream(), e)),
              a == -1 && (a = o.nextfd()),
              (e.fd = a),
              (o.streams[a] = e),
              e
            );
          },
          closeStream(e) {
            o.streams[e] = null;
          },
          dupStream(e, a = -1) {
            var t = o.createStream(e, a);
            return (t.stream_ops?.dup?.(t), t);
          },
          chrdev_stream_ops: {
            open(e) {
              var a = o.getDevice(e.node.rdev);
              ((e.stream_ops = a.stream_ops), e.stream_ops.open?.(e));
            },
            llseek() {
              throw new o.ErrnoError(70);
            },
          },
          major: (e) => e >> 8,
          minor: (e) => e & 255,
          makedev: (e, a) => (e << 8) | a,
          registerDevice(e, a) {
            o.devices[e] = { stream_ops: a };
          },
          getDevice: (e) => o.devices[e],
          getMounts(e) {
            for (var a = [], t = [e]; t.length; ) {
              var _ = t.pop();
              (a.push(_), t.push(..._.mounts));
            }
            return a;
          },
          syncfs(e, a) {
            (typeof e == "function" && ((a = e), (e = !1)),
              o.syncFSRequests++,
              o.syncFSRequests > 1 &&
                ne(
                  `warning: ${o.syncFSRequests} FS.syncfs operations in flight at once, probably just doing extra work`,
                ));
            var t = o.getMounts(o.root.mount),
              _ = 0;
            function n(m) {
              return (o.syncFSRequests--, a(m));
            }
            function i(m) {
              if (m) return i.errored ? void 0 : ((i.errored = !0), n(m));
              ++_ >= t.length && n(null);
            }
            t.forEach((m) => {
              if (!m.type.syncfs) return i(null);
              m.type.syncfs(m, e, i);
            });
          },
          mount(e, a, t) {
            var _ = t === "/",
              n = !t,
              i;
            if (_ && o.root) throw new o.ErrnoError(10);
            if (!_ && !n) {
              var m = o.lookupPath(t, { follow_mount: !1 });
              if (((t = m.path), (i = m.node), o.isMountpoint(i)))
                throw new o.ErrnoError(10);
              if (!o.isDir(i.mode)) throw new o.ErrnoError(54);
            }
            var l = { type: e, opts: a, mountpoint: t, mounts: [] },
              u = e.mount(l);
            return (
              (u.mount = l),
              (l.root = u),
              _
                ? (o.root = u)
                : i && ((i.mounted = l), i.mount && i.mount.mounts.push(l)),
              u
            );
          },
          unmount(e) {
            var a = o.lookupPath(e, { follow_mount: !1 });
            if (!o.isMountpoint(a.node)) throw new o.ErrnoError(28);
            var t = a.node,
              _ = t.mounted,
              n = o.getMounts(_);
            (Object.keys(o.nameTable).forEach((m) => {
              for (var l = o.nameTable[m]; l; ) {
                var u = l.name_next;
                (n.includes(l.mount) && o.destroyNode(l), (l = u));
              }
            }),
              (t.mounted = null));
            var i = t.mount.mounts.indexOf(_);
            t.mount.mounts.splice(i, 1);
          },
          lookup(e, a) {
            return e.node_ops.lookup(e, a);
          },
          mknod(e, a, t) {
            var _ = o.lookupPath(e, { parent: !0 }),
              n = _.node,
              i = j.basename(e);
            if (!i || i === "." || i === "..") throw new o.ErrnoError(28);
            var m = o.mayCreate(n, i);
            if (m) throw new o.ErrnoError(m);
            if (!n.node_ops.mknod) throw new o.ErrnoError(63);
            return n.node_ops.mknod(n, i, a, t);
          },
          create(e, a) {
            return (
              (a = a !== void 0 ? a : 438),
              (a &= 4095),
              (a |= 32768),
              o.mknod(e, a, 0)
            );
          },
          mkdir(e, a) {
            return (
              (a = a !== void 0 ? a : 511),
              (a &= 1023),
              (a |= 16384),
              o.mknod(e, a, 0)
            );
          },
          mkdirTree(e, a) {
            for (var t = e.split("/"), _ = "", n = 0; n < t.length; ++n)
              if (t[n]) {
                _ += "/" + t[n];
                try {
                  o.mkdir(_, a);
                } catch (i) {
                  if (i.errno != 20) throw i;
                }
              }
          },
          mkdev(e, a, t) {
            return (
              typeof t > "u" && ((t = a), (a = 438)),
              (a |= 8192),
              o.mknod(e, a, t)
            );
          },
          symlink(e, a) {
            if (!re.resolve(e)) throw new o.ErrnoError(44);
            var t = o.lookupPath(a, { parent: !0 }),
              _ = t.node;
            if (!_) throw new o.ErrnoError(44);
            var n = j.basename(a),
              i = o.mayCreate(_, n);
            if (i) throw new o.ErrnoError(i);
            if (!_.node_ops.symlink) throw new o.ErrnoError(63);
            return _.node_ops.symlink(_, n, e);
          },
          rename(e, a) {
            var t = j.dirname(e),
              _ = j.dirname(a),
              n = j.basename(e),
              i = j.basename(a),
              m,
              l,
              u;
            if (
              ((m = o.lookupPath(e, { parent: !0 })),
              (l = m.node),
              (m = o.lookupPath(a, { parent: !0 })),
              (u = m.node),
              !l || !u)
            )
              throw new o.ErrnoError(44);
            if (l.mount !== u.mount) throw new o.ErrnoError(75);
            var f = o.lookupNode(l, n),
              d = re.relative(e, _);
            if (d.charAt(0) !== ".") throw new o.ErrnoError(28);
            if (((d = re.relative(a, t)), d.charAt(0) !== "."))
              throw new o.ErrnoError(55);
            var A;
            try {
              A = o.lookupNode(u, i);
            } catch {}
            if (f !== A) {
              var p = o.isDir(f.mode),
                v = o.mayDelete(l, n, p);
              if (v) throw new o.ErrnoError(v);
              if (((v = A ? o.mayDelete(u, i, p) : o.mayCreate(u, i)), v))
                throw new o.ErrnoError(v);
              if (!l.node_ops.rename) throw new o.ErrnoError(63);
              if (o.isMountpoint(f) || (A && o.isMountpoint(A)))
                throw new o.ErrnoError(10);
              if (u !== l && ((v = o.nodePermissions(l, "w")), v))
                throw new o.ErrnoError(v);
              o.hashRemoveNode(f);
              try {
                (l.node_ops.rename(f, u, i), (f.parent = u));
              } catch (b) {
                throw b;
              } finally {
                o.hashAddNode(f);
              }
            }
          },
          rmdir(e) {
            var a = o.lookupPath(e, { parent: !0 }),
              t = a.node,
              _ = j.basename(e),
              n = o.lookupNode(t, _),
              i = o.mayDelete(t, _, !0);
            if (i) throw new o.ErrnoError(i);
            if (!t.node_ops.rmdir) throw new o.ErrnoError(63);
            if (o.isMountpoint(n)) throw new o.ErrnoError(10);
            (t.node_ops.rmdir(t, _), o.destroyNode(n));
          },
          readdir(e) {
            var a = o.lookupPath(e, { follow: !0 }),
              t = a.node;
            if (!t.node_ops.readdir) throw new o.ErrnoError(54);
            return t.node_ops.readdir(t);
          },
          unlink(e) {
            var a = o.lookupPath(e, { parent: !0 }),
              t = a.node;
            if (!t) throw new o.ErrnoError(44);
            var _ = j.basename(e),
              n = o.lookupNode(t, _),
              i = o.mayDelete(t, _, !1);
            if (i) throw new o.ErrnoError(i);
            if (!t.node_ops.unlink) throw new o.ErrnoError(63);
            if (o.isMountpoint(n)) throw new o.ErrnoError(10);
            (t.node_ops.unlink(t, _), o.destroyNode(n));
          },
          readlink(e) {
            var a = o.lookupPath(e),
              t = a.node;
            if (!t) throw new o.ErrnoError(44);
            if (!t.node_ops.readlink) throw new o.ErrnoError(28);
            return re.resolve(o.getPath(t.parent), t.node_ops.readlink(t));
          },
          stat(e, a) {
            var t = o.lookupPath(e, { follow: !a }),
              _ = t.node;
            if (!_) throw new o.ErrnoError(44);
            if (!_.node_ops.getattr) throw new o.ErrnoError(63);
            return _.node_ops.getattr(_);
          },
          lstat(e) {
            return o.stat(e, !0);
          },
          chmod(e, a, t) {
            var _;
            if (typeof e == "string") {
              var n = o.lookupPath(e, { follow: !t });
              _ = n.node;
            } else _ = e;
            if (!_.node_ops.setattr) throw new o.ErrnoError(63);
            _.node_ops.setattr(_, {
              mode: (a & 4095) | (_.mode & -4096),
              timestamp: Date.now(),
            });
          },
          lchmod(e, a) {
            o.chmod(e, a, !0);
          },
          fchmod(e, a) {
            var t = o.getStreamChecked(e);
            o.chmod(t.node, a);
          },
          chown(e, a, t, _) {
            var n;
            if (typeof e == "string") {
              var i = o.lookupPath(e, { follow: !_ });
              n = i.node;
            } else n = e;
            if (!n.node_ops.setattr) throw new o.ErrnoError(63);
            n.node_ops.setattr(n, { timestamp: Date.now() });
          },
          lchown(e, a, t) {
            o.chown(e, a, t, !0);
          },
          fchown(e, a, t) {
            var _ = o.getStreamChecked(e);
            o.chown(_.node, a, t);
          },
          truncate(e, a) {
            if (a < 0) throw new o.ErrnoError(28);
            var t;
            if (typeof e == "string") {
              var _ = o.lookupPath(e, { follow: !0 });
              t = _.node;
            } else t = e;
            if (!t.node_ops.setattr) throw new o.ErrnoError(63);
            if (o.isDir(t.mode)) throw new o.ErrnoError(31);
            if (!o.isFile(t.mode)) throw new o.ErrnoError(28);
            var n = o.nodePermissions(t, "w");
            if (n) throw new o.ErrnoError(n);
            t.node_ops.setattr(t, { size: a, timestamp: Date.now() });
          },
          ftruncate(e, a) {
            var t = o.getStreamChecked(e);
            if ((t.flags & 2097155) === 0) throw new o.ErrnoError(28);
            o.truncate(t.node, a);
          },
          utime(e, a, t) {
            var _ = o.lookupPath(e, { follow: !0 }),
              n = _.node;
            n.node_ops.setattr(n, { timestamp: Math.max(a, t) });
          },
          open(e, a, t) {
            if (e === "") throw new o.ErrnoError(44);
            ((a = typeof a == "string" ? I_(a) : a),
              a & 64
                ? ((t = typeof t > "u" ? 438 : t), (t = (t & 4095) | 32768))
                : (t = 0));
            var _;
            if (typeof e == "object") _ = e;
            else {
              e = j.normalize(e);
              try {
                var n = o.lookupPath(e, { follow: !(a & 131072) });
                _ = n.node;
              } catch {}
            }
            var i = !1;
            if (a & 64)
              if (_) {
                if (a & 128) throw new o.ErrnoError(20);
              } else ((_ = o.mknod(e, t, 0)), (i = !0));
            if (!_) throw new o.ErrnoError(44);
            if (
              (o.isChrdev(_.mode) && (a &= -513), a & 65536 && !o.isDir(_.mode))
            )
              throw new o.ErrnoError(54);
            if (!i) {
              var m = o.mayOpen(_, a);
              if (m) throw new o.ErrnoError(m);
            }
            (a & 512 && !i && o.truncate(_, 0), (a &= -131713));
            var l = o.createStream({
              node: _,
              path: o.getPath(_),
              flags: a,
              seekable: !0,
              position: 0,
              stream_ops: _.stream_ops,
              ungotten: [],
              error: !1,
            });
            return (
              l.stream_ops.open && l.stream_ops.open(l),
              r.logReadFiles &&
                !(a & 1) &&
                (e in o.readFiles || (o.readFiles[e] = 1)),
              l
            );
          },
          close(e) {
            if (o.isClosed(e)) throw new o.ErrnoError(8);
            e.getdents && (e.getdents = null);
            try {
              e.stream_ops.close && e.stream_ops.close(e);
            } catch (a) {
              throw a;
            } finally {
              o.closeStream(e.fd);
            }
            e.fd = null;
          },
          isClosed(e) {
            return e.fd === null;
          },
          llseek(e, a, t) {
            if (o.isClosed(e)) throw new o.ErrnoError(8);
            if (!e.seekable || !e.stream_ops.llseek) throw new o.ErrnoError(70);
            if (t != 0 && t != 1 && t != 2) throw new o.ErrnoError(28);
            return (
              (e.position = e.stream_ops.llseek(e, a, t)),
              (e.ungotten = []),
              e.position
            );
          },
          read(e, a, t, _, n) {
            if (_ < 0 || n < 0) throw new o.ErrnoError(28);
            if (o.isClosed(e)) throw new o.ErrnoError(8);
            if ((e.flags & 2097155) === 1) throw new o.ErrnoError(8);
            if (o.isDir(e.node.mode)) throw new o.ErrnoError(31);
            if (!e.stream_ops.read) throw new o.ErrnoError(28);
            var i = typeof n < "u";
            if (!i) n = e.position;
            else if (!e.seekable) throw new o.ErrnoError(70);
            var m = e.stream_ops.read(e, a, t, _, n);
            return (i || (e.position += m), m);
          },
          write(e, a, t, _, n, i) {
            if (_ < 0 || n < 0) throw new o.ErrnoError(28);
            if (o.isClosed(e)) throw new o.ErrnoError(8);
            if ((e.flags & 2097155) === 0) throw new o.ErrnoError(8);
            if (o.isDir(e.node.mode)) throw new o.ErrnoError(31);
            if (!e.stream_ops.write) throw new o.ErrnoError(28);
            e.seekable && e.flags & 1024 && o.llseek(e, 0, 2);
            var m = typeof n < "u";
            if (!m) n = e.position;
            else if (!e.seekable) throw new o.ErrnoError(70);
            var l = e.stream_ops.write(e, a, t, _, n, i);
            return (m || (e.position += l), l);
          },
          allocate(e, a, t) {
            if (o.isClosed(e)) throw new o.ErrnoError(8);
            if (a < 0 || t <= 0) throw new o.ErrnoError(28);
            if ((e.flags & 2097155) === 0) throw new o.ErrnoError(8);
            if (!o.isFile(e.node.mode) && !o.isDir(e.node.mode))
              throw new o.ErrnoError(43);
            if (!e.stream_ops.allocate) throw new o.ErrnoError(138);
            e.stream_ops.allocate(e, a, t);
          },
          mmap(e, a, t, _, n) {
            if ((_ & 2) !== 0 && (n & 2) === 0 && (e.flags & 2097155) !== 2)
              throw new o.ErrnoError(2);
            if ((e.flags & 2097155) === 1) throw new o.ErrnoError(2);
            if (!e.stream_ops.mmap) throw new o.ErrnoError(43);
            if (!a) throw new o.ErrnoError(28);
            return e.stream_ops.mmap(e, a, t, _, n);
          },
          msync(e, a, t, _, n) {
            return e.stream_ops.msync ? e.stream_ops.msync(e, a, t, _, n) : 0;
          },
          ioctl(e, a, t) {
            if (!e.stream_ops.ioctl) throw new o.ErrnoError(59);
            return e.stream_ops.ioctl(e, a, t);
          },
          readFile(e, a = {}) {
            if (
              ((a.flags = a.flags || 0),
              (a.encoding = a.encoding || "binary"),
              a.encoding !== "utf8" && a.encoding !== "binary")
            )
              throw new Error(`Invalid encoding type "${a.encoding}"`);
            var t,
              _ = o.open(e, a.flags),
              n = o.stat(e),
              i = n.size,
              m = new Uint8Array(i);
            return (
              o.read(_, m, 0, i, 0),
              a.encoding === "utf8"
                ? (t = be(m))
                : a.encoding === "binary" && (t = m),
              o.close(_),
              t
            );
          },
          writeFile(e, a, t = {}) {
            t.flags = t.flags || 577;
            var _ = o.open(e, t.flags, t.mode);
            if (typeof a == "string") {
              var n = new Uint8Array(Vr(a) + 1),
                i = br(a, n, 0, n.length);
              o.write(_, n, 0, i, void 0, t.canOwn);
            } else if (ArrayBuffer.isView(a))
              o.write(_, a, 0, a.byteLength, void 0, t.canOwn);
            else throw new Error("Unsupported data type");
            o.close(_);
          },
          cwd: () => o.currentPath,
          chdir(e) {
            var a = o.lookupPath(e, { follow: !0 });
            if (a.node === null) throw new o.ErrnoError(44);
            if (!o.isDir(a.node.mode)) throw new o.ErrnoError(54);
            var t = o.nodePermissions(a.node, "x");
            if (t) throw new o.ErrnoError(t);
            o.currentPath = a.path;
          },
          createDefaultDirectories() {
            (o.mkdir("/tmp"), o.mkdir("/home"), o.mkdir("/home/web_user"));
          },
          createDefaultDevices() {
            (o.mkdir("/dev"),
              o.registerDevice(o.makedev(1, 3), {
                read: () => 0,
                write: (_, n, i, m, l) => m,
              }),
              o.mkdev("/dev/null", o.makedev(1, 3)),
              ce.register(o.makedev(5, 0), ce.default_tty_ops),
              ce.register(o.makedev(6, 0), ce.default_tty1_ops),
              o.mkdev("/dev/tty", o.makedev(5, 0)),
              o.mkdev("/dev/tty1", o.makedev(6, 0)));
            var e = new Uint8Array(1024),
              a = 0,
              t = () => (a === 0 && (a = ma(e).byteLength), e[--a]);
            (o.createDevice("/dev", "random", t),
              o.createDevice("/dev", "urandom", t),
              o.mkdir("/dev/shm"),
              o.mkdir("/dev/shm/tmp"));
          },
          createSpecialDirectories() {
            o.mkdir("/proc");
            var e = o.mkdir("/proc/self");
            (o.mkdir("/proc/self/fd"),
              o.mount(
                {
                  mount() {
                    var a = o.createNode(e, "fd", 16895, 73);
                    return (
                      (a.node_ops = {
                        lookup(t, _) {
                          var n = +_,
                            i = o.getStreamChecked(n),
                            m = {
                              parent: null,
                              mount: { mountpoint: "fake" },
                              node_ops: { readlink: () => i.path },
                            };
                          return ((m.parent = m), m);
                        },
                      }),
                      a
                    );
                  },
                },
                {},
                "/proc/self/fd",
              ));
          },
          createStandardStreams(e, a, t) {
            (e
              ? o.createDevice("/dev", "stdin", e)
              : o.symlink("/dev/tty", "/dev/stdin"),
              a
                ? o.createDevice("/dev", "stdout", null, a)
                : o.symlink("/dev/tty", "/dev/stdout"),
              t
                ? o.createDevice("/dev", "stderr", null, t)
                : o.symlink("/dev/tty1", "/dev/stderr"));
            var _ = o.open("/dev/stdin", 0),
              n = o.open("/dev/stdout", 1),
              i = o.open("/dev/stderr", 1);
          },
          staticInit() {
            ([44].forEach((e) => {
              ((o.genericErrors[e] = new o.ErrnoError(e)),
                (o.genericErrors[e].stack = "<generic error, no stack>"));
            }),
              (o.nameTable = new Array(4096)),
              o.mount(x, {}, "/"),
              o.createDefaultDirectories(),
              o.createDefaultDevices(),
              o.createSpecialDirectories(),
              (o.filesystems = { MEMFS: x }));
          },
          init(e, a, t) {
            ((o.initialized = !0),
              (e ??= r.stdin),
              (a ??= r.stdout),
              (t ??= r.stderr),
              o.createStandardStreams(e, a, t));
          },
          quit() {
            o.initialized = !1;
            for (var e = 0; e < o.streams.length; e++) {
              var a = o.streams[e];
              a && o.close(a);
            }
          },
          findObject(e, a) {
            var t = o.analyzePath(e, a);
            return t.exists ? t.object : null;
          },
          analyzePath(e, a) {
            try {
              var t = o.lookupPath(e, { follow: !a });
              e = t.path;
            } catch {}
            var _ = {
              isRoot: !1,
              exists: !1,
              error: 0,
              name: null,
              path: null,
              object: null,
              parentExists: !1,
              parentPath: null,
              parentObject: null,
            };
            try {
              var t = o.lookupPath(e, { parent: !0 });
              ((_.parentExists = !0),
                (_.parentPath = t.path),
                (_.parentObject = t.node),
                (_.name = j.basename(e)),
                (t = o.lookupPath(e, { follow: !a })),
                (_.exists = !0),
                (_.path = t.path),
                (_.object = t.node),
                (_.name = t.node.name),
                (_.isRoot = t.path === "/"));
            } catch (n) {
              _.error = n.errno;
            }
            return _;
          },
          createPath(e, a, t, _) {
            e = typeof e == "string" ? e : o.getPath(e);
            for (var n = a.split("/").reverse(); n.length; ) {
              var i = n.pop();
              if (i) {
                var m = j.join2(e, i);
                try {
                  o.mkdir(m);
                } catch {}
                e = m;
              }
            }
            return m;
          },
          createFile(e, a, t, _, n) {
            var i = j.join2(typeof e == "string" ? e : o.getPath(e), a),
              m = hr(_, n);
            return o.create(i, m);
          },
          createDataFile(e, a, t, _, n, i) {
            var m = a;
            e &&
              ((e = typeof e == "string" ? e : o.getPath(e)),
              (m = a ? j.join2(e, a) : e));
            var l = hr(_, n),
              u = o.create(m, l);
            if (t) {
              if (typeof t == "string") {
                for (
                  var f = new Array(t.length), d = 0, A = t.length;
                  d < A;
                  ++d
                )
                  f[d] = t.charCodeAt(d);
                t = f;
              }
              o.chmod(u, l | 146);
              var p = o.open(u, 577);
              (o.write(p, t, 0, t.length, 0, i), o.close(p), o.chmod(u, l));
            }
          },
          createDevice(e, a, t, _) {
            var n = j.join2(typeof e == "string" ? e : o.getPath(e), a),
              i = hr(!!t, !!_);
            o.createDevice.major ??= 64;
            var m = o.makedev(o.createDevice.major++, 0);
            return (
              o.registerDevice(m, {
                open(l) {
                  l.seekable = !1;
                },
                close(l) {
                  _?.buffer?.length && _(10);
                },
                read(l, u, f, d, A) {
                  for (var p = 0, v = 0; v < d; v++) {
                    var b;
                    try {
                      b = t();
                    } catch {
                      throw new o.ErrnoError(29);
                    }
                    if (b === void 0 && p === 0) throw new o.ErrnoError(6);
                    if (b == null) break;
                    (p++, (u[f + v] = b));
                  }
                  return (p && (l.node.timestamp = Date.now()), p);
                },
                write(l, u, f, d, A) {
                  for (var p = 0; p < d; p++)
                    try {
                      _(u[f + p]);
                    } catch {
                      throw new o.ErrnoError(29);
                    }
                  return (d && (l.node.timestamp = Date.now()), p);
                },
              }),
              o.mkdev(n, i, m)
            );
          },
          forceLoadFile(e) {
            if (e.isDevice || e.isFolder || e.link || e.contents) return !0;
            if (typeof XMLHttpRequest < "u")
              throw new Error(
                "Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.",
              );
            try {
              ((e.contents = Ee(e.url)), (e.usedBytes = e.contents.length));
            } catch {
              throw new o.ErrnoError(29);
            }
          },
          createLazyFile(e, a, t, _, n) {
            class i {
              lengthKnown = !1;
              chunks = [];
              get(v) {
                if (!(v > this.length - 1 || v < 0)) {
                  var b = v % this.chunkSize,
                    y = (v / this.chunkSize) | 0;
                  return this.getter(y)[b];
                }
              }
              setDataGetter(v) {
                this.getter = v;
              }
              cacheLength() {
                var v = new XMLHttpRequest();
                if (
                  (v.open("HEAD", t, !1),
                  v.send(null),
                  !((v.status >= 200 && v.status < 300) || v.status === 304))
                )
                  throw new Error(
                    "Couldn't load " + t + ". Status: " + v.status,
                  );
                var b = Number(v.getResponseHeader("Content-length")),
                  y,
                  w =
                    (y = v.getResponseHeader("Accept-Ranges")) && y === "bytes",
                  F =
                    (y = v.getResponseHeader("Content-Encoding")) &&
                    y === "gzip",
                  M = 1024 * 1024;
                w || (M = b);
                var P = (T, g) => {
                    if (T > g)
                      throw new Error(
                        "invalid range (" +
                          T +
                          ", " +
                          g +
                          ") or no bytes requested!",
                      );
                    if (g > b - 1)
                      throw new Error(
                        "only " + b + " bytes available! programmer error!",
                      );
                    var S = new XMLHttpRequest();
                    if (
                      (S.open("GET", t, !1),
                      b !== M &&
                        S.setRequestHeader("Range", "bytes=" + T + "-" + g),
                      (S.responseType = "arraybuffer"),
                      S.overrideMimeType &&
                        S.overrideMimeType(
                          "text/plain; charset=x-user-defined",
                        ),
                      S.send(null),
                      !(
                        (S.status >= 200 && S.status < 300) ||
                        S.status === 304
                      ))
                    )
                      throw new Error(
                        "Couldn't load " + t + ". Status: " + S.status,
                      );
                    return S.response !== void 0
                      ? new Uint8Array(S.response || [])
                      : la(S.responseText || "", !0);
                  },
                  E = this;
                (E.setDataGetter((T) => {
                  var g = T * M,
                    S = (T + 1) * M - 1;
                  if (
                    ((S = Math.min(S, b - 1)),
                    typeof E.chunks[T] > "u" && (E.chunks[T] = P(g, S)),
                    typeof E.chunks[T] > "u")
                  )
                    throw new Error("doXHR failed!");
                  return E.chunks[T];
                }),
                  (F || !b) &&
                    ((M = b = 1),
                    (b = this.getter(0).length),
                    (M = b),
                    ur(
                      "LazyFiles on gzip forces download of the whole file when length is accessed",
                    )),
                  (this._length = b),
                  (this._chunkSize = M),
                  (this.lengthKnown = !0));
              }
              get length() {
                return (this.lengthKnown || this.cacheLength(), this._length);
              }
              get chunkSize() {
                return (
                  this.lengthKnown || this.cacheLength(),
                  this._chunkSize
                );
              }
            }
            if (typeof XMLHttpRequest < "u") {
              if (!le)
                throw "Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc";
              var m = new i(),
                l = { isDevice: !1, contents: m };
            } else var l = { isDevice: !1, url: t };
            var u = o.createFile(e, a, l, _, n);
            (l.contents
              ? (u.contents = l.contents)
              : l.url && ((u.contents = null), (u.url = l.url)),
              Object.defineProperties(u, {
                usedBytes: {
                  get: function () {
                    return this.contents.length;
                  },
                },
              }));
            var f = {},
              d = Object.keys(u.stream_ops);
            d.forEach((p) => {
              var v = u.stream_ops[p];
              f[p] = (...b) => (o.forceLoadFile(u), v(...b));
            });
            function A(p, v, b, y, w) {
              var F = p.node.contents;
              if (w >= F.length) return 0;
              var M = Math.min(F.length - w, y);
              if (F.slice) for (var P = 0; P < M; P++) v[b + P] = F[w + P];
              else for (var P = 0; P < M; P++) v[b + P] = F.get(w + P);
              return M;
            }
            return (
              (f.read = (p, v, b, y, w) => (
                o.forceLoadFile(u),
                A(p, v, b, y, w)
              )),
              (f.mmap = (p, v, b, y, w) => {
                o.forceLoadFile(u);
                var F = ua(v);
                if (!F) throw new o.ErrnoError(48);
                return (A(p, $, F, v, b), { ptr: F, allocated: !0 });
              }),
              (u.stream_ops = f),
              u
            );
          },
        },
        k = {
          DEFAULT_POLLMASK: 5,
          calculateAt(e, a, t) {
            if (j.isAbs(a)) return a;
            var _;
            if (e === -100) _ = o.cwd();
            else {
              var n = k.getStreamFromFD(e);
              _ = n.path;
            }
            if (a.length == 0) {
              if (!t) throw new o.ErrnoError(44);
              return _;
            }
            return j.join2(_, a);
          },
          doStat(e, a, t) {
            var _ = e(a);
            ((V[t >> 2] = _.dev),
              (V[(t + 4) >> 2] = _.mode),
              (z[(t + 8) >> 2] = _.nlink),
              (V[(t + 12) >> 2] = _.uid),
              (V[(t + 16) >> 2] = _.gid),
              (V[(t + 20) >> 2] = _.rdev),
              (D = [
                _.size >>> 0,
                ((C = _.size),
                +Math.abs(C) >= 1
                  ? C > 0
                    ? +Math.floor(C / 4294967296) >>> 0
                    : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                  : 0),
              ]),
              (V[(t + 24) >> 2] = D[0]),
              (V[(t + 28) >> 2] = D[1]),
              (V[(t + 32) >> 2] = 4096),
              (V[(t + 36) >> 2] = _.blocks));
            var n = _.atime.getTime(),
              i = _.mtime.getTime(),
              m = _.ctime.getTime();
            return (
              (D = [
                Math.floor(n / 1e3) >>> 0,
                ((C = Math.floor(n / 1e3)),
                +Math.abs(C) >= 1
                  ? C > 0
                    ? +Math.floor(C / 4294967296) >>> 0
                    : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                  : 0),
              ]),
              (V[(t + 40) >> 2] = D[0]),
              (V[(t + 44) >> 2] = D[1]),
              (z[(t + 48) >> 2] = (n % 1e3) * 1e3 * 1e3),
              (D = [
                Math.floor(i / 1e3) >>> 0,
                ((C = Math.floor(i / 1e3)),
                +Math.abs(C) >= 1
                  ? C > 0
                    ? +Math.floor(C / 4294967296) >>> 0
                    : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                  : 0),
              ]),
              (V[(t + 56) >> 2] = D[0]),
              (V[(t + 60) >> 2] = D[1]),
              (z[(t + 64) >> 2] = (i % 1e3) * 1e3 * 1e3),
              (D = [
                Math.floor(m / 1e3) >>> 0,
                ((C = Math.floor(m / 1e3)),
                +Math.abs(C) >= 1
                  ? C > 0
                    ? +Math.floor(C / 4294967296) >>> 0
                    : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                  : 0),
              ]),
              (V[(t + 72) >> 2] = D[0]),
              (V[(t + 76) >> 2] = D[1]),
              (z[(t + 80) >> 2] = (m % 1e3) * 1e3 * 1e3),
              (D = [
                _.ino >>> 0,
                ((C = _.ino),
                +Math.abs(C) >= 1
                  ? C > 0
                    ? +Math.floor(C / 4294967296) >>> 0
                    : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                  : 0),
              ]),
              (V[(t + 88) >> 2] = D[0]),
              (V[(t + 92) >> 2] = D[1]),
              0
            );
          },
          doMsync(e, a, t, _, n) {
            if (!o.isFile(a.node.mode)) throw new o.ErrnoError(43);
            if (_ & 2) return 0;
            var i = Ae.slice(e, e + t);
            o.msync(a, i, n, t, _);
          },
          getStreamFromFD(e) {
            var a = o.getStreamChecked(e);
            return a;
          },
          varargs: void 0,
          getStr(e) {
            var a = fe(e);
            return a;
          },
        },
        O_ = function (e, a, t, _, n) {
          try {
            for (
              var i = 0,
                m = a ? V[a >> 2] : 0,
                l = a ? V[(a + 4) >> 2] : 0,
                u = t ? V[t >> 2] : 0,
                f = t ? V[(t + 4) >> 2] : 0,
                d = _ ? V[_ >> 2] : 0,
                A = _ ? V[(_ + 4) >> 2] : 0,
                p = 0,
                v = 0,
                b = 0,
                y = 0,
                w = 0,
                F = 0,
                M =
                  (a ? V[a >> 2] : 0) |
                  (t ? V[t >> 2] : 0) |
                  (_ ? V[_ >> 2] : 0),
                P =
                  (a ? V[(a + 4) >> 2] : 0) |
                  (t ? V[(t + 4) >> 2] : 0) |
                  (_ ? V[(_ + 4) >> 2] : 0),
                E = (Ne, Uv, Nv, qt) => (Ne < 32 ? Uv & qt : Nv & qt),
                T = 0;
              T < e;
              T++
            ) {
              var g = 1 << (T % 32);
              if (E(T, M, P, g)) {
                var S = k.getStreamFromFD(T),
                  K = k.DEFAULT_POLLMASK;
                if (S.stream_ops.poll) {
                  var ee = -1;
                  if (n) {
                    var J = a ? V[n >> 2] : 0,
                      Fe = a ? V[(n + 4) >> 2] : 0;
                    ee = (J + Fe / 1e6) * 1e3;
                  }
                  K = S.stream_ops.poll(S, ee);
                }
                (K & 1 &&
                  E(T, m, l, g) &&
                  (T < 32 ? (p = p | g) : (v = v | g), i++),
                  K & 4 &&
                    E(T, u, f, g) &&
                    (T < 32 ? (b = b | g) : (y = y | g), i++),
                  K & 2 &&
                    E(T, d, A, g) &&
                    (T < 32 ? (w = w | g) : (F = F | g), i++));
              }
            }
            return (
              a && ((V[a >> 2] = p), (V[(a + 4) >> 2] = v)),
              t && ((V[t >> 2] = b), (V[(t + 4) >> 2] = y)),
              _ && ((V[_ >> 2] = w), (V[(_ + 4) >> 2] = F)),
              i
            );
          } catch (Ne) {
            if (typeof o > "u" || Ne.name !== "ErrnoError") throw Ne;
            return -Ne.errno;
          }
        };
      function U_(e) {
        try {
          var a = k.getStreamFromFD(e);
          return o.dupStream(a).fd;
        } catch (t) {
          if (typeof o > "u" || t.name !== "ErrnoError") throw t;
          return -t.errno;
        }
      }
      function N_(e, a, t) {
        try {
          var _ = k.getStreamFromFD(e);
          if (_.fd === a) return -28;
          if (a < 0 || a >= o.MAX_OPEN_FDS) return -8;
          var n = o.getStream(a);
          return (n && o.close(n), o.dupStream(_, a).fd);
        } catch (i) {
          if (typeof o > "u" || i.name !== "ErrnoError") throw i;
          return -i.errno;
        }
      }
      function L_(e, a, t, _) {
        try {
          if (((a = k.getStr(a)), (a = k.calculateAt(e, a)), t & -8))
            return -28;
          var n = o.lookupPath(a, { follow: !0 }),
            i = n.node;
          if (!i) return -44;
          var m = "";
          return (
            t & 4 && (m += "r"),
            t & 2 && (m += "w"),
            t & 1 && (m += "x"),
            m && o.nodePermissions(i, m) ? -2 : 0
          );
        } catch (l) {
          if (typeof o > "u" || l.name !== "ErrnoError") throw l;
          return -l.errno;
        }
      }
      var Ye = () => {
          var e = V[+k.varargs >> 2];
          return ((k.varargs += 4), e);
        },
        he = Ye;
      function H_(e, a, t) {
        k.varargs = t;
        try {
          var _ = k.getStreamFromFD(e);
          switch (a) {
            case 0: {
              var n = Ye();
              if (n < 0) return -28;
              for (; o.streams[n]; ) n++;
              var i;
              return ((i = o.dupStream(_, n)), i.fd);
            }
            case 1:
            case 2:
              return 0;
            case 3:
              return _.flags;
            case 4: {
              var n = Ye();
              return ((_.flags |= n), 0);
            }
            case 12: {
              var n = he(),
                m = 0;
              return ((Ve[(n + m) >> 1] = 2), 0);
            }
            case 13:
            case 14:
              return 0;
          }
          return -28;
        } catch (l) {
          if (typeof o > "u" || l.name !== "ErrnoError") throw l;
          return -l.errno;
        }
      }
      function B_(e, a) {
        try {
          var t = k.getStreamFromFD(e);
          return k.doStat(o.stat, t.path, a);
        } catch (_) {
          if (typeof o > "u" || _.name !== "ErrnoError") throw _;
          return -_.errno;
        }
      }
      var Ce = (e, a, t) => br(e, Ae, a, t);
      function q_(e, a, t) {
        try {
          var _ = k.getStreamFromFD(e);
          _.getdents ||= o.readdir(_.path);
          for (
            var n = 280, i = 0, m = o.llseek(_, 0, 1), l = Math.floor(m / n);
            l < _.getdents.length && i + n <= t;
          ) {
            var u,
              f,
              d = _.getdents[l];
            if (d === ".") ((u = _.node.id), (f = 4));
            else if (d === "..") {
              var A = o.lookupPath(_.path, { parent: !0 });
              ((u = A.node.id), (f = 4));
            } else {
              var p = o.lookupNode(_.node, d);
              ((u = p.id),
                (f = o.isChrdev(p.mode)
                  ? 2
                  : o.isDir(p.mode)
                    ? 4
                    : o.isLink(p.mode)
                      ? 10
                      : 8));
            }
            ((D = [
              u >>> 0,
              ((C = u),
              +Math.abs(C) >= 1
                ? C > 0
                  ? +Math.floor(C / 4294967296) >>> 0
                  : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                : 0),
            ]),
              (V[(a + i) >> 2] = D[0]),
              (V[(a + i + 4) >> 2] = D[1]),
              (D = [
                ((l + 1) * n) >>> 0,
                ((C = (l + 1) * n),
                +Math.abs(C) >= 1
                  ? C > 0
                    ? +Math.floor(C / 4294967296) >>> 0
                    : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                  : 0),
              ]),
              (V[(a + i + 8) >> 2] = D[0]),
              (V[(a + i + 12) >> 2] = D[1]),
              (Ve[(a + i + 16) >> 1] = 280),
              ($[a + i + 18] = f),
              Ce(d, a + i + 19, 256),
              (i += n),
              (l += 1));
          }
          return (o.llseek(_, l * n, 0), i);
        } catch (v) {
          if (typeof o > "u" || v.name !== "ErrnoError") throw v;
          return -v.errno;
        }
      }
      function W_(e, a, t) {
        k.varargs = t;
        try {
          var _ = k.getStreamFromFD(e);
          switch (a) {
            case 21509:
              return _.tty ? 0 : -59;
            case 21505: {
              if (!_.tty) return -59;
              if (_.tty.ops.ioctl_tcgets) {
                var n = _.tty.ops.ioctl_tcgets(_),
                  i = he();
                ((V[i >> 2] = n.c_iflag || 0),
                  (V[(i + 4) >> 2] = n.c_oflag || 0),
                  (V[(i + 8) >> 2] = n.c_cflag || 0),
                  (V[(i + 12) >> 2] = n.c_lflag || 0));
                for (var m = 0; m < 32; m++) $[i + m + 17] = n.c_cc[m] || 0;
                return 0;
              }
              return 0;
            }
            case 21510:
            case 21511:
            case 21512:
              return _.tty ? 0 : -59;
            case 21506:
            case 21507:
            case 21508: {
              if (!_.tty) return -59;
              if (_.tty.ops.ioctl_tcsets) {
                for (
                  var i = he(),
                    l = V[i >> 2],
                    u = V[(i + 4) >> 2],
                    f = V[(i + 8) >> 2],
                    d = V[(i + 12) >> 2],
                    A = [],
                    m = 0;
                  m < 32;
                  m++
                )
                  A.push($[i + m + 17]);
                return _.tty.ops.ioctl_tcsets(_.tty, a, {
                  c_iflag: l,
                  c_oflag: u,
                  c_cflag: f,
                  c_lflag: d,
                  c_cc: A,
                });
              }
              return 0;
            }
            case 21519: {
              if (!_.tty) return -59;
              var i = he();
              return ((V[i >> 2] = 0), 0);
            }
            case 21520:
              return _.tty ? -28 : -59;
            case 21531: {
              var i = he();
              return o.ioctl(_, a, i);
            }
            case 21523: {
              if (!_.tty) return -59;
              if (_.tty.ops.ioctl_tiocgwinsz) {
                var p = _.tty.ops.ioctl_tiocgwinsz(_.tty),
                  i = he();
                ((Ve[i >> 1] = p[0]), (Ve[(i + 2) >> 1] = p[1]));
              }
              return 0;
            }
            case 21524:
              return _.tty ? 0 : -59;
            case 21515:
              return _.tty ? 0 : -59;
            default:
              return -28;
          }
        } catch (v) {
          if (typeof o > "u" || v.name !== "ErrnoError") throw v;
          return -v.errno;
        }
      }
      function $_(e, a) {
        try {
          return ((e = k.getStr(e)), k.doStat(o.lstat, e, a));
        } catch (t) {
          if (typeof o > "u" || t.name !== "ErrnoError") throw t;
          return -t.errno;
        }
      }
      function Y_(e, a, t) {
        try {
          return (
            (a = k.getStr(a)),
            (a = k.calculateAt(e, a)),
            (a = j.normalize(a)),
            a[a.length - 1] === "/" && (a = a.substr(0, a.length - 1)),
            o.mkdir(a, t, 0),
            0
          );
        } catch (_) {
          if (typeof o > "u" || _.name !== "ErrnoError") throw _;
          return -_.errno;
        }
      }
      function J_(e, a, t, _) {
        try {
          a = k.getStr(a);
          var n = _ & 256,
            i = _ & 4096;
          return (
            (_ = _ & -6401),
            (a = k.calculateAt(e, a, i)),
            k.doStat(n ? o.lstat : o.stat, a, t)
          );
        } catch (m) {
          if (typeof o > "u" || m.name !== "ErrnoError") throw m;
          return -m.errno;
        }
      }
      function X_(e, a, t, _) {
        k.varargs = _;
        try {
          ((a = k.getStr(a)), (a = k.calculateAt(e, a)));
          var n = _ ? Ye() : 0;
          return o.open(a, t, n).fd;
        } catch (i) {
          if (typeof o > "u" || i.name !== "ErrnoError") throw i;
          return -i.errno;
        }
      }
      function G_(e, a, t, _) {
        try {
          return (
            (a = k.getStr(a)),
            (_ = k.getStr(_)),
            (a = k.calculateAt(e, a)),
            (_ = k.calculateAt(t, _)),
            o.rename(a, _),
            0
          );
        } catch (n) {
          if (typeof o > "u" || n.name !== "ErrnoError") throw n;
          return -n.errno;
        }
      }
      function K_(e) {
        try {
          return ((e = k.getStr(e)), o.rmdir(e), 0);
        } catch (a) {
          if (typeof o > "u" || a.name !== "ErrnoError") throw a;
          return -a.errno;
        }
      }
      function Z_(e, a) {
        try {
          return ((e = k.getStr(e)), k.doStat(o.stat, e, a));
        } catch (t) {
          if (typeof o > "u" || t.name !== "ErrnoError") throw t;
          return -t.errno;
        }
      }
      function Q_(e, a, t) {
        try {
          return (
            (a = k.getStr(a)),
            (a = k.calculateAt(e, a)),
            t === 0
              ? o.unlink(a)
              : t === 512
                ? o.rmdir(a)
                : se("Invalid flags passed to unlinkat"),
            0
          );
        } catch (_) {
          if (typeof o > "u" || _.name !== "ErrnoError") throw _;
          return -_.errno;
        }
      }
      var en = () => {
          se("");
        },
        rn = 1,
        an = () => rn,
        tn = () => {
          throw 1 / 0;
        },
        Cr = (e, a) =>
          (a + 2097152) >>> 0 < 4194305 - !!e
            ? (e >>> 0) + a * 4294967296
            : NaN;
      function _n(e, a, t) {
        var _ = Cr(e, a),
          n = new Date(_ * 1e3);
        ((V[t >> 2] = n.getUTCSeconds()),
          (V[(t + 4) >> 2] = n.getUTCMinutes()),
          (V[(t + 8) >> 2] = n.getUTCHours()),
          (V[(t + 12) >> 2] = n.getUTCDate()),
          (V[(t + 16) >> 2] = n.getUTCMonth()),
          (V[(t + 20) >> 2] = n.getUTCFullYear() - 1900),
          (V[(t + 24) >> 2] = n.getUTCDay()));
        var i = Date.UTC(n.getUTCFullYear(), 0, 1, 0, 0, 0, 0),
          m = ((n.getTime() - i) / (1e3 * 60 * 60 * 24)) | 0;
        V[(t + 28) >> 2] = m;
      }
      var nn = (e) => e % 4 === 0 && (e % 100 !== 0 || e % 400 === 0),
        on = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335],
        sn = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334],
        da = (e) => {
          var a = nn(e.getFullYear()),
            t = a ? on : sn,
            _ = t[e.getMonth()] + e.getDate() - 1;
          return _;
        };
      function cn(e, a, t) {
        var _ = Cr(e, a),
          n = new Date(_ * 1e3);
        ((V[t >> 2] = n.getSeconds()),
          (V[(t + 4) >> 2] = n.getMinutes()),
          (V[(t + 8) >> 2] = n.getHours()),
          (V[(t + 12) >> 2] = n.getDate()),
          (V[(t + 16) >> 2] = n.getMonth()),
          (V[(t + 20) >> 2] = n.getFullYear() - 1900),
          (V[(t + 24) >> 2] = n.getDay()));
        var i = da(n) | 0;
        ((V[(t + 28) >> 2] = i),
          (V[(t + 36) >> 2] = -(n.getTimezoneOffset() * 60)));
        var m = new Date(n.getFullYear(), 0, 1),
          l = new Date(n.getFullYear(), 6, 1).getTimezoneOffset(),
          u = m.getTimezoneOffset(),
          f = (l != u && n.getTimezoneOffset() == Math.min(u, l)) | 0;
        V[(t + 32) >> 2] = f;
      }
      var mn = (e) => ka(e),
        ln = function (e) {
          var a = (() => {
            var t = new Date(
                V[(e + 20) >> 2] + 1900,
                V[(e + 16) >> 2],
                V[(e + 12) >> 2],
                V[(e + 8) >> 2],
                V[(e + 4) >> 2],
                V[e >> 2],
                0,
              ),
              _ = V[(e + 32) >> 2],
              n = t.getTimezoneOffset(),
              i = new Date(t.getFullYear(), 0, 1),
              m = new Date(t.getFullYear(), 6, 1).getTimezoneOffset(),
              l = i.getTimezoneOffset(),
              u = Math.min(l, m);
            if (_ < 0) V[(e + 32) >> 2] = +(m != l && u == n);
            else if (_ > 0 != (u == n)) {
              var f = Math.max(l, m),
                d = _ > 0 ? u : f;
              t.setTime(t.getTime() + (d - n) * 6e4);
            }
            V[(e + 24) >> 2] = t.getDay();
            var A = da(t) | 0;
            ((V[(e + 28) >> 2] = A),
              (V[e >> 2] = t.getSeconds()),
              (V[(e + 4) >> 2] = t.getMinutes()),
              (V[(e + 8) >> 2] = t.getHours()),
              (V[(e + 12) >> 2] = t.getDate()),
              (V[(e + 16) >> 2] = t.getMonth()),
              (V[(e + 20) >> 2] = t.getYear()));
            var p = t.getTime();
            return isNaN(p) ? -1 : p / 1e3;
          })();
          return (
            mn(
              ((C = a),
              +Math.abs(C) >= 1
                ? C > 0
                  ? +Math.floor(C / 4294967296) >>> 0
                  : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                : 0),
            ),
            a >>> 0
          );
        },
        un = (e, a, t, _) => {
          var n = new Date().getFullYear(),
            i = new Date(n, 0, 1),
            m = new Date(n, 6, 1),
            l = i.getTimezoneOffset(),
            u = m.getTimezoneOffset(),
            f = Math.max(l, u);
          ((z[e >> 2] = f * 60), (V[a >> 2] = +(l != u)));
          var d = (v) => {
              var b = v >= 0 ? "-" : "+",
                y = Math.abs(v),
                w = String(Math.floor(y / 60)).padStart(2, "0"),
                F = String(y % 60).padStart(2, "0");
              return `UTC${b}${w}${F}`;
            },
            A = d(l),
            p = d(u);
          u < l ? (Ce(A, t, 17), Ce(p, _, 17)) : (Ce(A, _, 17), Ce(p, t, 17));
        },
        wr = [],
        dn = (e, a) => {
          wr.length = 0;
          for (var t; (t = Ae[e++]); ) {
            var _ = t != 105;
            ((_ &= t != 112),
              (a += _ && a % 8 ? 4 : 0),
              wr.push(t == 112 ? z[a >> 2] : t == 105 ? V[a >> 2] : ea[a >> 3]),
              (a += _ ? 8 : 4));
          }
          return wr;
        },
        fn = (e, a, t) => {
          var _ = dn(a, t);
          return c_[e](..._);
        },
        vn = (e, a, t) => fn(e, a, t),
        pn = () => Date.now(),
        Je = (e) => {
          try {
            return e();
          } catch (a) {
            se(a);
          }
        },
        fa = (e) => {
          if (e instanceof ca || e == "unwind") return pe;
          ir(1, e);
        },
        yr = 0,
        va = () => F_ || yr > 0,
        An = (e) => {
          ((pe = e), va() || (r.onExit?.(e), (oe = !0)), ir(e, new ca(e)));
        },
        Vn = (e, a) => {
          ((pe = e), An(e));
        },
        pa = Vn,
        bn = () => {
          if (!va())
            try {
              pa(pe);
            } catch (e) {
              fa(e);
            }
        },
        Aa = (e) => {
          if (!oe)
            try {
              (e(), bn());
            } catch (a) {
              fa(a);
            }
        },
        hn = () => {
          yr += 1;
        },
        Cn = () => {
          yr -= 1;
        },
        h = {
          instrumentWasmImports(e) {
            var a =
              /^(libavjs_wait_reader|jsfetch_open_js|jsfetch_read|jsfetch_read_js|decoder_thread|invoke_.*|__asyncjs__.*)$/;
            for (let [t, _] of Object.entries(e))
              if (typeof _ == "function") {
                let n = _.isAsync || a.test(t);
              }
          },
          instrumentWasmExports(e) {
            var a = {};
            for (let [t, _] of Object.entries(e))
              typeof _ == "function"
                ? (a[t] = (...n) => {
                    h.exportCallStack.push(t);
                    try {
                      return _(...n);
                    } finally {
                      if (!oe) {
                        var i = h.exportCallStack.pop();
                        h.maybeStopUnwind();
                      }
                    }
                  })
                : (a[t] = _);
            return a;
          },
          State: { Normal: 0, Unwinding: 1, Rewinding: 2, Disabled: 3 },
          state: 0,
          StackSize: 4096,
          currData: null,
          handleSleepReturnValue: 0,
          exportCallStack: [],
          callStackNameToId: {},
          callStackIdToName: {},
          callStackId: 0,
          asyncPromiseHandlers: null,
          sleepCallbacks: [],
          getCallStackId(e) {
            var a = h.callStackNameToId[e];
            return (
              a === void 0 &&
                ((a = h.callStackId++),
                (h.callStackNameToId[e] = a),
                (h.callStackIdToName[a] = e)),
              a
            );
          },
          maybeStopUnwind() {
            h.currData &&
              h.state === h.State.Unwinding &&
              h.exportCallStack.length === 0 &&
              ((h.state = h.State.Normal),
              Je(Ba),
              typeof X < "u" && X.trampoline());
          },
          whenDone() {
            return new Promise((e, a) => {
              h.asyncPromiseHandlers = { resolve: e, reject: a };
            });
          },
          allocateData() {
            var e = xa(12 + h.StackSize);
            return (
              h.setDataHeader(e, e + 12, h.StackSize),
              h.setDataRewindFunc(e),
              e
            );
          },
          setDataHeader(e, a, t) {
            ((z[e >> 2] = a), (z[(e + 4) >> 2] = a + t));
          },
          setDataRewindFunc(e) {
            var a = h.exportCallStack[0],
              t = h.getCallStackId(a);
            V[(e + 8) >> 2] = t;
          },
          getDataRewindFuncName(e) {
            var a = V[(e + 8) >> 2],
              t = h.callStackIdToName[a];
            return t;
          },
          getDataRewindFunc(e) {
            var a = s[e];
            return a;
          },
          doRewind(e) {
            var a = h.getDataRewindFuncName(e),
              t = h.getDataRewindFunc(a);
            return t();
          },
          handleSleep(e) {
            if (!oe) {
              if (h.state === h.State.Normal) {
                var a = !1,
                  t = !1;
                (e((_ = 0) => {
                  if (!oe && ((h.handleSleepReturnValue = _), (a = !0), !!t)) {
                    ((h.state = h.State.Rewinding),
                      Je(() => Fr(h.currData)),
                      typeof MainLoop < "u" &&
                        MainLoop.func &&
                        MainLoop.resume());
                    var n,
                      i = !1;
                    try {
                      n = h.doRewind(h.currData);
                    } catch (u) {
                      ((n = u), (i = !0));
                    }
                    var m = !1;
                    if (!h.currData) {
                      var l = h.asyncPromiseHandlers;
                      l &&
                        ((h.asyncPromiseHandlers = null),
                        (i ? l.reject : l.resolve)(n),
                        (m = !0));
                    }
                    if (i && !m) throw n;
                  }
                }),
                  (t = !0),
                  a ||
                    ((h.state = h.State.Unwinding),
                    (h.currData = h.allocateData()),
                    typeof MainLoop < "u" && MainLoop.func && MainLoop.pause(),
                    Je(() => kr(h.currData))));
              } else
                h.state === h.State.Rewinding
                  ? ((h.state = h.State.Normal),
                    Je(Pr),
                    ga(h.currData),
                    (h.currData = null),
                    h.sleepCallbacks.forEach(Aa))
                  : se(`invalid state: ${h.state}`);
              return h.handleSleepReturnValue;
            }
          },
          handleAsync(e) {
            return h.handleSleep((a) => {
              e().then(a);
            });
          },
        },
        X = {
          nextFiber: 0,
          trampolineRunning: !1,
          trampoline() {
            if (!X.trampolineRunning && X.nextFiber) {
              X.trampolineRunning = !0;
              do {
                var e = X.nextFiber;
                ((X.nextFiber = 0), X.finishContextSwitch(e));
              } while (X.nextFiber);
              X.trampolineRunning = !1;
            }
          },
          finishContextSwitch(e) {
            var a = z[e >> 2],
              t = z[(e + 4) >> 2];
            (Fa(a, t), H(z[(e + 8) >> 2]));
            var _ = z[(e + 12) >> 2];
            if (_ !== 0) {
              ((h.currData = null), (z[(e + 12) >> 2] = 0));
              var n = z[(e + 16) >> 2];
              ((m) => xr(_, m))(n);
            } else {
              var i = e + 20;
              ((h.currData = i),
                (h.state = h.State.Rewinding),
                Fr(i),
                h.doRewind(i));
            }
          },
        },
        Va = (e, a) => {
          if (!oe)
            if (h.state === h.State.Normal) {
              h.state = h.State.Unwinding;
              var t = e + 20;
              (h.setDataRewindFunc(t), (h.currData = t), kr(t));
              var _ = B();
              ((z[(e + 8) >> 2] = _), (X.nextFiber = a));
            } else ((h.state = h.State.Normal), Pr(), (h.currData = null));
        };
      Va.isAsync = !0;
      var ba = () => 2147483648,
        wn = () => ba(),
        yn = () => performance.now(),
        gn = (e) => {
          var a = qe.buffer,
            t = ((e - a.byteLength + 65535) / 65536) | 0;
          try {
            return (qe.grow(t), ra(), 1);
          } catch {}
        },
        xn = (e) => {
          var a = Ae.length;
          e >>>= 0;
          var t = ba();
          if (e > t) return !1;
          for (var _ = 1; _ <= 4; _ *= 2) {
            var n = a * (1 + 0.2 / _);
            n = Math.min(n, e + 100663296);
            var i = Math.min(t, S_(Math.max(e, n), 65536)),
              m = gn(i);
            if (m) return !0;
          }
          return !1;
        },
        kn = (e, a) =>
          setTimeout(() => {
            Aa(e);
          }, a),
        ha = (e) => h.handleSleep((a) => kn(a, e));
      ha.isAsync = !0;
      var gr = {},
        Fn = () => cr || "./this.program",
        Se = () => {
          if (!Se.strings) {
            var e =
                (
                  (typeof navigator == "object" &&
                    navigator.languages &&
                    navigator.languages[0]) ||
                  "C"
                ).replace("-", "_") + ".UTF-8",
              a = {
                USER: "web_user",
                LOGNAME: "web_user",
                PATH: "/",
                PWD: "/",
                HOME: "/home/web_user",
                LANG: e,
                _: Fn(),
              };
            for (var t in gr) gr[t] === void 0 ? delete a[t] : (a[t] = gr[t]);
            var _ = [];
            for (var t in a) _.push(`${t}=${a[t]}`);
            Se.strings = _;
          }
          return Se.strings;
        },
        Pn = (e, a) => {
          for (var t = 0; t < e.length; ++t) $[a++] = e.charCodeAt(t);
          $[a] = 0;
        },
        En = (e, a) => {
          var t = 0;
          return (
            Se().forEach((_, n) => {
              var i = a + t;
              ((z[(e + n * 4) >> 2] = i), Pn(_, i), (t += _.length + 1));
            }),
            0
          );
        },
        Dn = (e, a) => {
          var t = Se();
          z[e >> 2] = t.length;
          var _ = 0;
          return (t.forEach((n) => (_ += n.length + 1)), (z[a >> 2] = _), 0);
        };
      function Sn(e) {
        try {
          var a = k.getStreamFromFD(e);
          return (o.close(a), 0);
        } catch (t) {
          if (typeof o > "u" || t.name !== "ErrnoError") throw t;
          return t.errno;
        }
      }
      function jn(e, a) {
        try {
          var t = 0,
            _ = 0,
            n = 0,
            i = k.getStreamFromFD(e),
            m = i.tty ? 2 : o.isDir(i.mode) ? 3 : o.isLink(i.mode) ? 7 : 4;
          return (
            ($[a] = m),
            (Ve[(a + 2) >> 1] = n),
            (D = [
              t >>> 0,
              ((C = t),
              +Math.abs(C) >= 1
                ? C > 0
                  ? +Math.floor(C / 4294967296) >>> 0
                  : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                : 0),
            ]),
            (V[(a + 8) >> 2] = D[0]),
            (V[(a + 12) >> 2] = D[1]),
            (D = [
              _ >>> 0,
              ((C = _),
              +Math.abs(C) >= 1
                ? C > 0
                  ? +Math.floor(C / 4294967296) >>> 0
                  : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                : 0),
            ]),
            (V[(a + 16) >> 2] = D[0]),
            (V[(a + 20) >> 2] = D[1]),
            0
          );
        } catch (l) {
          if (typeof o > "u" || l.name !== "ErrnoError") throw l;
          return l.errno;
        }
      }
      var Tn = (e, a, t, _) => {
        for (var n = 0, i = 0; i < t; i++) {
          var m = z[a >> 2],
            l = z[(a + 4) >> 2];
          a += 8;
          var u = o.read(e, $, m, l, _);
          if (u < 0) return -1;
          if (((n += u), u < l)) break;
          typeof _ < "u" && (_ += u);
        }
        return n;
      };
      function zn(e, a, t, _) {
        try {
          var n = k.getStreamFromFD(e),
            i = Tn(n, a, t);
          return ((z[_ >> 2] = i), 0);
        } catch (m) {
          if (typeof o > "u" || m.name !== "ErrnoError") throw m;
          return m.errno;
        }
      }
      function Mn(e, a, t, _, n) {
        var i = Cr(a, t);
        try {
          if (isNaN(i)) return 61;
          var m = k.getStreamFromFD(e);
          return (
            o.llseek(m, i, _),
            (D = [
              m.position >>> 0,
              ((C = m.position),
              +Math.abs(C) >= 1
                ? C > 0
                  ? +Math.floor(C / 4294967296) >>> 0
                  : ~~+Math.ceil((C - +(~~C >>> 0)) / 4294967296) >>> 0
                : 0),
            ]),
            (V[n >> 2] = D[0]),
            (V[(n + 4) >> 2] = D[1]),
            m.getdents && i === 0 && _ === 0 && (m.getdents = null),
            0
          );
        } catch (l) {
          if (typeof o > "u" || l.name !== "ErrnoError") throw l;
          return l.errno;
        }
      }
      var Rn = (e, a, t, _) => {
        for (var n = 0, i = 0; i < t; i++) {
          var m = z[a >> 2],
            l = z[(a + 4) >> 2];
          a += 8;
          var u = o.write(e, $, m, l, _);
          if (u < 0) return -1;
          if (((n += u), u < l)) break;
          typeof _ < "u" && (_ += u);
        }
        return n;
      };
      function In(e, a, t, _) {
        try {
          var n = k.getStreamFromFD(e),
            i = Rn(n, a, t);
          return ((z[_ >> 2] = i), 0);
        } catch (m) {
          if (typeof o > "u" || m.name !== "ErrnoError") throw m;
          return m.errno;
        }
      }
      var On,
        Ca = (e) => {
          var a = r["_" + e];
          return a;
        },
        Un = (e, a) => {
          $.set(e, a);
        },
        wa = (e) => Ea(e),
        Nn = (e) => {
          var a = Vr(e) + 1,
            t = wa(a);
          return (Ce(e, t, a), t);
        },
        ya = (e, a, t, _, n) => {
          var i = {
            string: (w) => {
              var F = 0;
              return (w != null && w !== 0 && (F = Nn(w)), F);
            },
            array: (w) => {
              var F = wa(w.length);
              return (Un(w, F), F);
            },
          };
          function m(w) {
            return a === "string" ? fe(w) : a === "boolean" ? !!w : w;
          }
          var l = Ca(e),
            u = [],
            f = 0;
          if (_)
            for (var d = 0; d < _.length; d++) {
              var A = i[t[d]];
              A ? (f === 0 && (f = B()), (u[d] = A(_[d]))) : (u[d] = _[d]);
            }
          var p = h.currData,
            v = l(...u);
          function b(w) {
            return (Cn(), f !== 0 && H(f), m(w));
          }
          var y = n?.async;
          return (
            hn(),
            h.currData != p
              ? h.whenDone().then(b)
              : ((v = b(v)), y ? Promise.resolve(v) : v)
          );
        },
        Ln = (e, a, t, _) => {
          var n = !t || t.every((m) => m === "number" || m === "boolean"),
            i = a !== "string";
          return i && n && !_ ? Ca(e) : (...m) => ya(e, a, t, m, _);
        };
      ((o.createPreloadedFile = R_), o.staticInit());
      var Hn = {
          a: P_,
          K: O_,
          Z: U_,
          F: N_,
          _: L_,
          n: H_,
          X: B_,
          O: q_,
          m: W_,
          T: $_,
          Q: Y_,
          U: J_,
          r: X_,
          N: G_,
          M: K_,
          W: Z_,
          I: Q_,
          $: en,
          Y: an,
          G: tn,
          B: _n,
          C: cn,
          D: ln,
          P: un,
          ca: k_,
          da: x_,
          ba: vn,
          h: pn,
          ea: Va,
          J: wn,
          k: yn,
          H: xn,
          x: ha,
          R: En,
          S: Dn,
          d: pa,
          i: Sn,
          q: jn,
          s: zn,
          E: Mn,
          l: In,
          fa: fd,
          f: cd,
          g: _d,
          j: md,
          ja: ad,
          b: sd,
          v: td,
          e: od,
          c: nd,
          o: ud,
          ga: dd,
          t: ld,
          u: id,
          A: p_,
          ma: A_,
          la: g_,
          L: v_,
          w: y_,
          na: w_,
          y: l_,
          p: b_,
          oa: h_,
          z: V_,
          ha: u_,
          V: f_,
          aa: d_,
          pa: C_,
          ka: m_,
          ia: i_,
        },
        s = s_(),
        Bn = () => (Bn = s.ra)(),
        qn = (r._ff_nothing = () => (qn = r._ff_nothing = s.sa)()),
        Wn = (r._AVFrame_crop_bottom = (e) =>
          (Wn = r._AVFrame_crop_bottom = s.ta)(e)),
        $n = (r._AVFrame_crop_bottom_s = (e, a) =>
          ($n = r._AVFrame_crop_bottom_s = s.ua)(e, a)),
        Yn = (r._AVFrame_crop_left = (e) =>
          (Yn = r._AVFrame_crop_left = s.va)(e)),
        Jn = (r._AVFrame_crop_left_s = (e, a) =>
          (Jn = r._AVFrame_crop_left_s = s.wa)(e, a)),
        Xn = (r._AVFrame_crop_right = (e) =>
          (Xn = r._AVFrame_crop_right = s.xa)(e)),
        Gn = (r._AVFrame_crop_right_s = (e, a) =>
          (Gn = r._AVFrame_crop_right_s = s.ya)(e, a)),
        Kn = (r._AVFrame_crop_top = (e) =>
          (Kn = r._AVFrame_crop_top = s.za)(e)),
        Zn = (r._AVFrame_crop_top_s = (e, a) =>
          (Zn = r._AVFrame_crop_top_s = s.Aa)(e, a)),
        Qn = (r._AVFrame_data_a = (e, a) =>
          (Qn = r._AVFrame_data_a = s.Ba)(e, a)),
        eo = (r._AVFrame_data_a_s = (e, a, t) =>
          (eo = r._AVFrame_data_a_s = s.Ca)(e, a, t)),
        ro = (r._AVFrame_format = (e) => (ro = r._AVFrame_format = s.Da)(e)),
        ao = (r._AVFrame_format_s = (e, a) =>
          (ao = r._AVFrame_format_s = s.Ea)(e, a)),
        to = (r._AVFrame_height = (e) => (to = r._AVFrame_height = s.Fa)(e)),
        _o = (r._AVFrame_height_s = (e, a) =>
          (_o = r._AVFrame_height_s = s.Ga)(e, a)),
        no = (r._AVFrame_key_frame = (e) =>
          (no = r._AVFrame_key_frame = s.Ha)(e)),
        oo = (r._AVFrame_key_frame_s = (e, a) =>
          (oo = r._AVFrame_key_frame_s = s.Ia)(e, a)),
        so = (r._AVFrame_linesize_a = (e, a) =>
          (so = r._AVFrame_linesize_a = s.Ja)(e, a)),
        co = (r._AVFrame_linesize_a_s = (e, a, t) =>
          (co = r._AVFrame_linesize_a_s = s.Ka)(e, a, t)),
        io = (r._AVFrame_nb_samples = (e) =>
          (io = r._AVFrame_nb_samples = s.La)(e)),
        mo = (r._AVFrame_nb_samples_s = (e, a) =>
          (mo = r._AVFrame_nb_samples_s = s.Ma)(e, a)),
        lo = (r._AVFrame_pict_type = (e) =>
          (lo = r._AVFrame_pict_type = s.Na)(e)),
        uo = (r._AVFrame_pict_type_s = (e, a) =>
          (uo = r._AVFrame_pict_type_s = s.Oa)(e, a)),
        fo = (r._AVFrame_pts = (e) => (fo = r._AVFrame_pts = s.Pa)(e)),
        vo = (r._AVFrame_ptshi = (e) => (vo = r._AVFrame_ptshi = s.Qa)(e)),
        po = (r._AVFrame_pts_s = (e, a) =>
          (po = r._AVFrame_pts_s = s.Ra)(e, a)),
        Ao = (r._AVFrame_ptshi_s = (e, a) =>
          (Ao = r._AVFrame_ptshi_s = s.Sa)(e, a)),
        Vo = (r._AVFrame_sample_rate = (e) =>
          (Vo = r._AVFrame_sample_rate = s.Ta)(e)),
        bo = (r._AVFrame_sample_rate_s = (e, a) =>
          (bo = r._AVFrame_sample_rate_s = s.Ua)(e, a)),
        ho = (r._AVFrame_width = (e) => (ho = r._AVFrame_width = s.Va)(e)),
        Co = (r._AVFrame_width_s = (e, a) =>
          (Co = r._AVFrame_width_s = s.Wa)(e, a)),
        wo = (r._AVFrame_sample_aspect_ratio_num = (e) =>
          (wo = r._AVFrame_sample_aspect_ratio_num = s.Xa)(e)),
        yo = (r._AVFrame_sample_aspect_ratio_den = (e) =>
          (yo = r._AVFrame_sample_aspect_ratio_den = s.Ya)(e)),
        go = (r._AVFrame_sample_aspect_ratio_num_s = (e, a) =>
          (go = r._AVFrame_sample_aspect_ratio_num_s = s.Za)(e, a)),
        xo = (r._AVFrame_sample_aspect_ratio_den_s = (e, a) =>
          (xo = r._AVFrame_sample_aspect_ratio_den_s = s._a)(e, a)),
        ko = (r._AVFrame_sample_aspect_ratio_s = (e, a, t) =>
          (ko = r._AVFrame_sample_aspect_ratio_s = s.$a)(e, a, t)),
        Fo = (r._AVFrame_time_base_num = (e) =>
          (Fo = r._AVFrame_time_base_num = s.ab)(e)),
        Po = (r._AVFrame_time_base_den = (e) =>
          (Po = r._AVFrame_time_base_den = s.bb)(e)),
        Eo = (r._AVFrame_time_base_num_s = (e, a) =>
          (Eo = r._AVFrame_time_base_num_s = s.cb)(e, a)),
        Do = (r._AVFrame_time_base_den_s = (e, a) =>
          (Do = r._AVFrame_time_base_den_s = s.db)(e, a)),
        So = (r._AVFrame_time_base_s = (e, a, t) =>
          (So = r._AVFrame_time_base_s = s.eb)(e, a, t)),
        jo = (r._AVFrame_channel_layoutmask_s = (e, a, t) =>
          (jo = r._AVFrame_channel_layoutmask_s = s.fb)(e, a, t)),
        To = (r._AVFrame_channel_layoutmask = (e) =>
          (To = r._AVFrame_channel_layoutmask = s.gb)(e)),
        zo = (r._AVFrame_channels = (e) =>
          (zo = r._AVFrame_channels = s.hb)(e)),
        Mo = (r._AVFrame_channels_s = (e, a) =>
          (Mo = r._AVFrame_channels_s = s.ib)(e, a)),
        Ro = (r._AVFrame_ch_layout_nb_channels = (e) =>
          (Ro = r._AVFrame_ch_layout_nb_channels = s.jb)(e)),
        Io = (r._AVFrame_ch_layout_nb_channels_s = (e, a) =>
          (Io = r._AVFrame_ch_layout_nb_channels_s = s.kb)(e, a)),
        Oo = (r._AVFrame_channel_layout = (e) =>
          (Oo = r._AVFrame_channel_layout = s.lb)(e)),
        Uo = (r._AVFrame_channel_layouthi = (e) =>
          (Uo = r._AVFrame_channel_layouthi = s.mb)(e)),
        No = (r._AVFrame_channel_layout_s = (e, a) =>
          (No = r._AVFrame_channel_layout_s = s.nb)(e, a)),
        Lo = (r._AVFrame_channel_layouthi_s = (e, a) =>
          (Lo = r._AVFrame_channel_layouthi_s = s.ob)(e, a)),
        Ho = (r._ff_frame_rescale_ts_js = (e, a, t, _, n) =>
          (Ho = r._ff_frame_rescale_ts_js = s.pb)(e, a, t, _, n)),
        Bo = (r._AVPixFmtDescriptor_flags = (e) =>
          (Bo = r._AVPixFmtDescriptor_flags = s.qb)(e)),
        qo = (r._AVPixFmtDescriptor_flags_s = (e, a, t) =>
          (qo = r._AVPixFmtDescriptor_flags_s = s.rb)(e, a, t)),
        Wo = (r._AVPixFmtDescriptor_nb_components = (e) =>
          (Wo = r._AVPixFmtDescriptor_nb_components = s.sb)(e)),
        $o = (r._AVPixFmtDescriptor_nb_components_s = (e, a) =>
          ($o = r._AVPixFmtDescriptor_nb_components_s = s.tb)(e, a)),
        Yo = (r._AVPixFmtDescriptor_log2_chroma_h = (e) =>
          (Yo = r._AVPixFmtDescriptor_log2_chroma_h = s.ub)(e)),
        Jo = (r._AVPixFmtDescriptor_log2_chroma_h_s = (e, a) =>
          (Jo = r._AVPixFmtDescriptor_log2_chroma_h_s = s.vb)(e, a)),
        Xo = (r._AVPixFmtDescriptor_log2_chroma_w = (e) =>
          (Xo = r._AVPixFmtDescriptor_log2_chroma_w = s.wb)(e)),
        Go = (r._AVPixFmtDescriptor_log2_chroma_w_s = (e, a) =>
          (Go = r._AVPixFmtDescriptor_log2_chroma_w_s = s.xb)(e, a)),
        Ko = (r._AVPixFmtDescriptor_comp_depth = (e, a) =>
          (Ko = r._AVPixFmtDescriptor_comp_depth = s.yb)(e, a)),
        Zo = (r._av_opt_set_int_list_js = (e, a, t, _, n, i) =>
          (Zo = r._av_opt_set_int_list_js = s.zb)(e, a, t, _, n, i)),
        Qo = (r._AVCodec_name = (e) => (Qo = r._AVCodec_name = s.Ab)(e)),
        es = (r._AVCodec_sample_fmts = (e) =>
          (es = r._AVCodec_sample_fmts = s.Bb)(e)),
        rs = (r._AVCodec_sample_fmts_s = (e, a) =>
          (rs = r._AVCodec_sample_fmts_s = s.Cb)(e, a)),
        as = (r._AVCodec_sample_fmts_a = (e, a) =>
          (as = r._AVCodec_sample_fmts_a = s.Db)(e, a)),
        ts = (r._AVCodec_sample_fmts_a_s = (e, a, t) =>
          (ts = r._AVCodec_sample_fmts_a_s = s.Eb)(e, a, t)),
        _s = (r._AVCodec_supported_samplerates = (e) =>
          (_s = r._AVCodec_supported_samplerates = s.Fb)(e)),
        ns = (r._AVCodec_supported_samplerates_s = (e, a) =>
          (ns = r._AVCodec_supported_samplerates_s = s.Gb)(e, a)),
        os = (r._AVCodec_supported_samplerates_a = (e, a) =>
          (os = r._AVCodec_supported_samplerates_a = s.Hb)(e, a)),
        ss = (r._AVCodec_supported_samplerates_a_s = (e, a, t) =>
          (ss = r._AVCodec_supported_samplerates_a_s = s.Ib)(e, a, t)),
        cs = (r._AVCodec_type = (e) => (cs = r._AVCodec_type = s.Jb)(e)),
        is = (r._AVCodec_type_s = (e, a) =>
          (is = r._AVCodec_type_s = s.Kb)(e, a)),
        ms = (r._AVCodecContext_codec_id = (e) =>
          (ms = r._AVCodecContext_codec_id = s.Lb)(e)),
        ls = (r._AVCodecContext_codec_id_s = (e, a) =>
          (ls = r._AVCodecContext_codec_id_s = s.Mb)(e, a)),
        us = (r._AVCodecContext_codec_type = (e) =>
          (us = r._AVCodecContext_codec_type = s.Nb)(e)),
        ds = (r._AVCodecContext_codec_type_s = (e, a) =>
          (ds = r._AVCodecContext_codec_type_s = s.Ob)(e, a)),
        fs = (r._AVCodecContext_bit_rate = (e) =>
          (fs = r._AVCodecContext_bit_rate = s.Pb)(e)),
        vs = (r._AVCodecContext_bit_ratehi = (e) =>
          (vs = r._AVCodecContext_bit_ratehi = s.Qb)(e)),
        ps = (r._AVCodecContext_bit_rate_s = (e, a) =>
          (ps = r._AVCodecContext_bit_rate_s = s.Rb)(e, a)),
        As = (r._AVCodecContext_bit_ratehi_s = (e, a) =>
          (As = r._AVCodecContext_bit_ratehi_s = s.Sb)(e, a)),
        Vs = (r._AVCodecContext_extradata = (e) =>
          (Vs = r._AVCodecContext_extradata = s.Tb)(e)),
        bs = (r._AVCodecContext_extradata_s = (e, a) =>
          (bs = r._AVCodecContext_extradata_s = s.Ub)(e, a)),
        hs = (r._AVCodecContext_extradata_size = (e) =>
          (hs = r._AVCodecContext_extradata_size = s.Vb)(e)),
        Cs = (r._AVCodecContext_extradata_size_s = (e, a) =>
          (Cs = r._AVCodecContext_extradata_size_s = s.Wb)(e, a)),
        ws = (r._AVCodecContext_frame_size = (e) =>
          (ws = r._AVCodecContext_frame_size = s.Xb)(e)),
        ys = (r._AVCodecContext_frame_size_s = (e, a) =>
          (ys = r._AVCodecContext_frame_size_s = s.Yb)(e, a)),
        gs = (r._AVCodecContext_gop_size = (e) =>
          (gs = r._AVCodecContext_gop_size = s.Zb)(e)),
        xs = (r._AVCodecContext_gop_size_s = (e, a) =>
          (xs = r._AVCodecContext_gop_size_s = s._b)(e, a)),
        ks = (r._AVCodecContext_height = (e) =>
          (ks = r._AVCodecContext_height = s.$b)(e)),
        Fs = (r._AVCodecContext_height_s = (e, a) =>
          (Fs = r._AVCodecContext_height_s = s.ac)(e, a)),
        Ps = (r._AVCodecContext_keyint_min = (e) =>
          (Ps = r._AVCodecContext_keyint_min = s.bc)(e)),
        Es = (r._AVCodecContext_keyint_min_s = (e, a) =>
          (Es = r._AVCodecContext_keyint_min_s = s.cc)(e, a)),
        Ds = (r._AVCodecContext_level = (e) =>
          (Ds = r._AVCodecContext_level = s.dc)(e)),
        Ss = (r._AVCodecContext_level_s = (e, a) =>
          (Ss = r._AVCodecContext_level_s = s.ec)(e, a)),
        js = (r._AVCodecContext_max_b_frames = (e) =>
          (js = r._AVCodecContext_max_b_frames = s.fc)(e)),
        Ts = (r._AVCodecContext_max_b_frames_s = (e, a) =>
          (Ts = r._AVCodecContext_max_b_frames_s = s.gc)(e, a)),
        zs = (r._AVCodecContext_pix_fmt = (e) =>
          (zs = r._AVCodecContext_pix_fmt = s.hc)(e)),
        Ms = (r._AVCodecContext_pix_fmt_s = (e, a) =>
          (Ms = r._AVCodecContext_pix_fmt_s = s.ic)(e, a)),
        Rs = (r._AVCodecContext_profile = (e) =>
          (Rs = r._AVCodecContext_profile = s.jc)(e)),
        Is = (r._AVCodecContext_profile_s = (e, a) =>
          (Is = r._AVCodecContext_profile_s = s.kc)(e, a)),
        Os = (r._AVCodecContext_rc_max_rate = (e) =>
          (Os = r._AVCodecContext_rc_max_rate = s.lc)(e)),
        Us = (r._AVCodecContext_rc_max_ratehi = (e) =>
          (Us = r._AVCodecContext_rc_max_ratehi = s.mc)(e)),
        Ns = (r._AVCodecContext_rc_max_rate_s = (e, a) =>
          (Ns = r._AVCodecContext_rc_max_rate_s = s.nc)(e, a)),
        Ls = (r._AVCodecContext_rc_max_ratehi_s = (e, a) =>
          (Ls = r._AVCodecContext_rc_max_ratehi_s = s.oc)(e, a)),
        Hs = (r._AVCodecContext_rc_min_rate = (e) =>
          (Hs = r._AVCodecContext_rc_min_rate = s.pc)(e)),
        Bs = (r._AVCodecContext_rc_min_ratehi = (e) =>
          (Bs = r._AVCodecContext_rc_min_ratehi = s.qc)(e)),
        qs = (r._AVCodecContext_rc_min_rate_s = (e, a) =>
          (qs = r._AVCodecContext_rc_min_rate_s = s.rc)(e, a)),
        Ws = (r._AVCodecContext_rc_min_ratehi_s = (e, a) =>
          (Ws = r._AVCodecContext_rc_min_ratehi_s = s.sc)(e, a)),
        $s = (r._AVCodecContext_sample_fmt = (e) =>
          ($s = r._AVCodecContext_sample_fmt = s.tc)(e)),
        Ys = (r._AVCodecContext_sample_fmt_s = (e, a) =>
          (Ys = r._AVCodecContext_sample_fmt_s = s.uc)(e, a)),
        Js = (r._AVCodecContext_sample_rate = (e) =>
          (Js = r._AVCodecContext_sample_rate = s.vc)(e)),
        Xs = (r._AVCodecContext_sample_rate_s = (e, a) =>
          (Xs = r._AVCodecContext_sample_rate_s = s.wc)(e, a)),
        Gs = (r._AVCodecContext_qmax = (e) =>
          (Gs = r._AVCodecContext_qmax = s.xc)(e)),
        Ks = (r._AVCodecContext_qmax_s = (e, a) =>
          (Ks = r._AVCodecContext_qmax_s = s.yc)(e, a)),
        Zs = (r._AVCodecContext_qmin = (e) =>
          (Zs = r._AVCodecContext_qmin = s.zc)(e)),
        Qs = (r._AVCodecContext_qmin_s = (e, a) =>
          (Qs = r._AVCodecContext_qmin_s = s.Ac)(e, a)),
        ec = (r._AVCodecContext_width = (e) =>
          (ec = r._AVCodecContext_width = s.Bc)(e)),
        rc = (r._AVCodecContext_width_s = (e, a) =>
          (rc = r._AVCodecContext_width_s = s.Cc)(e, a)),
        ac = (r._AVCodecContext_framerate_num = (e) =>
          (ac = r._AVCodecContext_framerate_num = s.Dc)(e)),
        tc = (r._AVCodecContext_framerate_den = (e) =>
          (tc = r._AVCodecContext_framerate_den = s.Ec)(e)),
        _c = (r._AVCodecContext_framerate_num_s = (e, a) =>
          (_c = r._AVCodecContext_framerate_num_s = s.Fc)(e, a)),
        nc = (r._AVCodecContext_framerate_den_s = (e, a) =>
          (nc = r._AVCodecContext_framerate_den_s = s.Gc)(e, a)),
        oc = (r._AVCodecContext_framerate_s = (e, a, t) =>
          (oc = r._AVCodecContext_framerate_s = s.Hc)(e, a, t)),
        sc = (r._AVCodecContext_sample_aspect_ratio_num = (e) =>
          (sc = r._AVCodecContext_sample_aspect_ratio_num = s.Ic)(e)),
        cc = (r._AVCodecContext_sample_aspect_ratio_den = (e) =>
          (cc = r._AVCodecContext_sample_aspect_ratio_den = s.Jc)(e)),
        ic = (r._AVCodecContext_sample_aspect_ratio_num_s = (e, a) =>
          (ic = r._AVCodecContext_sample_aspect_ratio_num_s = s.Kc)(e, a)),
        mc = (r._AVCodecContext_sample_aspect_ratio_den_s = (e, a) =>
          (mc = r._AVCodecContext_sample_aspect_ratio_den_s = s.Lc)(e, a)),
        lc = (r._AVCodecContext_sample_aspect_ratio_s = (e, a, t) =>
          (lc = r._AVCodecContext_sample_aspect_ratio_s = s.Mc)(e, a, t)),
        uc = (r._AVCodecContext_time_base_num = (e) =>
          (uc = r._AVCodecContext_time_base_num = s.Nc)(e)),
        dc = (r._AVCodecContext_time_base_den = (e) =>
          (dc = r._AVCodecContext_time_base_den = s.Oc)(e)),
        fc = (r._AVCodecContext_time_base_num_s = (e, a) =>
          (fc = r._AVCodecContext_time_base_num_s = s.Pc)(e, a)),
        vc = (r._AVCodecContext_time_base_den_s = (e, a) =>
          (vc = r._AVCodecContext_time_base_den_s = s.Qc)(e, a)),
        pc = (r._AVCodecContext_time_base_s = (e, a, t) =>
          (pc = r._AVCodecContext_time_base_s = s.Rc)(e, a, t)),
        Ac = (r._AVCodecContext_channel_layoutmask_s = (e, a, t) =>
          (Ac = r._AVCodecContext_channel_layoutmask_s = s.Sc)(e, a, t)),
        Vc = (r._AVCodecContext_channel_layoutmask = (e) =>
          (Vc = r._AVCodecContext_channel_layoutmask = s.Tc)(e)),
        bc = (r._AVCodecContext_channels = (e) =>
          (bc = r._AVCodecContext_channels = s.Uc)(e)),
        hc = (r._AVCodecContext_channels_s = (e, a) =>
          (hc = r._AVCodecContext_channels_s = s.Vc)(e, a)),
        Cc = (r._AVCodecContext_ch_layout_nb_channels = (e) =>
          (Cc = r._AVCodecContext_ch_layout_nb_channels = s.Wc)(e)),
        wc = (r._AVCodecContext_ch_layout_nb_channels_s = (e, a) =>
          (wc = r._AVCodecContext_ch_layout_nb_channels_s = s.Xc)(e, a)),
        yc = (r._AVCodecContext_channel_layout = (e) =>
          (yc = r._AVCodecContext_channel_layout = s.Yc)(e)),
        gc = (r._AVCodecContext_channel_layouthi = (e) =>
          (gc = r._AVCodecContext_channel_layouthi = s.Zc)(e)),
        xc = (r._AVCodecContext_channel_layout_s = (e, a) =>
          (xc = r._AVCodecContext_channel_layout_s = s._c)(e, a)),
        kc = (r._AVCodecContext_channel_layouthi_s = (e, a) =>
          (kc = r._AVCodecContext_channel_layouthi_s = s.$c)(e, a)),
        Fc = (r._AVCodecDescriptor_id = (e) =>
          (Fc = r._AVCodecDescriptor_id = s.ad)(e)),
        Pc = (r._AVCodecDescriptor_id_s = (e, a) =>
          (Pc = r._AVCodecDescriptor_id_s = s.bd)(e, a)),
        Ec = (r._AVCodecDescriptor_long_name = (e) =>
          (Ec = r._AVCodecDescriptor_long_name = s.cd)(e)),
        Dc = (r._AVCodecDescriptor_long_name_s = (e, a) =>
          (Dc = r._AVCodecDescriptor_long_name_s = s.dd)(e, a)),
        Sc = (r._AVCodecDescriptor_mime_types_a = (e, a) =>
          (Sc = r._AVCodecDescriptor_mime_types_a = s.ed)(e, a)),
        jc = (r._AVCodecDescriptor_mime_types_a_s = (e, a, t) =>
          (jc = r._AVCodecDescriptor_mime_types_a_s = s.fd)(e, a, t)),
        Tc = (r._AVCodecDescriptor_name = (e) =>
          (Tc = r._AVCodecDescriptor_name = s.gd)(e)),
        zc = (r._AVCodecDescriptor_name_s = (e, a) =>
          (zc = r._AVCodecDescriptor_name_s = s.hd)(e, a)),
        Mc = (r._AVCodecDescriptor_props = (e) =>
          (Mc = r._AVCodecDescriptor_props = s.id)(e)),
        Rc = (r._AVCodecDescriptor_props_s = (e, a) =>
          (Rc = r._AVCodecDescriptor_props_s = s.jd)(e, a)),
        Ic = (r._AVCodecDescriptor_type = (e) =>
          (Ic = r._AVCodecDescriptor_type = s.kd)(e)),
        Oc = (r._AVCodecDescriptor_type_s = (e, a) =>
          (Oc = r._AVCodecDescriptor_type_s = s.ld)(e, a)),
        Uc = (r._AVCodecParameters_codec_id = (e) =>
          (Uc = r._AVCodecParameters_codec_id = s.md)(e)),
        Nc = (r._AVCodecParameters_codec_id_s = (e, a) =>
          (Nc = r._AVCodecParameters_codec_id_s = s.nd)(e, a)),
        Lc = (r._AVCodecParameters_codec_tag = (e) =>
          (Lc = r._AVCodecParameters_codec_tag = s.od)(e)),
        Hc = (r._AVCodecParameters_codec_tag_s = (e, a) =>
          (Hc = r._AVCodecParameters_codec_tag_s = s.pd)(e, a)),
        Bc = (r._AVCodecParameters_codec_type = (e) =>
          (Bc = r._AVCodecParameters_codec_type = s.qd)(e)),
        qc = (r._AVCodecParameters_codec_type_s = (e, a) =>
          (qc = r._AVCodecParameters_codec_type_s = s.rd)(e, a)),
        Wc = (r._AVCodecParameters_extradata = (e) =>
          (Wc = r._AVCodecParameters_extradata = s.sd)(e)),
        $c = (r._AVCodecParameters_extradata_s = (e, a) =>
          ($c = r._AVCodecParameters_extradata_s = s.td)(e, a)),
        Yc = (r._AVCodecParameters_extradata_size = (e) =>
          (Yc = r._AVCodecParameters_extradata_size = s.ud)(e)),
        Jc = (r._AVCodecParameters_extradata_size_s = (e, a) =>
          (Jc = r._AVCodecParameters_extradata_size_s = s.vd)(e, a)),
        Xc = (r._AVCodecParameters_format = (e) =>
          (Xc = r._AVCodecParameters_format = s.wd)(e)),
        Gc = (r._AVCodecParameters_format_s = (e, a) =>
          (Gc = r._AVCodecParameters_format_s = s.xd)(e, a)),
        Kc = (r._AVCodecParameters_bit_rate = (e) =>
          (Kc = r._AVCodecParameters_bit_rate = s.yd)(e)),
        Zc = (r._AVCodecParameters_bit_rate_s = (e, a, t) =>
          (Zc = r._AVCodecParameters_bit_rate_s = s.zd)(e, a, t)),
        Qc = (r._AVCodecParameters_profile = (e) =>
          (Qc = r._AVCodecParameters_profile = s.Ad)(e)),
        ei = (r._AVCodecParameters_profile_s = (e, a) =>
          (ei = r._AVCodecParameters_profile_s = s.Bd)(e, a)),
        ri = (r._AVCodecParameters_level = (e) =>
          (ri = r._AVCodecParameters_level = s.Cd)(e)),
        ai = (r._AVCodecParameters_level_s = (e, a) =>
          (ai = r._AVCodecParameters_level_s = s.Dd)(e, a)),
        ti = (r._AVCodecParameters_width = (e) =>
          (ti = r._AVCodecParameters_width = s.Ed)(e)),
        _i = (r._AVCodecParameters_width_s = (e, a) =>
          (_i = r._AVCodecParameters_width_s = s.Fd)(e, a)),
        ni = (r._AVCodecParameters_height = (e) =>
          (ni = r._AVCodecParameters_height = s.Gd)(e)),
        oi = (r._AVCodecParameters_height_s = (e, a) =>
          (oi = r._AVCodecParameters_height_s = s.Hd)(e, a)),
        si = (r._AVCodecParameters_color_range = (e) =>
          (si = r._AVCodecParameters_color_range = s.Id)(e)),
        ci = (r._AVCodecParameters_color_range_s = (e, a) =>
          (ci = r._AVCodecParameters_color_range_s = s.Jd)(e, a)),
        ii = (r._AVCodecParameters_color_primaries = (e) =>
          (ii = r._AVCodecParameters_color_primaries = s.Kd)(e)),
        mi = (r._AVCodecParameters_color_primaries_s = (e, a) =>
          (mi = r._AVCodecParameters_color_primaries_s = s.Ld)(e, a)),
        li = (r._AVCodecParameters_color_trc = (e) =>
          (li = r._AVCodecParameters_color_trc = s.Md)(e)),
        ui = (r._AVCodecParameters_color_trc_s = (e, a) =>
          (ui = r._AVCodecParameters_color_trc_s = s.Nd)(e, a)),
        di = (r._AVCodecParameters_color_space = (e) =>
          (di = r._AVCodecParameters_color_space = s.Od)(e)),
        fi = (r._AVCodecParameters_color_space_s = (e, a) =>
          (fi = r._AVCodecParameters_color_space_s = s.Pd)(e, a)),
        vi = (r._AVCodecParameters_chroma_location = (e) =>
          (vi = r._AVCodecParameters_chroma_location = s.Qd)(e)),
        pi = (r._AVCodecParameters_chroma_location_s = (e, a) =>
          (pi = r._AVCodecParameters_chroma_location_s = s.Rd)(e, a)),
        Ai = (r._AVCodecParameters_sample_rate = (e) =>
          (Ai = r._AVCodecParameters_sample_rate = s.Sd)(e)),
        Vi = (r._AVCodecParameters_sample_rate_s = (e, a) =>
          (Vi = r._AVCodecParameters_sample_rate_s = s.Td)(e, a)),
        bi = (r._AVCodecParameters_framerate_num = (e) =>
          (bi = r._AVCodecParameters_framerate_num = s.Ud)(e)),
        hi = (r._AVCodecParameters_framerate_den = (e) =>
          (hi = r._AVCodecParameters_framerate_den = s.Vd)(e)),
        Ci = (r._AVCodecParameters_framerate_num_s = (e, a) =>
          (Ci = r._AVCodecParameters_framerate_num_s = s.Wd)(e, a)),
        wi = (r._AVCodecParameters_framerate_den_s = (e, a) =>
          (wi = r._AVCodecParameters_framerate_den_s = s.Xd)(e, a)),
        yi = (r._AVCodecParameters_framerate_s = (e, a, t) =>
          (yi = r._AVCodecParameters_framerate_s = s.Yd)(e, a, t)),
        gi = (r._AVCodecParameters_channel_layoutmask_s = (e, a, t) =>
          (gi = r._AVCodecParameters_channel_layoutmask_s = s.Zd)(e, a, t)),
        xi = (r._AVCodecParameters_channel_layoutmask = (e) =>
          (xi = r._AVCodecParameters_channel_layoutmask = s._d)(e)),
        ki = (r._AVCodecParameters_channels = (e) =>
          (ki = r._AVCodecParameters_channels = s.$d)(e)),
        Fi = (r._AVCodecParameters_channels_s = (e, a) =>
          (Fi = r._AVCodecParameters_channels_s = s.ae)(e, a)),
        Pi = (r._AVCodecParameters_ch_layout_nb_channels = (e) =>
          (Pi = r._AVCodecParameters_ch_layout_nb_channels = s.be)(e)),
        Ei = (r._AVCodecParameters_ch_layout_nb_channels_s = (e, a) =>
          (Ei = r._AVCodecParameters_ch_layout_nb_channels_s = s.ce)(e, a)),
        Di = (r._AVPacket_data = (e) => (Di = r._AVPacket_data = s.de)(e)),
        Si = (r._AVPacket_data_s = (e, a) =>
          (Si = r._AVPacket_data_s = s.ee)(e, a)),
        ji = (r._AVPacket_dts = (e) => (ji = r._AVPacket_dts = s.fe)(e)),
        Ti = (r._AVPacket_dtshi = (e) => (Ti = r._AVPacket_dtshi = s.ge)(e)),
        zi = (r._AVPacket_dts_s = (e, a) =>
          (zi = r._AVPacket_dts_s = s.he)(e, a)),
        Mi = (r._AVPacket_dtshi_s = (e, a) =>
          (Mi = r._AVPacket_dtshi_s = s.ie)(e, a)),
        Ri = (r._AVPacket_duration = (e) =>
          (Ri = r._AVPacket_duration = s.je)(e)),
        Ii = (r._AVPacket_durationhi = (e) =>
          (Ii = r._AVPacket_durationhi = s.ke)(e)),
        Oi = (r._AVPacket_duration_s = (e, a) =>
          (Oi = r._AVPacket_duration_s = s.le)(e, a)),
        Ui = (r._AVPacket_durationhi_s = (e, a) =>
          (Ui = r._AVPacket_durationhi_s = s.me)(e, a)),
        Ni = (r._AVPacket_flags = (e) => (Ni = r._AVPacket_flags = s.ne)(e)),
        Li = (r._AVPacket_flags_s = (e, a) =>
          (Li = r._AVPacket_flags_s = s.oe)(e, a)),
        Hi = (r._AVPacket_pos = (e) => (Hi = r._AVPacket_pos = s.pe)(e)),
        Bi = (r._AVPacket_poshi = (e) => (Bi = r._AVPacket_poshi = s.qe)(e)),
        qi = (r._AVPacket_pos_s = (e, a) =>
          (qi = r._AVPacket_pos_s = s.re)(e, a)),
        Wi = (r._AVPacket_poshi_s = (e, a) =>
          (Wi = r._AVPacket_poshi_s = s.se)(e, a)),
        $i = (r._AVPacket_pts = (e) => ($i = r._AVPacket_pts = s.te)(e)),
        Yi = (r._AVPacket_ptshi = (e) => (Yi = r._AVPacket_ptshi = s.ue)(e)),
        Ji = (r._AVPacket_pts_s = (e, a) =>
          (Ji = r._AVPacket_pts_s = s.ve)(e, a)),
        Xi = (r._AVPacket_ptshi_s = (e, a) =>
          (Xi = r._AVPacket_ptshi_s = s.we)(e, a)),
        Gi = (r._AVPacket_side_data = (e) =>
          (Gi = r._AVPacket_side_data = s.xe)(e)),
        Ki = (r._AVPacket_side_data_s = (e, a) =>
          (Ki = r._AVPacket_side_data_s = s.ye)(e, a)),
        Zi = (r._AVPacket_side_data_elems = (e) =>
          (Zi = r._AVPacket_side_data_elems = s.ze)(e)),
        Qi = (r._AVPacket_side_data_elems_s = (e, a) =>
          (Qi = r._AVPacket_side_data_elems_s = s.Ae)(e, a)),
        em = (r._AVPacket_size = (e) => (em = r._AVPacket_size = s.Be)(e)),
        rm = (r._AVPacket_size_s = (e, a) =>
          (rm = r._AVPacket_size_s = s.Ce)(e, a)),
        am = (r._AVPacket_stream_index = (e) =>
          (am = r._AVPacket_stream_index = s.De)(e)),
        tm = (r._AVPacket_stream_index_s = (e, a) =>
          (tm = r._AVPacket_stream_index_s = s.Ee)(e, a)),
        _m = (r._AVPacket_time_base_num = (e) =>
          (_m = r._AVPacket_time_base_num = s.Fe)(e)),
        nm = (r._AVPacket_time_base_den = (e) =>
          (nm = r._AVPacket_time_base_den = s.Ge)(e)),
        om = (r._AVPacket_time_base_num_s = (e, a) =>
          (om = r._AVPacket_time_base_num_s = s.He)(e, a)),
        sm = (r._AVPacket_time_base_den_s = (e, a) =>
          (sm = r._AVPacket_time_base_den_s = s.Ie)(e, a)),
        cm = (r._AVPacket_time_base_s = (e, a, t) =>
          (cm = r._AVPacket_time_base_s = s.Je)(e, a, t)),
        im = (r._AVPacketSideData_data = (e, a) =>
          (im = r._AVPacketSideData_data = s.Ke)(e, a)),
        mm = (r._AVPacketSideData_size = (e, a) =>
          (mm = r._AVPacketSideData_size = s.Le)(e, a)),
        lm = (r._AVPacketSideData_type = (e, a) =>
          (lm = r._AVPacketSideData_type = s.Me)(e, a)),
        um = (r._avcodec_open2_js = (e, a, t) =>
          (um = r._avcodec_open2_js = s.Ne)(e, a, t)),
        dm = (r._avcodec_open2 = (e, a, t) =>
          (dm = r._avcodec_open2 = s.Oe)(e, a, t)),
        fm = (r._av_packet_rescale_ts_js = (e, a, t, _, n) =>
          (fm = r._av_packet_rescale_ts_js = s.Pe)(e, a, t, _, n)),
        vm = (r._AVFormatContext_duration = (e) =>
          (vm = r._AVFormatContext_duration = s.Qe)(e)),
        pm = (r._AVFormatContext_durationhi = (e) =>
          (pm = r._AVFormatContext_durationhi = s.Re)(e)),
        Am = (r._AVFormatContext_duration_s = (e, a) =>
          (Am = r._AVFormatContext_duration_s = s.Se)(e, a)),
        Vm = (r._AVFormatContext_durationhi_s = (e, a) =>
          (Vm = r._AVFormatContext_durationhi_s = s.Te)(e, a)),
        bm = (r._AVFormatContext_flags = (e) =>
          (bm = r._AVFormatContext_flags = s.Ue)(e)),
        hm = (r._AVFormatContext_flags_s = (e, a) =>
          (hm = r._AVFormatContext_flags_s = s.Ve)(e, a)),
        Cm = (r._AVFormatContext_nb_streams = (e) =>
          (Cm = r._AVFormatContext_nb_streams = s.We)(e)),
        wm = (r._AVFormatContext_nb_streams_s = (e, a) =>
          (wm = r._AVFormatContext_nb_streams_s = s.Xe)(e, a)),
        ym = (r._AVFormatContext_oformat = (e) =>
          (ym = r._AVFormatContext_oformat = s.Ye)(e)),
        gm = (r._AVFormatContext_oformat_s = (e, a) =>
          (gm = r._AVFormatContext_oformat_s = s.Ze)(e, a)),
        xm = (r._AVFormatContext_pb = (e) =>
          (xm = r._AVFormatContext_pb = s._e)(e)),
        km = (r._AVFormatContext_pb_s = (e, a) =>
          (km = r._AVFormatContext_pb_s = s.$e)(e, a)),
        Fm = (r._AVFormatContext_start_time = (e) =>
          (Fm = r._AVFormatContext_start_time = s.af)(e)),
        Pm = (r._AVFormatContext_start_timehi = (e) =>
          (Pm = r._AVFormatContext_start_timehi = s.bf)(e)),
        Em = (r._AVFormatContext_start_time_s = (e, a) =>
          (Em = r._AVFormatContext_start_time_s = s.cf)(e, a)),
        Dm = (r._AVFormatContext_start_timehi_s = (e, a) =>
          (Dm = r._AVFormatContext_start_timehi_s = s.df)(e, a)),
        Sm = (r._AVFormatContext_streams_a = (e, a) =>
          (Sm = r._AVFormatContext_streams_a = s.ef)(e, a)),
        jm = (r._AVFormatContext_streams_a_s = (e, a, t) =>
          (jm = r._AVFormatContext_streams_a_s = s.ff)(e, a, t)),
        Tm = (r._AVStream_codecpar = (e) =>
          (Tm = r._AVStream_codecpar = s.gf)(e)),
        zm = (r._AVStream_codecpar_s = (e, a) =>
          (zm = r._AVStream_codecpar_s = s.hf)(e, a)),
        Mm = (r._AVStream_discard = (e) =>
          (Mm = r._AVStream_discard = s.jf)(e)),
        Rm = (r._AVStream_discard_s = (e, a) =>
          (Rm = r._AVStream_discard_s = s.kf)(e, a)),
        Im = (r._AVStream_duration = (e) =>
          (Im = r._AVStream_duration = s.lf)(e)),
        Om = (r._AVStream_durationhi = (e) =>
          (Om = r._AVStream_durationhi = s.mf)(e)),
        Um = (r._AVStream_duration_s = (e, a) =>
          (Um = r._AVStream_duration_s = s.nf)(e, a)),
        Nm = (r._AVStream_durationhi_s = (e, a) =>
          (Nm = r._AVStream_durationhi_s = s.of)(e, a)),
        Lm = (r._AVStream_time_base_num = (e) =>
          (Lm = r._AVStream_time_base_num = s.pf)(e)),
        Hm = (r._AVStream_time_base_den = (e) =>
          (Hm = r._AVStream_time_base_den = s.qf)(e)),
        Bm = (r._AVStream_time_base_num_s = (e, a) =>
          (Bm = r._AVStream_time_base_num_s = s.rf)(e, a)),
        qm = (r._AVStream_time_base_den_s = (e, a) =>
          (qm = r._AVStream_time_base_den_s = s.sf)(e, a)),
        Wm = (r._AVStream_time_base_s = (e, a, t) =>
          (Wm = r._AVStream_time_base_s = s.tf)(e, a, t)),
        $m = (r._avformat_seek_file_min = (e, a, t, _, n) =>
          ($m = r._avformat_seek_file_min = s.uf)(e, a, t, _, n)),
        Ym = (r._avformat_seek_file = (e, a, t, _, n, i, m, l, u) =>
          (Ym = r._avformat_seek_file = s.vf)(e, a, t, _, n, i, m, l, u)),
        Jm = (r._avformat_seek_file_max = (e, a, t, _, n) =>
          (Jm = r._avformat_seek_file_max = s.wf)(e, a, t, _, n)),
        Xm = (r._avformat_seek_file_approx = (e, a, t, _, n) =>
          (Xm = r._avformat_seek_file_approx = s.xf)(e, a, t, _, n)),
        Gm = (r._AVFilterInOut_filter_ctx = (e) =>
          (Gm = r._AVFilterInOut_filter_ctx = s.yf)(e)),
        Km = (r._AVFilterInOut_filter_ctx_s = (e, a) =>
          (Km = r._AVFilterInOut_filter_ctx_s = s.zf)(e, a)),
        Zm = (r._AVFilterInOut_name = (e) =>
          (Zm = r._AVFilterInOut_name = s.Af)(e)),
        Qm = (r._AVFilterInOut_name_s = (e, a) =>
          (Qm = r._AVFilterInOut_name_s = s.Bf)(e, a)),
        el = (r._AVFilterInOut_next = (e) =>
          (el = r._AVFilterInOut_next = s.Cf)(e)),
        rl = (r._AVFilterInOut_next_s = (e, a) =>
          (rl = r._AVFilterInOut_next_s = s.Df)(e, a)),
        al = (r._AVFilterInOut_pad_idx = (e) =>
          (al = r._AVFilterInOut_pad_idx = s.Ef)(e)),
        tl = (r._AVFilterInOut_pad_idx_s = (e, a) =>
          (tl = r._AVFilterInOut_pad_idx_s = s.Ff)(e, a)),
        _l = (r._av_buffersink_get_time_base_num = (e) =>
          (_l = r._av_buffersink_get_time_base_num = s.Gf)(e)),
        nl = (r._av_buffersink_get_time_base_den = (e) =>
          (nl = r._av_buffersink_get_time_base_den = s.Hf)(e)),
        ol = (r._ff_buffersink_set_ch_layout = (e, a, t) =>
          (ol = r._ff_buffersink_set_ch_layout = s.If)(e, a, t)),
        sl = (r._av_opt_set = (e, a, t, _) =>
          (sl = r._av_opt_set = s.Jf)(e, a, t, _)),
        cl = (r._libavjs_with_swscale = () =>
          (cl = r._libavjs_with_swscale = s.Kf)()),
        il = (r._libavjs_create_main_thread = () =>
          (il = r._libavjs_create_main_thread = s.Lf)()),
        ml = (r._avformat_alloc_output_context2_js = (e, a, t) =>
          (ml = r._avformat_alloc_output_context2_js = s.Mf)(e, a, t)),
        ll = (r._avformat_open_input_js = (e, a, t) =>
          (ll = r._avformat_open_input_js = s.Nf)(e, a, t)),
        ul = (r._avformat_open_input = (e, a, t, _) =>
          (ul = r._avformat_open_input = s.Of)(e, a, t, _)),
        dl = (r._avio_open2_js = (e, a, t, _) =>
          (dl = r._avio_open2_js = s.Pf)(e, a, t, _)),
        fl = (r._avfilter_graph_create_filter_js = (e, a, t, _, n) =>
          (fl = r._avfilter_graph_create_filter_js = s.Qf)(e, a, t, _, n)),
        vl = (r._av_dict_copy_js = (e, a, t) =>
          (vl = r._av_dict_copy_js = s.Rf)(e, a, t)),
        pl = (r._av_dict_set_js = (e, a, t, _) =>
          (pl = r._av_dict_set_js = s.Sf)(e, a, t, _)),
        Al = (r._av_compare_ts_js = (e, a, t, _, n, i, m, l) =>
          (Al = r._av_compare_ts_js = s.Tf)(e, a, t, _, n, i, m, l)),
        Vl = (r._ff_error = (e) => (Vl = r._ff_error = s.Uf)(e)),
        bl = (r._mallinfo_uordblks = () =>
          (bl = r._mallinfo_uordblks = s.Vf)()),
        hl = (r._av_dict_free = (e) => (hl = r._av_dict_free = s.Wf)(e)),
        Cl = (r._av_log_set_level = (e) =>
          (Cl = r._av_log_set_level = s.Xf)(e)),
        wl = (r._av_strdup = (e) => (wl = r._av_strdup = s.Yf)(e)),
        yl = (r._avcodec_free_context = (e) =>
          (yl = r._avcodec_free_context = s._f)(e)),
        gl = (r._av_frame_free = (e) => (gl = r._av_frame_free = s.$f)(e)),
        xl = (r._av_packet_free = (e) => (xl = r._av_packet_free = s.ag)(e)),
        kl = (r._av_frame_alloc = () => (kl = r._av_frame_alloc = s.bg)()),
        Fl = (r._av_packet_alloc = () => (Fl = r._av_packet_alloc = s.cg)()),
        Pl = (r._avcodec_alloc_context3 = (e) =>
          (Pl = r._avcodec_alloc_context3 = s.dg)(e)),
        El = (r._avcodec_parameters_to_context = (e, a) =>
          (El = r._avcodec_parameters_to_context = s.eg)(e, a)),
        Dl = (r._avcodec_find_decoder_by_name = (e) =>
          (Dl = r._avcodec_find_decoder_by_name = s.fg)(e)),
        Sl = (r._avcodec_find_decoder = (e) =>
          (Sl = r._avcodec_find_decoder = s.gg)(e)),
        jl = (r._avcodec_descriptor_get = (e) =>
          (jl = r._avcodec_descriptor_get = s.hg)(e)),
        Tl = (r._av_frame_unref = (e) => (Tl = r._av_frame_unref = s.ig)(e)),
        zl = (r._avcodec_send_packet = (e, a) =>
          (zl = r._avcodec_send_packet = s.jg)(e, a)),
        Ml = (r._avcodec_receive_frame = (e, a) =>
          (Ml = r._avcodec_receive_frame = s.kg)(e, a)),
        Rl = (r._av_frame_ref = (e, a) => (Rl = r._av_frame_ref = s.lg)(e, a)),
        Il = (r._av_packet_unref = (e) => (Il = r._av_packet_unref = s.mg)(e)),
        Ol = (r._avcodec_flush_buffers = (e) =>
          (Ol = r._avcodec_flush_buffers = s.ng)(e)),
        Ul = (r._av_pix_fmt_desc_get = (e) =>
          (Ul = r._av_pix_fmt_desc_get = s.og)(e)),
        Nl = (r._avformat_close_input = (e) =>
          (Nl = r._avformat_close_input = s.pg)(e)),
        Ll = (r._avcodec_parameters_free = (e) =>
          (Ll = r._avcodec_parameters_free = s.qg)(e)),
        Hl = (r._avcodec_get_name = (e) =>
          (Hl = r._avcodec_get_name = s.rg)(e)),
        Bl = (r._av_find_input_format = (e) =>
          (Bl = r._av_find_input_format = s.sg)(e)),
        ql = (r._avformat_alloc_context = () =>
          (ql = r._avformat_alloc_context = s.tg)()),
        Wl = (r._avformat_free_context = (e) =>
          (Wl = r._avformat_free_context = s.ug)(e)),
        $l = (r._avformat_find_stream_info = (e, a) =>
          ($l = r._avformat_find_stream_info = s.vg)(e, a)),
        Yl = (r._avio_close = (e) => (Yl = r._avio_close = s.wg)(e)),
        Jl = (r._avcodec_parameters_alloc = () =>
          (Jl = r._avcodec_parameters_alloc = s.xg)()),
        Xl = (r._avcodec_parameters_copy = (e, a) =>
          (Xl = r._avcodec_parameters_copy = s.yg)(e, a)),
        Gl = (r._av_read_frame = (e, a) =>
          (Gl = r._av_read_frame = s.zg)(e, a)),
        Kl = (r._av_get_bytes_per_sample = (e) =>
          (Kl = r._av_get_bytes_per_sample = s.Ag)(e)),
        Zl = (r._avcodec_parameters_from_context = (e, a) =>
          (Zl = r._avcodec_parameters_from_context = s.Bg)(e, a)),
        Ql = (r._avio_flush = (e) => (Ql = r._avio_flush = s.Cg)(e)),
        eu = (r._av_shrink_packet = (e, a) =>
          (eu = r._av_shrink_packet = s.Dg)(e, a)),
        ru = (r._avcodec_send_frame = (e, a) =>
          (ru = r._avcodec_send_frame = s.Eg)(e, a)),
        au = (r._avcodec_receive_packet = (e, a) =>
          (au = r._avcodec_receive_packet = s.Fg)(e, a)),
        tu = (r._avfilter_graph_alloc = () =>
          (tu = r._avfilter_graph_alloc = s.Gg)()),
        _u = (r._avfilter_inout_free = (e) =>
          (_u = r._avfilter_inout_free = s.Hg)(e)),
        nu = (r._avfilter_graph_free = (e) =>
          (nu = r._avfilter_graph_free = s.Ig)(e)),
        ou = (r._av_get_sample_fmt_name = (e) =>
          (ou = r._av_get_sample_fmt_name = s.Jg)(e)),
        su = (r._av_buffersrc_add_frame_flags = (e, a, t) =>
          (su = r._av_buffersrc_add_frame_flags = s.Kg)(e, a, t)),
        cu = (r._avfilter_get_by_name = (e) =>
          (cu = r._avfilter_get_by_name = s.Lg)(e)),
        iu = (r._avfilter_link = (e, a, t, _) =>
          (iu = r._avfilter_link = s.Mg)(e, a, t, _)),
        mu = (r._avfilter_graph_config = (e, a) =>
          (mu = r._avfilter_graph_config = s.Ng)(e, a)),
        lu = (r._av_frame_get_buffer = (e, a) =>
          (lu = r._av_frame_get_buffer = s.Og)(e, a)),
        uu = (r._avcodec_find_encoder = (e) =>
          (uu = r._avcodec_find_encoder = s.Pg)(e)),
        du = (r._avformat_new_stream = (e, a) =>
          (du = r._avformat_new_stream = s.Qg)(e, a)),
        fu = (r._strerror = (e) => (fu = r._strerror = s.Rg)(e)),
        vu = (r._avformat_write_header = (e, a) =>
          (vu = r._avformat_write_header = s.Sg)(e, a)),
        pu = (r._av_write_trailer = (e) =>
          (pu = r._av_write_trailer = s.Tg)(e)),
        Au = (r._av_interleaved_write_frame = (e, a) =>
          (Au = r._av_interleaved_write_frame = s.Ug)(e, a)),
        Vu = (r._ffmpeg_get_out_time_ms = () =>
          (Vu = r._ffmpeg_get_out_time_ms = s.Vg)()),
        bu = (r._ffmpeg_get_total_size_bytes = () =>
          (bu = r._ffmpeg_get_total_size_bytes = s.Wg)()),
        hu = (r._ffmpeg_interrupt = () => (hu = r._ffmpeg_interrupt = s.Xg)()),
        Cu = (r._ffmpeg_main = (e, a) => (Cu = r._ffmpeg_main = s.Yg)(e, a)),
        wu = (r._av_log_get_level = () => (wu = r._av_log_get_level = s.Zg)()),
        yu = (r._avcodec_find_encoder_by_name = (e) =>
          (yu = r._avcodec_find_encoder_by_name = s._g)(e)),
        gu = (r._avcodec_descriptor_get_by_name = (e) =>
          (gu = r._avcodec_descriptor_get_by_name = s.$g)(e)),
        xu = (r._av_packet_ref = (e, a) =>
          (xu = r._av_packet_ref = s.ah)(e, a)),
        ku = (r._ffprobe_main = (e, a) => (ku = r._ffprobe_main = s.bh)(e, a)),
        Fu = (r._avcodec_descriptor_next = (e) =>
          (Fu = r._avcodec_descriptor_next = s.ch)(e)),
        Pu = (r._av_frame_clone = (e) => (Pu = r._av_frame_clone = s.dh)(e)),
        Eu = (r._av_frame_make_writable = (e) =>
          (Eu = r._av_frame_make_writable = s.eh)(e)),
        ga = (r._free = (e) => (ga = r._free = s.fh)(e)),
        Du = (r._open = (e, a, t) => (Du = r._open = s.gh)(e, a, t)),
        Su = (r._av_find_best_stream = (e, a, t, _, n, i) =>
          (Su = r._av_find_best_stream = s.hh)(e, a, t, _, n, i)),
        ju = (r._av_seek_frame = (e, a, t, _, n) =>
          (ju = r._av_seek_frame = s.ih)(e, a, t, _, n)),
        Tu = (r._av_packet_new_side_data = (e, a, t) =>
          (Tu = r._av_packet_new_side_data = s.jh)(e, a, t)),
        zu = (r._av_write_frame = (e, a) =>
          (zu = r._av_write_frame = s.kh)(e, a)),
        Mu = (r._jsfetch_set_fetch_timeout = (e) =>
          (Mu = r._jsfetch_set_fetch_timeout = s.lh)(e)),
        Ru = (r._jsfetch_set_read_timeout = (e) =>
          (Ru = r._jsfetch_set_read_timeout = s.mh)(e)),
        Iu = (r._jsfetch_set_initial_retry_delay = (e) =>
          (Iu = r._jsfetch_set_initial_retry_delay = s.nh)(e)),
        Ou = (r._jsfetch_set_bypass_cache = (e) =>
          (Ou = r._jsfetch_set_bypass_cache = s.oh)(e)),
        Uu = (r._av_grow_packet = (e, a) =>
          (Uu = r._av_grow_packet = s.ph)(e, a)),
        Nu = (r._av_packet_make_writable = (e) =>
          (Nu = r._av_packet_make_writable = s.qh)(e)),
        Lu = (r._close = (e) => (Lu = r._close = s.rh)(e)),
        Hu = (r._avformat_flush = (e) => (Hu = r._avformat_flush = s.sh)(e)),
        Bu = (r._avcodec_close = (e) => (Bu = r._avcodec_close = s.th)(e)),
        qu = (r._av_packet_clone = (e) => (qu = r._av_packet_clone = s.uh)(e)),
        Wu = (r._avfilter_free = (e) => (Wu = r._avfilter_free = s.vh)(e)),
        $u = (r._av_buffersink_get_frame = (e, a) =>
          ($u = r._av_buffersink_get_frame = s.wh)(e, a)),
        Yu = (r._av_buffersink_set_frame_size = (e, a) =>
          (Yu = r._av_buffersink_set_frame_size = s.xh)(e, a)),
        Ju = (r._avfilter_inout_alloc = () =>
          (Ju = r._avfilter_inout_alloc = s.yh)()),
        Xu = (r._avfilter_graph_parse = (e, a, t, _, n) =>
          (Xu = r._avfilter_graph_parse = s.zh)(e, a, t, _, n)),
        Gu = (r._sws_scale_frame = (e, a, t) =>
          (Gu = r._sws_scale_frame = s.Ah)(e, a, t)),
        Ku = (r._sws_getContext = (e, a, t, _, n, i, m, l, u, f) =>
          (Ku = r._sws_getContext = s.Bh)(e, a, t, _, n, i, m, l, u, f)),
        Zu = (r._sws_freeContext = (e) => (Zu = r._sws_freeContext = s.Ch)(e)),
        Qu = (r._calloc = (e, a) => (Qu = r._calloc = s.Dh)(e, a)),
        xa = (r._malloc = (e) => (xa = r._malloc = s.Eh)(e)),
        ed = (r._emfiberthreads_timeout_expiry = (e, a) =>
          (ed = r._emfiberthreads_timeout_expiry = s.Fh)(e, a)),
        rd = (r._dup2 = (e, a) => (rd = r._dup2 = s.Gh)(e, a)),
        Y = (e, a) => (Y = s.Hh)(e, a),
        ka = (e) => (ka = s.Ih)(e),
        Fa = (e, a) => (Fa = s.Jh)(e, a),
        Pa = (e) => (Pa = s.Kh)(e),
        Ea = (e) => (Ea = s.Lh)(e),
        Da = () => (Da = s.Mh)(),
        Sa = (r.dynCall_iiii = (e, a, t, _) =>
          (Sa = r.dynCall_iiii = s.Nh)(e, a, t, _)),
        ja = (r.dynCall_ii = (e, a) => (ja = r.dynCall_ii = s.Oh)(e, a)),
        Ta = (r.dynCall_iii = (e, a, t) =>
          (Ta = r.dynCall_iii = s.Ph)(e, a, t)),
        za = (r.dynCall_vii = (e, a, t) =>
          (za = r.dynCall_vii = s.Qh)(e, a, t)),
        xr = (r.dynCall_vi = (e, a) => (xr = r.dynCall_vi = s.Rh)(e, a)),
        Ma = (r.dynCall_viii = (e, a, t, _) =>
          (Ma = r.dynCall_viii = s.Sh)(e, a, t, _)),
        Ra = (r.dynCall_iiiii = (e, a, t, _, n) =>
          (Ra = r.dynCall_iiiii = s.Th)(e, a, t, _, n)),
        Ia = (r.dynCall_i = (e) => (Ia = r.dynCall_i = s.Uh)(e)),
        Oa = (r.dynCall_viiii = (e, a, t, _, n) =>
          (Oa = r.dynCall_viiii = s.Vh)(e, a, t, _, n)),
        Ua = (r.dynCall_viiiiii = (e, a, t, _, n, i, m) =>
          (Ua = r.dynCall_viiiiii = s.Wh)(e, a, t, _, n, i, m)),
        Na = (r.dynCall_viiiii = (e, a, t, _, n, i) =>
          (Na = r.dynCall_viiiii = s.Xh)(e, a, t, _, n, i)),
        La = (r.dynCall_viiiiiiii = (e, a, t, _, n, i, m, l, u) =>
          (La = r.dynCall_viiiiiiii = s.Yh)(e, a, t, _, n, i, m, l, u)),
        Ha = (r.dynCall_viiiiiii = (e, a, t, _, n, i, m, l) =>
          (Ha = r.dynCall_viiiiiii = s.Zh)(e, a, t, _, n, i, m, l)),
        kr = (e) => (kr = s._h)(e),
        Ba = () => (Ba = s.$h)(),
        Fr = (e) => (Fr = s.ai)(e),
        Pr = () => (Pr = s.bi)(),
        Hv = (r._ff_h264_cabac_tables = 503244);
      function ad(e, a, t, _, n) {
        var i = B();
        try {
          return Ra(e, a, t, _, n);
        } catch (m) {
          if ((H(i), m !== m + 0)) throw m;
          Y(1, 0);
        }
      }
      function td(e, a, t) {
        var _ = B();
        try {
          za(e, a, t);
        } catch (n) {
          if ((H(_), n !== n + 0)) throw n;
          Y(1, 0);
        }
      }
      function _d(e, a, t) {
        var _ = B();
        try {
          return Ta(e, a, t);
        } catch (n) {
          if ((H(_), n !== n + 0)) throw n;
          Y(1, 0);
        }
      }
      function nd(e, a, t, _, n) {
        var i = B();
        try {
          Oa(e, a, t, _, n);
        } catch (m) {
          if ((H(i), m !== m + 0)) throw m;
          Y(1, 0);
        }
      }
      function od(e, a, t, _) {
        var n = B();
        try {
          Ma(e, a, t, _);
        } catch (i) {
          if ((H(n), i !== i + 0)) throw i;
          Y(1, 0);
        }
      }
      function sd(e, a) {
        var t = B();
        try {
          xr(e, a);
        } catch (_) {
          if ((H(t), _ !== _ + 0)) throw _;
          Y(1, 0);
        }
      }
      function cd(e, a) {
        var t = B();
        try {
          return ja(e, a);
        } catch (_) {
          if ((H(t), _ !== _ + 0)) throw _;
          Y(1, 0);
        }
      }
      function id(e, a, t, _, n, i, m, l, u) {
        var f = B();
        try {
          La(e, a, t, _, n, i, m, l, u);
        } catch (d) {
          if ((H(f), d !== d + 0)) throw d;
          Y(1, 0);
        }
      }
      function md(e, a, t, _) {
        var n = B();
        try {
          return Sa(e, a, t, _);
        } catch (i) {
          if ((H(n), i !== i + 0)) throw i;
          Y(1, 0);
        }
      }
      function ld(e, a, t, _, n, i, m, l) {
        var u = B();
        try {
          Ha(e, a, t, _, n, i, m, l);
        } catch (f) {
          if ((H(u), f !== f + 0)) throw f;
          Y(1, 0);
        }
      }
      function ud(e, a, t, _, n, i) {
        var m = B();
        try {
          Na(e, a, t, _, n, i);
        } catch (l) {
          if ((H(m), l !== l + 0)) throw l;
          Y(1, 0);
        }
      }
      function dd(e, a, t, _, n, i, m) {
        var l = B();
        try {
          Ua(e, a, t, _, n, i, m);
        } catch (u) {
          if ((H(l), u !== u + 0)) throw u;
          Y(1, 0);
        }
      }
      function fd(e) {
        var a = B();
        try {
          return Ia(e);
        } catch (t) {
          if ((H(a), t !== t + 0)) throw t;
          Y(1, 0);
        }
      }
      ((r.ccall = ya), (r.cwrap = Ln));
      var Xe;
      De = function e() {
        (Xe || qa(), Xe || (De = e));
      };
      function qa() {
        if (de > 0 || (Gt(), de > 0)) return;
        function e() {
          Xe ||
            ((Xe = !0),
            (r.calledRun = !0),
            !oe && (Kt(), N(r), r.onRuntimeInitialized?.(), Zt()));
        }
        r.setStatus
          ? (r.setStatus("Running..."),
            setTimeout(() => {
              (setTimeout(() => r.setStatus(""), 1), e());
            }, 1))
          : e();
      }
      if (r.preInit)
        for (
          typeof r.preInit == "function" && (r.preInit = [r.preInit]);
          r.preInit.length > 0;
        )
          r.preInit.pop()();
      qa();
      var je = null;
      function U(e) {
        var a;
        return (
          je
            ? (a = je
                .catch(function () {})
                .then(function () {
                  return e();
                }))
            : (a = e()),
          (je = a =
            a.finally(function () {
              je === a && (je = null);
            })),
          a
        );
      }
      r.fsThrownError = null;
      var R = { EPERM: 1, EIO: 5, EAGAIN: 6, ECANCELED: 11, ESPIPE: 29 },
        vd = {
          open: function (e) {
            if (e.flags & 3) throw new o.ErrnoError(R.EPERM);
          },
          close: function () {},
          read: function (e, a, t, _, n) {
            var i = r.readBuffers[e.node.name];
            if (!i || (i.buf.length === 0 && !i.eof)) {
              if (r.onread)
                try {
                  var m = r.onread(e.node.name, n, _);
                  m &&
                    m.then &&
                    m.catch &&
                    m.catch(function (u) {
                      Tt(e.node.name, null, { error: u });
                    });
                } catch (u) {
                  Tt(e.node.name, null, { error: u });
                }
              i = r.readBuffers[e.node.name];
            }
            if (!i) throw new o.ErrnoError(R.EAGAIN);
            if (i.error)
              throw (
                (r.fsThrownError = i.error),
                new o.ErrnoError(R.ECANCELED)
              );
            if (i.errorCode) throw new o.ErrnoError(i.errorCode);
            if (i.buf.length === 0) {
              if (i.eof) return 0;
              throw ((i.ready = !1), new o.ErrnoError(R.EAGAIN));
            }
            var l;
            return (
              _ < i.buf.length
                ? ((l = i.buf.subarray(0, _)), (i.buf = i.buf.slice(_)))
                : ((l = i.buf), (i.buf = new Uint8Array(0))),
              new Uint8Array(a.buffer).set(l, t),
              l.length
            );
          },
          write: function () {
            throw new o.ErrnoError(R.EIO);
          },
          llseek: function () {
            throw new o.ErrnoError(R.ESPIPE);
          },
        },
        pd = {
          open: function (e) {
            if (e.flags & 3) throw new o.ErrnoError(R.EPERM);
          },
          close: function () {},
          read: function (e, a, t, _, n) {
            var i = r.blockReadBuffers[e.node.name];
            if (!i) throw new o.ErrnoError(R.EAGAIN);
            if (i.error)
              throw (
                (r.fsThrownError = i.error),
                new o.ErrnoError(R.ECANCELED)
              );
            if (i.errorCode) throw new o.ErrnoError(i.errorCode);
            var m = i.position,
              l = i.position + i.buf.length;
            if (n < m || n >= l) {
              if (n >= e.node.ff_block_reader_dev_size) return 0;
              if (!r.onblockread) throw new o.ErrnoError(R.EIO);
              try {
                var u = r.onblockread(e.node.name, n, _);
                u &&
                  u.then &&
                  u.catch &&
                  u.catch(function (A) {
                    zt(e.node.name, n, null, { error: A });
                  });
              } catch (A) {
                throw ((r.fsThrownError = A), new o.ErrnoError(R.ECANCELED));
              }
              if (
                ((m = i.position),
                (l = i.position + i.buf.length),
                n < m || n >= l)
              )
                throw ((i.ready = !1), new o.ErrnoError(R.EAGAIN));
            }
            var f = n - m,
              d;
            return (
              f + _ < i.buf.length
                ? (d = i.buf.subarray(f, f + _))
                : (d = i.buf.subarray(f, i.buf.length)),
              new Uint8Array(a.buffer).set(d, t),
              d.length
            );
          },
          write: function () {
            throw new o.ErrnoError(R.EIO);
          },
          llseek: function (e, a, t) {
            return (
              t === 2 ? (a = e.node.size + a) : t === 1 && (a += e.position),
              a
            );
          },
        },
        Ge = {
          open: function (e) {
            if (!(e.flags & 1)) throw new o.ErrnoError(R.EPERM);
          },
          close: function () {},
          read: function () {
            throw new o.ErrnoError(R.EIO);
          },
          write: function (e, a, t, _, n) {
            if (!r.onwrite) throw new o.ErrnoError(R.EIO);
            return (r.onwrite(e.node.name, n, a.subarray(t, t + _)), _);
          },
          llseek: function (e, a, t) {
            if (t === 2) throw new o.ErrnoError(R.EIO);
            return (t === 1 && (a += e.position), a);
          },
        },
        Er = Object.create(Ge);
      ((Er.write = function (e, a, t, _, n) {
        if (n != e.position) throw new o.ErrnoError(R.ESPIPE);
        return Ge.write(e, a, t, _, n);
      }),
        (Er.llseek = function () {
          throw new o.ErrnoError(R.ESPIPE);
        }));
      var ae = Object.create(x);
      ((ae.mount = function (e) {
        return ae.createNode(null, "/", 16895, 0);
      }),
        (ae.createNode = function () {
          var e = x.createNode.apply(x, arguments);
          return (
            o.isDir(e.mode)
              ? (ae.dir_node_ops ||
                  ((ae.dir_node_ops = Object.create(e.node_ops)),
                  (ae.dir_node_ops.mknod = function (a, t, _, n) {
                    return ae.createNode(a, t, _, n);
                  })),
                (e.node_ops = ae.dir_node_ops))
              : o.isFile(e.mode) && (e.stream_ops = Ge),
            e
          );
        }));
      var c = {},
        Bv =
          (r.av_get_bytes_per_sample =
          c.av_get_bytes_per_sample =
            r.cwrap("av_get_bytes_per_sample", "number", ["number"])),
        qv =
          (r.av_compare_ts_js =
          c.av_compare_ts_js =
            r.cwrap("av_compare_ts_js", "number", [
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
            ])),
        Wv =
          (r.av_opt_set =
          c.av_opt_set =
            r.cwrap("av_opt_set", "number", [
              "number",
              "string",
              "string",
              "number",
            ])),
        Dr =
          (r.av_opt_set_int_list_js =
          c.av_opt_set_int_list_js =
            r.cwrap("av_opt_set_int_list_js", "number", [
              "number",
              "string",
              "number",
              "number",
              "number",
              "number",
            ])),
        Wa =
          (r.av_frame_alloc =
          c.av_frame_alloc =
            r.cwrap("av_frame_alloc", "number", [])),
        Ad =
          (r.av_frame_clone =
          c.av_frame_clone =
            r.cwrap("av_frame_clone", "number", ["number", "number"])),
        $v =
          (r.av_frame_free =
          c.av_frame_free =
            r.cwrap("av_frame_free", null, ["number"])),
        $a =
          (r.av_frame_get_buffer =
          c.av_frame_get_buffer =
            r.cwrap("av_frame_get_buffer", "number", ["number", "number"])),
        Ya =
          (r.av_frame_make_writable =
          c.av_frame_make_writable =
            r.cwrap("av_frame_make_writable", "number", ["number"])),
        Vd =
          (r.av_frame_ref =
          c.av_frame_ref =
            r.cwrap("av_frame_ref", "number", ["number", "number"])),
        we =
          (r.av_frame_unref =
          c.av_frame_unref =
            r.cwrap("av_frame_unref", null, ["number"])),
        Ja =
          (r.ff_frame_rescale_ts_js =
          c.ff_frame_rescale_ts_js =
            r.cwrap("ff_frame_rescale_ts_js", null, [
              "number",
              "number",
              "number",
              "number",
              "number",
            ])),
        Yv =
          (r.av_log_get_level =
          c.av_log_get_level =
            r.cwrap("av_log_get_level", "number", [])),
        Jv =
          (r.av_log_set_level =
          c.av_log_set_level =
            r.cwrap("av_log_set_level", null, ["number"])),
        Xa =
          (r.av_packet_alloc =
          c.av_packet_alloc =
            r.cwrap("av_packet_alloc", "number", [])),
        bd =
          (r.av_packet_clone =
          c.av_packet_clone =
            r.cwrap("av_packet_clone", "number", ["number"])),
        Xv =
          (r.av_packet_free =
          c.av_packet_free =
            r.cwrap("av_packet_free", null, ["number"])),
        hd =
          (r.av_packet_new_side_data =
          c.av_packet_new_side_data =
            r.cwrap("av_packet_new_side_data", "number", [
              "number",
              "number",
              "number",
            ])),
        Cd =
          (r.av_packet_ref =
          c.av_packet_ref =
            r.cwrap("av_packet_ref", "number", ["number", "number"])),
        Sr =
          (r.av_packet_rescale_ts_js =
          c.av_packet_rescale_ts_js =
            r.cwrap("av_packet_rescale_ts_js", null, [
              "number",
              "number",
              "number",
              "number",
              "number",
            ])),
        Q =
          (r.av_packet_unref =
          c.av_packet_unref =
            r.cwrap("av_packet_unref", null, ["number"])),
        jr =
          (r.av_strdup =
          c.av_strdup =
            r.cwrap("av_strdup", "number", ["string"])),
        wd =
          (r.av_buffersink_get_frame =
          c.av_buffersink_get_frame =
            r.cwrap("av_buffersink_get_frame", "number", ["number", "number"])),
        yd =
          (r.av_buffersink_get_time_base_num =
          c.av_buffersink_get_time_base_num =
            r.cwrap("av_buffersink_get_time_base_num", "number", ["number"])),
        gd =
          (r.av_buffersink_get_time_base_den =
          c.av_buffersink_get_time_base_den =
            r.cwrap("av_buffersink_get_time_base_den", "number", ["number"])),
        xd =
          (r.av_buffersink_set_frame_size =
          c.av_buffersink_set_frame_size =
            r.cwrap("av_buffersink_set_frame_size", null, [
              "number",
              "number",
            ])),
        kd =
          (r.ff_buffersink_set_ch_layout =
          c.ff_buffersink_set_ch_layout =
            r.cwrap("ff_buffersink_set_ch_layout", "number", [
              "number",
              "number",
              "number",
            ])),
        Fd =
          (r.av_buffersrc_add_frame_flags =
          c.av_buffersrc_add_frame_flags =
            r.cwrap("av_buffersrc_add_frame_flags", "number", [
              "number",
              "number",
              "number",
            ])),
        Ga =
          (r.avfilter_free =
          c.avfilter_free =
            r.cwrap("avfilter_free", null, ["number"])),
        Ke =
          (r.avfilter_get_by_name =
          c.avfilter_get_by_name =
            r.cwrap("avfilter_get_by_name", "number", ["string"])),
        Pd =
          (r.avfilter_graph_alloc =
          c.avfilter_graph_alloc =
            r.cwrap("avfilter_graph_alloc", "number", [])),
        Ed =
          (r.avfilter_graph_config =
          c.avfilter_graph_config =
            r.cwrap("avfilter_graph_config", "number", ["number", "number"])),
        Ze =
          (r.avfilter_graph_create_filter_js =
          c.avfilter_graph_create_filter_js =
            r.cwrap("avfilter_graph_create_filter_js", "number", [
              "number",
              "string",
              "string",
              "number",
              "number",
            ])),
        Dd =
          (r.avfilter_graph_free =
          c.avfilter_graph_free =
            r.cwrap("avfilter_graph_free", null, ["number"])),
        Sd =
          (r.avfilter_graph_parse =
          c.avfilter_graph_parse =
            r.cwrap("avfilter_graph_parse", "number", [
              "number",
              "string",
              "number",
              "number",
              "number",
            ])),
        Ka =
          (r.avfilter_inout_alloc =
          c.avfilter_inout_alloc =
            r.cwrap("avfilter_inout_alloc", "number", [])),
        Za =
          (r.avfilter_inout_free =
          c.avfilter_inout_free =
            r.cwrap("avfilter_inout_free", null, ["number"])),
        Gv =
          (r.avfilter_link =
          c.avfilter_link =
            r.cwrap("avfilter_link", "number", [
              "number",
              "number",
              "number",
              "number",
            ])),
        Qa =
          (r.avcodec_alloc_context3 =
          c.avcodec_alloc_context3 =
            r.cwrap("avcodec_alloc_context3", "number", ["number"])),
        Kv =
          (r.avcodec_close =
          c.avcodec_close =
            r.cwrap("avcodec_close", "number", ["number"])),
        Zv =
          (r.avcodec_descriptor_get =
          c.avcodec_descriptor_get =
            r.cwrap("avcodec_descriptor_get", "number", ["number"])),
        Qv =
          (r.avcodec_descriptor_get_by_name =
          c.avcodec_descriptor_get_by_name =
            r.cwrap("avcodec_descriptor_get_by_name", "number", ["string"])),
        ep =
          (r.avcodec_descriptor_next =
          c.avcodec_descriptor_next =
            r.cwrap("avcodec_descriptor_next", "number", ["number"])),
        jd =
          (r.avcodec_find_decoder =
          c.avcodec_find_decoder =
            r.cwrap("avcodec_find_decoder", "number", ["number"])),
        Td =
          (r.avcodec_find_decoder_by_name =
          c.avcodec_find_decoder_by_name =
            r.cwrap("avcodec_find_decoder_by_name", "number", ["string"])),
        rp =
          (r.avcodec_find_encoder =
          c.avcodec_find_encoder =
            r.cwrap("avcodec_find_encoder", "number", ["number"])),
        zd =
          (r.avcodec_find_encoder_by_name =
          c.avcodec_find_encoder_by_name =
            r.cwrap("avcodec_find_encoder_by_name", "number", ["string"])),
        ap =
          (r.avcodec_flush_buffers =
          c.avcodec_flush_buffers =
            r.cwrap("avcodec_flush_buffers", null, ["number"])),
        tp =
          (r.avcodec_free_context =
          c.avcodec_free_context =
            r.cwrap("avcodec_free_context", null, ["number"])),
        _p =
          (r.avcodec_get_name =
          c.avcodec_get_name =
            r.cwrap("avcodec_get_name", "string", ["number"])),
        Md =
          (r.avcodec_open2 =
          c.avcodec_open2 =
            r.cwrap("avcodec_open2", "number", ["number", "number", "number"])),
        Rd =
          (r.avcodec_open2_js =
          c.avcodec_open2_js =
            r.cwrap("avcodec_open2_js", "number", [
              "number",
              "number",
              "number",
            ])),
        Id =
          (r.avcodec_parameters_alloc =
          c.avcodec_parameters_alloc =
            r.cwrap("avcodec_parameters_alloc", "number", [])),
        Od =
          (r.avcodec_parameters_copy =
          c.avcodec_parameters_copy =
            r.cwrap("avcodec_parameters_copy", "number", ["number", "number"])),
        np =
          (r.avcodec_parameters_free =
          c.avcodec_parameters_free =
            r.cwrap("avcodec_parameters_free", null, ["number"])),
        Ud =
          (r.avcodec_parameters_from_context =
          c.avcodec_parameters_from_context =
            r.cwrap("avcodec_parameters_from_context", "number", [
              "number",
              "number",
            ])),
        Nd =
          (r.avcodec_parameters_to_context =
          c.avcodec_parameters_to_context =
            r.cwrap("avcodec_parameters_to_context", "number", [
              "number",
              "number",
            ])),
        Ld =
          (r.avcodec_receive_frame =
          c.avcodec_receive_frame =
            r.cwrap("avcodec_receive_frame", "number", ["number", "number"])),
        Hd =
          (r.avcodec_receive_packet =
          c.avcodec_receive_packet =
            r.cwrap("avcodec_receive_packet", "number", ["number", "number"])),
        Bd =
          (r.avcodec_send_frame =
          c.avcodec_send_frame =
            r.cwrap("avcodec_send_frame", "number", ["number", "number"])),
        qd =
          (r.avcodec_send_packet =
          c.avcodec_send_packet =
            r.cwrap("avcodec_send_packet", "number", ["number", "number"])),
        op =
          (r.av_find_input_format =
          c.av_find_input_format =
            r.cwrap("av_find_input_format", "number", ["string"])),
        sp =
          (r.avformat_alloc_context =
          c.avformat_alloc_context =
            r.cwrap("avformat_alloc_context", "number", [])),
        Wd =
          (r.avformat_alloc_output_context2_js =
          c.avformat_alloc_output_context2_js =
            r.cwrap("avformat_alloc_output_context2_js", "number", [
              "number",
              "string",
              "string",
            ])),
        cp =
          (r.avformat_close_input =
          c.avformat_close_input =
            r.cwrap("avformat_close_input", null, ["number"])),
        Qe =
          (r.avformat_find_stream_info =
          c.avformat_find_stream_info =
            r.cwrap(
              "avformat_find_stream_info",
              "number",
              ["number", "number"],
              { async: !0 },
            )),
        $d = Qe;
      ((Qe = r.avformat_find_stream_info =
        function () {
          var e = arguments,
            a = $d.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.avformat_find_stream_info = function () {
          var e = arguments;
          return U(function () {
            return Qe.apply(void 0, e);
          });
        }));
      var ip =
          (r.avformat_flush =
          c.avformat_flush =
            r.cwrap("avformat_flush", "number", ["number"])),
        Yd =
          (r.avformat_free_context =
          c.avformat_free_context =
            r.cwrap("avformat_free_context", null, ["number"])),
        Jd =
          (r.avformat_new_stream =
          c.avformat_new_stream =
            r.cwrap("avformat_new_stream", "number", ["number", "number"])),
        Tr =
          (r.avformat_open_input =
          c.avformat_open_input =
            r.cwrap(
              "avformat_open_input",
              "number",
              ["number", "string", "number", "number"],
              { async: !0 },
            )),
        Xd = Tr;
      ((Tr = r.avformat_open_input =
        function () {
          var e = arguments,
            a = Xd.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.avformat_open_input = function () {
          var e = arguments;
          return U(function () {
            return Tr.apply(void 0, e);
          });
        }));
      var er =
          (r.avformat_open_input_js =
          c.avformat_open_input_js =
            r.cwrap(
              "avformat_open_input_js",
              "number",
              ["string", "number", "number"],
              { async: !0 },
            )),
        Gd = er;
      ((er = r.avformat_open_input_js =
        function () {
          var e = arguments,
            a = Gd.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.avformat_open_input_js = function () {
          var e = arguments;
          return U(function () {
            return er.apply(void 0, e);
          });
        }));
      var zr =
          (r.av_seek_frame =
          c.av_seek_frame =
            r.cwrap(
              "av_seek_frame",
              "number",
              ["number", "number", "number", "number"],
              { async: !0 },
            )),
        Kd = zr;
      ((zr = r.av_seek_frame =
        function () {
          var e = arguments,
            a = Kd.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.av_seek_frame = function () {
          var e = arguments;
          return U(function () {
            return zr.apply(void 0, e);
          });
        }));
      var Mr =
          (r.avformat_seek_file =
          c.avformat_seek_file =
            r.cwrap(
              "avformat_seek_file",
              "number",
              ["number", "number", "number", "number", "number", "number"],
              { async: !0 },
            )),
        Zd = Mr;
      ((Mr = r.avformat_seek_file =
        function () {
          var e = arguments,
            a = Zd.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.avformat_seek_file = function () {
          var e = arguments;
          return U(function () {
            return Mr.apply(void 0, e);
          });
        }));
      var Rr =
          (r.avformat_seek_file_min =
          c.avformat_seek_file_min =
            r.cwrap(
              "avformat_seek_file_min",
              "number",
              ["number", "number", "number", "number"],
              { async: !0 },
            )),
        Qd = Rr;
      ((Rr = r.avformat_seek_file_min =
        function () {
          var e = arguments,
            a = Qd.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.avformat_seek_file_min = function () {
          var e = arguments;
          return U(function () {
            return Rr.apply(void 0, e);
          });
        }));
      var Ir =
          (r.avformat_seek_file_max =
          c.avformat_seek_file_max =
            r.cwrap(
              "avformat_seek_file_max",
              "number",
              ["number", "number", "number", "number"],
              { async: !0 },
            )),
        ef = Ir;
      ((Ir = r.avformat_seek_file_max =
        function () {
          var e = arguments,
            a = ef.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.avformat_seek_file_max = function () {
          var e = arguments;
          return U(function () {
            return Ir.apply(void 0, e);
          });
        }));
      var Or =
          (r.avformat_seek_file_approx =
          c.avformat_seek_file_approx =
            r.cwrap(
              "avformat_seek_file_approx",
              "number",
              ["number", "number", "number", "number"],
              { async: !0 },
            )),
        rf = Or;
      ((Or = r.avformat_seek_file_approx =
        function () {
          var e = arguments,
            a = rf.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.avformat_seek_file_approx = function () {
          var e = arguments;
          return U(function () {
            return Or.apply(void 0, e);
          });
        }));
      var mp =
          (r.avformat_write_header =
          c.avformat_write_header =
            r.cwrap("avformat_write_header", "number", ["number", "number"])),
        af =
          (r.avio_open2_js =
          c.avio_open2_js =
            r.cwrap("avio_open2_js", "number", [
              "string",
              "number",
              "number",
              "number",
            ])),
        tf =
          (r.avio_close =
          c.avio_close =
            r.cwrap("avio_close", "number", ["number"])),
        lp =
          (r.avio_flush =
          c.avio_flush =
            r.cwrap("avio_flush", null, ["number"])),
        up =
          (r.av_find_best_stream =
          c.av_find_best_stream =
            r.cwrap("av_find_best_stream", "number", [
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
            ])),
        dp =
          (r.av_get_sample_fmt_name =
          c.av_get_sample_fmt_name =
            r.cwrap("av_get_sample_fmt_name", "string", ["number"])),
        _f =
          (r.av_grow_packet =
          c.av_grow_packet =
            r.cwrap("av_grow_packet", "number", ["number", "number"])),
        nf =
          (r.av_interleaved_write_frame =
          c.av_interleaved_write_frame =
            r.cwrap("av_interleaved_write_frame", "number", [
              "number",
              "number",
            ])),
        et =
          (r.av_packet_make_writable =
          c.av_packet_make_writable =
            r.cwrap("av_packet_make_writable", "number", ["number"])),
        rr =
          (r.av_pix_fmt_desc_get =
          c.av_pix_fmt_desc_get =
            r.cwrap("av_pix_fmt_desc_get", "number", ["number"])),
        ar =
          (r.av_read_frame =
          c.av_read_frame =
            r.cwrap("av_read_frame", "number", ["number", "number"], {
              async: !0,
            })),
        of = ar;
      ((ar = r.av_read_frame =
        function () {
          var e = arguments,
            a = of.apply(void 0, e);
          if (a === -11) throw r.fsThrownError;
          return a && a.then
            ? a.then(function (t) {
                if (t === -11) throw r.fsThrownError;
                return t;
              })
            : a;
        }),
        (r.av_read_frame = function () {
          var e = arguments;
          return U(function () {
            return ar.apply(void 0, e);
          });
        }));
      var sf =
          (r.av_shrink_packet =
          c.av_shrink_packet =
            r.cwrap("av_shrink_packet", null, ["number", "number"])),
        cf =
          (r.av_write_frame =
          c.av_write_frame =
            r.cwrap("av_write_frame", "number", ["number", "number"])),
        fp =
          (r.av_write_trailer =
          c.av_write_trailer =
            r.cwrap("av_write_trailer", "number", ["number"])),
        vp =
          (r.av_dict_copy_js =
          c.av_dict_copy_js =
            r.cwrap("av_dict_copy_js", "number", [
              "number",
              "number",
              "number",
            ])),
        pp =
          (r.av_dict_free =
          c.av_dict_free =
            r.cwrap("av_dict_free", null, ["number"])),
        mf =
          (r.av_dict_set_js =
          c.av_dict_set_js =
            r.cwrap("av_dict_set_js", "number", [
              "number",
              "string",
              "string",
              "number",
            ])),
        Ap =
          (r.sws_getContext =
          c.sws_getContext =
            r.cwrap("sws_getContext", "number", [
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
              "number",
            ])),
        Vp =
          (r.sws_freeContext =
          c.sws_freeContext =
            r.cwrap("sws_freeContext", null, ["number"])),
        bp =
          (r.sws_scale_frame =
          c.sws_scale_frame =
            r.cwrap("sws_scale_frame", "number", [
              "number",
              "number",
              "number",
            ])),
        lf =
          (r.AVPacketSideData_data =
          c.AVPacketSideData_data =
            r.cwrap("AVPacketSideData_data", "number", ["number", "number"])),
        uf =
          (r.AVPacketSideData_size =
          c.AVPacketSideData_size =
            r.cwrap("AVPacketSideData_size", "number", ["number", "number"])),
        df =
          (r.AVPacketSideData_type =
          c.AVPacketSideData_type =
            r.cwrap("AVPacketSideData_type", "number", ["number", "number"])),
        hp =
          (r.AVPixFmtDescriptor_comp_depth =
          c.AVPixFmtDescriptor_comp_depth =
            r.cwrap("AVPixFmtDescriptor_comp_depth", "number", [
              "number",
              "number",
            ])),
        I =
          (r.ff_error =
          c.ff_error =
            r.cwrap("ff_error", "string", ["number"])),
        rt =
          (r.ff_nothing =
          c.ff_nothing =
            r.cwrap("ff_nothing", null, [], { async: !0 }));
      r.ff_nothing = function () {
        var e = arguments;
        return U(function () {
          return rt.apply(void 0, e);
        });
      };
      var Cp =
          (r.calloc =
          c.calloc =
            r.cwrap("calloc", "number", ["number", "number"])),
        wp = (r.close = c.close = r.cwrap("close", "number", ["number"])),
        yp =
          (r.dup2 =
          c.dup2 =
            r.cwrap("dup2", "number", ["number", "number"])),
        q = (r.free = c.free = r.cwrap("free", null, ["number"])),
        G = (r.malloc = c.malloc = r.cwrap("malloc", "number", ["number"])),
        gp =
          (r.mallinfo_uordblks =
          c.mallinfo_uordblks =
            r.cwrap("mallinfo_uordblks", "number", [])),
        xp =
          (r.open =
          c.open =
            r.cwrap("open", "number", ["string", "number", "number"])),
        ff =
          (r.strerror =
          c.strerror =
            r.cwrap("strerror", "string", ["number"])),
        kp =
          (r.libavjs_with_swscale =
          c.libavjs_with_swscale =
            r.cwrap("libavjs_with_swscale", "number", [])),
        Fp =
          (r.libavjs_create_main_thread =
          c.libavjs_create_main_thread =
            r.cwrap("libavjs_create_main_thread", "number", [])),
        at =
          (r.ffmpeg_main =
          c.ffmpeg_main =
            r.cwrap("ffmpeg_main", "number", ["number", "number"], {
              async: !0,
            }));
      r.ffmpeg_main = function () {
        var e = arguments;
        return U(function () {
          return at.apply(void 0, e);
        });
      };
      var tt =
        (r.ffprobe_main =
        c.ffprobe_main =
          r.cwrap("ffprobe_main", "number", ["number", "number"], {
            async: !0,
          }));
      r.ffprobe_main = function () {
        var e = arguments;
        return U(function () {
          return tt.apply(void 0, e);
        });
      };
      var vf =
        (r.ffmpeg_interrupt =
        c.ffmpeg_interrupt =
          r.cwrap("ffmpeg_interrupt", null, [], { async: !0 }));
      r.ffmpeg_interrupt = function () {
        var e = arguments;
        return U(function () {
          return vf.apply(void 0, e);
        });
      };
      var pf =
        (r.ffmpeg_get_out_time_ms =
        c.ffmpeg_get_out_time_ms =
          r.cwrap("ffmpeg_get_out_time_ms", "number", [], { async: !0 }));
      r.ffmpeg_get_out_time_ms = function () {
        var e = arguments;
        return U(function () {
          return pf.apply(void 0, e);
        });
      };
      var Af =
        (r.ffmpeg_get_total_size_bytes =
        c.ffmpeg_get_total_size_bytes =
          r.cwrap("ffmpeg_get_total_size_bytes", "number", [], { async: !0 }));
      r.ffmpeg_get_total_size_bytes = function () {
        var e = arguments;
        return U(function () {
          return Af.apply(void 0, e);
        });
      };
      var Pp =
          (r.jsfetch_set_read_timeout =
          c.jsfetch_set_read_timeout =
            r.cwrap("jsfetch_set_read_timeout", null, ["number"])),
        Ep =
          (r.jsfetch_set_fetch_timeout =
          c.jsfetch_set_fetch_timeout =
            r.cwrap("jsfetch_set_fetch_timeout", null, ["number"])),
        Dp =
          (r.jsfetch_set_initial_retry_delay =
          c.jsfetch_set_initial_retry_delay =
            r.cwrap("jsfetch_set_initial_retry_delay", null, ["number"])),
        Sp =
          (r.jsfetch_set_bypass_cache =
          c.jsfetch_set_bypass_cache =
            r.cwrap("jsfetch_set_bypass_cache", null, ["boolean"])),
        Vf =
          (r.AVFrame_channel_layout =
          c.AVFrame_channel_layout =
            r.cwrap("AVFrame_channel_layout", "number", ["number"])),
        jp =
          (r.AVFrame_channel_layout_s =
          c.AVFrame_channel_layout_s =
            r.cwrap("AVFrame_channel_layout_s", null, ["number", "number"])),
        Tp =
          (r.AVFrame_channel_layouthi =
          c.AVFrame_channel_layouthi =
            r.cwrap("AVFrame_channel_layouthi", "number", ["number"])),
        zp =
          (r.AVFrame_channel_layouthi_s =
          c.AVFrame_channel_layouthi_s =
            r.cwrap("AVFrame_channel_layouthi_s", null, ["number", "number"])),
        bf =
          (r.AVFrame_channels =
          c.AVFrame_channels =
            r.cwrap("AVFrame_channels", "number", ["number"])),
        Mp =
          (r.AVFrame_channels_s =
          c.AVFrame_channels_s =
            r.cwrap("AVFrame_channels_s", null, ["number", "number"])),
        Rp =
          (r.AVFrame_channel_layoutmask =
          c.AVFrame_channel_layoutmask =
            r.cwrap("AVFrame_channel_layoutmask", "number", ["number"])),
        Ip =
          (r.AVFrame_channel_layoutmask_s =
          c.AVFrame_channel_layoutmask_s =
            r.cwrap("AVFrame_channel_layoutmask_s", null, [
              "number",
              "number",
            ])),
        Op =
          (r.AVFrame_ch_layout_nb_channels =
          c.AVFrame_ch_layout_nb_channels =
            r.cwrap("AVFrame_ch_layout_nb_channels", "number", ["number"])),
        Up =
          (r.AVFrame_ch_layout_nb_channels_s =
          c.AVFrame_ch_layout_nb_channels_s =
            r.cwrap("AVFrame_ch_layout_nb_channels_s", null, [
              "number",
              "number",
            ])),
        hf =
          (r.AVFrame_crop_bottom =
          c.AVFrame_crop_bottom =
            r.cwrap("AVFrame_crop_bottom", "number", ["number"])),
        Cf =
          (r.AVFrame_crop_bottom_s =
          c.AVFrame_crop_bottom_s =
            r.cwrap("AVFrame_crop_bottom_s", null, ["number", "number"])),
        wf =
          (r.AVFrame_crop_left =
          c.AVFrame_crop_left =
            r.cwrap("AVFrame_crop_left", "number", ["number"])),
        yf =
          (r.AVFrame_crop_left_s =
          c.AVFrame_crop_left_s =
            r.cwrap("AVFrame_crop_left_s", null, ["number", "number"])),
        gf =
          (r.AVFrame_crop_right =
          c.AVFrame_crop_right =
            r.cwrap("AVFrame_crop_right", "number", ["number"])),
        xf =
          (r.AVFrame_crop_right_s =
          c.AVFrame_crop_right_s =
            r.cwrap("AVFrame_crop_right_s", null, ["number", "number"])),
        kf =
          (r.AVFrame_crop_top =
          c.AVFrame_crop_top =
            r.cwrap("AVFrame_crop_top", "number", ["number"])),
        Ff =
          (r.AVFrame_crop_top_s =
          c.AVFrame_crop_top_s =
            r.cwrap("AVFrame_crop_top_s", null, ["number", "number"])),
        ie =
          (r.AVFrame_data_a =
          c.AVFrame_data_a =
            r.cwrap("AVFrame_data_a", "number", ["number", "number"])),
        Np =
          (r.AVFrame_data_a_s =
          c.AVFrame_data_a_s =
            r.cwrap("AVFrame_data_a_s", null, ["number", "number", "number"])),
        ye =
          (r.AVFrame_format =
          c.AVFrame_format =
            r.cwrap("AVFrame_format", "number", ["number"])),
        Lp =
          (r.AVFrame_format_s =
          c.AVFrame_format_s =
            r.cwrap("AVFrame_format_s", null, ["number", "number"])),
        Te =
          (r.AVFrame_height =
          c.AVFrame_height =
            r.cwrap("AVFrame_height", "number", ["number"])),
        Hp =
          (r.AVFrame_height_s =
          c.AVFrame_height_s =
            r.cwrap("AVFrame_height_s", null, ["number", "number"])),
        _t =
          (r.AVFrame_key_frame =
          c.AVFrame_key_frame =
            r.cwrap("AVFrame_key_frame", "number", ["number"])),
        Bp =
          (r.AVFrame_key_frame_s =
          c.AVFrame_key_frame_s =
            r.cwrap("AVFrame_key_frame_s", null, ["number", "number"])),
        ge =
          (r.AVFrame_linesize_a =
          c.AVFrame_linesize_a =
            r.cwrap("AVFrame_linesize_a", "number", ["number", "number"])),
        qp =
          (r.AVFrame_linesize_a_s =
          c.AVFrame_linesize_a_s =
            r.cwrap("AVFrame_linesize_a_s", null, [
              "number",
              "number",
              "number",
            ])),
        Pf =
          (r.AVFrame_nb_samples =
          c.AVFrame_nb_samples =
            r.cwrap("AVFrame_nb_samples", "number", ["number"])),
        Ef =
          (r.AVFrame_nb_samples_s =
          c.AVFrame_nb_samples_s =
            r.cwrap("AVFrame_nb_samples_s", null, ["number", "number"])),
        nt =
          (r.AVFrame_pict_type =
          c.AVFrame_pict_type =
            r.cwrap("AVFrame_pict_type", "number", ["number"])),
        Wp =
          (r.AVFrame_pict_type_s =
          c.AVFrame_pict_type_s =
            r.cwrap("AVFrame_pict_type_s", null, ["number", "number"])),
        Ur =
          (r.AVFrame_pts =
          c.AVFrame_pts =
            r.cwrap("AVFrame_pts", "number", ["number"])),
        $p =
          (r.AVFrame_pts_s =
          c.AVFrame_pts_s =
            r.cwrap("AVFrame_pts_s", null, ["number", "number"])),
        Nr =
          (r.AVFrame_ptshi =
          c.AVFrame_ptshi =
            r.cwrap("AVFrame_ptshi", "number", ["number"])),
        Yp =
          (r.AVFrame_ptshi_s =
          c.AVFrame_ptshi_s =
            r.cwrap("AVFrame_ptshi_s", null, ["number", "number"])),
        ot =
          (r.AVFrame_sample_aspect_ratio_num =
          c.AVFrame_sample_aspect_ratio_num =
            r.cwrap("AVFrame_sample_aspect_ratio_num", "number", ["number"])),
        Jp =
          (r.AVFrame_sample_aspect_ratio_num_s =
          c.AVFrame_sample_aspect_ratio_num_s =
            r.cwrap("AVFrame_sample_aspect_ratio_num_s", null, [
              "number",
              "number",
            ])),
        st =
          (r.AVFrame_sample_aspect_ratio_den =
          c.AVFrame_sample_aspect_ratio_den =
            r.cwrap("AVFrame_sample_aspect_ratio_den", "number", ["number"])),
        Xp =
          (r.AVFrame_sample_aspect_ratio_den_s =
          c.AVFrame_sample_aspect_ratio_den_s =
            r.cwrap("AVFrame_sample_aspect_ratio_den_s", null, [
              "number",
              "number",
            ])),
        Df =
          (r.AVFrame_sample_aspect_ratio_s =
          c.AVFrame_sample_aspect_ratio_s =
            r.cwrap("AVFrame_sample_aspect_ratio_s", null, [
              "number",
              "number",
              "number",
            ])),
        Sf =
          (r.AVFrame_sample_rate =
          c.AVFrame_sample_rate =
            r.cwrap("AVFrame_sample_rate", "number", ["number"])),
        Gp =
          (r.AVFrame_sample_rate_s =
          c.AVFrame_sample_rate_s =
            r.cwrap("AVFrame_sample_rate_s", null, ["number", "number"])),
        ze =
          (r.AVFrame_time_base_num =
          c.AVFrame_time_base_num =
            r.cwrap("AVFrame_time_base_num", "number", ["number"])),
        Kp =
          (r.AVFrame_time_base_num_s =
          c.AVFrame_time_base_num_s =
            r.cwrap("AVFrame_time_base_num_s", null, ["number", "number"])),
        tr =
          (r.AVFrame_time_base_den =
          c.AVFrame_time_base_den =
            r.cwrap("AVFrame_time_base_den", "number", ["number"])),
        Zp =
          (r.AVFrame_time_base_den_s =
          c.AVFrame_time_base_den_s =
            r.cwrap("AVFrame_time_base_den_s", null, ["number", "number"])),
        _r =
          (r.AVFrame_time_base_s =
          c.AVFrame_time_base_s =
            r.cwrap("AVFrame_time_base_s", null, [
              "number",
              "number",
              "number",
            ])),
        xe =
          (r.AVFrame_width =
          c.AVFrame_width =
            r.cwrap("AVFrame_width", "number", ["number"])),
        Qp =
          (r.AVFrame_width_s =
          c.AVFrame_width_s =
            r.cwrap("AVFrame_width_s", null, ["number", "number"])),
        Lr =
          (r.AVPixFmtDescriptor_flags =
          c.AVPixFmtDescriptor_flags =
            r.cwrap("AVPixFmtDescriptor_flags", "number", ["number"])),
        eA =
          (r.AVPixFmtDescriptor_flags_s =
          c.AVPixFmtDescriptor_flags_s =
            r.cwrap("AVPixFmtDescriptor_flags_s", null, ["number", "number"])),
        nr =
          (r.AVPixFmtDescriptor_log2_chroma_h =
          c.AVPixFmtDescriptor_log2_chroma_h =
            r.cwrap("AVPixFmtDescriptor_log2_chroma_h", "number", ["number"])),
        rA =
          (r.AVPixFmtDescriptor_log2_chroma_h_s =
          c.AVPixFmtDescriptor_log2_chroma_h_s =
            r.cwrap("AVPixFmtDescriptor_log2_chroma_h_s", null, [
              "number",
              "number",
            ])),
        Hr =
          (r.AVPixFmtDescriptor_log2_chroma_w =
          c.AVPixFmtDescriptor_log2_chroma_w =
            r.cwrap("AVPixFmtDescriptor_log2_chroma_w", "number", ["number"])),
        aA =
          (r.AVPixFmtDescriptor_log2_chroma_w_s =
          c.AVPixFmtDescriptor_log2_chroma_w_s =
            r.cwrap("AVPixFmtDescriptor_log2_chroma_w_s", null, [
              "number",
              "number",
            ])),
        Br =
          (r.AVPixFmtDescriptor_nb_components =
          c.AVPixFmtDescriptor_nb_components =
            r.cwrap("AVPixFmtDescriptor_nb_components", "number", ["number"])),
        tA =
          (r.AVPixFmtDescriptor_nb_components_s =
          c.AVPixFmtDescriptor_nb_components_s =
            r.cwrap("AVPixFmtDescriptor_nb_components_s", null, [
              "number",
              "number",
            ])),
        _A =
          (r.AVCodec_name =
          c.AVCodec_name =
            r.cwrap("AVCodec_name", "string", ["number"])),
        nA =
          (r.AVCodec_sample_fmts =
          c.AVCodec_sample_fmts =
            r.cwrap("AVCodec_sample_fmts", "number", ["number"])),
        oA =
          (r.AVCodec_sample_fmts_s =
          c.AVCodec_sample_fmts_s =
            r.cwrap("AVCodec_sample_fmts_s", null, ["number", "number"])),
        sA =
          (r.AVCodec_sample_fmts_a =
          c.AVCodec_sample_fmts_a =
            r.cwrap("AVCodec_sample_fmts_a", "number", ["number", "number"])),
        cA =
          (r.AVCodec_sample_fmts_a_s =
          c.AVCodec_sample_fmts_a_s =
            r.cwrap("AVCodec_sample_fmts_a_s", null, [
              "number",
              "number",
              "number",
            ])),
        iA =
          (r.AVCodec_supported_samplerates =
          c.AVCodec_supported_samplerates =
            r.cwrap("AVCodec_supported_samplerates", "number", ["number"])),
        mA =
          (r.AVCodec_supported_samplerates_s =
          c.AVCodec_supported_samplerates_s =
            r.cwrap("AVCodec_supported_samplerates_s", null, [
              "number",
              "number",
            ])),
        lA =
          (r.AVCodec_supported_samplerates_a =
          c.AVCodec_supported_samplerates_a =
            r.cwrap("AVCodec_supported_samplerates_a", "number", [
              "number",
              "number",
            ])),
        uA =
          (r.AVCodec_supported_samplerates_a_s =
          c.AVCodec_supported_samplerates_a_s =
            r.cwrap("AVCodec_supported_samplerates_a_s", null, [
              "number",
              "number",
              "number",
            ])),
        dA =
          (r.AVCodec_type =
          c.AVCodec_type =
            r.cwrap("AVCodec_type", "number", ["number"])),
        fA =
          (r.AVCodec_type_s =
          c.AVCodec_type_s =
            r.cwrap("AVCodec_type_s", null, ["number", "number"])),
        ct =
          (r.AVCodecContext_codec_id =
          c.AVCodecContext_codec_id =
            r.cwrap("AVCodecContext_codec_id", "number", ["number"])),
        jf =
          (r.AVCodecContext_codec_id_s =
          c.AVCodecContext_codec_id_s =
            r.cwrap("AVCodecContext_codec_id_s", null, ["number", "number"])),
        vA =
          (r.AVCodecContext_codec_type =
          c.AVCodecContext_codec_type =
            r.cwrap("AVCodecContext_codec_type", "number", ["number"])),
        pA =
          (r.AVCodecContext_codec_type_s =
          c.AVCodecContext_codec_type_s =
            r.cwrap("AVCodecContext_codec_type_s", null, ["number", "number"])),
        AA =
          (r.AVCodecContext_bit_rate =
          c.AVCodecContext_bit_rate =
            r.cwrap("AVCodecContext_bit_rate", "number", ["number"])),
        VA =
          (r.AVCodecContext_bit_rate_s =
          c.AVCodecContext_bit_rate_s =
            r.cwrap("AVCodecContext_bit_rate_s", null, ["number", "number"])),
        bA =
          (r.AVCodecContext_bit_ratehi =
          c.AVCodecContext_bit_ratehi =
            r.cwrap("AVCodecContext_bit_ratehi", "number", ["number"])),
        hA =
          (r.AVCodecContext_bit_ratehi_s =
          c.AVCodecContext_bit_ratehi_s =
            r.cwrap("AVCodecContext_bit_ratehi_s", null, ["number", "number"])),
        CA =
          (r.AVCodecContext_channel_layout =
          c.AVCodecContext_channel_layout =
            r.cwrap("AVCodecContext_channel_layout", "number", ["number"])),
        wA =
          (r.AVCodecContext_channel_layout_s =
          c.AVCodecContext_channel_layout_s =
            r.cwrap("AVCodecContext_channel_layout_s", null, [
              "number",
              "number",
            ])),
        yA =
          (r.AVCodecContext_channel_layouthi =
          c.AVCodecContext_channel_layouthi =
            r.cwrap("AVCodecContext_channel_layouthi", "number", ["number"])),
        gA =
          (r.AVCodecContext_channel_layouthi_s =
          c.AVCodecContext_channel_layouthi_s =
            r.cwrap("AVCodecContext_channel_layouthi_s", null, [
              "number",
              "number",
            ])),
        xA =
          (r.AVCodecContext_channels =
          c.AVCodecContext_channels =
            r.cwrap("AVCodecContext_channels", "number", ["number"])),
        kA =
          (r.AVCodecContext_channels_s =
          c.AVCodecContext_channels_s =
            r.cwrap("AVCodecContext_channels_s", null, ["number", "number"])),
        FA =
          (r.AVCodecContext_channel_layoutmask =
          c.AVCodecContext_channel_layoutmask =
            r.cwrap("AVCodecContext_channel_layoutmask", "number", ["number"])),
        PA =
          (r.AVCodecContext_channel_layoutmask_s =
          c.AVCodecContext_channel_layoutmask_s =
            r.cwrap("AVCodecContext_channel_layoutmask_s", null, [
              "number",
              "number",
            ])),
        EA =
          (r.AVCodecContext_ch_layout_nb_channels =
          c.AVCodecContext_ch_layout_nb_channels =
            r.cwrap("AVCodecContext_ch_layout_nb_channels", "number", [
              "number",
            ])),
        DA =
          (r.AVCodecContext_ch_layout_nb_channels_s =
          c.AVCodecContext_ch_layout_nb_channels_s =
            r.cwrap("AVCodecContext_ch_layout_nb_channels_s", null, [
              "number",
              "number",
            ])),
        SA =
          (r.AVCodecContext_extradata =
          c.AVCodecContext_extradata =
            r.cwrap("AVCodecContext_extradata", "number", ["number"])),
        jA =
          (r.AVCodecContext_extradata_s =
          c.AVCodecContext_extradata_s =
            r.cwrap("AVCodecContext_extradata_s", null, ["number", "number"])),
        TA =
          (r.AVCodecContext_extradata_size =
          c.AVCodecContext_extradata_size =
            r.cwrap("AVCodecContext_extradata_size", "number", ["number"])),
        zA =
          (r.AVCodecContext_extradata_size_s =
          c.AVCodecContext_extradata_size_s =
            r.cwrap("AVCodecContext_extradata_size_s", null, [
              "number",
              "number",
            ])),
        Tf =
          (r.AVCodecContext_frame_size =
          c.AVCodecContext_frame_size =
            r.cwrap("AVCodecContext_frame_size", "number", ["number"])),
        MA =
          (r.AVCodecContext_frame_size_s =
          c.AVCodecContext_frame_size_s =
            r.cwrap("AVCodecContext_frame_size_s", null, ["number", "number"])),
        RA =
          (r.AVCodecContext_framerate_num =
          c.AVCodecContext_framerate_num =
            r.cwrap("AVCodecContext_framerate_num", "number", ["number"])),
        IA =
          (r.AVCodecContext_framerate_num_s =
          c.AVCodecContext_framerate_num_s =
            r.cwrap("AVCodecContext_framerate_num_s", null, [
              "number",
              "number",
            ])),
        OA =
          (r.AVCodecContext_framerate_den =
          c.AVCodecContext_framerate_den =
            r.cwrap("AVCodecContext_framerate_den", "number", ["number"])),
        UA =
          (r.AVCodecContext_framerate_den_s =
          c.AVCodecContext_framerate_den_s =
            r.cwrap("AVCodecContext_framerate_den_s", null, [
              "number",
              "number",
            ])),
        NA =
          (r.AVCodecContext_framerate_s =
          c.AVCodecContext_framerate_s =
            r.cwrap("AVCodecContext_framerate_s", null, [
              "number",
              "number",
              "number",
            ])),
        LA =
          (r.AVCodecContext_gop_size =
          c.AVCodecContext_gop_size =
            r.cwrap("AVCodecContext_gop_size", "number", ["number"])),
        HA =
          (r.AVCodecContext_gop_size_s =
          c.AVCodecContext_gop_size_s =
            r.cwrap("AVCodecContext_gop_size_s", null, ["number", "number"])),
        BA =
          (r.AVCodecContext_height =
          c.AVCodecContext_height =
            r.cwrap("AVCodecContext_height", "number", ["number"])),
        qA =
          (r.AVCodecContext_height_s =
          c.AVCodecContext_height_s =
            r.cwrap("AVCodecContext_height_s", null, ["number", "number"])),
        WA =
          (r.AVCodecContext_keyint_min =
          c.AVCodecContext_keyint_min =
            r.cwrap("AVCodecContext_keyint_min", "number", ["number"])),
        $A =
          (r.AVCodecContext_keyint_min_s =
          c.AVCodecContext_keyint_min_s =
            r.cwrap("AVCodecContext_keyint_min_s", null, ["number", "number"])),
        YA =
          (r.AVCodecContext_level =
          c.AVCodecContext_level =
            r.cwrap("AVCodecContext_level", "number", ["number"])),
        JA =
          (r.AVCodecContext_level_s =
          c.AVCodecContext_level_s =
            r.cwrap("AVCodecContext_level_s", null, ["number", "number"])),
        XA =
          (r.AVCodecContext_max_b_frames =
          c.AVCodecContext_max_b_frames =
            r.cwrap("AVCodecContext_max_b_frames", "number", ["number"])),
        GA =
          (r.AVCodecContext_max_b_frames_s =
          c.AVCodecContext_max_b_frames_s =
            r.cwrap("AVCodecContext_max_b_frames_s", null, [
              "number",
              "number",
            ])),
        KA =
          (r.AVCodecContext_pix_fmt =
          c.AVCodecContext_pix_fmt =
            r.cwrap("AVCodecContext_pix_fmt", "number", ["number"])),
        ZA =
          (r.AVCodecContext_pix_fmt_s =
          c.AVCodecContext_pix_fmt_s =
            r.cwrap("AVCodecContext_pix_fmt_s", null, ["number", "number"])),
        QA =
          (r.AVCodecContext_profile =
          c.AVCodecContext_profile =
            r.cwrap("AVCodecContext_profile", "number", ["number"])),
        eV =
          (r.AVCodecContext_profile_s =
          c.AVCodecContext_profile_s =
            r.cwrap("AVCodecContext_profile_s", null, ["number", "number"])),
        rV =
          (r.AVCodecContext_rc_max_rate =
          c.AVCodecContext_rc_max_rate =
            r.cwrap("AVCodecContext_rc_max_rate", "number", ["number"])),
        aV =
          (r.AVCodecContext_rc_max_rate_s =
          c.AVCodecContext_rc_max_rate_s =
            r.cwrap("AVCodecContext_rc_max_rate_s", null, [
              "number",
              "number",
            ])),
        tV =
          (r.AVCodecContext_rc_max_ratehi =
          c.AVCodecContext_rc_max_ratehi =
            r.cwrap("AVCodecContext_rc_max_ratehi", "number", ["number"])),
        _V =
          (r.AVCodecContext_rc_max_ratehi_s =
          c.AVCodecContext_rc_max_ratehi_s =
            r.cwrap("AVCodecContext_rc_max_ratehi_s", null, [
              "number",
              "number",
            ])),
        nV =
          (r.AVCodecContext_rc_min_rate =
          c.AVCodecContext_rc_min_rate =
            r.cwrap("AVCodecContext_rc_min_rate", "number", ["number"])),
        oV =
          (r.AVCodecContext_rc_min_rate_s =
          c.AVCodecContext_rc_min_rate_s =
            r.cwrap("AVCodecContext_rc_min_rate_s", null, [
              "number",
              "number",
            ])),
        sV =
          (r.AVCodecContext_rc_min_ratehi =
          c.AVCodecContext_rc_min_ratehi =
            r.cwrap("AVCodecContext_rc_min_ratehi", "number", ["number"])),
        cV =
          (r.AVCodecContext_rc_min_ratehi_s =
          c.AVCodecContext_rc_min_ratehi_s =
            r.cwrap("AVCodecContext_rc_min_ratehi_s", null, [
              "number",
              "number",
            ])),
        iV =
          (r.AVCodecContext_sample_aspect_ratio_num =
          c.AVCodecContext_sample_aspect_ratio_num =
            r.cwrap("AVCodecContext_sample_aspect_ratio_num", "number", [
              "number",
            ])),
        mV =
          (r.AVCodecContext_sample_aspect_ratio_num_s =
          c.AVCodecContext_sample_aspect_ratio_num_s =
            r.cwrap("AVCodecContext_sample_aspect_ratio_num_s", null, [
              "number",
              "number",
            ])),
        lV =
          (r.AVCodecContext_sample_aspect_ratio_den =
          c.AVCodecContext_sample_aspect_ratio_den =
            r.cwrap("AVCodecContext_sample_aspect_ratio_den", "number", [
              "number",
            ])),
        uV =
          (r.AVCodecContext_sample_aspect_ratio_den_s =
          c.AVCodecContext_sample_aspect_ratio_den_s =
            r.cwrap("AVCodecContext_sample_aspect_ratio_den_s", null, [
              "number",
              "number",
            ])),
        dV =
          (r.AVCodecContext_sample_aspect_ratio_s =
          c.AVCodecContext_sample_aspect_ratio_s =
            r.cwrap("AVCodecContext_sample_aspect_ratio_s", null, [
              "number",
              "number",
              "number",
            ])),
        fV =
          (r.AVCodecContext_sample_fmt =
          c.AVCodecContext_sample_fmt =
            r.cwrap("AVCodecContext_sample_fmt", "number", ["number"])),
        vV =
          (r.AVCodecContext_sample_fmt_s =
          c.AVCodecContext_sample_fmt_s =
            r.cwrap("AVCodecContext_sample_fmt_s", null, ["number", "number"])),
        pV =
          (r.AVCodecContext_sample_rate =
          c.AVCodecContext_sample_rate =
            r.cwrap("AVCodecContext_sample_rate", "number", ["number"])),
        AV =
          (r.AVCodecContext_sample_rate_s =
          c.AVCodecContext_sample_rate_s =
            r.cwrap("AVCodecContext_sample_rate_s", null, [
              "number",
              "number",
            ])),
        it =
          (r.AVCodecContext_time_base_num =
          c.AVCodecContext_time_base_num =
            r.cwrap("AVCodecContext_time_base_num", "number", ["number"])),
        VV =
          (r.AVCodecContext_time_base_num_s =
          c.AVCodecContext_time_base_num_s =
            r.cwrap("AVCodecContext_time_base_num_s", null, [
              "number",
              "number",
            ])),
        mt =
          (r.AVCodecContext_time_base_den =
          c.AVCodecContext_time_base_den =
            r.cwrap("AVCodecContext_time_base_den", "number", ["number"])),
        bV =
          (r.AVCodecContext_time_base_den_s =
          c.AVCodecContext_time_base_den_s =
            r.cwrap("AVCodecContext_time_base_den_s", null, [
              "number",
              "number",
            ])),
        lt =
          (r.AVCodecContext_time_base_s =
          c.AVCodecContext_time_base_s =
            r.cwrap("AVCodecContext_time_base_s", null, [
              "number",
              "number",
              "number",
            ])),
        hV =
          (r.AVCodecContext_qmax =
          c.AVCodecContext_qmax =
            r.cwrap("AVCodecContext_qmax", "number", ["number"])),
        CV =
          (r.AVCodecContext_qmax_s =
          c.AVCodecContext_qmax_s =
            r.cwrap("AVCodecContext_qmax_s", null, ["number", "number"])),
        wV =
          (r.AVCodecContext_qmin =
          c.AVCodecContext_qmin =
            r.cwrap("AVCodecContext_qmin", "number", ["number"])),
        yV =
          (r.AVCodecContext_qmin_s =
          c.AVCodecContext_qmin_s =
            r.cwrap("AVCodecContext_qmin_s", null, ["number", "number"])),
        gV =
          (r.AVCodecContext_width =
          c.AVCodecContext_width =
            r.cwrap("AVCodecContext_width", "number", ["number"])),
        xV =
          (r.AVCodecContext_width_s =
          c.AVCodecContext_width_s =
            r.cwrap("AVCodecContext_width_s", null, ["number", "number"])),
        kV =
          (r.AVCodecDescriptor_id =
          c.AVCodecDescriptor_id =
            r.cwrap("AVCodecDescriptor_id", "number", ["number"])),
        FV =
          (r.AVCodecDescriptor_id_s =
          c.AVCodecDescriptor_id_s =
            r.cwrap("AVCodecDescriptor_id_s", null, ["number", "number"])),
        PV =
          (r.AVCodecDescriptor_long_name =
          c.AVCodecDescriptor_long_name =
            r.cwrap("AVCodecDescriptor_long_name", "number", ["number"])),
        EV =
          (r.AVCodecDescriptor_long_name_s =
          c.AVCodecDescriptor_long_name_s =
            r.cwrap("AVCodecDescriptor_long_name_s", null, [
              "number",
              "number",
            ])),
        DV =
          (r.AVCodecDescriptor_mime_types_a =
          c.AVCodecDescriptor_mime_types_a =
            r.cwrap("AVCodecDescriptor_mime_types_a", "number", [
              "number",
              "number",
            ])),
        SV =
          (r.AVCodecDescriptor_mime_types_a_s =
          c.AVCodecDescriptor_mime_types_a_s =
            r.cwrap("AVCodecDescriptor_mime_types_a_s", null, [
              "number",
              "number",
              "number",
            ])),
        jV =
          (r.AVCodecDescriptor_name =
          c.AVCodecDescriptor_name =
            r.cwrap("AVCodecDescriptor_name", "number", ["number"])),
        TV =
          (r.AVCodecDescriptor_name_s =
          c.AVCodecDescriptor_name_s =
            r.cwrap("AVCodecDescriptor_name_s", null, ["number", "number"])),
        zV =
          (r.AVCodecDescriptor_props =
          c.AVCodecDescriptor_props =
            r.cwrap("AVCodecDescriptor_props", "number", ["number"])),
        MV =
          (r.AVCodecDescriptor_props_s =
          c.AVCodecDescriptor_props_s =
            r.cwrap("AVCodecDescriptor_props_s", null, ["number", "number"])),
        RV =
          (r.AVCodecDescriptor_type =
          c.AVCodecDescriptor_type =
            r.cwrap("AVCodecDescriptor_type", "number", ["number"])),
        IV =
          (r.AVCodecDescriptor_type_s =
          c.AVCodecDescriptor_type_s =
            r.cwrap("AVCodecDescriptor_type_s", null, ["number", "number"])),
        zf =
          (r.AVCodecParameters_bit_rate =
          c.AVCodecParameters_bit_rate =
            r.cwrap("AVCodecParameters_bit_rate", "number", ["number"])),
        OV =
          (r.AVCodecParameters_bit_rate_s =
          c.AVCodecParameters_bit_rate_s =
            r.cwrap("AVCodecParameters_bit_rate_s", null, [
              "number",
              "number",
            ])),
        Mf =
          (r.AVCodecParameters_channel_layoutmask =
          c.AVCodecParameters_channel_layoutmask =
            r.cwrap("AVCodecParameters_channel_layoutmask", "number", [
              "number",
            ])),
        UV =
          (r.AVCodecParameters_channel_layoutmask_s =
          c.AVCodecParameters_channel_layoutmask_s =
            r.cwrap("AVCodecParameters_channel_layoutmask_s", null, [
              "number",
              "number",
            ])),
        Rf =
          (r.AVCodecParameters_channels =
          c.AVCodecParameters_channels =
            r.cwrap("AVCodecParameters_channels", "number", ["number"])),
        NV =
          (r.AVCodecParameters_channels_s =
          c.AVCodecParameters_channels_s =
            r.cwrap("AVCodecParameters_channels_s", null, [
              "number",
              "number",
            ])),
        LV =
          (r.AVCodecParameters_ch_layout_nb_channels =
          c.AVCodecParameters_ch_layout_nb_channels =
            r.cwrap("AVCodecParameters_ch_layout_nb_channels", "number", [
              "number",
            ])),
        HV =
          (r.AVCodecParameters_ch_layout_nb_channels_s =
          c.AVCodecParameters_ch_layout_nb_channels_s =
            r.cwrap("AVCodecParameters_ch_layout_nb_channels_s", null, [
              "number",
              "number",
            ])),
        If =
          (r.AVCodecParameters_chroma_location =
          c.AVCodecParameters_chroma_location =
            r.cwrap("AVCodecParameters_chroma_location", "number", ["number"])),
        BV =
          (r.AVCodecParameters_chroma_location_s =
          c.AVCodecParameters_chroma_location_s =
            r.cwrap("AVCodecParameters_chroma_location_s", null, [
              "number",
              "number",
            ])),
        ut =
          (r.AVCodecParameters_codec_id =
          c.AVCodecParameters_codec_id =
            r.cwrap("AVCodecParameters_codec_id", "number", ["number"])),
        qV =
          (r.AVCodecParameters_codec_id_s =
          c.AVCodecParameters_codec_id_s =
            r.cwrap("AVCodecParameters_codec_id_s", null, [
              "number",
              "number",
            ])),
        Of =
          (r.AVCodecParameters_codec_tag =
          c.AVCodecParameters_codec_tag =
            r.cwrap("AVCodecParameters_codec_tag", "number", ["number"])),
        Uf =
          (r.AVCodecParameters_codec_tag_s =
          c.AVCodecParameters_codec_tag_s =
            r.cwrap("AVCodecParameters_codec_tag_s", null, [
              "number",
              "number",
            ])),
        dt =
          (r.AVCodecParameters_codec_type =
          c.AVCodecParameters_codec_type =
            r.cwrap("AVCodecParameters_codec_type", "number", ["number"])),
        WV =
          (r.AVCodecParameters_codec_type_s =
          c.AVCodecParameters_codec_type_s =
            r.cwrap("AVCodecParameters_codec_type_s", null, [
              "number",
              "number",
            ])),
        Nf =
          (r.AVCodecParameters_color_primaries =
          c.AVCodecParameters_color_primaries =
            r.cwrap("AVCodecParameters_color_primaries", "number", ["number"])),
        $V =
          (r.AVCodecParameters_color_primaries_s =
          c.AVCodecParameters_color_primaries_s =
            r.cwrap("AVCodecParameters_color_primaries_s", null, [
              "number",
              "number",
            ])),
        Lf =
          (r.AVCodecParameters_color_range =
          c.AVCodecParameters_color_range =
            r.cwrap("AVCodecParameters_color_range", "number", ["number"])),
        YV =
          (r.AVCodecParameters_color_range_s =
          c.AVCodecParameters_color_range_s =
            r.cwrap("AVCodecParameters_color_range_s", null, [
              "number",
              "number",
            ])),
        Hf =
          (r.AVCodecParameters_color_space =
          c.AVCodecParameters_color_space =
            r.cwrap("AVCodecParameters_color_space", "number", ["number"])),
        JV =
          (r.AVCodecParameters_color_space_s =
          c.AVCodecParameters_color_space_s =
            r.cwrap("AVCodecParameters_color_space_s", null, [
              "number",
              "number",
            ])),
        Bf =
          (r.AVCodecParameters_color_trc =
          c.AVCodecParameters_color_trc =
            r.cwrap("AVCodecParameters_color_trc", "number", ["number"])),
        XV =
          (r.AVCodecParameters_color_trc_s =
          c.AVCodecParameters_color_trc_s =
            r.cwrap("AVCodecParameters_color_trc_s", null, [
              "number",
              "number",
            ])),
        qf =
          (r.AVCodecParameters_extradata =
          c.AVCodecParameters_extradata =
            r.cwrap("AVCodecParameters_extradata", "number", ["number"])),
        Wf =
          (r.AVCodecParameters_extradata_s =
          c.AVCodecParameters_extradata_s =
            r.cwrap("AVCodecParameters_extradata_s", null, [
              "number",
              "number",
            ])),
        $f =
          (r.AVCodecParameters_extradata_size =
          c.AVCodecParameters_extradata_size =
            r.cwrap("AVCodecParameters_extradata_size", "number", ["number"])),
        Yf =
          (r.AVCodecParameters_extradata_size_s =
          c.AVCodecParameters_extradata_size_s =
            r.cwrap("AVCodecParameters_extradata_size_s", null, [
              "number",
              "number",
            ])),
        Jf =
          (r.AVCodecParameters_format =
          c.AVCodecParameters_format =
            r.cwrap("AVCodecParameters_format", "number", ["number"])),
        GV =
          (r.AVCodecParameters_format_s =
          c.AVCodecParameters_format_s =
            r.cwrap("AVCodecParameters_format_s", null, ["number", "number"])),
        KV =
          (r.AVCodecParameters_framerate_num =
          c.AVCodecParameters_framerate_num =
            r.cwrap("AVCodecParameters_framerate_num", "number", ["number"])),
        ZV =
          (r.AVCodecParameters_framerate_num_s =
          c.AVCodecParameters_framerate_num_s =
            r.cwrap("AVCodecParameters_framerate_num_s", null, [
              "number",
              "number",
            ])),
        QV =
          (r.AVCodecParameters_framerate_den =
          c.AVCodecParameters_framerate_den =
            r.cwrap("AVCodecParameters_framerate_den", "number", ["number"])),
        eb =
          (r.AVCodecParameters_framerate_den_s =
          c.AVCodecParameters_framerate_den_s =
            r.cwrap("AVCodecParameters_framerate_den_s", null, [
              "number",
              "number",
            ])),
        rb =
          (r.AVCodecParameters_framerate_s =
          c.AVCodecParameters_framerate_s =
            r.cwrap("AVCodecParameters_framerate_s", null, [
              "number",
              "number",
              "number",
            ])),
        Xf =
          (r.AVCodecParameters_height =
          c.AVCodecParameters_height =
            r.cwrap("AVCodecParameters_height", "number", ["number"])),
        ab =
          (r.AVCodecParameters_height_s =
          c.AVCodecParameters_height_s =
            r.cwrap("AVCodecParameters_height_s", null, ["number", "number"])),
        Gf =
          (r.AVCodecParameters_level =
          c.AVCodecParameters_level =
            r.cwrap("AVCodecParameters_level", "number", ["number"])),
        tb =
          (r.AVCodecParameters_level_s =
          c.AVCodecParameters_level_s =
            r.cwrap("AVCodecParameters_level_s", null, ["number", "number"])),
        Kf =
          (r.AVCodecParameters_profile =
          c.AVCodecParameters_profile =
            r.cwrap("AVCodecParameters_profile", "number", ["number"])),
        _b =
          (r.AVCodecParameters_profile_s =
          c.AVCodecParameters_profile_s =
            r.cwrap("AVCodecParameters_profile_s", null, ["number", "number"])),
        Zf =
          (r.AVCodecParameters_sample_rate =
          c.AVCodecParameters_sample_rate =
            r.cwrap("AVCodecParameters_sample_rate", "number", ["number"])),
        nb =
          (r.AVCodecParameters_sample_rate_s =
          c.AVCodecParameters_sample_rate_s =
            r.cwrap("AVCodecParameters_sample_rate_s", null, [
              "number",
              "number",
            ])),
        Qf =
          (r.AVCodecParameters_width =
          c.AVCodecParameters_width =
            r.cwrap("AVCodecParameters_width", "number", ["number"])),
        ob =
          (r.AVCodecParameters_width_s =
          c.AVCodecParameters_width_s =
            r.cwrap("AVCodecParameters_width_s", null, ["number", "number"])),
        ft =
          (r.AVPacket_data =
          c.AVPacket_data =
            r.cwrap("AVPacket_data", "number", ["number"])),
        sb =
          (r.AVPacket_data_s =
          c.AVPacket_data_s =
            r.cwrap("AVPacket_data_s", null, ["number", "number"])),
        ev =
          (r.AVPacket_dts =
          c.AVPacket_dts =
            r.cwrap("AVPacket_dts", "number", ["number"])),
        cb =
          (r.AVPacket_dts_s =
          c.AVPacket_dts_s =
            r.cwrap("AVPacket_dts_s", null, ["number", "number"])),
        rv =
          (r.AVPacket_dtshi =
          c.AVPacket_dtshi =
            r.cwrap("AVPacket_dtshi", "number", ["number"])),
        ib =
          (r.AVPacket_dtshi_s =
          c.AVPacket_dtshi_s =
            r.cwrap("AVPacket_dtshi_s", null, ["number", "number"])),
        av =
          (r.AVPacket_duration =
          c.AVPacket_duration =
            r.cwrap("AVPacket_duration", "number", ["number"])),
        mb =
          (r.AVPacket_duration_s =
          c.AVPacket_duration_s =
            r.cwrap("AVPacket_duration_s", null, ["number", "number"])),
        tv =
          (r.AVPacket_durationhi =
          c.AVPacket_durationhi =
            r.cwrap("AVPacket_durationhi", "number", ["number"])),
        lb =
          (r.AVPacket_durationhi_s =
          c.AVPacket_durationhi_s =
            r.cwrap("AVPacket_durationhi_s", null, ["number", "number"])),
        _v =
          (r.AVPacket_flags =
          c.AVPacket_flags =
            r.cwrap("AVPacket_flags", "number", ["number"])),
        ub =
          (r.AVPacket_flags_s =
          c.AVPacket_flags_s =
            r.cwrap("AVPacket_flags_s", null, ["number", "number"])),
        db =
          (r.AVPacket_pos =
          c.AVPacket_pos =
            r.cwrap("AVPacket_pos", "number", ["number"])),
        fb =
          (r.AVPacket_pos_s =
          c.AVPacket_pos_s =
            r.cwrap("AVPacket_pos_s", null, ["number", "number"])),
        vb =
          (r.AVPacket_poshi =
          c.AVPacket_poshi =
            r.cwrap("AVPacket_poshi", "number", ["number"])),
        pb =
          (r.AVPacket_poshi_s =
          c.AVPacket_poshi_s =
            r.cwrap("AVPacket_poshi_s", null, ["number", "number"])),
        nv =
          (r.AVPacket_pts =
          c.AVPacket_pts =
            r.cwrap("AVPacket_pts", "number", ["number"])),
        Ab =
          (r.AVPacket_pts_s =
          c.AVPacket_pts_s =
            r.cwrap("AVPacket_pts_s", null, ["number", "number"])),
        ov =
          (r.AVPacket_ptshi =
          c.AVPacket_ptshi =
            r.cwrap("AVPacket_ptshi", "number", ["number"])),
        Vb =
          (r.AVPacket_ptshi_s =
          c.AVPacket_ptshi_s =
            r.cwrap("AVPacket_ptshi_s", null, ["number", "number"])),
        sv =
          (r.AVPacket_side_data =
          c.AVPacket_side_data =
            r.cwrap("AVPacket_side_data", "number", ["number"])),
        bb =
          (r.AVPacket_side_data_s =
          c.AVPacket_side_data_s =
            r.cwrap("AVPacket_side_data_s", null, ["number", "number"])),
        cv =
          (r.AVPacket_side_data_elems =
          c.AVPacket_side_data_elems =
            r.cwrap("AVPacket_side_data_elems", "number", ["number"])),
        hb =
          (r.AVPacket_side_data_elems_s =
          c.AVPacket_side_data_elems_s =
            r.cwrap("AVPacket_side_data_elems_s", null, ["number", "number"])),
        qr =
          (r.AVPacket_size =
          c.AVPacket_size =
            r.cwrap("AVPacket_size", "number", ["number"])),
        Cb =
          (r.AVPacket_size_s =
          c.AVPacket_size_s =
            r.cwrap("AVPacket_size_s", null, ["number", "number"])),
        vt =
          (r.AVPacket_stream_index =
          c.AVPacket_stream_index =
            r.cwrap("AVPacket_stream_index", "number", ["number"])),
        wb =
          (r.AVPacket_stream_index_s =
          c.AVPacket_stream_index_s =
            r.cwrap("AVPacket_stream_index_s", null, ["number", "number"])),
        Me =
          (r.AVPacket_time_base_num =
          c.AVPacket_time_base_num =
            r.cwrap("AVPacket_time_base_num", "number", ["number"])),
        yb =
          (r.AVPacket_time_base_num_s =
          c.AVPacket_time_base_num_s =
            r.cwrap("AVPacket_time_base_num_s", null, ["number", "number"])),
        or =
          (r.AVPacket_time_base_den =
          c.AVPacket_time_base_den =
            r.cwrap("AVPacket_time_base_den", "number", ["number"])),
        gb =
          (r.AVPacket_time_base_den_s =
          c.AVPacket_time_base_den_s =
            r.cwrap("AVPacket_time_base_den_s", null, ["number", "number"])),
        Re =
          (r.AVPacket_time_base_s =
          c.AVPacket_time_base_s =
            r.cwrap("AVPacket_time_base_s", null, [
              "number",
              "number",
              "number",
            ])),
        xb =
          (r.AVFormatContext_duration =
          c.AVFormatContext_duration =
            r.cwrap("AVFormatContext_duration", "number", ["number"])),
        kb =
          (r.AVFormatContext_duration_s =
          c.AVFormatContext_duration_s =
            r.cwrap("AVFormatContext_duration_s", null, ["number", "number"])),
        Fb =
          (r.AVFormatContext_durationhi =
          c.AVFormatContext_durationhi =
            r.cwrap("AVFormatContext_durationhi", "number", ["number"])),
        Pb =
          (r.AVFormatContext_durationhi_s =
          c.AVFormatContext_durationhi_s =
            r.cwrap("AVFormatContext_durationhi_s", null, [
              "number",
              "number",
            ])),
        Eb =
          (r.AVFormatContext_flags =
          c.AVFormatContext_flags =
            r.cwrap("AVFormatContext_flags", "number", ["number"])),
        Db =
          (r.AVFormatContext_flags_s =
          c.AVFormatContext_flags_s =
            r.cwrap("AVFormatContext_flags_s", null, ["number", "number"])),
        iv =
          (r.AVFormatContext_nb_streams =
          c.AVFormatContext_nb_streams =
            r.cwrap("AVFormatContext_nb_streams", "number", ["number"])),
        Sb =
          (r.AVFormatContext_nb_streams_s =
          c.AVFormatContext_nb_streams_s =
            r.cwrap("AVFormatContext_nb_streams_s", null, [
              "number",
              "number",
            ])),
        mv =
          (r.AVFormatContext_oformat =
          c.AVFormatContext_oformat =
            r.cwrap("AVFormatContext_oformat", "number", ["number"])),
        jb =
          (r.AVFormatContext_oformat_s =
          c.AVFormatContext_oformat_s =
            r.cwrap("AVFormatContext_oformat_s", null, ["number", "number"])),
        Tb =
          (r.AVFormatContext_pb =
          c.AVFormatContext_pb =
            r.cwrap("AVFormatContext_pb", "number", ["number"])),
        lv =
          (r.AVFormatContext_pb_s =
          c.AVFormatContext_pb_s =
            r.cwrap("AVFormatContext_pb_s", null, ["number", "number"])),
        zb =
          (r.AVFormatContext_start_time =
          c.AVFormatContext_start_time =
            r.cwrap("AVFormatContext_start_time", "number", ["number"])),
        Mb =
          (r.AVFormatContext_start_time_s =
          c.AVFormatContext_start_time_s =
            r.cwrap("AVFormatContext_start_time_s", null, [
              "number",
              "number",
            ])),
        Rb =
          (r.AVFormatContext_start_timehi =
          c.AVFormatContext_start_timehi =
            r.cwrap("AVFormatContext_start_timehi", "number", ["number"])),
        Ib =
          (r.AVFormatContext_start_timehi_s =
          c.AVFormatContext_start_timehi_s =
            r.cwrap("AVFormatContext_start_timehi_s", null, [
              "number",
              "number",
            ])),
        Wr =
          (r.AVFormatContext_streams_a =
          c.AVFormatContext_streams_a =
            r.cwrap("AVFormatContext_streams_a", "number", [
              "number",
              "number",
            ])),
        Ob =
          (r.AVFormatContext_streams_a_s =
          c.AVFormatContext_streams_a_s =
            r.cwrap("AVFormatContext_streams_a_s", null, [
              "number",
              "number",
              "number",
            ])),
        pt =
          (r.AVStream_codecpar =
          c.AVStream_codecpar =
            r.cwrap("AVStream_codecpar", "number", ["number"])),
        Ub =
          (r.AVStream_codecpar_s =
          c.AVStream_codecpar_s =
            r.cwrap("AVStream_codecpar_s", null, ["number", "number"])),
        Nb =
          (r.AVStream_discard =
          c.AVStream_discard =
            r.cwrap("AVStream_discard", "number", ["number"])),
        Lb =
          (r.AVStream_discard_s =
          c.AVStream_discard_s =
            r.cwrap("AVStream_discard_s", null, ["number", "number"])),
        uv =
          (r.AVStream_duration =
          c.AVStream_duration =
            r.cwrap("AVStream_duration", "number", ["number"])),
        Hb =
          (r.AVStream_duration_s =
          c.AVStream_duration_s =
            r.cwrap("AVStream_duration_s", null, ["number", "number"])),
        dv =
          (r.AVStream_durationhi =
          c.AVStream_durationhi =
            r.cwrap("AVStream_durationhi", "number", ["number"])),
        Bb =
          (r.AVStream_durationhi_s =
          c.AVStream_durationhi_s =
            r.cwrap("AVStream_durationhi_s", null, ["number", "number"])),
        $r =
          (r.AVStream_time_base_num =
          c.AVStream_time_base_num =
            r.cwrap("AVStream_time_base_num", "number", ["number"])),
        qb =
          (r.AVStream_time_base_num_s =
          c.AVStream_time_base_num_s =
            r.cwrap("AVStream_time_base_num_s", null, ["number", "number"])),
        Yr =
          (r.AVStream_time_base_den =
          c.AVStream_time_base_den =
            r.cwrap("AVStream_time_base_den", "number", ["number"])),
        Wb =
          (r.AVStream_time_base_den_s =
          c.AVStream_time_base_den_s =
            r.cwrap("AVStream_time_base_den_s", null, ["number", "number"])),
        fv =
          (r.AVStream_time_base_s =
          c.AVStream_time_base_s =
            r.cwrap("AVStream_time_base_s", null, [
              "number",
              "number",
              "number",
            ])),
        $b =
          (r.AVFilterInOut_filter_ctx =
          c.AVFilterInOut_filter_ctx =
            r.cwrap("AVFilterInOut_filter_ctx", "number", ["number"])),
        At =
          (r.AVFilterInOut_filter_ctx_s =
          c.AVFilterInOut_filter_ctx_s =
            r.cwrap("AVFilterInOut_filter_ctx_s", null, ["number", "number"])),
        Yb =
          (r.AVFilterInOut_name =
          c.AVFilterInOut_name =
            r.cwrap("AVFilterInOut_name", "number", ["number"])),
        Vt =
          (r.AVFilterInOut_name_s =
          c.AVFilterInOut_name_s =
            r.cwrap("AVFilterInOut_name_s", null, ["number", "number"])),
        Jb =
          (r.AVFilterInOut_next =
          c.AVFilterInOut_next =
            r.cwrap("AVFilterInOut_next", "number", ["number"])),
        bt =
          (r.AVFilterInOut_next_s =
          c.AVFilterInOut_next_s =
            r.cwrap("AVFilterInOut_next_s", null, ["number", "number"])),
        Xb =
          (r.AVFilterInOut_pad_idx =
          c.AVFilterInOut_pad_idx =
            r.cwrap("AVFilterInOut_pad_idx", "number", ["number"])),
        ht =
          (r.AVFilterInOut_pad_idx_s =
          c.AVFilterInOut_pad_idx_s =
            r.cwrap("AVFilterInOut_pad_idx_s", null, ["number", "number"])),
        Ct =
          (r.av_frame_free_js =
          c.av_frame_free_js =
            function (e) {
              var a = G(4);
              if (a === 0) throw new Error("Could not malloc");
              ((new Uint32Array(r.HEAPU8.buffer, a, 1)[0] = e),
                c.av_frame_free(a),
                q(a));
            }),
        wt =
          (r.av_packet_free_js =
          c.av_packet_free_js =
            function (e) {
              var a = G(4);
              if (a === 0) throw new Error("Could not malloc");
              ((new Uint32Array(r.HEAPU8.buffer, a, 1)[0] = e),
                c.av_packet_free(a),
                q(a));
            }),
        Gb =
          (r.avformat_close_input_js =
          c.avformat_close_input_js =
            function (e) {
              var a = G(4);
              if (a === 0) throw new Error("Could not malloc");
              ((new Uint32Array(r.HEAPU8.buffer, a, 1)[0] = e),
                c.avformat_close_input(a),
                q(a));
            }),
        vv =
          (r.avcodec_free_context_js =
          c.avcodec_free_context_js =
            function (e) {
              var a = G(4);
              if (a === 0) throw new Error("Could not malloc");
              ((new Uint32Array(r.HEAPU8.buffer, a, 1)[0] = e),
                c.avcodec_free_context(a),
                q(a));
            }),
        pv =
          (r.avcodec_parameters_free_js =
          c.avcodec_parameters_free_js =
            function (e) {
              var a = G(4);
              if (a === 0) throw new Error("Could not malloc");
              ((new Uint32Array(r.HEAPU8.buffer, a, 1)[0] = e),
                c.avcodec_parameters_free(a),
                q(a));
            }),
        Kb =
          (r.avfilter_graph_free_js =
          c.avfilter_graph_free_js =
            function (e) {
              var a = G(4);
              if (a === 0) throw new Error("Could not malloc");
              ((new Uint32Array(r.HEAPU8.buffer, a, 1)[0] = e),
                c.avfilter_graph_free(a),
                q(a));
            }),
        Zb =
          (r.avfilter_inout_free_js =
          c.avfilter_inout_free_js =
            function (e) {
              var a = G(4);
              if (a === 0) throw new Error("Could not malloc");
              ((new Uint32Array(r.HEAPU8.buffer, a, 1)[0] = e),
                c.avfilter_inout_free(a),
                q(a));
            }),
        Qb =
          (r.av_dict_free_js =
          c.av_dict_free_js =
            function (e) {
              var a = G(4);
              if (a === 0) throw new Error("Could not malloc");
              ((new Uint32Array(r.HEAPU8.buffer, a, 1)[0] = e),
                c.av_dict_free(a),
                q(a));
            }),
        Ie =
          (r.copyin_u8 =
          c.copyin_u8 =
            function (e, a) {
              var t = new Uint8Array(r.HEAPU8.buffer, e);
              t.set(a);
            }),
        Oe =
          (r.copyout_u8 =
          c.copyout_u8 =
            function (e, a) {
              var t = new Uint8Array(r.HEAPU8.buffer, e, a).slice(0);
              return ((t.libavjsTransfer = [t.buffer]), t);
            }),
        yt =
          (r.copyin_s16 =
          c.copyin_s16 =
            function (e, a) {
              var t = new Int16Array(r.HEAPU8.buffer, e);
              t.set(a);
            }),
        gt =
          (r.copyout_s16 =
          c.copyout_s16 =
            function (e, a) {
              var t = new Int16Array(r.HEAPU8.buffer, e, a).slice(0);
              return ((t.libavjsTransfer = [t.buffer]), t);
            }),
        xt =
          (r.copyin_s32 =
          c.copyin_s32 =
            function (e, a) {
              var t = new Int32Array(r.HEAPU8.buffer, e);
              t.set(a);
            }),
        kt =
          (r.copyout_s32 =
          c.copyout_s32 =
            function (e, a) {
              var t = new Int32Array(r.HEAPU8.buffer, e, a).slice(0);
              return ((t.libavjsTransfer = [t.buffer]), t);
            }),
        Ft =
          (r.copyin_f32 =
          c.copyin_f32 =
            function (e, a) {
              var t = new Float32Array(r.HEAPU8.buffer, e);
              t.set(a);
            }),
        Pt =
          (r.copyout_f32 =
          c.copyout_f32 =
            function (e, a) {
              var t = new Float32Array(r.HEAPU8.buffer, e, a).slice(0);
              return ((t.libavjsTransfer = [t.buffer]), t);
            });
      function ke(e) {
        r[e] = function () {
          try {
            return o[e].apply(o, arguments);
          } catch (a) {
            throw (
              a &&
                a.name === "ErrnoError" &&
                ((a.message = ff(a.errno)),
                typeof arguments[0] == "string" &&
                  (a.message = arguments[0] + ": " + a.message)),
              a
            );
          }
        };
      }
      var Et = o.makedev(44, 0);
      (o.registerDevice(Et, vd),
        (r.readBuffers = Object.create(null)),
        (r.blockReadBuffers = Object.create(null)));
      var Jr = o.makedev(44, 1);
      o.registerDevice(Jr, Ge);
      var Dt = o.makedev(44, 2);
      (o.registerDevice(Dt, Er),
        ke("readFile"),
        ke("writeFile"),
        ke("unlink"),
        ke("unmount"),
        ke("mkdev"),
        ke("createLazyFile"),
        (r.mkreaderdev = function (e, a) {
          return (
            o.mkdev(e, a || 511, Et),
            (r.readBuffers[e] = {
              buf: new Uint8Array(0),
              eof: !1,
              errorCode: 0,
              error: null,
            }),
            0
          );
        }));
      var Av = (r.mkblockreaderdev = function (e, a) {
          o.writeFile(e, new Uint8Array(0));
          var t = o.open(e, 0),
            _ = t.node.node_ops,
            n = (t.node.node_ops = Object.create(_));
          ((n.getattr = function (i) {
            var m = _.getattr(i);
            return (
              (m.size = a),
              (m.blksize = 4096),
              (m.blocks = Math.ceil(a / 4096)),
              m
            );
          }),
            (t.node.stream_ops = pd),
            (t.node.ff_block_reader_dev_size = a),
            (r.blockReadBuffers[e] = {
              position: -1,
              buf: new Uint8Array(0),
              ready: !1,
              errorCode: 0,
              error: null,
            }),
            o.close(t));
        }),
        sr = {},
        Xr = null;
      function St(e, a, t) {
        if (!(e in sr)) return Xr ? Xr(e, a, t) : void 0;
        var _ = sr[e];
        function n() {
          if (_.position !== a) {
            ((_.position = a),
              (_.buf = null),
              (_.bufPromise = _.file
                .slice(a, a + t)
                .arrayBuffer()
                .then(function (i) {
                  _.buf = i;
                })
                .catch(function (i) {
                  (console.error(
                    i +
                      `
` +
                      i.stack,
                  ),
                    (_.buf = new Uint8Array(0)));
                })
                .then(n)));
            return;
          }
          (zt(e, a, new Uint8Array(_.buf)),
            (a += t),
            (_.position = a),
            (_.buf = null),
            (_.bufPromise = _.file
              .slice(a, a + t)
              .arrayBuffer()
              .then(function (i) {
                _.buf = i;
              })
              .catch(function (i) {
                (console.error(
                  i +
                    `
` +
                    i.stack,
                ),
                  (_.buf = new Uint8Array(0)));
              })));
        }
        !_.buf && _.bufPromise ? _.bufPromise.then(n) : n();
      }
      ((r.mkreadaheadfile = function (e, a) {
        (r.onblockread !== St && ((Xr = r.onblockread), (r.onblockread = St)),
          Av(e, a.size),
          (sr[e] = { file: a, position: -1, bufPromise: null, buf: null }));
      }),
        (r.unlinkreadaheadfile = function (e) {
          (o.unlink(e), delete sr[e]);
        }));
      var Vv = (r.mkwriterdev = function (e, a) {
        return (o.mkdev(e, a || 511, Jr), 0);
      });
      ((r.mkstreamwriterdev = function (e, a) {
        return (o.mkdev(e, a || 511, Dt), 0);
      }),
        (r.mountwriterfs = function (e) {
          try {
            o.mkdir(e);
          } catch {}
          return (o.mount(ae, {}, e), 0);
        }),
        (r.ff_reader_dev_waiters = Object.create(null)),
        (r.mkworkerfsfile = function (e, a) {
          return (
            o.mkdir("/" + e + ".d"),
            o.mount(
              WORKERFS,
              { blobs: [{ name: e, data: a }] },
              "/" + e + ".d",
            ),
            "/" + e + ".d/" + e
          );
        }),
        (r.unlinkworkerfsfile = function (e) {
          (o.unmount("/" + e + ".d"), o.rmdir("/" + e + ".d"));
        }));
      var Ue = {},
        Gr = null;
      function jt(e, a, t) {
        if (!(e in Ue)) return Gr ? Gr(e, a, t) : void 0;
        var _ = Ue[e];
        if (((t = t.slice(0)), _.syncHandle)) {
          _.syncHandle.write(t.buffer, { at: a });
          return;
        }
        var n = _.promise.then(function () {
          return _.handle.write({ type: "write", position: a, data: t });
        });
        return ((_.promise = n.catch(console.error)), n);
      }
      ((r.mkfsfhfile = function (e, a) {
        (r.onwrite !== jt && ((Gr = r.onwrite), (r.onwrite = jt)), Vv(e));
        var t = (Ue[e] = { promise: Promise.all([]) });
        return (
          (t.promise = t.promise
            .then(function () {
              return a.createSyncAccessHandle();
            })
            .then(function (_) {
              t.syncHandle = _;
            })
            .catch(function () {
              return a.createWritable();
            })
            .then(function (_) {
              t.handle = _;
            })),
          t.promise
        );
      }),
        (r.unlinkfsfhfile = function (e) {
          o.unlink(e);
          var a = Ue[e];
          return (
            delete Ue[e],
            a.syncHandle
              ? (a.syncHandle.close(), Promise.all([]))
              : a.promise.then(function () {
                  return a.handle.close();
                })
          );
        }));
      var Tt = (r.ff_reader_dev_send = function (e, a, t) {
          t = t || {};
          var _ = r.readBuffers[e];
          if (a === null) _.eof = !0;
          else {
            var n = new Uint8Array(_.buf.length + a.length);
            (n.set(_.buf), n.set(a, _.buf.length), (_.buf = n));
          }
          ((_.ready = !0),
            (_.errorCode = 0),
            typeof t.errorCode == "number" && (_.errorCode = t.errorCode),
            (_.error = null),
            t.error && (_.error = t.error));
          var i = r.ff_reader_dev_waiters[e] || [];
          delete r.ff_reader_dev_waiters[e];
          for (var m = 0; m < i.length; m++) i[m]();
        }),
        zt = (r.ff_block_reader_dev_send = function (e, a, t, _) {
          _ = _ || {};
          var n = r.blockReadBuffers[e];
          ((n.position = a),
            (n.buf = t),
            (n.ready = !0),
            (n.errorCode = 0),
            (n.error = null),
            t === null && (n.buf = new Uint8Array(0)),
            typeof _.errorCode == "number" && (n.errorCode = _.errorCode),
            _.error && (n.error = _.error));
          var i = r.ff_reader_dev_waiters[e] || [];
          delete r.ff_reader_dev_waiters[e];
          for (var m = 0; m < i.length; m++) i[m]();
        }),
        eh = (r.ff_reader_dev_waiting = function (e) {
          return (
            console.log(
              "[libav.js] ff_reader_dev_waiting is deprecated. Use the onread callback.",
            ),
            rt().then(function () {
              return e
                ? !!r.ff_reader_dev_waiters[e]
                : !!Object.keys(r.ff_reader_dev_waiters).length;
            })
          );
        });
      ((r.readerDevReady = function (e) {
        var a = o.streams[e].node.name;
        return a in r.readBuffers
          ? r.readBuffers[a].ready
          : a in r.blockReadBuffers
            ? r.blockReadBuffers[a].ready
            : !1;
      }),
        (r.fdName = function (e) {
          return o.streams[e].node.name;
        }));
      var rh = (r.ff_init_encoder = function (e, a) {
          a = a || {};
          var t = zd(e);
          if (t === 0) throw new Error("Codec not found");
          var _ = Qa(t);
          if (_ === 0)
            throw new Error("Could not allocate audio codec context");
          var n = a.ctx || {};
          for (var i in n) this["AVCodecContext_" + i + "_s"](_, n[i]);
          var m = a.time_base || [1, 1e3];
          lt(_, m[0], m[1]);
          var l = 0;
          if (a.options) for (var i in a.options) l = mf(l, i, a.options[i], 0);
          var u = Rd(_, t, l);
          if (u < 0) throw new Error("Could not open codec: " + I(u));
          var f = Wa();
          if (f === 0) throw new Error("Could not allocate frame");
          var d = Xa();
          if (d === 0) throw new Error("Could not allocate packet");
          var A = Tf(_);
          return [t, _, f, d, A];
        }),
        ah = (r.ff_init_decoder = function (e, a) {
          typeof a == "number" ? (a = { codecpar: a }) : (a = a || {});
          var t, _;
          if ((typeof e == "string" ? (t = Td(e)) : (t = jd(e)), t === 0))
            throw new Error("Codec not found");
          var n = Qa(t);
          if (n === 0)
            throw new Error("Could not allocate audio codec context");
          var i = ct(n);
          if (a.codecpar) {
            var m = 0,
              l = a.codecpar;
            if (typeof l == "object") {
              if (((m = Id()), m === 0))
                throw new Error("Failed to allocate codec parameters");
              (zv(m, l), (l = m));
            }
            if (((_ = Nd(n, l)), m && pv(m), _ < 0))
              throw new Error("Could not set codec parameters: " + I(_));
          }
          if (
            (ct(n) === 0 && jf(n, i),
            a.time_base && lt(n, a.time_base[0], a.time_base[1]),
            (_ = Md(n, t, 0)),
            _ < 0)
          )
            throw new Error("Could not open codec: " + I(_));
          var u = Xa();
          if (u === 0) throw new Error("Could not allocate packet");
          var f = Wa();
          if (f === 0) throw new Error("Could not allocate frame");
          return [t, n, u, f];
        }),
        bv = (r.ff_free_encoder = function (e, a, t) {
          (Ct(a), wt(t), vv(e));
        }),
        th = (r.ff_free_decoder = function (e, a, t) {
          bv(e, t, a);
        }),
        _h = (r.ff_encode_multi = function (e, a, t, _, n) {
          typeof n == "boolean" ? (n = { fin: n }) : (n = n || {});
          var i = [],
            m = it(e),
            l = mt(e),
            u = function (d) {
              var A = Zr(d);
              return (
                A.time_base_num ||
                  ((A.time_base_num = m), (A.time_base_den = l)),
                A
              );
            };
          n.copyoutPacket === "ptr" &&
            (u = function (d) {
              var A = Nt(d);
              return (Me(A) || Re(A, m, l), A);
            });
          function f(d) {
            if (d !== null && (Ut(a, d), m))
              if (typeof d == "number") {
                var A = ze(a);
                A && (Ja(a, A, tr(a), m, l), _r(a, m, l));
              } else
                d &&
                  d.time_base_num &&
                  (Ja(a, d.time_base_num, d.time_base_den, m, l), _r(a, m, l));
            var p = Bd(e, d ? a : 0);
            if (p < 0)
              throw new Error(
                "Error sending the frame to the encoder: " + I(p),
              );
            for (d && we(a); ; ) {
              if (((p = Hd(e, t)), p === -6 || p === -541478725)) return;
              if (p < 0) throw new Error("Error encoding audio frame: " + I(p));
              (i.push(u(t)), Q(t));
            }
          }
          return (_.forEach(f), n.fin && f(null), i);
        }),
        hv = (r.ff_decode_multi = function (e, a, t, _, n) {
          var i = [],
            m = [];
          typeof n == "boolean" ? (n = { fin: n }) : (n = n || {});
          var l = it(e),
            u = mt(e),
            f = Kr;
          n.copyoutFrame && (f = Ot[n.copyoutFrame]);
          var d = function (p) {
            var v = f(p);
            return (
              v.time_base_num || ((v.time_base_num = l), (v.time_base_den = u)),
              v
            );
          };
          n.copyoutFrame === "ptr" &&
            (d = function (p) {
              var v = It(p);
              return (ze(v) || _r(v, l, u), v);
            });
          function A(p) {
            var v;
            if (p !== null) {
              if (((v = et(a)), v < 0))
                throw new Error("Failed to make packet writable: " + I(v));
              if ((Lt(a, p), l))
                if (typeof p == "number") {
                  var b = Me(a);
                  b && (Sr(a, b, or(a), l, u), Re(a, l, u));
                } else
                  p &&
                    p.time_base_num &&
                    (Sr(a, p.time_base_num, p.time_base_den, l, u),
                    Re(a, l, u));
            } else Q(a);
            if (((v = qd(e, a)), v < 0)) {
              var y = "Error submitting the packet to the decoder: " + I(v);
              if (n.ignoreErrors) {
                (console.log(y), Q(a));
                return;
              } else throw new Error(y);
            }
            for (Q(a); ; ) {
              if (((v = Ld(e, t)), v === -6 || v === -541478725)) return;
              if (v < 0) throw new Error("Error decoding audio frame: " + I(v));
              var w = d(t);
              (w &&
                w.libavjsTransfer &&
                w.libavjsTransfer.length &&
                m.push.apply(m, w.libavjsTransfer),
                i.push(w),
                we(t));
            }
          }
          return (_.forEach(A), n.fin && A(null), (i.libavjsTransfer = m), i);
        }),
        Cv = (r.ff_set_packet = function (e, a) {
          if (a.length === 0) Q(e);
          else {
            var t = qr(e);
            if (t < a.length) {
              var _ = _f(e, a.length - t);
              if (_ < 0) throw new Error("Error growing packet: " + I(_));
            } else t > a.length && sf(e, a.length);
          }
          var n = ft(e);
          r.HEAPU8.set(a, n);
        }),
        nh = (r.ff_init_muxer = function (e, a) {
          var t = e.oformat ? e.oformat : 0,
            _ = e.format_name ? e.format_name : null,
            n = e.filename ? e.filename : null,
            i = Wd(t, _, n);
          if (i === 0) throw new Error("Failed to allocate output context");
          var m = mv(i),
            l = [];
          (a.forEach(function (f) {
            var d = Jd(i, 0);
            if (d === 0) throw new Error("Could not allocate stream");
            l.push(d);
            var A = pt(d),
              p;
            if (
              (e.codecpars ? ((p = Od(A, f[0])), Uf(A, 0)) : (p = Ud(A, f[0])),
              p < 0)
            )
              throw new Error("Could not copy the stream parameters: " + I(p));
            fv(d, f[1], f[2]);
          }),
            e.device && o.mkdev(e.filename, 511, Jr));
          var u = null;
          if (e.open) {
            if (((u = af(e.filename, 2, 0, 0)), u === 0))
              throw new Error("Could not open file");
            lv(i, u);
          }
          return [i, m, u, l];
        }),
        oh = (r.ff_free_muxer = function (e, a) {
          (Yd(e), a && tf(a));
        });
      function wv(e, a) {
        var t;
        return er(e, a || null, null)
          .then(function (_) {
            if (((t = _), t === 0))
              throw new Error("Could not open source file");
            return Qe(t, 0);
          })
          .then(function () {
            for (var _ = iv(t), n = [], i = 0; i < _; i++) {
              var m = Wr(t, i),
                l = { ptr: m, index: i },
                u = pt(m);
              ((l.codecpar = u),
                (l.codec_type = dt(u)),
                (l.codec_id = ut(u)),
                (l.time_base_num = $r(m)),
                (l.time_base_den = Yr(m)),
                (l.duration_time_base = uv(m) + dv(m) * 4294967296),
                (l.duration =
                  (l.duration_time_base * l.time_base_num) / l.time_base_den),
                n.push(l));
            }
            return [t, n];
          });
      }
      r.ff_init_demuxer_file = function () {
        var e = arguments;
        return U(function () {
          return wv.apply(void 0, e);
        });
      };
      var sh = (r.ff_write_multi = function (e, a, t, _) {
        var n = nf;
        _ === !1 && (n = cf);
        var i = {};
        (t.forEach(function (m) {
          var l = et(a);
          if (l < 0) throw new Error("Error making packet writable: " + I(l));
          Lt(a, m);
          var u = m.stream_index || 0,
            f,
            d;
          if (
            (typeof m == "number"
              ? ((f = Me(a)), (d = or(a)))
              : ((f = m.time_base_num), (d = m.time_base_den)),
            f)
          ) {
            var A = i[u];
            if (!A) {
              var p = Wr(e, u);
              A = i[u] = [$r(p), Yr(p)];
            }
            A[0] && (Sr(a, f, d, A[0], A[1]), Re(a, A[0], A[1]));
          }
          (n(e, a), Q(a));
        }),
          Q(a));
      });
      function yv(e, a, t) {
        var _ = 0,
          n = {},
          i = {};
        (typeof t == "number" && (t = { limit: t }),
          typeof t > "u" && (t = {}));
        var m = !!t.unify,
          l = Zr;
        t.copyoutPacket && (l = Sv[t.copyoutPacket]);
        function u() {
          return ar(e, a).then(function (f) {
            if (f < 0) return [f, n];
            var d = l(a),
              A = vt(a),
              p,
              v;
            if (
              (typeof d == "number"
                ? ((p = Me(d)), (v = or(d)))
                : ((p = d.time_base_num), (v = d.time_base_den)),
              !p)
            ) {
              var b = i[A];
              if (!b) {
                var y = Wr(e, A);
                b = i[A] = [$r(y), Yr(y)];
              }
              typeof d == "number"
                ? Re(d, b[0], b[1])
                : ((d.time_base_num = b[0]), (d.time_base_den = b[1]));
            }
            var w = m ? 0 : A;
            return (
              w in n || (n[w] = []),
              n[w].push(d),
              (_ += qr(a)),
              Q(a),
              t.limit && _ >= t.limit ? [-6, n] : Promise.all([]).then(u)
            );
          });
        }
        return u();
      }
      ((r.ff_read_frame_multi = function () {
        var e = arguments;
        return U(function () {
          return yv.apply(void 0, e);
        });
      }),
        (r.ff_read_multi = function (e, a, t, _) {
          return (
            console.log(
              "[libav.js] ff_read_multi is deprecated. Use ff_read_frame_multi.",
            ),
            r.ff_read_frame_multi(e, a, _)
          );
        }));
      var ch = (r.ff_init_filter_graph = function (e, a, t) {
          var _,
            n,
            i,
            m,
            l,
            u,
            f,
            d,
            A,
            p,
            v,
            b,
            y,
            w,
            F = !!a.length;
          F || (a = [a]);
          var M = !!t.length;
          (M || (t = [t]), (d = []), (A = []));
          try {
            if (
              ((_ = Ke("buffer")),
              (n = Ke("abuffer")),
              (i = Ke("buffersink")),
              (m = Ke("abuffersink")),
              (l = Pd()),
              l === 0)
            )
              throw new Error("Failed to allocate filter graph");
            p = 0;
            var P = 0;
            (a.forEach(function (g) {
              var S = Ka();
              if (S === 0) throw new Error("Failed to allocate outputs");
              (bt(S, p), (p = S));
              var K = "in" + (F ? P : "");
              if (g.type === 0) {
                if (_ === 0) throw new Error("Failed to load buffer filter");
                var ee = g.frame_rate,
                  J = g.time_base;
                (typeof ee > "u" && (ee = 30),
                  typeof J > "u" && (J = [1, ee]),
                  (u = Ze(
                    _,
                    K,
                    "time_base=" +
                      J[0] +
                      "/" +
                      J[1] +
                      ":frame_rate=" +
                      ee +
                      ":pix_fmt=" +
                      (g.pix_fmt ? g.pix_fmt : 0) +
                      ":width=" +
                      (g.width ? g.width : 640) +
                      ":height=" +
                      (g.height ? g.height : 360),
                    null,
                    l,
                  )));
              } else {
                if (n === 0) throw new Error("Failed to load abuffer filter");
                var Fe = g.sample_rate,
                  J = g.time_base;
                (typeof Fe > "u" && (Fe = 48e3),
                  typeof J > "u" && (J = [1, Fe]),
                  (u = Ze(
                    n,
                    K,
                    "time_base=" +
                      J[0] +
                      "/" +
                      J[1] +
                      ":sample_rate=" +
                      Fe +
                      ":sample_fmt=" +
                      (g.sample_fmt ? g.sample_fmt : 3) +
                      ":channel_layout=0x" +
                      (g.channel_layout ? g.channel_layout : 4).toString(16),
                    null,
                    l,
                  )));
              }
              if (u === 0) throw new Error("Cannot create buffer source");
              if ((d.push(u), (y = jr(K)), y === 0))
                throw new Error("Failed to allocate output");
              (Vt(p, y), (y = 0), At(p, u), (u = 0), ht(p, 0), P++);
            }),
              (v = 0));
            var T = 0;
            t.forEach(function (g) {
              var S = Ka();
              if (S === 0) throw new Error("Failed to allocate inputs");
              (bt(S, v), (v = S));
              var K = "out" + (M ? T : "");
              if (g.type === 0) {
                if (i === 0)
                  throw new Error("Failed to load buffersink filter");
                f = Ze(i, K, null, null, l);
              } else f = Ze(m, K, null, null, l);
              if (f === 0) throw new Error("Cannot create buffer sink");
              if ((A.push(f), g.type === 0)) {
                if (((b = Ht([g.pix_fmt ? g.pix_fmt : 0, -1])), b === 0))
                  throw new Error("Failed to transfer parameters");
                if (Dr(f, "pix_fmts", 4, b, -1, 1) < 0)
                  throw new Error("Failed to set filter parameters");
                (q(b), (b = 0));
              } else {
                if (
                  ((b = Ht([
                    g.sample_fmt ? g.sample_fmt : 3,
                    -1,
                    g.sample_rate ? g.sample_rate : 48e3,
                    -1,
                  ])),
                  b === 0)
                )
                  throw new Error("Failed to transfer parameters");
                var ee = g.channel_layout ? g.channel_layout : 4,
                  J = [~~ee, Math.floor(ee / 4294967296)];
                if (
                  Dr(f, "sample_fmts", 4, b, -1, 1) < 0 ||
                  kd(f, J[0], J[1]) < 0 ||
                  Dr(f, "sample_rates", 4, b + 8, -1, 1) < 0
                )
                  throw new Error("Failed to set filter parameters");
                (q(b), (b = 0));
              }
              if (((w = jr(K)), w === 0))
                throw new Error("Failed to transfer parameters");
              (Vt(v, w), (w = 0), At(v, f), (f = 0), ht(v, 0), T++);
            });
            var E = Sd(l, e, v, p, 0);
            if (E < 0) throw new Error("Failed to initialize filters: " + I(E));
            v = p = 0;
            var T = 0;
            if (
              (t.forEach(function (g) {
                (g.frame_size && xd(A[T], g.frame_size), T++);
              }),
              (E = Ed(l, 0)),
              E < 0)
            )
              throw new Error("Failed to configure filter graph: " + I(E));
          } catch (g) {
            throw (
              p && Za(p),
              v && Za(v),
              l && Dd(l),
              u && Ga(u),
              f && Ga(f),
              b && q(b),
              y && q(y),
              w && q(w),
              g
            );
          }
          return [l, F ? d : d[0], M ? A : A[0]];
        }),
        gv = (r.ff_filter_multi = function (e, a, t, _, n) {
          var i = [],
            m = [],
            l = -1,
            u = -1;
          (e.length || ((e = [e]), (_ = [_]), (n = [n])),
            (n = n.map(function (y) {
              return y === !0 ? { fin: !0 } : y || {};
            })));
          var f = _.map(function (y) {
            return y.length;
          }).reduce(function (y, w) {
            return Math.max(y, w);
          });
          function d(y, w, F, M) {
            w !== null && Ut(t, w);
            var P = Fd(y, w ? t : 0, 8);
            if (P < 0)
              throw new Error(
                "Error while feeding the audio filtergraph: " + I(P),
              );
            for (we(t); (P = wd(a, t)), !(P === -6 || P === -541478725); ) {
              if (P < 0)
                throw new Error(
                  "Error while receiving a frame from the filtergraph: " + I(P),
                );
              l < 0 && ((l = yd(a)), (u = gd(a)));
              var E = F(t);
              (l &&
                !M.ignoreSinkTimebase &&
                (typeof E == "number"
                  ? _r(E, l, u)
                  : E && ((E.time_base_num = l), (E.time_base_den = u))),
                E &&
                  E.libavjsTransfer &&
                  E.libavjsTransfer.length &&
                  m.push.apply(m, E.libavjsTransfer),
                i.push(E),
                we(t));
            }
          }
          for (var A = [], p = 0; p < _.length; p++)
            (function (y) {
              var w = Kr;
              (n[y].copyoutFrame && (w = Ot[n[y].copyoutFrame]), A.push(w));
            })(p);
          for (var v = 0; v <= f; v++)
            for (var p = 0; p < _.length; p++) {
              var b = _[p][v];
              b
                ? d(e[p], b, A[p], n[p])
                : n[p].fin && d(e[p], null, A[p], n[p]);
            }
          return ((i.libavjsTransfer = m), i);
        }),
        ih = (r.ff_decode_filter_multi = function (e, a, t, _, n, i, m) {
          typeof m == "boolean" ? (m = { fin: m }) : (m = m || {});
          var l = hv(e, _, n, i, {
            fin: !!m.fin,
            ignoreErrors: !!m.ignoreErrors,
            copyoutFrame: "ptr",
          });
          return gv(a, t, n, l, {
            fin: !!m.fin,
            copyoutFrame: m.copyoutFrame || "default",
          });
        }),
        Kr = (r.ff_copyout_frame = function (e) {
          var a = Pf(e);
          if (a === 0) {
            var t = xe(e);
            if (t) return Mt(e, t);
          }
          var _ = bf(e),
            n = ye(e),
            i = [],
            m = {
              data: null,
              libavjsTransfer: i,
              channel_layout: Vf(e),
              channels: _,
              format: n,
              nb_samples: a,
              pts: Ur(e),
              ptshi: Nr(e),
              time_base_num: ze(e),
              time_base_den: tr(e),
              sample_rate: Sf(e),
            };
          if (n >= 5) {
            for (var l = [], u = 0; u < _; u++) {
              var f = ie(e, u),
                d = null;
              switch (n) {
                case 5:
                  d = Oe(f, a);
                  break;
                case 6:
                  d = gt(f, a);
                  break;
                case 7:
                  d = kt(f, a);
                  break;
                case 8:
                  d = Pt(f, a);
                  break;
              }
              d && (l.push(d), i.push(d.buffer));
            }
            m.data = l;
          } else {
            var A = _ * a,
              f = ie(e, 0),
              d = null;
            switch (n) {
              case 0:
                d = Oe(f, A);
                break;
              case 1:
                d = gt(f, A);
                break;
              case 2:
                d = kt(f, A);
                break;
              case 3:
                d = Pt(f, A);
                break;
            }
            d && ((m.data = d), i.push(d.buffer));
          }
          return m;
        }),
        xv = (r.ff_copyout_frame_video = function (e) {
          return Mt(e, xe(e));
        }),
        Mt = (r.ff_copyout_frame_video = function (e, a) {
          for (
            var t = Te(e),
              _ = ye(e),
              n = rr(_),
              i = nr(n),
              m = [],
              l = [],
              u = {
                data: null,
                layout: m,
                libavjsTransfer: l,
                width: a,
                height: t,
                crop: { top: kf(e), bottom: hf(e), left: wf(e), right: gf(e) },
                format: ye(e),
                key_frame: _t(e),
                pict_type: nt(e),
                pts: Ur(e),
                ptshi: Nr(e),
                time_base_num: ze(e),
                time_base_den: tr(e),
                sample_aspect_ratio: [ot(e), st(e)],
              },
              f = 1 / 0,
              d = 0,
              A = 0;
            A < 8;
            A++
          ) {
            var p = ge(e, A);
            if (!p) break;
            var v = ie(e, A);
            v < f && (f = v);
            var b = t;
            ((A === 1 || A === 2) && (b >>= i), (v += p * b), v > d && (d = v));
          }
          ((u.data = r.HEAPU8.slice(f, d)), l.push(u.data.buffer));
          for (var A = 0; A < 8; A++) {
            var p = ge(e, A);
            if (!p) break;
            var v = ie(e, A);
            m.push({ offset: v - f, stride: p });
          }
          return u;
        }),
        kv = (r.ff_frame_video_packed_size = function (e) {
          var a = xe(e),
            t = Te(e),
            _ = ye(e),
            n = rr(_),
            i = 1;
          Lr(n) & 16 || (i *= Br(n));
          for (var m = 0, l = 0; l < 8; l++) {
            var u = ge(e, l);
            if (!u) break;
            var f = a * i,
              d = t;
            ((l === 1 || l === 2) && ((f >>= Hr(n)), (d >>= nr(n))),
              (m += f * d));
          }
          return m;
        });
      function Rt(e, a, t) {
        var _ = xe(t),
          n = Te(t),
          i = ye(t),
          m = rr(i),
          l = 1;
        Lr(m) & 16 || (l *= Br(m));
        for (var u = 0, f = 0; f < 8; f++) {
          var d = ge(t, f);
          if (!d) break;
          var A = ie(t, f),
            p = _ * l,
            v = n;
          ((f === 1 || f === 2) && ((p >>= Hr(m)), (v >>= nr(m))),
            a.push({ offset: u, stride: p }));
          for (var b = 0; b < v; b++) {
            var y = A + b * d;
            (e.set(r.HEAPU8.subarray(y, y + p), u), (u += p));
          }
        }
      }
      var Fv = (r.ff_copyout_frame_video_packed = function (e) {
          var a = new Uint8Array(kv(e)),
            t = [];
          Rt(a, t, e);
          var _ = {
            data: a,
            libavjsTransfer: [a.buffer],
            width: xe(e),
            height: Te(e),
            format: ye(e),
            key_frame: _t(e),
            pict_type: nt(e),
            pts: Ur(e),
            ptshi: Nr(e),
            time_base_num: ze(e),
            time_base_den: tr(e),
            sample_aspect_ratio: [ot(e), st(e)],
          };
          return _;
        }),
        Pv = (r.ff_copyout_frame_video_imagedata = function (e) {
          var a = xe(e),
            t = Te(e),
            _ = new ImageData(a, t),
            n = [];
          return (Rt(_.data, n, e), (_.libavjsTransfer = [_.data.buffer]), _);
        }),
        It = (r.ff_copyout_frame_ptr = function (e) {
          var a = Ad(e);
          if (!a) throw new Error("Failed to allocate new frame");
          return a;
        }),
        Ot = {
          default: Kr,
          video: xv,
          video_packed: Fv,
          ImageData: Pv,
          ptr: It,
        },
        Ut = (r.ff_copyin_frame = function (e, a) {
          if (typeof a == "number") {
            we(e);
            var t = Vd(e, a);
            if (t < 0)
              throw new Error("Failed to reference frame data: " + I(t));
            (we(a), Ct(a));
            return;
          }
          if (a.width) return Ev(e, a);
          var _ = a.format,
            n = a.channels;
          if (!n) {
            var i = a.channel_layout;
            for (n = 0; i; ) (i & 1 && n++, (i >>>= 1));
          }
          [
            "channel_layout",
            "channels",
            "format",
            "pts",
            "ptshi",
            "sample_rate",
            "time_base_num",
            "time_base_den",
          ].forEach(function (d) {
            d in a && c["AVFrame_" + d + "_s"](e, a[d]);
          });
          var m;
          if (
            (_ >= 5 ? (m = a.data[0].length) : (m = a.data.length / n),
            Ef(e, m),
            Ya(e) < 0)
          ) {
            var t = $a(e, 0);
            if (t < 0)
              throw new Error("Failed to allocate frame buffers: " + I(t));
          }
          if (_ >= 5)
            for (var l = 0; l < n; l++) {
              var u = ie(e, l),
                f = a.data[l];
              switch (_) {
                case 5:
                  Ie(u, f);
                  break;
                case 6:
                  yt(u, f);
                  break;
                case 7:
                  xt(u, f);
                  break;
                case 8:
                  Ft(u, f);
                  break;
              }
            }
          else {
            var u = ie(e, 0),
              f = a.data;
            switch (_) {
              case 0:
                Ie(u, f);
                break;
              case 1:
                yt(u, f);
                break;
              case 2:
                xt(u, f);
                break;
              case 3:
                Ft(u, f);
                break;
            }
          }
        }),
        Ev = (r.ff_copyin_frame_video = function (e, a) {
          ([
            "format",
            "height",
            "key_frame",
            "pict_type",
            "pts",
            "ptshi",
            "width",
            "time_base_num",
            "time_base_den",
          ].forEach(function (E) {
            E in a && c["AVFrame_" + E + "_s"](e, a[E]);
          }),
            "sample_aspect_ratio" in a &&
              Df(e, a.sample_aspect_ratio[0], a.sample_aspect_ratio[1]));
          var t = a.crop || { top: 0, bottom: 0, left: 0, right: 0 };
          (Ff(e, t.top), Cf(e, t.bottom), yf(e, t.left), xf(e, t.right));
          var _ = rr(a.format),
            n = Hr(_),
            i = nr(_);
          if (Ya(e) < 0) {
            var m = $a(e, 0);
            if (m < 0)
              throw new Error("Failed to allocate frame buffers: " + I(m));
          }
          var l = a.layout;
          if (!l) {
            l = [];
            var u = 1;
            Lr(_) & 16 || (u *= Br(_));
            for (var f = 0, d = 0; d < 8; d++) {
              var A = ge(e, d);
              if (!A) break;
              var p = a.width,
                v = a.height;
              ((d === 1 || d === 2) && ((p >>= n), (v >>= i)),
                l.push({ offset: f, stride: p * u }),
                (f += p * v * u));
            }
          }
          for (var d = 0; d < l.length; d++) {
            var b = l[d],
              A = ge(e, d),
              y = ie(e, d),
              v = a.height;
            (d === 1 || d === 2) && (v >>= i);
            for (
              var w = b.offset, F = 0, M = Math.min(b.stride, A), P = 0;
              P < v;
              P++
            )
              (Ie(y + F, a.data.subarray(w, w + M)), (F += A), (w += b.stride));
          }
        }),
        Zr = (r.ff_copyout_packet = function (e) {
          var t = ft(e),
            a = qr(e),
            t = Oe(t, a);
          return {
            data: t,
            libavjsTransfer: [t.buffer],
            pts: nv(e),
            ptshi: ov(e),
            dts: ev(e),
            dtshi: rv(e),
            time_base_num: Me(e),
            time_base_den: or(e),
            stream_index: vt(e),
            flags: _v(e),
            duration: av(e),
            durationhi: tv(e),
            side_data: Dv(e),
          };
        }),
        Dv = (r.ff_copyout_side_data = function (e) {
          var a = sv(e),
            t = cv(e);
          if (!a) return null;
          for (var _ = [], n = 0; n < t; n++) {
            var i = lf(a, n),
              m = uf(a, n);
            _.push({ data: Oe(i, m), type: df(a, n) });
          }
          return _;
        }),
        Nt = (r.ff_copyout_packet_ptr = function (e) {
          var a = bd(e);
          if (!a) throw new Error("Failed to clone packet");
          return a;
        }),
        Sv = { default: Zr, ptr: Nt },
        Lt = (r.ff_copyin_packet = function (e, a) {
          if (typeof a == "number") {
            Q(e);
            var t = Cd(e, a);
            if (t < 0) throw new Error("Failed to reference packet: " + I(t));
            (Q(a), wt(a));
            return;
          }
          (Cv(e, a.data),
            [
              "dts",
              "dtshi",
              "duration",
              "durationhi",
              "flags",
              "side_data",
              "side_data_elems",
              "stream_index",
              "pts",
              "ptshi",
              "time_base_num",
              "time_base_den",
            ].forEach(function (_) {
              _ in a && c["AVPacket_" + _ + "_s"](e, a[_]);
            }),
            a.side_data && jv(e, a.side_data));
        }),
        jv = (r.ff_copyin_side_data = function (e, a) {
          a.forEach(function (t) {
            var _ = hd(e, t.type, t.data.length);
            if (_ === 0) throw new Error("Failed to allocate side data!");
            Ie(_, t.data);
          });
        }),
        mh = (r.ff_copyout_codecpar = function (e) {
          return {
            bit_rate: zf(e),
            channel_layoutmask: Mf(e),
            channels: Rf(e),
            chroma_location: If(e),
            codec_id: ut(e),
            codec_tag: Of(e),
            codec_type: dt(e),
            color_primaries: Nf(e),
            color_range: Lf(e),
            color_space: Hf(e),
            color_trc: Bf(e),
            format: Jf(e),
            height: Xf(e),
            level: Gf(e),
            profile: Kf(e),
            sample_rate: Zf(e),
            width: Qf(e),
            extradata: Tv(e),
          };
        }),
        Tv = (r.ff_copyout_codecpar_extradata = function (e) {
          var a = qf(e),
            t = $f(e);
          return !a || !t ? null : Oe(a, t);
        }),
        zv = (r.ff_copyin_codecpar = function (e, a) {
          ([
            "bit_rate",
            "channel_layoutmask",
            "channels",
            "chroma_location",
            "codec_id",
            "codec_tag",
            "codec_type",
            "color_primaries",
            "color_range",
            "color_space",
            "color_trc",
            "format",
            "height",
            "level",
            "profile",
            "sample_rate",
            "width",
          ].forEach(function (t) {
            t in a && c["AVCodecParameters_" + t + "_s"](e, a[t]);
          }),
            a.extradata && Mv(e, a.extradata));
        }),
        Mv = (r.ff_copyin_codecpar_extradata = function (e, a) {
          var t = G(a.length);
          (Ie(t, a), Wf(e, t), Yf(e, a.length));
        }),
        Ht = (r.ff_malloc_int32_list = function (e) {
          var a = G(e.length * 4);
          if (a === 0) throw new Error("Failed to malloc");
          for (
            var t = new Uint32Array(r.HEAPU8.buffer, a, e.length), _ = 0;
            _ < e.length;
            _++
          )
            t[_] = e[_];
          return a;
        }),
        lh = (r.ff_malloc_int64_list = function (e) {
          var a = G(e.length * 8);
          if (a === 0) throw new Error("Failed to malloc");
          for (
            var t = new Int32Array(r.HEAPU8.buffer, a, e.length * 2), _ = 0;
            _ < e.length;
            _++
          )
            ((t[_ * 2] = e[_]), (t[_ * 2 + 1] = e[_] < 0 ? -1 : 0));
          return a;
        }),
        Rv = (r.ff_malloc_string_array = function (e) {
          var a = G((e.length + 1) * 4);
          if (a === 0) throw new Error("Failed to malloc");
          var t = new Uint32Array(r.HEAPU8.buffer, a, e.length + 1),
            _;
          for (_ = 0; _ < e.length; _++) t[_] = jr(e[_]);
          return ((t[_] = 0), a);
        }),
        Iv = (r.ff_free_string_array = function (e) {
          for (var a = e / 4; ; a++) {
            var t = r.HEAPU32[a];
            if (!t) break;
            q(t);
          }
          q(e);
        });
      function Ov(e, a) {
        var t = [e];
        t = t.concat(Array.prototype.slice.call(a, 0));
        for (var _ = 0; _ < t.length; _++) {
          var n = t[_];
          typeof n != "string" &&
            ("length" in n
              ? t.splice.apply(t, [_, 1].concat(n))
              : (t[_] = "" + n));
        }
        return t;
      }
      function Bt(e, a, t) {
        t = Ov(r.thisProgram || a, t);
        var _ = Rv(t);
        r.fsThrownError = null;
        var n = null;
        try {
          n = e(t.length, _);
        } catch (l) {
          if (l && l.name === "ExitStatus") n = l.status;
          else if (l === "unwind") n = pe;
          else throw l;
        }
        function i() {
          Iv(_);
        }
        if (n && n.then)
          return n
            .then(function (l) {
              return (i(), l);
            })
            .catch(function (l) {
              return (
                i(),
                l && l.name === "ExitStatus"
                  ? Promise.resolve(l.status)
                  : l === "unwind"
                    ? Promise.resolve(pe)
                    : Promise.reject(l)
              );
            })
            .then(function (l) {
              if (r.fsThrownError) {
                var u = r.fsThrownError;
                throw ((r.fsThrownError = null), u);
              }
              return l;
            });
        if ((i(), r.fsThrownError)) {
          var m = r.fsThrownError;
          throw ((r.fsThrownError = null), m);
        }
        return n;
      }
      var uh = (r.ffmpeg = function () {
          return Bt(at, "ffmpeg", arguments);
        }),
        dh = (r.ffprobe = function () {
          return Bt(tt, "ffprobe", arguments);
        });
      return ((W = O), W);
    };
  })(),
  fh = Wt;
typeof importScripts < "u" &&
  typeof LibAV > "u" &&
  ((typeof self > "u" && typeof Module > "u") ||
    (typeof self < "u" && self.name !== "em-pthread")) &&
  (function () {
    var me;
    Promise.all([])
      .then(function () {
        return new Promise(function (te, W) {
          onmessage = function (r) {
            r &&
              r.data &&
              r.data.config &&
              Wt({
                wasmurl: r.data.config.wasmurl,
                variant: r.data.config.variant,
              })
                .then(te)
                .catch(W);
          };
        });
      })
      .then(function (te) {
        ((me = te),
          (onmessage = function (W) {
            var r = W.data[0],
              N = W.data[1],
              ve = W.data.slice(2),
              O = void 0,
              _e = !0;
            function le() {
              var L = [];
              O && O.libavjsTransfer && (L = O.libavjsTransfer);
              try {
                postMessage([r, N, _e, O], L);
              } catch {
                try {
                  ((O = JSON.parse(
                    JSON.stringify(O, function (ue, Le) {
                      return Le;
                    }),
                  )),
                    postMessage([r, N, _e, O], L));
                } catch {
                  postMessage([r, N, _e, "" + O]);
                }
              }
            }
            try {
              O = me[N].apply(me, ve);
            } catch (L) {
              ((_e = !1), (O = L));
            }
            _e && O && O.then
              ? O.then(function (L) {
                  O = L;
                })
                  .catch(function (L) {
                    ((_e = !1), (O = L));
                  })
                  .then(le)
              : le();
          }),
          (me.onwrite = function (W, r, N) {
            ((N = N.slice(0)),
              postMessage(["onwrite", "onwrite", !0, [W, r, N]], [N.buffer]));
          }),
          (me.onread = function (W, r, N) {
            postMessage(["onread", "onread", !0, [W, r, N]]);
          }),
          (me.onblockread = function (W, r, N) {
            postMessage(["onblockread", "onblockread", !0, [W, r, N]]);
          }),
          postMessage(["onready", "onready", !0, null]));
      })
      .catch(function (te) {
        console.log(
          `Loading LibAV failed
` +
            te +
            `
` +
            te.stack,
        );
      });
  })();
export { fh as default };
