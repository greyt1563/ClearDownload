var Bi = Object.create;
var $t = Object.defineProperty;
var Ri = Object.getOwnPropertyDescriptor;
var Vi = Object.getOwnPropertyNames;
var Ni = Object.getPrototypeOf,
  Mi = Object.prototype.hasOwnProperty;
var er = ((t) =>
  typeof require < "u"
    ? require
    : typeof Proxy < "u"
      ? new Proxy(t, { get: (e, r) => (typeof require < "u" ? require : e)[r] })
      : t)(function (t) {
  if (typeof require < "u") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + t + '" is not supported');
});
var Pi = (t, e) => () => (e || t((e = { exports: {} }).exports, e), e.exports);
var ki = (t, e, r, i) => {
  if ((e && typeof e == "object") || typeof e == "function")
    for (let n of Vi(e))
      !Mi.call(t, n) &&
        n !== r &&
        $t(t, n, {
          get: () => e[n],
          enumerable: !(i = Ri(e, n)) || i.enumerable,
        });
  return t;
};
var Oi = (t, e, r) => (
  (r = t != null ? Bi(Ni(t)) : {}),
  ki(
    e || !t || !t.__esModule
      ? $t(r, "default", { value: t, enumerable: !0 })
      : r,
    t,
  )
);
var pr = Pi((Sl, fr) => {
  var ke;
  typeof window < "u"
    ? (ke = window)
    : typeof global < "u"
      ? (ke = global)
      : typeof self < "u"
        ? (ke = self)
        : (ke = {});
  fr.exports = ke;
});
var D = {};
(function () {
  function t(a) {
    if (
      ((a = a || [0, 97, 115, 109, 1, 0, 0, 0]),
      typeof WebAssembly != "object" ||
        typeof WebAssembly.instantiate != "function")
    )
      return !1;
    try {
      var a = new WebAssembly.Module(new Uint8Array(a));
      if (a instanceof WebAssembly.Module)
        return new WebAssembly.Instance(a) instanceof WebAssembly.Instance;
    } catch {}
    return !1;
  }
  function e() {
    try {
      var a = new WebAssembly.Memory({ initial: 1, maximum: 1, shared: !0 });
      return a.buffer instanceof SharedArrayBuffer;
    } catch {}
    return !1;
  }
  var r = typeof process < "u";
  (D.base ||
    ((D.base = import.meta.url), (D.base = D.base.replace(/\/[^\/]*$/, ""))),
    (D.isWebAssemblySupported = t),
    (D.isThreadingSupported = e));
  function i(a) {
    a = a || {};
    var s = !a.nowasm && t(),
      u = a.yesthreads && s && !a.nothreads && e();
    return s ? (u ? "thr" : "wasm") : "asm";
  }
  ((D.target = i),
    (D.VER = "6.5.7.1"),
    (D.CONFIG = "h264-aac-mp3"),
    (D.DBG = ""),
    (D.factories = {}));
  var n = {};
  ((n.i64tof64 = function (a, s) {
    return (!s && a >= 0) || (s === -1 && a < 0)
      ? a
      : s * 4294967296 + a + (a < 0 ? 4294967296 : 0);
  }),
    (n.f64toi64 = function (a) {
      return [~~a, Math.floor(a / 4294967296)];
    }),
    (n.i64ToBigInt = function (a, s) {
      var u = new DataView(new ArrayBuffer(8));
      return (u.setInt32(0, a, !0), u.setInt32(4, s, !0), u.getBigInt64(0, !0));
    }),
    (n.bigIntToi64 = function (a) {
      var s = new DataView(new ArrayBuffer(8));
      return (s.setBigInt64(0, a, !0), [s.getInt32(0, !0), s.getInt32(4, !0)]);
    }),
    (n.ff_channel_layout = function (a) {
      return a.channel_layout
        ? a.channel_layout
        : a.channels && a.channels !== 1
          ? (1 << a.channels) - 1
          : 4;
    }),
    (n.ff_channels = function (a) {
      if (a.channels) return a.channels;
      if (a.channel_layout) {
        for (var s = 0, u = a.channel_layout; u;) ((s += u & 1), (u >>= 1));
        return s;
      } else return 1;
    }));
  function o(a, s) {
    typeof s === void 0 && (s = 0);
    var u = s;
    a.forEach(function (A) {
      n[A] = u++;
    });
  }
  ((n.AV_TIME_BASE = 1e6),
    (n.AV_OPT_SEARCH_CHILDREN = 1),
    o(
      [
        "AVMEDIA_TYPE_UNKNOWN",
        "AVMEDIA_TYPE_VIDEO",
        "AVMEDIA_TYPE_AUDIO",
        "AVMEDIA_TYPE_DATA",
        "AVMEDIA_TYPE_SUBTITLE",
        "AVMEDIA_TYPE_ATTACHMENT",
      ],
      -1,
    ),
    o(
      [
        "AV_SAMPLE_FMT_NONE",
        "AV_SAMPLE_FMT_U8",
        "AV_SAMPLE_FMT_S16",
        "AV_SAMPLE_FMT_S32",
        "AV_SAMPLE_FMT_FLT",
        "AV_SAMPLE_FMT_DBL",
        "AV_SAMPLE_FMT_U8P",
        "AV_SAMPLE_FMT_S16P",
        "AV_SAMPLE_FMT_S32P",
        "AV_SAMPLE_FMT_FLTP",
        "AV_SAMPLE_FMT_DBLP",
        "AV_SAMPLE_FMT_S64",
        "AV_SAMPLE_FMT_S64P",
        "AV_SAMPLE_FMT_NB",
      ],
      -1,
    ),
    o(
      [
        "AV_PIX_FMT_NONE",
        "AV_PIX_FMT_YUV420P",
        "AV_PIX_FMT_YUYV422",
        "AV_PIX_FMT_RGB24",
        "AV_PIX_FMT_BGR24",
        "AV_PIX_FMT_YUV422P",
        "AV_PIX_FMT_YUV444P",
        "AV_PIX_FMT_YUV410P",
        "AV_PIX_FMT_YUV411P",
        "AV_PIX_FMT_GRAY8",
        "AV_PIX_FMT_MONOWHITE",
        "AV_PIX_FMT_MONOBLACK",
        "AV_PIX_FMT_PAL8",
        "AV_PIX_FMT_YUVJ420P",
        "AV_PIX_FMT_YUVJ422P",
        "AV_PIX_FMT_YUVJ444P",
        "AV_PIX_FMT_UYVY422",
        "AV_PIX_FMT_UYYVYY411",
        "AV_PIX_FMT_BGR8",
        "AV_PIX_FMT_BGR4",
        "AV_PIX_FMT_BGR4_BYTE",
        "AV_PIX_FMT_RGB8",
        "AV_PIX_FMT_RGB4",
        "AV_PIX_FMT_RGB4_BYTE",
        "AV_PIX_FMT_NV12",
        "AV_PIX_FMT_NV21",
        "AV_PIX_FMT_ARGB",
        "AV_PIX_FMT_RGBA",
        "AV_PIX_FMT_ABGR",
        "AV_PIX_FMT_BGRA",
        "AV_PIX_FMT_GRAY16BE",
        "AV_PIX_FMT_GRAY16LE",
        "AV_PIX_FMT_YUV440P",
        "AV_PIX_FMT_YUVJ440P",
        "AV_PIX_FMT_YUVA420P",
        "AV_PIX_FMT_RGB48BE",
        "AV_PIX_FMT_RGB48LE",
        "AV_PIX_FMT_RGB565BE",
        "AV_PIX_FMT_RGB565LE",
        "AV_PIX_FMT_RGB555BE",
        "AV_PIX_FMT_RGB555LE",
        "AV_PIX_FMT_BGR565BE",
        "AV_PIX_FMT_BGR565LE",
        "AV_PIX_FMT_BGR555BE",
        "AV_PIX_FMT_BGR555LE",
      ],
      -1,
    ),
    (n.AVIO_FLAG_READ = 1),
    (n.AVIO_FLAG_WRITE = 2),
    (n.AVIO_FLAG_READ_WRITE = 3),
    (n.AVIO_FLAG_NONBLOCK = 8),
    (n.AVIO_FLAG_DIRECT = 32768),
    (n.AVFMT_FLAG_NOBUFFER = 64),
    (n.AVFMT_FLAG_FLUSH_PACKETS = 512),
    (n.AVSEEK_FLAG_BACKWARD = 1),
    (n.AVSEEK_FLAG_BYTE = 2),
    (n.AVSEEK_FLAG_ANY = 4),
    (n.AVSEEK_FLAG_FRAME = 8),
    (n.AVDISCARD_NONE = -16),
    (n.AVDISCARD_DEFAULT = 0),
    (n.AVDISCARD_NONREF = 8),
    (n.AVDISCARD_BIDIR = 16),
    (n.AVDISCARD_NONINTRA = 24),
    (n.AVDISCARD_NONKEY = 32),
    (n.AVDISCARD_ALL = 48),
    (n.AV_LOG_QUIET = -8),
    (n.AV_LOG_PANIC = 0),
    (n.AV_LOG_FATAL = 8),
    (n.AV_LOG_ERROR = 16),
    (n.AV_LOG_WARNING = 24),
    (n.AV_LOG_INFO = 32),
    (n.AV_LOG_VERBOSE = 40),
    (n.AV_LOG_DEBUG = 48),
    (n.AV_LOG_TRACE = 56),
    (n.AV_PKT_FLAG_KEY = 1),
    (n.AV_PKT_FLAG_CORRUPT = 2),
    (n.AV_PKT_FLAG_DISCARD = 4),
    (n.AV_PKT_FLAG_TRUSTED = 8),
    (n.AV_PKT_FLAG_DISPOSABLE = 16),
    o(
      [
        "E2BIG",
        "EPERM",
        "EADDRINUSE",
        "EADDRNOTAVAIL",
        "EAFNOSUPPORT",
        "EAGAIN",
        "EALREADY",
        "EBADF",
        "EBADMSG",
        "EBUSY",
        "ECANCELED",
        "ECHILD",
        "ECONNABORTED",
        "ECONNREFUSED",
        "ECONNRESET",
        "EDEADLOCK",
        "EDESTADDRREQ",
        "EDOM",
        "EDQUOT",
        "EEXIST",
        "EFAULT",
        "EFBIG",
        "EHOSTUNREACH",
        "EIDRM",
        "EILSEQ",
        "EINPROGRESS",
        "EINTR",
        "EINVAL",
        "EIO",
        "EISCONN",
        "EISDIR",
        "ELOOP",
        "EMFILE",
        "EMLINK",
        "EMSGSIZE",
        "EMULTIHOP",
        "ENAMETOOLONG",
        "ENETDOWN",
        "ENETRESET",
        "ENETUNREACH",
        "ENFILE",
        "ENOBUFS",
        "ENODEV",
        "ENOENT",
      ],
      1,
    ),
    (n.AVERROR_EOF = -541478725),
    Object.assign(D, n),
    (D.LibAV = function (a) {
      a = a || {};
      var s = a.base || D.base,
        u = i(a),
        A = "h264-aac-mp3";
      u === "asm" && (A = a.variant || D.variant || "h264-aac-mp3");
      var l = !0;
      l && (a.noes6 || D.noes6) && (l = !1);
      var d =
          a.toImport ||
          D.toImport ||
          s + "/libav-6.5.7.1-" + A + "." + u + "." + (l ? "mjs" : "js"),
        f,
        _ = "direct";
      return (
        u === "thr"
          ? (_ = "threads")
          : !r && !a.noworker && typeof Worker < "u" && (_ = "worker"),
        Promise.all([])
          .then(function () {
            if (a.factory || D.factory) return a.factory || D.factory;
            if (D.factories[d]) return D.factories[d];
            if (_ !== "worker")
              return l
                ? import(d).then(function (h) {
                    return ((D.factories[d] = h.default), h.default);
                  })
                : r
                  ? (D.factories[d] = er(d))
                  : typeof importScripts < "u"
                    ? (importScripts(d), (D.factories[d] = LibAVFactory))
                    : new Promise(function (h, c) {
                        var g = document.createElement("script");
                        ((g.src = d),
                          g.addEventListener("load", h),
                          g.addEventListener("error", c),
                          (g.async = !0),
                          document.body.appendChild(g));
                      }).then(function () {
                        return (D.factories[d] = LibAVFactory);
                      });
          })
          .then(function (h) {
            return _ === "worker"
              ? ((f = {}),
                (f.worker = new Worker(d, { type: l ? "module" : "classic" })),
                f.worker.postMessage({
                  config: {
                    variant: a.variant || D.variant,
                    wasmurl: a.wasmurl || D.wasmurl,
                  },
                }),
                new Promise(function (c, g) {
                  ((f.on = 1),
                    (f.handlers = {
                      onready: [
                        function () {
                          c();
                        },
                        null,
                      ],
                      onwrite: [
                        function (p) {
                          f.onwrite && f.onwrite.apply(f, p);
                        },
                        null,
                      ],
                      onread: [
                        function (p) {
                          try {
                            var m = null;
                            (f.onread && (m = f.onread.apply(f, p)),
                              m &&
                                m.then &&
                                m.catch &&
                                m.catch(function (w) {
                                  f.ff_reader_dev_send(p[0], null, {
                                    error: w,
                                  });
                                }));
                          } catch (w) {
                            f.ff_reader_dev_send(p[0], null, { error: w });
                          }
                        },
                        null,
                      ],
                      onblockread: [
                        function (p) {
                          try {
                            var m = null;
                            (f.onblockread && (m = f.onblockread.apply(f, p)),
                              m &&
                                m.then &&
                                m.catch &&
                                m.catch(function (w) {
                                  f.ff_block_reader_dev_send(p[0], p[1], null, {
                                    error: w,
                                  });
                                }));
                          } catch (w) {
                            f.ff_block_reader_dev_send(p[0], p[1], null, {
                              error: w,
                            });
                          }
                        },
                        null,
                      ],
                    }),
                    (f.c = function () {
                      for (
                        var p = Array.prototype.slice.call(arguments),
                          m = [],
                          w = 0;
                        w < p.length;
                        w++
                      )
                        p[w] &&
                          p[w].libavjsTransfer &&
                          m.push.apply(m, p[w].libavjsTransfer);
                      return new Promise(function (T, E) {
                        var S = f.on++;
                        ((p = [S].concat(p)),
                          (f.handlers[S] = [T, E]),
                          f.worker.postMessage(p, m));
                      });
                    }));
                  function y(p) {
                    var m = p.data[0],
                      w = f.handlers[m];
                    w &&
                      (p.data[2] ? w[0](p.data[3]) : w[1](p.data[3]),
                      typeof m == "number" && delete f.handlers[m]);
                  }
                  ((f.worker.onmessage = y),
                    (f.terminate = function () {
                      f.worker.terminate();
                    }));
                }))
              : _ === "threads"
                ? Promise.all([])
                    .then(function () {
                      return h({
                        wasmurl: a.wasmurl || D.wasmurl,
                        variant: a.variant || D.variant,
                      });
                    })
                    .then(function (c) {
                      f = c;
                      var g = f.libavjs_create_main_thread(),
                        y = f.PThread.pthreads[g],
                        p = 0,
                        m = 1,
                        w = {},
                        T = null,
                        E = new Promise(function (I) {
                          T = I;
                        });
                      f.c = function () {
                        var I = Array.prototype.slice.call(arguments);
                        return new Promise(function (X, q) {
                          var N = m++;
                          ((I = [N].concat(I)),
                            (w[N] = [X, q]),
                            y.postMessage({ c: "libavjs_run", a: I }));
                        });
                      };
                      var S = y.onmessage;
                      return (
                        (y.onmessage = function (I) {
                          if (I.data && I.data.c === "libavjs_ret") {
                            var X = I.data.a,
                              q = w[X[0]];
                            q &&
                              (X[2] ? q[0](X[3]) : q[1](X[3]), delete w[X[0]]);
                          } else if (
                            I.data &&
                            I.data.c === "libavjs_wait_reader"
                          )
                            if (f.readerDevReady(I.data.fd))
                              y.postMessage({
                                c: "libavjs_wait_reader",
                                fd: I.data.fd,
                              });
                            else {
                              var N = f.fdName(I.data.fd),
                                x = f.ff_reader_dev_waiters[N];
                              (x || (x = f.ff_reader_dev_waiters[N] = []),
                                x.push(function () {
                                  y.postMessage({
                                    c: "libavjs_wait_reader",
                                    fd: I.data.fd,
                                  });
                                }));
                            }
                          else if (I.data && I.data.c === "libavjs_ready") T();
                          else return S.apply(this, arguments);
                        }),
                        (f.terminate = function () {
                          f.PThread.unusedWorkers
                            .concat(f.PThread.runningWorkers)
                            .forEach(function (I) {
                              I.terminate();
                            });
                        }),
                        E
                      );
                    })
                : Promise.all([])
                    .then(function () {
                      return h({
                        wasmurl: a.wasmurl || D.wasmurl,
                        variant: a.variant || D.variant,
                      });
                    })
                    .then(function (c) {
                      ((f = c),
                        (f.worker = !1),
                        (f.c = function (g) {
                          var y = Array.prototype.slice.call(arguments, 1);
                          return new Promise(function (p, m) {
                            try {
                              p(f[g].apply(f, y));
                            } catch (w) {
                              m(w);
                            }
                          });
                        }),
                        (f.terminate = function () {}));
                    });
          })
          .then(function () {
            function h(p) {
              p.forEach(function (m) {
                f[m] = function () {
                  return f.c.apply(
                    f,
                    [m].concat(Array.prototype.slice.call(arguments)),
                  );
                };
              });
            }
            function c(p) {
              p.forEach(function (m) {
                var w = (f[m + "_sync"] = f[m]);
                f[m] = function () {
                  var T = arguments;
                  return new Promise(function (E, S) {
                    try {
                      var I = w.apply(f, T);
                      typeof I == "object" && I !== null && I.then
                        ? I.then(E).catch(S)
                        : E(I);
                    } catch (X) {
                      S(X);
                    }
                  });
                };
              });
            }
            var g = [
                "av_get_bytes_per_sample",
                "av_compare_ts_js",
                "av_opt_set",
                "av_opt_set_int_list_js",
                "av_frame_alloc",
                "av_frame_clone",
                "av_frame_free",
                "av_frame_get_buffer",
                "av_frame_make_writable",
                "av_frame_ref",
                "av_frame_unref",
                "ff_frame_rescale_ts_js",
                "av_log_get_level",
                "av_log_set_level",
                "av_packet_alloc",
                "av_packet_clone",
                "av_packet_free",
                "av_packet_new_side_data",
                "av_packet_ref",
                "av_packet_rescale_ts_js",
                "av_packet_unref",
                "av_strdup",
                "av_buffersink_get_frame",
                "av_buffersink_get_time_base_num",
                "av_buffersink_get_time_base_den",
                "av_buffersink_set_frame_size",
                "ff_buffersink_set_ch_layout",
                "av_buffersrc_add_frame_flags",
                "avfilter_free",
                "avfilter_get_by_name",
                "avfilter_graph_alloc",
                "avfilter_graph_config",
                "avfilter_graph_create_filter_js",
                "avfilter_graph_free",
                "avfilter_graph_parse",
                "avfilter_inout_alloc",
                "avfilter_inout_free",
                "avfilter_link",
                "avcodec_alloc_context3",
                "avcodec_close",
                "avcodec_descriptor_get",
                "avcodec_descriptor_get_by_name",
                "avcodec_descriptor_next",
                "avcodec_find_decoder",
                "avcodec_find_decoder_by_name",
                "avcodec_find_encoder",
                "avcodec_find_encoder_by_name",
                "avcodec_flush_buffers",
                "avcodec_free_context",
                "avcodec_get_name",
                "avcodec_open2",
                "avcodec_open2_js",
                "avcodec_parameters_alloc",
                "avcodec_parameters_copy",
                "avcodec_parameters_free",
                "avcodec_parameters_from_context",
                "avcodec_parameters_to_context",
                "avcodec_receive_frame",
                "avcodec_receive_packet",
                "avcodec_send_frame",
                "avcodec_send_packet",
                "av_find_input_format",
                "avformat_alloc_context",
                "avformat_alloc_output_context2_js",
                "avformat_close_input",
                "avformat_find_stream_info",
                "avformat_flush",
                "avformat_free_context",
                "avformat_new_stream",
                "avformat_open_input",
                "avformat_open_input_js",
                "av_seek_frame",
                "avformat_seek_file",
                "avformat_seek_file_min",
                "avformat_seek_file_max",
                "avformat_seek_file_approx",
                "avformat_write_header",
                "avio_open2_js",
                "avio_close",
                "avio_flush",
                "av_find_best_stream",
                "av_get_sample_fmt_name",
                "av_grow_packet",
                "av_interleaved_write_frame",
                "av_packet_make_writable",
                "av_pix_fmt_desc_get",
                "av_read_frame",
                "av_shrink_packet",
                "av_write_frame",
                "av_write_trailer",
                "av_dict_copy_js",
                "av_dict_free",
                "av_dict_set_js",
                "sws_getContext",
                "sws_freeContext",
                "sws_scale_frame",
                "AVPacketSideData_data",
                "AVPacketSideData_size",
                "AVPacketSideData_type",
                "AVPixFmtDescriptor_comp_depth",
                "ff_error",
                "ff_nothing",
                "calloc",
                "close",
                "dup2",
                "free",
                "malloc",
                "mallinfo_uordblks",
                "open",
                "strerror",
                "libavjs_with_swscale",
                "libavjs_create_main_thread",
                "ffmpeg_main",
                "ffprobe_main",
                "ffmpeg_interrupt",
                "ffmpeg_get_out_time_ms",
                "ffmpeg_get_total_size_bytes",
                "jsfetch_set_read_timeout",
                "jsfetch_set_fetch_timeout",
                "jsfetch_set_initial_retry_delay",
                "jsfetch_set_bypass_cache",
                "AVFrame_channel_layout",
                "AVFrame_channel_layout_s",
                "AVFrame_channel_layouthi",
                "AVFrame_channel_layouthi_s",
                "AVFrame_channels",
                "AVFrame_channels_s",
                "AVFrame_channel_layoutmask",
                "AVFrame_channel_layoutmask_s",
                "AVFrame_ch_layout_nb_channels",
                "AVFrame_ch_layout_nb_channels_s",
                "AVFrame_crop_bottom",
                "AVFrame_crop_bottom_s",
                "AVFrame_crop_left",
                "AVFrame_crop_left_s",
                "AVFrame_crop_right",
                "AVFrame_crop_right_s",
                "AVFrame_crop_top",
                "AVFrame_crop_top_s",
                "AVFrame_data_a",
                "AVFrame_data_a_s",
                "AVFrame_format",
                "AVFrame_format_s",
                "AVFrame_height",
                "AVFrame_height_s",
                "AVFrame_key_frame",
                "AVFrame_key_frame_s",
                "AVFrame_linesize_a",
                "AVFrame_linesize_a_s",
                "AVFrame_nb_samples",
                "AVFrame_nb_samples_s",
                "AVFrame_pict_type",
                "AVFrame_pict_type_s",
                "AVFrame_pts",
                "AVFrame_pts_s",
                "AVFrame_ptshi",
                "AVFrame_ptshi_s",
                "AVFrame_sample_aspect_ratio_num",
                "AVFrame_sample_aspect_ratio_num_s",
                "AVFrame_sample_aspect_ratio_den",
                "AVFrame_sample_aspect_ratio_den_s",
                "AVFrame_sample_aspect_ratio_s",
                "AVFrame_sample_rate",
                "AVFrame_sample_rate_s",
                "AVFrame_time_base_num",
                "AVFrame_time_base_num_s",
                "AVFrame_time_base_den",
                "AVFrame_time_base_den_s",
                "AVFrame_time_base_s",
                "AVFrame_width",
                "AVFrame_width_s",
                "AVPixFmtDescriptor_flags",
                "AVPixFmtDescriptor_flags_s",
                "AVPixFmtDescriptor_log2_chroma_h",
                "AVPixFmtDescriptor_log2_chroma_h_s",
                "AVPixFmtDescriptor_log2_chroma_w",
                "AVPixFmtDescriptor_log2_chroma_w_s",
                "AVPixFmtDescriptor_nb_components",
                "AVPixFmtDescriptor_nb_components_s",
                "AVCodec_name",
                "AVCodec_sample_fmts",
                "AVCodec_sample_fmts_s",
                "AVCodec_sample_fmts_a",
                "AVCodec_sample_fmts_a_s",
                "AVCodec_supported_samplerates",
                "AVCodec_supported_samplerates_s",
                "AVCodec_supported_samplerates_a",
                "AVCodec_supported_samplerates_a_s",
                "AVCodec_type",
                "AVCodec_type_s",
                "AVCodecContext_codec_id",
                "AVCodecContext_codec_id_s",
                "AVCodecContext_codec_type",
                "AVCodecContext_codec_type_s",
                "AVCodecContext_bit_rate",
                "AVCodecContext_bit_rate_s",
                "AVCodecContext_bit_ratehi",
                "AVCodecContext_bit_ratehi_s",
                "AVCodecContext_channel_layout",
                "AVCodecContext_channel_layout_s",
                "AVCodecContext_channel_layouthi",
                "AVCodecContext_channel_layouthi_s",
                "AVCodecContext_channels",
                "AVCodecContext_channels_s",
                "AVCodecContext_channel_layoutmask",
                "AVCodecContext_channel_layoutmask_s",
                "AVCodecContext_ch_layout_nb_channels",
                "AVCodecContext_ch_layout_nb_channels_s",
                "AVCodecContext_extradata",
                "AVCodecContext_extradata_s",
                "AVCodecContext_extradata_size",
                "AVCodecContext_extradata_size_s",
                "AVCodecContext_frame_size",
                "AVCodecContext_frame_size_s",
                "AVCodecContext_framerate_num",
                "AVCodecContext_framerate_num_s",
                "AVCodecContext_framerate_den",
                "AVCodecContext_framerate_den_s",
                "AVCodecContext_framerate_s",
                "AVCodecContext_gop_size",
                "AVCodecContext_gop_size_s",
                "AVCodecContext_height",
                "AVCodecContext_height_s",
                "AVCodecContext_keyint_min",
                "AVCodecContext_keyint_min_s",
                "AVCodecContext_level",
                "AVCodecContext_level_s",
                "AVCodecContext_max_b_frames",
                "AVCodecContext_max_b_frames_s",
                "AVCodecContext_pix_fmt",
                "AVCodecContext_pix_fmt_s",
                "AVCodecContext_profile",
                "AVCodecContext_profile_s",
                "AVCodecContext_rc_max_rate",
                "AVCodecContext_rc_max_rate_s",
                "AVCodecContext_rc_max_ratehi",
                "AVCodecContext_rc_max_ratehi_s",
                "AVCodecContext_rc_min_rate",
                "AVCodecContext_rc_min_rate_s",
                "AVCodecContext_rc_min_ratehi",
                "AVCodecContext_rc_min_ratehi_s",
                "AVCodecContext_sample_aspect_ratio_num",
                "AVCodecContext_sample_aspect_ratio_num_s",
                "AVCodecContext_sample_aspect_ratio_den",
                "AVCodecContext_sample_aspect_ratio_den_s",
                "AVCodecContext_sample_aspect_ratio_s",
                "AVCodecContext_sample_fmt",
                "AVCodecContext_sample_fmt_s",
                "AVCodecContext_sample_rate",
                "AVCodecContext_sample_rate_s",
                "AVCodecContext_time_base_num",
                "AVCodecContext_time_base_num_s",
                "AVCodecContext_time_base_den",
                "AVCodecContext_time_base_den_s",
                "AVCodecContext_time_base_s",
                "AVCodecContext_qmax",
                "AVCodecContext_qmax_s",
                "AVCodecContext_qmin",
                "AVCodecContext_qmin_s",
                "AVCodecContext_width",
                "AVCodecContext_width_s",
                "AVCodecDescriptor_id",
                "AVCodecDescriptor_id_s",
                "AVCodecDescriptor_long_name",
                "AVCodecDescriptor_long_name_s",
                "AVCodecDescriptor_mime_types_a",
                "AVCodecDescriptor_mime_types_a_s",
                "AVCodecDescriptor_name",
                "AVCodecDescriptor_name_s",
                "AVCodecDescriptor_props",
                "AVCodecDescriptor_props_s",
                "AVCodecDescriptor_type",
                "AVCodecDescriptor_type_s",
                "AVCodecParameters_bit_rate",
                "AVCodecParameters_bit_rate_s",
                "AVCodecParameters_channel_layoutmask",
                "AVCodecParameters_channel_layoutmask_s",
                "AVCodecParameters_channels",
                "AVCodecParameters_channels_s",
                "AVCodecParameters_ch_layout_nb_channels",
                "AVCodecParameters_ch_layout_nb_channels_s",
                "AVCodecParameters_chroma_location",
                "AVCodecParameters_chroma_location_s",
                "AVCodecParameters_codec_id",
                "AVCodecParameters_codec_id_s",
                "AVCodecParameters_codec_tag",
                "AVCodecParameters_codec_tag_s",
                "AVCodecParameters_codec_type",
                "AVCodecParameters_codec_type_s",
                "AVCodecParameters_color_primaries",
                "AVCodecParameters_color_primaries_s",
                "AVCodecParameters_color_range",
                "AVCodecParameters_color_range_s",
                "AVCodecParameters_color_space",
                "AVCodecParameters_color_space_s",
                "AVCodecParameters_color_trc",
                "AVCodecParameters_color_trc_s",
                "AVCodecParameters_extradata",
                "AVCodecParameters_extradata_s",
                "AVCodecParameters_extradata_size",
                "AVCodecParameters_extradata_size_s",
                "AVCodecParameters_format",
                "AVCodecParameters_format_s",
                "AVCodecParameters_framerate_num",
                "AVCodecParameters_framerate_num_s",
                "AVCodecParameters_framerate_den",
                "AVCodecParameters_framerate_den_s",
                "AVCodecParameters_framerate_s",
                "AVCodecParameters_height",
                "AVCodecParameters_height_s",
                "AVCodecParameters_level",
                "AVCodecParameters_level_s",
                "AVCodecParameters_profile",
                "AVCodecParameters_profile_s",
                "AVCodecParameters_sample_rate",
                "AVCodecParameters_sample_rate_s",
                "AVCodecParameters_width",
                "AVCodecParameters_width_s",
                "AVPacket_data",
                "AVPacket_data_s",
                "AVPacket_dts",
                "AVPacket_dts_s",
                "AVPacket_dtshi",
                "AVPacket_dtshi_s",
                "AVPacket_duration",
                "AVPacket_duration_s",
                "AVPacket_durationhi",
                "AVPacket_durationhi_s",
                "AVPacket_flags",
                "AVPacket_flags_s",
                "AVPacket_pos",
                "AVPacket_pos_s",
                "AVPacket_poshi",
                "AVPacket_poshi_s",
                "AVPacket_pts",
                "AVPacket_pts_s",
                "AVPacket_ptshi",
                "AVPacket_ptshi_s",
                "AVPacket_side_data",
                "AVPacket_side_data_s",
                "AVPacket_side_data_elems",
                "AVPacket_side_data_elems_s",
                "AVPacket_size",
                "AVPacket_size_s",
                "AVPacket_stream_index",
                "AVPacket_stream_index_s",
                "AVPacket_time_base_num",
                "AVPacket_time_base_num_s",
                "AVPacket_time_base_den",
                "AVPacket_time_base_den_s",
                "AVPacket_time_base_s",
                "AVFormatContext_duration",
                "AVFormatContext_duration_s",
                "AVFormatContext_durationhi",
                "AVFormatContext_durationhi_s",
                "AVFormatContext_flags",
                "AVFormatContext_flags_s",
                "AVFormatContext_nb_streams",
                "AVFormatContext_nb_streams_s",
                "AVFormatContext_oformat",
                "AVFormatContext_oformat_s",
                "AVFormatContext_pb",
                "AVFormatContext_pb_s",
                "AVFormatContext_start_time",
                "AVFormatContext_start_time_s",
                "AVFormatContext_start_timehi",
                "AVFormatContext_start_timehi_s",
                "AVFormatContext_streams_a",
                "AVFormatContext_streams_a_s",
                "AVStream_codecpar",
                "AVStream_codecpar_s",
                "AVStream_discard",
                "AVStream_discard_s",
                "AVStream_duration",
                "AVStream_duration_s",
                "AVStream_durationhi",
                "AVStream_durationhi_s",
                "AVStream_time_base_num",
                "AVStream_time_base_num_s",
                "AVStream_time_base_den",
                "AVStream_time_base_den_s",
                "AVStream_time_base_s",
                "AVFilterInOut_filter_ctx",
                "AVFilterInOut_filter_ctx_s",
                "AVFilterInOut_name",
                "AVFilterInOut_name_s",
                "AVFilterInOut_next",
                "AVFilterInOut_next_s",
                "AVFilterInOut_pad_idx",
                "AVFilterInOut_pad_idx_s",
                "ff_init_encoder",
                "ff_init_decoder",
                "ff_free_encoder",
                "ff_free_decoder",
                "ff_encode_multi",
                "ff_decode_multi",
                "ff_set_packet",
                "ff_init_muxer",
                "ff_free_muxer",
                "ff_init_demuxer_file",
                "ff_write_multi",
                "ff_read_frame_multi",
                "ff_read_multi",
                "ff_init_filter_graph",
                "ff_filter_multi",
                "ff_decode_filter_multi",
                "ff_copyout_frame",
                "ff_copyout_frame_video",
                "ff_frame_video_packed_size",
                "ff_copyout_frame_video_packed",
                "ff_copyout_frame_video_imagedata",
                "ff_copyout_frame_ptr",
                "ff_copyin_frame",
                "ff_copyout_packet",
                "ff_copyout_packet_ptr",
                "ff_copyin_packet",
                "ff_copyout_codecpar",
                "ff_copyin_codecpar",
                "ff_malloc_int32_list",
                "ff_malloc_int64_list",
                "ffmpeg",
                "ffprobe",
                "av_frame_free_js",
                "av_packet_free_js",
                "avformat_close_input_js",
                "avcodec_free_context_js",
                "avcodec_parameters_free_js",
                "avfilter_graph_free_js",
                "avfilter_inout_free_js",
                "av_dict_free_js",
              ],
              y = [
                "readFile",
                "writeFile",
                "unlink",
                "unmount",
                "mkdev",
                "createLazyFile",
                "mkreaderdev",
                "mkblockreaderdev",
                "mkreadaheadfile",
                "unlinkreadaheadfile",
                "mkwriterdev",
                "mkstreamwriterdev",
                "mountwriterfs",
                "mkfsfhfile",
                "unlinkfsfhfile",
                "mkworkerfsfile",
                "unlinkworkerfsfile",
                "ff_reader_dev_send",
                "ff_block_reader_dev_send",
                "ff_reader_dev_waiting",
                "copyin_u8",
                "copyout_u8",
                "copyin_s16",
                "copyout_s16",
                "copyin_s32",
                "copyout_s32",
                "copyin_f32",
                "copyout_f32",
              ];
            return (
              (f.libavjsMode = _),
              _ === "worker"
                ? (h(g), h(y))
                : _ === "threads"
                  ? (h(g), c(y))
                  : (c(g), c(y)),
              Object.assign(f, n),
              f
            );
          })
      );
    }));
})();
var {
    base: Po,
    isWebAssemblySupported: ko,
    isThreadingSupported: Oo,
    target: Lo,
    VER: Go,
    CONFIG: Uo,
    DBG: Yo,
    factories: Qo,
    i64tof64: Ko,
    f64toi64: Wo,
    i64ToBigInt: Ho,
    bigIntToi64: Xo,
    ff_channel_layout: Jo,
    ff_channels: Zo,
    AV_TIME_BASE: jo,
    AV_OPT_SEARCH_CHILDREN: zo,
    AVMEDIA_TYPE_UNKNOWN: qo,
    AVMEDIA_TYPE_VIDEO: $o,
    AVMEDIA_TYPE_AUDIO: ea,
    AVMEDIA_TYPE_DATA: ta,
    AVMEDIA_TYPE_SUBTITLE: ra,
    AVMEDIA_TYPE_ATTACHMENT: ia,
    AV_SAMPLE_FMT_NONE: na,
    AV_SAMPLE_FMT_U8: oa,
    AV_SAMPLE_FMT_S16: aa,
    AV_SAMPLE_FMT_S32: sa,
    AV_SAMPLE_FMT_FLT: Aa,
    AV_SAMPLE_FMT_DBL: la,
    AV_SAMPLE_FMT_U8P: ua,
    AV_SAMPLE_FMT_S16P: ca,
    AV_SAMPLE_FMT_S32P: da,
    AV_SAMPLE_FMT_FLTP: fa,
    AV_SAMPLE_FMT_DBLP: pa,
    AV_SAMPLE_FMT_S64: ma,
    AV_SAMPLE_FMT_S64P: ha,
    AV_SAMPLE_FMT_NB: ga,
    AV_PIX_FMT_NONE: ya,
    AV_PIX_FMT_YUV420P: wa,
    AV_PIX_FMT_YUYV422: ba,
    AV_PIX_FMT_RGB24: Ea,
    AV_PIX_FMT_BGR24: Ia,
    AV_PIX_FMT_YUV422P: Ca,
    AV_PIX_FMT_YUV444P: va,
    AV_PIX_FMT_YUV410P: Ta,
    AV_PIX_FMT_YUV411P: Sa,
    AV_PIX_FMT_GRAY8: Da,
    AV_PIX_FMT_MONOWHITE: Fa,
    AV_PIX_FMT_MONOBLACK: xa,
    AV_PIX_FMT_PAL8: Ba,
    AV_PIX_FMT_YUVJ420P: Ra,
    AV_PIX_FMT_YUVJ422P: Va,
    AV_PIX_FMT_YUVJ444P: Na,
    AV_PIX_FMT_UYVY422: Ma,
    AV_PIX_FMT_UYYVYY411: Pa,
    AV_PIX_FMT_BGR8: ka,
    AV_PIX_FMT_BGR4: Oa,
    AV_PIX_FMT_BGR4_BYTE: La,
    AV_PIX_FMT_RGB8: Ga,
    AV_PIX_FMT_RGB4: Ua,
    AV_PIX_FMT_RGB4_BYTE: Ya,
    AV_PIX_FMT_NV12: Qa,
    AV_PIX_FMT_NV21: Ka,
    AV_PIX_FMT_ARGB: Wa,
    AV_PIX_FMT_RGBA: Ha,
    AV_PIX_FMT_ABGR: Xa,
    AV_PIX_FMT_BGRA: Ja,
    AV_PIX_FMT_GRAY16BE: Za,
    AV_PIX_FMT_GRAY16LE: ja,
    AV_PIX_FMT_YUV440P: za,
    AV_PIX_FMT_YUVJ440P: qa,
    AV_PIX_FMT_YUVA420P: $a,
    AV_PIX_FMT_RGB48BE: es,
    AV_PIX_FMT_RGB48LE: ts,
    AV_PIX_FMT_RGB565BE: rs,
    AV_PIX_FMT_RGB565LE: is,
    AV_PIX_FMT_RGB555BE: ns,
    AV_PIX_FMT_RGB555LE: os,
    AV_PIX_FMT_BGR565BE: as,
    AV_PIX_FMT_BGR565LE: ss,
    AV_PIX_FMT_BGR555BE: As,
    AV_PIX_FMT_BGR555LE: ls,
    AVIO_FLAG_READ: us,
    AVIO_FLAG_WRITE: cs,
    AVIO_FLAG_READ_WRITE: ds,
    AVIO_FLAG_NONBLOCK: fs,
    AVIO_FLAG_DIRECT: ps,
    AVFMT_FLAG_NOBUFFER: ms,
    AVFMT_FLAG_FLUSH_PACKETS: _s,
    AVSEEK_FLAG_BACKWARD: hs,
    AVSEEK_FLAG_BYTE: gs,
    AVSEEK_FLAG_ANY: ys,
    AVSEEK_FLAG_FRAME: ws,
    AVDISCARD_NONE: bs,
    AVDISCARD_DEFAULT: Es,
    AVDISCARD_NONREF: Is,
    AVDISCARD_BIDIR: Cs,
    AVDISCARD_NONINTRA: vs,
    AVDISCARD_NONKEY: Ts,
    AVDISCARD_ALL: Ss,
    AV_LOG_QUIET: Ds,
    AV_LOG_PANIC: Fs,
    AV_LOG_FATAL: xs,
    AV_LOG_ERROR: Bs,
    AV_LOG_WARNING: Rs,
    AV_LOG_INFO: Vs,
    AV_LOG_VERBOSE: Ns,
    AV_LOG_DEBUG: Ms,
    AV_LOG_TRACE: Ps,
    AV_PKT_FLAG_KEY: ks,
    AV_PKT_FLAG_CORRUPT: Os,
    AV_PKT_FLAG_DISCARD: Ls,
    AV_PKT_FLAG_TRUSTED: Gs,
    AV_PKT_FLAG_DISPOSABLE: Us,
    E2BIG: Ys,
    EPERM: Qs,
    EADDRINUSE: Ks,
    EADDRNOTAVAIL: Ws,
    EAFNOSUPPORT: Hs,
    EAGAIN: Xs,
    EALREADY: Js,
    EBADF: Zs,
    EBADMSG: js,
    EBUSY: zs,
    ECANCELED: qs,
    ECHILD: $s,
    ECONNABORTED: eA,
    ECONNREFUSED: tA,
    ECONNRESET: rA,
    EDEADLOCK: iA,
    EDESTADDRREQ: nA,
    EDOM: oA,
    EDQUOT: aA,
    EEXIST: sA,
    EFAULT: AA,
    EFBIG: lA,
    EHOSTUNREACH: uA,
    EIDRM: cA,
    EILSEQ: dA,
    EINPROGRESS: fA,
    EINTR: pA,
    EINVAL: mA,
    EIO: _A,
    EISCONN: hA,
    EISDIR: gA,
    ELOOP: yA,
    EMFILE: wA,
    EMLINK: bA,
    EMSGSIZE: EA,
    EMULTIHOP: IA,
    ENAMETOOLONG: CA,
    ENETDOWN: vA,
    ENETRESET: TA,
    ENETUNREACH: SA,
    ENFILE: DA,
    ENOBUFS: FA,
    ENODEV: xA,
    ENOENT: BA,
    AVERROR_EOF: RA,
    LibAV: tr,
  } = D,
  ye = D;
function M(t) {
  throw t;
}
function rr(t) {
  if (t instanceof Object) {
    let e = t.toString();
    if ("errno" in t) {
      e = `(de)muxer error. ${t.errno}`;
      for (let [r, i] of Object.entries(tr))
        typeof i == "number" &&
          r.startsWith("E") &&
          i == t.errno &&
          (e = `(de)muxer error. ${r}`);
    }
    return e;
  }
  return t.toString();
}
async function Re(t, e) {
  if (e < 0) {
    let r = await t.strerror(e);
    M(r);
  }
}
async function Ve(t, e) {
  if (e != 0) {
    let r = await t.strerror(e);
    M(r);
  }
}
function ae(t) {
  var e = String(t);
  if (e === "[object Object]")
    try {
      e = JSON.stringify(t);
    } catch {}
  return e;
}
var Li = (function () {
    function t() {}
    return (
      (t.prototype.isSome = function () {
        return !1;
      }),
      (t.prototype.isNone = function () {
        return !0;
      }),
      (t.prototype[Symbol.iterator] = function () {
        return {
          next: function () {
            return { done: !0, value: void 0 };
          },
        };
      }),
      (t.prototype.unwrapOr = function (e) {
        return e;
      }),
      (t.prototype.expect = function (e) {
        throw new Error("".concat(e));
      }),
      (t.prototype.unwrap = function () {
        throw new Error("Tried to unwrap None");
      }),
      (t.prototype.map = function (e) {
        return this;
      }),
      (t.prototype.mapOr = function (e, r) {
        return e;
      }),
      (t.prototype.mapOrElse = function (e, r) {
        return e();
      }),
      (t.prototype.or = function (e) {
        return e;
      }),
      (t.prototype.orElse = function (e) {
        return e();
      }),
      (t.prototype.andThen = function (e) {
        return this;
      }),
      (t.prototype.toResult = function (e) {
        return C(e);
      }),
      (t.prototype.toString = function () {
        return "None";
      }),
      (t.prototype.toAsyncOption = function () {
        return new Ne(B);
      }),
      t
    );
  })(),
  B = new Li();
Object.freeze(B);
var Gi = (function () {
    function t(e) {
      if (!(this instanceof t)) return new t(e);
      this.value = e;
    }
    return (
      (t.prototype.isSome = function () {
        return !0;
      }),
      (t.prototype.isNone = function () {
        return !1;
      }),
      (t.prototype[Symbol.iterator] = function () {
        var e = Object(this.value);
        return Symbol.iterator in e
          ? e[Symbol.iterator]()
          : {
              next: function () {
                return { done: !0, value: void 0 };
              },
            };
      }),
      (t.prototype.unwrapOr = function (e) {
        return this.value;
      }),
      (t.prototype.expect = function (e) {
        return this.value;
      }),
      (t.prototype.unwrap = function () {
        return this.value;
      }),
      (t.prototype.map = function (e) {
        return P(e(this.value));
      }),
      (t.prototype.mapOr = function (e, r) {
        return r(this.value);
      }),
      (t.prototype.mapOrElse = function (e, r) {
        return r(this.value);
      }),
      (t.prototype.or = function (e) {
        return this;
      }),
      (t.prototype.orElse = function (e) {
        return this;
      }),
      (t.prototype.andThen = function (e) {
        return e(this.value);
      }),
      (t.prototype.toResult = function (e) {
        return v(this.value);
      }),
      (t.prototype.toAsyncOption = function () {
        return new Ne(this);
      }),
      (t.prototype.safeUnwrap = function () {
        return this.value;
      }),
      (t.prototype.toString = function () {
        return "Some(".concat(ae(this.value), ")");
      }),
      (t.EMPTY = new t(void 0)),
      t
    );
  })(),
  P = Gi,
  ct;
(function (t) {
  function e() {
    for (var n = [], o = 0; o < arguments.length; o++) n[o] = arguments[o];
    for (var a = [], s = 0, u = n; s < u.length; s++) {
      var A = u[s];
      if (A.isSome()) a.push(A.value);
      else return A;
    }
    return P(a);
  }
  t.all = e;
  function r() {
    for (var n = [], o = 0; o < arguments.length; o++) n[o] = arguments[o];
    for (var a = 0, s = n; a < s.length; a++) {
      var u = s[a];
      if (u.isSome()) return u;
    }
    return B;
  }
  t.any = r;
  function i(n) {
    return n instanceof P || n === B;
  }
  t.isOption = i;
})(ct || (ct = {}));
var we = function (t, e, r) {
    if (r || arguments.length === 2)
      for (var i = 0, n = e.length, o; i < n; i++)
        (o || !(i in e)) &&
          (o || (o = Array.prototype.slice.call(e, 0, i)), (o[i] = e[i]));
    return t.concat(o || Array.prototype.slice.call(e));
  },
  Ui = (function () {
    function t(e) {
      if (!(this instanceof t)) return new t(e);
      this.error = e;
      var r = new Error().stack
        .split(
          `
`,
        )
        .slice(2);
      (r && r.length > 0 && r[0].includes("ErrImpl") && r.shift(),
        (this._stack = r.join(`
`)));
    }
    return (
      (t.prototype.isOk = function () {
        return !1;
      }),
      (t.prototype.isErr = function () {
        return !0;
      }),
      (t.prototype[Symbol.iterator] = function () {
        return {
          next: function () {
            return { done: !0, value: void 0 };
          },
        };
      }),
      (t.prototype.else = function (e) {
        return e;
      }),
      (t.prototype.unwrapOr = function (e) {
        return e;
      }),
      (t.prototype.expect = function (e) {
        throw new Error(
          ""
            .concat(e, " - Error: ")
            .concat(
              ae(this.error),
              `
`,
            )
            .concat(this._stack),
          { cause: this.error },
        );
      }),
      (t.prototype.expectErr = function (e) {
        return this.error;
      }),
      (t.prototype.unwrap = function () {
        throw new Error(
          "Tried to unwrap Error: "
            .concat(
              ae(this.error),
              `
`,
            )
            .concat(this._stack),
          { cause: this.error },
        );
      }),
      (t.prototype.unwrapErr = function () {
        return this.error;
      }),
      (t.prototype.map = function (e) {
        return this;
      }),
      (t.prototype.andThen = function (e) {
        return this;
      }),
      (t.prototype.mapErr = function (e) {
        return new C(e(this.error));
      }),
      (t.prototype.mapOr = function (e, r) {
        return e;
      }),
      (t.prototype.mapOrElse = function (e, r) {
        return e(this.error);
      }),
      (t.prototype.or = function (e) {
        return e;
      }),
      (t.prototype.orElse = function (e) {
        return e(this.error);
      }),
      (t.prototype.toOption = function () {
        return B;
      }),
      (t.prototype.toString = function () {
        return "Err(".concat(ae(this.error), ")");
      }),
      Object.defineProperty(t.prototype, "stack", {
        get: function () {
          return ""
            .concat(
              this,
              `
`,
            )
            .concat(this._stack);
        },
        enumerable: !1,
        configurable: !0,
      }),
      (t.prototype.toAsyncResult = function () {
        return new Me(this);
      }),
      (t.EMPTY = new t(void 0)),
      t
    );
  })();
var C = Ui,
  Yi = (function () {
    function t(e) {
      if (!(this instanceof t)) return new t(e);
      this.value = e;
    }
    return (
      (t.prototype.isOk = function () {
        return !0;
      }),
      (t.prototype.isErr = function () {
        return !1;
      }),
      (t.prototype[Symbol.iterator] = function () {
        var e = Object(this.value);
        return Symbol.iterator in e
          ? e[Symbol.iterator]()
          : {
              next: function () {
                return { done: !0, value: void 0 };
              },
            };
      }),
      (t.prototype.else = function (e) {
        return this.value;
      }),
      (t.prototype.unwrapOr = function (e) {
        return this.value;
      }),
      (t.prototype.expect = function (e) {
        return this.value;
      }),
      (t.prototype.expectErr = function (e) {
        throw new Error(e);
      }),
      (t.prototype.unwrap = function () {
        return this.value;
      }),
      (t.prototype.unwrapErr = function () {
        throw new Error("Tried to unwrap Ok: ".concat(ae(this.value)), {
          cause: this.value,
        });
      }),
      (t.prototype.map = function (e) {
        return new v(e(this.value));
      }),
      (t.prototype.andThen = function (e) {
        return e(this.value);
      }),
      (t.prototype.mapErr = function (e) {
        return this;
      }),
      (t.prototype.mapOr = function (e, r) {
        return r(this.value);
      }),
      (t.prototype.mapOrElse = function (e, r) {
        return r(this.value);
      }),
      (t.prototype.or = function (e) {
        return this;
      }),
      (t.prototype.orElse = function (e) {
        return this;
      }),
      (t.prototype.toOption = function () {
        return P(this.value);
      }),
      (t.prototype.safeUnwrap = function () {
        return this.value;
      }),
      (t.prototype.toString = function () {
        return "Ok(".concat(ae(this.value), ")");
      }),
      (t.prototype.toAsyncResult = function () {
        return new Me(this);
      }),
      (t.EMPTY = new t(void 0)),
      t
    );
  })();
var v = Yi,
  dt;
(function (t) {
  function e(s) {
    for (var u = [], A = 1; A < arguments.length; A++) u[A - 1] = arguments[A];
    for (
      var l = s === void 0 ? [] : Array.isArray(s) ? s : we([s], u, !0),
        d = [],
        f = 0,
        _ = l;
      f < _.length;
      f++
    ) {
      var h = _[f];
      if (h.isOk()) d.push(h.value);
      else return h;
    }
    return new v(d);
  }
  t.all = e;
  function r(s) {
    for (var u = [], A = 1; A < arguments.length; A++) u[A - 1] = arguments[A];
    for (
      var l = s === void 0 ? [] : Array.isArray(s) ? s : we([s], u, !0),
        d = [],
        f = 0,
        _ = l;
      f < _.length;
      f++
    ) {
      var h = _[f];
      if (h.isOk()) return h;
      d.push(h.error);
    }
    return new C(d);
  }
  t.any = r;
  function i(s) {
    try {
      return new v(s());
    } catch (u) {
      return new C(u);
    }
  }
  t.wrap = i;
  function n(s) {
    try {
      return s()
        .then(function (u) {
          return new v(u);
        })
        .catch(function (u) {
          return new C(u);
        });
    } catch (u) {
      return Promise.resolve(new C(u));
    }
  }
  t.wrapAsync = n;
  function o(s) {
    return s.reduce(
      function (u, A) {
        var l = u[0],
          d = u[1];
        return A.isOk()
          ? [we(we([], l, !0), [A.value], !1), d]
          : [l, we(we([], d, !0), [A.error], !1)];
      },
      [[], []],
    );
  }
  t.partition = o;
  function a(s) {
    return s instanceof C || s instanceof v;
  }
  t.isResult = a;
})(dt || (dt = {}));
var He = function (t, e, r, i) {
    function n(o) {
      return o instanceof r
        ? o
        : new r(function (a) {
            a(o);
          });
    }
    return new (r || (r = Promise))(function (o, a) {
      function s(l) {
        try {
          A(i.next(l));
        } catch (d) {
          a(d);
        }
      }
      function u(l) {
        try {
          A(i.throw(l));
        } catch (d) {
          a(d);
        }
      }
      function A(l) {
        l.done ? o(l.value) : n(l.value).then(s, u);
      }
      A((i = i.apply(t, e || [])).next());
    });
  },
  Xe = function (t, e) {
    var r = {
        label: 0,
        sent: function () {
          if (o[0] & 1) throw o[1];
          return o[1];
        },
        trys: [],
        ops: [],
      },
      i,
      n,
      o,
      a;
    return (
      (a = { next: s(0), throw: s(1), return: s(2) }),
      typeof Symbol == "function" &&
        (a[Symbol.iterator] = function () {
          return this;
        }),
      a
    );
    function s(A) {
      return function (l) {
        return u([A, l]);
      };
    }
    function u(A) {
      if (i) throw new TypeError("Generator is already executing.");
      for (; a && ((a = 0), A[0] && (r = 0)), r;)
        try {
          if (
            ((i = 1),
            n &&
              (o =
                A[0] & 2
                  ? n.return
                  : A[0]
                    ? n.throw || ((o = n.return) && o.call(n), 0)
                    : n.next) &&
              !(o = o.call(n, A[1])).done)
          )
            return o;
          switch (((n = 0), o && (A = [A[0] & 2, o.value]), A[0])) {
            case 0:
            case 1:
              o = A;
              break;
            case 4:
              return (r.label++, { value: A[1], done: !1 });
            case 5:
              (r.label++, (n = A[1]), (A = [0]));
              continue;
            case 7:
              ((A = r.ops.pop()), r.trys.pop());
              continue;
            default:
              if (
                ((o = r.trys),
                !(o = o.length > 0 && o[o.length - 1]) &&
                  (A[0] === 6 || A[0] === 2))
              ) {
                r = 0;
                continue;
              }
              if (A[0] === 3 && (!o || (A[1] > o[0] && A[1] < o[3]))) {
                r.label = A[1];
                break;
              }
              if (A[0] === 6 && r.label < o[1]) {
                ((r.label = o[1]), (o = A));
                break;
              }
              if (o && r.label < o[2]) {
                ((r.label = o[2]), r.ops.push(A));
                break;
              }
              (o[2] && r.ops.pop(), r.trys.pop());
              continue;
          }
          A = e.call(t, r);
        } catch (l) {
          ((A = [6, l]), (n = 0));
        } finally {
          i = o = 0;
        }
      if (A[0] & 5) throw A[1];
      return { value: A[0] ? A[1] : void 0, done: !0 };
    }
  },
  Me = (function () {
    function t(e) {
      this.promise = Promise.resolve(e);
    }
    return (
      (t.prototype.andThen = function (e) {
        var r = this;
        return this.thenInternal(function (i) {
          return He(r, void 0, void 0, function () {
            var n;
            return Xe(this, function (o) {
              return i.isErr()
                ? [2, i]
                : ((n = e(i.value)), [2, n instanceof t ? n.promise : n]);
            });
          });
        });
      }),
      (t.prototype.map = function (e) {
        var r = this;
        return this.thenInternal(function (i) {
          return He(r, void 0, void 0, function () {
            var n;
            return Xe(this, function (o) {
              switch (o.label) {
                case 0:
                  return i.isErr() ? [2, i] : ((n = v), [4, e(i.value)]);
                case 1:
                  return [2, n.apply(void 0, [o.sent()])];
              }
            });
          });
        });
      }),
      (t.prototype.mapErr = function (e) {
        var r = this;
        return this.thenInternal(function (i) {
          return He(r, void 0, void 0, function () {
            var n;
            return Xe(this, function (o) {
              switch (o.label) {
                case 0:
                  return i.isOk() ? [2, i] : ((n = C), [4, e(i.error)]);
                case 1:
                  return [2, n.apply(void 0, [o.sent()])];
              }
            });
          });
        });
      }),
      (t.prototype.or = function (e) {
        return this.orElse(function () {
          return e;
        });
      }),
      (t.prototype.orElse = function (e) {
        var r = this;
        return this.thenInternal(function (i) {
          return He(r, void 0, void 0, function () {
            var n;
            return Xe(this, function (o) {
              return i.isOk()
                ? [2, i]
                : ((n = e(i.error)), [2, n instanceof t ? n.promise : n]);
            });
          });
        });
      }),
      (t.prototype.toOption = function () {
        return new Ne(
          this.promise.then(function (e) {
            return e.toOption();
          }),
        );
      }),
      (t.prototype.thenInternal = function (e) {
        return new t(this.promise.then(e));
      }),
      t
    );
  })();
var ft = function (t, e, r, i) {
    function n(o) {
      return o instanceof r
        ? o
        : new r(function (a) {
            a(o);
          });
    }
    return new (r || (r = Promise))(function (o, a) {
      function s(l) {
        try {
          A(i.next(l));
        } catch (d) {
          a(d);
        }
      }
      function u(l) {
        try {
          A(i.throw(l));
        } catch (d) {
          a(d);
        }
      }
      function A(l) {
        l.done ? o(l.value) : n(l.value).then(s, u);
      }
      A((i = i.apply(t, e || [])).next());
    });
  },
  pt = function (t, e) {
    var r = {
        label: 0,
        sent: function () {
          if (o[0] & 1) throw o[1];
          return o[1];
        },
        trys: [],
        ops: [],
      },
      i,
      n,
      o,
      a;
    return (
      (a = { next: s(0), throw: s(1), return: s(2) }),
      typeof Symbol == "function" &&
        (a[Symbol.iterator] = function () {
          return this;
        }),
      a
    );
    function s(A) {
      return function (l) {
        return u([A, l]);
      };
    }
    function u(A) {
      if (i) throw new TypeError("Generator is already executing.");
      for (; a && ((a = 0), A[0] && (r = 0)), r;)
        try {
          if (
            ((i = 1),
            n &&
              (o =
                A[0] & 2
                  ? n.return
                  : A[0]
                    ? n.throw || ((o = n.return) && o.call(n), 0)
                    : n.next) &&
              !(o = o.call(n, A[1])).done)
          )
            return o;
          switch (((n = 0), o && (A = [A[0] & 2, o.value]), A[0])) {
            case 0:
            case 1:
              o = A;
              break;
            case 4:
              return (r.label++, { value: A[1], done: !1 });
            case 5:
              (r.label++, (n = A[1]), (A = [0]));
              continue;
            case 7:
              ((A = r.ops.pop()), r.trys.pop());
              continue;
            default:
              if (
                ((o = r.trys),
                !(o = o.length > 0 && o[o.length - 1]) &&
                  (A[0] === 6 || A[0] === 2))
              ) {
                r = 0;
                continue;
              }
              if (A[0] === 3 && (!o || (A[1] > o[0] && A[1] < o[3]))) {
                r.label = A[1];
                break;
              }
              if (A[0] === 6 && r.label < o[1]) {
                ((r.label = o[1]), (o = A));
                break;
              }
              if (o && r.label < o[2]) {
                ((r.label = o[2]), r.ops.push(A));
                break;
              }
              (o[2] && r.ops.pop(), r.trys.pop());
              continue;
          }
          A = e.call(t, r);
        } catch (l) {
          ((A = [6, l]), (n = 0));
        } finally {
          i = o = 0;
        }
      if (A[0] & 5) throw A[1];
      return { value: A[0] ? A[1] : void 0, done: !0 };
    }
  },
  Ne = (function () {
    function t(e) {
      this.promise = Promise.resolve(e);
    }
    return (
      (t.prototype.andThen = function (e) {
        var r = this;
        return this.thenInternal(function (i) {
          return ft(r, void 0, void 0, function () {
            var n;
            return pt(this, function (o) {
              return i.isNone()
                ? [2, i]
                : ((n = e(i.value)), [2, n instanceof t ? n.promise : n]);
            });
          });
        });
      }),
      (t.prototype.map = function (e) {
        var r = this;
        return this.thenInternal(function (i) {
          return ft(r, void 0, void 0, function () {
            var n;
            return pt(this, function (o) {
              switch (o.label) {
                case 0:
                  return i.isNone() ? [2, i] : ((n = P), [4, e(i.value)]);
                case 1:
                  return [2, n.apply(void 0, [o.sent()])];
              }
            });
          });
        });
      }),
      (t.prototype.or = function (e) {
        return this.orElse(function () {
          return e;
        });
      }),
      (t.prototype.orElse = function (e) {
        var r = this;
        return this.thenInternal(function (i) {
          return ft(r, void 0, void 0, function () {
            var n;
            return pt(this, function (o) {
              return i.isSome()
                ? [2, i]
                : ((n = e()), [2, n instanceof t ? n.promise : n]);
            });
          });
        });
      }),
      (t.prototype.toResult = function (e) {
        return new Me(
          this.promise.then(function (r) {
            return r.toResult(e);
          }),
        );
      }),
      (t.prototype.thenInternal = function (e) {
        return new t(this.promise.then(e));
      }),
      t
    );
  })();
function $(t) {
  if (t.__serde_tag == "primitive") return t.__serde_val;
  if (t.__serde_tag == "object") {
    let e = {};
    for (let [r, i] of Object.entries(t.__serde_val)) {
      let n = i;
      e[r] = $(n);
    }
    return e;
  } else {
    if (t.__serde_tag == "map")
      return new Map(t.__serde_val.map(([e, r]) => [$(e), $(r)]));
    if (t.__serde_tag == "set") return new Set(t.__serde_val.map($));
    if (t.__serde_tag == "url") return new URL(t.__serde_val);
    if (t.__serde_tag == "array") return t.__serde_val.map($);
    if (t.__serde_tag == "headers") return new Headers(t.__serde_val);
    if (t.__serde_tag == "regex")
      return new RegExp(t.__serde_val[0], t.__serde_val[1]);
    if (t.__serde_tag == "some") return P($(t.__serde_val));
    if (t.__serde_tag == "none") return B;
    if (t.__serde_tag == "ok") return v($(t.__serde_val));
    if (t.__serde_tag == "err") return C($(t.__serde_val));
    throw new Error("Unreachable");
  }
}
async function ir(t, e) {
  let r;
  return (
    await new Promise((i) => {
      let n = () => {
        (clearTimeout(r), e.removeEventListener("abort", n), i());
      };
      if ((e.addEventListener("abort", n), e.aborted)) {
        i();
        return;
      }
      r = setTimeout(() => {
        (e.removeEventListener("abort", n), i());
      }, t);
    }),
    e.aborted
      ? { aborted: !0, timeout_id: r }
      : { timed_out: !0, timeout_id: r }
  );
}
async function Qi(t, e, r, i, n, o, a) {
  let s = o ? "reload" : "default",
    u;
  for (let A = 0; A < r; ++A) {
    let l = new AbortController(),
      d = AbortSignal.any([l.signal, a]),
      f = setTimeout(() => l.abort(`Timed out after ${i}`), i);
    try {
      let c = await fetch(t, { headers: e, cache: s, signal: d });
      if (c.ok) return c;
      if (c.status == 404 || c.status == 416) return { err_status: c.status };
      u = { err_status: c.status };
    } catch (c) {
      if (c instanceof DOMException && c.name == "AbortError")
        return a.aborted ? { aborted: !0 } : { timeout: !0 };
      u = c;
    } finally {
      clearTimeout(f);
    }
    let _ = Math.pow(2, A) * n;
    A + 1 < r;
    let h = await ir(_, a);
    if ((h.timeout_id && clearTimeout(f), h.aborted)) return { aborted: !0 };
  }
  return u;
}
function mt(t) {
  let e = [137, 80, 78, 71, 13, 10, 26, 10],
    r = [73, 69, 78, 68, 174, 66, 96, 130];
  for (let a = 0; a < e.length; a++) if (t[a] !== e[a]) return -1;
  let i = r.length,
    n = t.length;
  if (i === 0 || i > n) return -1;
  let o = r[0];
  for (let a = e.length; a <= n - i; a++) {
    if (t[a] !== o) continue;
    let s = !0;
    for (let u = 1; u < i; u++)
      if (t[a + u] !== r[u]) {
        s = !1;
        break;
      }
    if (s) return a + r.length;
  }
  return -1;
}
function nr() {
  ((globalThis.FetchWithRetry = Qi),
    (globalThis.DoAbortableSleep = ir),
    (globalThis.FindPngSliceIndex = mt),
    (globalThis.MutateUrl = (t) => t),
    (globalThis.MAX_FETCH_ATTEMPTS = 6),
    (globalThis.MAX_READ_ATTEMPTS = 6));
}
Object.defineProperty(Object.prototype, "_a", {
  get: function () {
    return this;
  },
  configurable: !0,
});
_a.requestAnimation = () => {};
delete Object.prototype._a;
var _t = {
  FromInjectedToService: 0,
  FromContentToService: 1,
  FromServiceToWorker: 2,
  FromWorkerToService: 3,
  FromUntrustedInjectedToTrusted: 4,
  FromTrustedInjectedToUntrusted: 5,
  FromServiceToContent: 6,
  FromServiceToInjected: 7,
  FromServiceToService: 8,
};
var ht = new BroadcastChannel("worker_service");
function re(t) {
  let e = _t.FromWorkerToService;
  ht.postMessage({ msg: t, channel: e });
}
function or(t) {
  let e = (r) => {
    let i = r.data.msg;
    r.data.channel == _t.FromServiceToWorker && t(i);
  };
  return (
    ht.addEventListener("message", e),
    () => {
      ht.removeEventListener("message", e);
    }
  );
}
var z = class {
    constructor(e) {
      ((this.download_id = e),
        (this.progress = { status: "queuing" }),
        this.postNow());
    }
    schedulePost() {
      this.timeout || (this.timeout = setTimeout(() => this.postNow(), 500));
    }
    postNow() {
      (this.timeout && (clearTimeout(this.timeout), delete this.timeout),
        re({
          name: "download_progress",
          data: { download_id: this.download_id, progress: this.progress },
        }));
    }
    set_progress(e) {
      ((this.progress = e), this.schedulePost());
    }
    set_duration_in_s(e) {
      this.progress.status == "downloading" &&
        (this.progress.output_duration_s = e);
    }
    add_bytes(e) {
      (this.progress.status == "downloading"
        ? (this.progress.fetched_bytes_count += e)
        : this.progress.status == "queuing" &&
          (this.progress = {
            status: "downloading",
            percent: { is_known: !0, value: 0 },
            fetched_bytes_count: e,
            output_duration_s: 0,
          }),
        this.schedulePost());
    }
    dont_trust_percent() {
      this.progress.status == "downloading" &&
        ((this.progress.percent.is_known = !1), this.schedulePost());
    }
    set_percent(e) {
      (this.progress.status == "downloading" && this.progress.percent.is_known
        ? (this.progress.percent.value = e)
        : this.progress.status == "queuing" &&
          (this.progress = {
            status: "downloading",
            percent: { is_known: !0, value: e },
            fetched_bytes_count: 0,
            output_duration_s: 0,
          }),
        this.schedulePost());
    }
  },
  Pe = class extends z {
    constructor(e) {
      super(e);
    }
    nextStream() {
      ((this.second_stream = !0),
        (this.progress = { status: "queuing" }),
        this.postNow());
    }
    postNow() {
      if (
        (this.timeout && (clearTimeout(this.timeout), delete this.timeout),
        !(!this.second_stream && this.progress.status == "finalizing"))
      ) {
        if (!(this.second_stream && this.progress.status == "queuing")) {
          let e = structuredClone(this.progress);
          (e.status == "downloading" &&
            e.percent.is_known &&
            (this.second_stream
              ? ((e.percent.value *= 0.5), (e.percent.value += 50))
              : (e.percent.value *= 0.5)),
            re({
              name: "download_progress",
              data: { download_id: this.download_id, progress: e },
            }));
        }
      }
    }
  };
var L = class {
  constructor() {
    this.filename_writable_map = new Map();
  }
  async open(e) {
    let i = await (
        await navigator.storage.getDirectory()
      ).getFileHandle(e, { create: !0 }),
      n = await i.createSyncAccessHandle();
    this.filename_writable_map.set(e, { writable: n, handle: i, size: 0 });
  }
  async onwrite(e, r, i) {
    let n = this.filename_writable_map.get(e);
    n && (await n.writable.write(i, { at: r }), (n.size += i.length));
  }
  async close(e) {
    let r = this.filename_writable_map.get(e);
    if (!r) return 0;
    await r.writable.close();
    let i = this.filename_writable_map.get(e)?.size;
    return (this.filename_writable_map.delete(e), i || 0);
  }
  async remove(e) {
    await (await navigator.storage.getDirectory()).removeEntry(e);
  }
};
async function Q(t, e) {
  let n = await (
    await (await navigator.storage.getDirectory()).getFileHandle(e)
  ).getFile();
  switch (t.extension) {
    case "mkv":
      return URL.createObjectURL(
        new File([n], e, { type: "video/x-matroska" }),
      );
    case "flv":
      return URL.createObjectURL(new File([n], e, { type: "video/x-flv" }));
    default:
      return URL.createObjectURL(n);
  }
}
function ce() {
  return {
    user_abort: !0,
    e4XX_5XX_failure: !1,
    other_failure: !1,
    percentage_incomplete: !1,
  };
}
function gt() {
  return {
    user_abort: !1,
    e4XX_5XX_failure: !1,
    other_failure: !1,
    percentage_incomplete: !0,
  };
}
function F(t) {
  return {
    user_abort: !1,
    e4XX_5XX_failure: !1,
    percentage_incomplete: !1,
    other_failure: !0,
    message: t,
  };
}
function Je(t) {
  return {
    user_abort: !1,
    e4XX_5XX_failure: !0,
    percentage_incomplete: !1,
    other_failure: !1,
    status: t,
  };
}
var ar, sr, Ar;
function lr(t) {
  return t == 255 || t == -1415072069;
}
function yt(t) {
  return t < 1e3
    ? Je(t)
    : t == 1001
      ? F("Network error")
      : t == 1002
        ? F("Read() error")
        : F("Fetch timeout");
}
function wt(t) {
  return t ? (t > 0 && t < 1e3) || t == 1001 || t == 1002 : !1;
}
async function G(t, e, r, i, n) {
  let o = await ye.LibAV({ noworker: !0 }),
    a = new L();
  ((o.onwrite = a.onwrite.bind(a)),
    ar &&
      sr &&
      Ar &&
      (await o.jsfetch_set_read_timeout(ar),
      await o.jsfetch_set_fetch_timeout(sr),
      await o.jsfetch_set_initial_retry_delay(Ar)),
    await o.jsfetch_set_bypass_cache(t.cache == "reload"));
  let s = !1;
  (e.addEventListener("abort", async (y) => {
    d && (await o.ffmpeg_interrupt(), (d = !1), (s = !0));
  }),
    i || (i = new z(t.download_id)));
  let u = 0,
    A = () => {
      setTimeout(async () => {
        let y = await o.ffmpeg_get_total_size_bytes(),
          p = y - u;
        ((u = y), i.add_bytes(p));
        let m = await o.ffmpeg_get_out_time_ms();
        if (
          (i.set_duration_in_s(m / 1e3),
          t.strategy == "http_strip_audio_jsfetch")
        )
          i.dont_trust_percent();
        else if ("duration" in t && typeof t.duration == "number") {
          let w = t.duration * 1e3,
            T = 100 * (m / w);
          i.set_percent(T);
        } else if ("size" in t && t.size.isSome()) {
          let w = t.size.value,
            T = 100 * (y / w);
          i.set_percent(T);
        } else i.dont_trust_percent();
        d && A();
      }, 500);
    },
    l,
    d = !1,
    f = 0,
    _;
  await a.open(r);
  try {
    (await o.mkwriterdev(r), (d = !0), A(), (l = await o.ffmpeg(n)));
  } catch (y) {
    _ = `${y}`;
  } finally {
    ((f = await a.close(r)), (d = !1));
  }
  let h = f < 1e3,
    c = !1,
    g = 0;
  if ("duration" in t && typeof t.duration == "number") {
    let y = t.duration * 1e3;
    ((g = 100 * ((await o.ffmpeg_get_out_time_ms()) / y)), (c = g < 95));
  } else if ("size" in t && t.size.isSome()) {
    let y = await o.ffmpeg_get_total_size_bytes(),
      p = t.size.value;
    ((g = 100 * (y / p)), (c = g < 90));
  }
  if (_)
    return g <= 5
      ? (await a.remove(r),
        {
          aborted_no_partial: !0,
          download_id: t.download_id,
          ending_reason: F(`Unknown libav error: ${_}`),
        })
      : {
          internal_filename: r,
          aborted_no_partial: !1,
          internal_bloburl: await Q(t, r),
          download_id: t.download_id,
          ending_reason: gt(),
        };
  if (h) {
    if ((await a.remove(r), lr(l) || s))
      return {
        aborted_no_partial: !0,
        download_id: t.download_id,
        ending_reason: ce(),
      };
    if (l != 0 && l != null) {
      if (wt(l))
        return {
          aborted_no_partial: !0,
          download_id: t.download_id,
          ending_reason: yt(l),
        };
      let y = await o.strerror(l);
      return {
        aborted_no_partial: !0,
        download_id: t.download_id,
        ending_reason: F(y),
      };
    } else
      return {
        aborted_no_partial: !0,
        download_id: t.download_id,
        ending_reason: F(`Expected larger size, but only got ${f} bytes`),
      };
  }
  if (lr(l) || s)
    return {
      internal_filename: r,
      aborted_no_partial: !1,
      internal_bloburl: await Q(t, r),
      download_id: t.download_id,
      ending_reason: ce(),
    };
  if (c && g >= 5) {
    let y = wt(l) ? yt(l) : gt();
    return {
      internal_filename: r,
      aborted_no_partial: !1,
      internal_bloburl: await Q(t, r),
      download_id: t.download_id,
      ending_reason: y,
    };
  }
  if (l == 0)
    return {
      internal_filename: r,
      aborted_no_partial: !1,
      internal_bloburl: await Q(t, r),
      download_id: t.download_id,
      ending_reason: "end_of_file",
    };
  if (l && wt(l))
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: yt(l),
    };
  if (l) {
    await a.remove(r);
    let y = await o.strerror(l);
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: F(y),
    };
  }
  return (
    await a.remove(r),
    {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: F("Unreachable"),
    }
  );
}
async function ur(t, e) {
  let r = `${t.download_id}.${t.extension}`;
  return await G(t, e, r, void 0, [
    "-analyzeduration",
    "10M",
    "-f",
    "dash",
    "-i",
    `jsfetch:${t.url}`,
    "-map",
    `0:${t.entry}`,
    "-map",
    "0:a:0?",
    "-c",
    "copy",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
async function cr(t, e) {
  let r = `${t.download_id}.${t.extension}`;
  return await G(t, e, r, void 0, [
    "-analyzeduration",
    "10M",
    "-f",
    "dash",
    "-i",
    `jsfetch:${t.url}`,
    "-map",
    "0:a:0",
    "-c:a",
    "libmp3lame",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
async function dr(t, e) {
  let r = `${t.download_id}.${t.extension}`;
  return await G(t, e, r, void 0, [
    "-analyzeduration",
    "1M",
    "-f",
    "dash",
    "-i",
    `jsfetch:${t.url}`,
    "-map",
    `0:${t.entry}`,
    "-t",
    "3",
    "-c",
    "copy",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
var Ze = (function () {
  function t() {
    this.listeners = {};
  }
  var e = t.prototype;
  return (
    (e.on = function (i, n) {
      (this.listeners[i] || (this.listeners[i] = []),
        this.listeners[i].push(n));
    }),
    (e.off = function (i, n) {
      if (!this.listeners[i]) return !1;
      var o = this.listeners[i].indexOf(n);
      return (
        (this.listeners[i] = this.listeners[i].slice(0)),
        this.listeners[i].splice(o, 1),
        o > -1
      );
    }),
    (e.trigger = function (i) {
      var n = this.listeners[i];
      if (n)
        if (arguments.length === 2)
          for (var o = n.length, a = 0; a < o; ++a)
            n[a].call(this, arguments[1]);
        else
          for (
            var s = Array.prototype.slice.call(arguments, 1),
              u = n.length,
              A = 0;
            A < u;
            ++A
          )
            n[A].apply(this, s);
    }),
    (e.dispose = function () {
      this.listeners = {};
    }),
    (e.pipe = function (i) {
      this.on("data", function (n) {
        i.push(n);
      });
    }),
    t
  );
})();
function de() {
  return (
    (de = Object.assign
      ? Object.assign.bind()
      : function (t) {
          for (var e = 1; e < arguments.length; e++) {
            var r = arguments[e];
            for (var i in r) ({}).hasOwnProperty.call(r, i) && (t[i] = r[i]);
          }
          return t;
        }),
    de.apply(null, arguments)
  );
}
var bt = Oi(pr()),
  Xi = function (e) {
    return bt.default.atob
      ? bt.default.atob(e)
      : Buffer.from(e, "base64").toString("binary");
  };
function Et(t) {
  for (var e = Xi(t), r = new Uint8Array(e.length), i = 0; i < e.length; i++)
    r[i] = e.charCodeAt(i);
  return r;
}
var vt = class extends Ze {
    constructor() {
      (super(), (this.buffer = ""));
    }
    push(e) {
      let r;
      for (
        this.buffer += e,
          r = this.buffer.indexOf(`
`);
        r > -1;
        r = this.buffer.indexOf(`
`)
      )
        (this.trigger("data", this.buffer.substring(0, r)),
          (this.buffer = this.buffer.substring(r + 1)));
    }
  },
  Ji = "	",
  It = function (t) {
    let e = /([0-9.]*)?@?([0-9.]*)?/.exec(t || ""),
      r = {};
    return (
      e[1] && (r.length = parseInt(e[1], 10)),
      e[2] && (r.offset = parseInt(e[2], 10)),
      r
    );
  },
  Zi = function () {
    let r = "(?:" + "[^=]*" + ")=(?:" + '"[^"]*"|[^,]*' + ")";
    return new RegExp("(?:^|,)(" + r + ")");
  },
  U = function (t) {
    let e = {};
    if (!t) return e;
    let r = t.split(Zi()),
      i = r.length,
      n;
    for (; i--;)
      r[i] !== "" &&
        ((n = /([^=]*)=(.*)/.exec(r[i]).slice(1)),
        (n[0] = n[0].replace(/^\s+|\s+$/g, "")),
        (n[1] = n[1].replace(/^\s+|\s+$/g, "")),
        (n[1] = n[1].replace(/^['"](.*)['"]$/g, "$1")),
        (e[n[0]] = n[1]));
    return e;
  },
  mr = (t) => {
    let e = t.split("x"),
      r = {};
    return (
      e[0] && (r.width = parseInt(e[0], 10)),
      e[1] && (r.height = parseInt(e[1], 10)),
      r
    );
  },
  Tt = class extends Ze {
    constructor() {
      (super(), (this.customParsers = []), (this.tagMappers = []));
    }
    push(e) {
      let r, i;
      if (((e = e.trim()), e.length === 0)) return;
      if (e[0] !== "#") {
        this.trigger("data", { type: "uri", uri: e });
        return;
      }
      this.tagMappers
        .reduce(
          (o, a) => {
            let s = a(e);
            return s === e ? o : o.concat([s]);
          },
          [e],
        )
        .forEach((o) => {
          for (let a = 0; a < this.customParsers.length; a++)
            if (this.customParsers[a].call(this, o)) return;
          if (o.indexOf("#EXT") !== 0) {
            this.trigger("data", { type: "comment", text: o.slice(1) });
            return;
          }
          if (((o = o.replace("\r", "")), (r = /^#EXTM3U/.exec(o)), r)) {
            this.trigger("data", { type: "tag", tagType: "m3u" });
            return;
          }
          if (((r = /^#EXTINF:([0-9\.]*)?,?(.*)?$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "inf" }),
              r[1] && (i.duration = parseFloat(r[1])),
              r[2] && (i.title = r[2]),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-TARGETDURATION:([0-9.]*)?/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "targetduration" }),
              r[1] && (i.duration = parseInt(r[1], 10)),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-VERSION:([0-9.]*)?/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "version" }),
              r[1] && (i.version = parseInt(r[1], 10)),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-MEDIA-SEQUENCE:(\-?[0-9.]*)?/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "media-sequence" }),
              r[1] && (i.number = parseInt(r[1], 10)),
              this.trigger("data", i));
            return;
          }
          if (
            ((r = /^#EXT-X-DISCONTINUITY-SEQUENCE:(\-?[0-9.]*)?/.exec(o)), r)
          ) {
            ((i = { type: "tag", tagType: "discontinuity-sequence" }),
              r[1] && (i.number = parseInt(r[1], 10)),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-PLAYLIST-TYPE:(.*)?$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "playlist-type" }),
              r[1] && (i.playlistType = r[1]),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-BYTERANGE:(.*)?$/.exec(o)), r)) {
            ((i = de(It(r[1]), { type: "tag", tagType: "byterange" })),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-ALLOW-CACHE:(YES|NO)?/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "allow-cache" }),
              r[1] && (i.allowed = !/NO/.test(r[1])),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-MAP:(.*)$/.exec(o)), r)) {
            if (((i = { type: "tag", tagType: "map" }), r[1])) {
              let a = U(r[1]);
              (a.URI && (i.uri = a.URI),
                a.BYTERANGE && (i.byterange = It(a.BYTERANGE)));
            }
            this.trigger("data", i);
            return;
          }
          if (((r = /^#EXT-X-STREAM-INF:(.*)$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "stream-inf" }),
              r[1] &&
                ((i.attributes = U(r[1])),
                i.attributes.RESOLUTION &&
                  (i.attributes.RESOLUTION = mr(i.attributes.RESOLUTION)),
                i.attributes.BANDWIDTH &&
                  (i.attributes.BANDWIDTH = parseInt(
                    i.attributes.BANDWIDTH,
                    10,
                  )),
                i.attributes["FRAME-RATE"] &&
                  (i.attributes["FRAME-RATE"] = parseFloat(
                    i.attributes["FRAME-RATE"],
                  )),
                i.attributes["PROGRAM-ID"] &&
                  (i.attributes["PROGRAM-ID"] = parseInt(
                    i.attributes["PROGRAM-ID"],
                    10,
                  ))),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-MEDIA:(.*)$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "media" }),
              r[1] && (i.attributes = U(r[1])),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-ENDLIST/.exec(o)), r)) {
            this.trigger("data", { type: "tag", tagType: "endlist" });
            return;
          }
          if (((r = /^#EXT-X-DISCONTINUITY/.exec(o)), r)) {
            this.trigger("data", { type: "tag", tagType: "discontinuity" });
            return;
          }
          if (((r = /^#EXT-X-PROGRAM-DATE-TIME:(.*)$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "program-date-time" }),
              r[1] &&
                ((i.dateTimeString = r[1]),
                (i.dateTimeObject = new Date(r[1]))),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-KEY:(.*)$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "key" }),
              r[1] &&
                ((i.attributes = U(r[1])),
                i.attributes.IV &&
                  (i.attributes.IV.substring(0, 2).toLowerCase() === "0x" &&
                    (i.attributes.IV = i.attributes.IV.substring(2)),
                  (i.attributes.IV = i.attributes.IV.match(/.{8}/g)),
                  (i.attributes.IV[0] = parseInt(i.attributes.IV[0], 16)),
                  (i.attributes.IV[1] = parseInt(i.attributes.IV[1], 16)),
                  (i.attributes.IV[2] = parseInt(i.attributes.IV[2], 16)),
                  (i.attributes.IV[3] = parseInt(i.attributes.IV[3], 16)),
                  (i.attributes.IV = new Uint32Array(i.attributes.IV)))),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-START:(.*)$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "start" }),
              r[1] &&
                ((i.attributes = U(r[1])),
                (i.attributes["TIME-OFFSET"] = parseFloat(
                  i.attributes["TIME-OFFSET"],
                )),
                (i.attributes.PRECISE = /YES/.test(i.attributes.PRECISE))),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-CUE-OUT-CONT:(.*)?$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "cue-out-cont" }),
              r[1] ? (i.data = r[1]) : (i.data = ""),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-CUE-OUT:(.*)?$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "cue-out" }),
              r[1] ? (i.data = r[1]) : (i.data = ""),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-CUE-IN:?(.*)?$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "cue-in" }),
              r[1] ? (i.data = r[1]) : (i.data = ""),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-SKIP:(.*)$/.exec(o)), r && r[1])) {
            ((i = { type: "tag", tagType: "skip" }),
              (i.attributes = U(r[1])),
              i.attributes.hasOwnProperty("SKIPPED-SEGMENTS") &&
                (i.attributes["SKIPPED-SEGMENTS"] = parseInt(
                  i.attributes["SKIPPED-SEGMENTS"],
                  10,
                )),
              i.attributes.hasOwnProperty("RECENTLY-REMOVED-DATERANGES") &&
                (i.attributes["RECENTLY-REMOVED-DATERANGES"] =
                  i.attributes["RECENTLY-REMOVED-DATERANGES"].split(Ji)),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-PART:(.*)$/.exec(o)), r && r[1])) {
            ((i = { type: "tag", tagType: "part" }),
              (i.attributes = U(r[1])),
              ["DURATION"].forEach(function (a) {
                i.attributes.hasOwnProperty(a) &&
                  (i.attributes[a] = parseFloat(i.attributes[a]));
              }),
              ["INDEPENDENT", "GAP"].forEach(function (a) {
                i.attributes.hasOwnProperty(a) &&
                  (i.attributes[a] = /YES/.test(i.attributes[a]));
              }),
              i.attributes.hasOwnProperty("BYTERANGE") &&
                (i.attributes.byterange = It(i.attributes.BYTERANGE)),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-SERVER-CONTROL:(.*)$/.exec(o)), r && r[1])) {
            ((i = { type: "tag", tagType: "server-control" }),
              (i.attributes = U(r[1])),
              ["CAN-SKIP-UNTIL", "PART-HOLD-BACK", "HOLD-BACK"].forEach(
                function (a) {
                  i.attributes.hasOwnProperty(a) &&
                    (i.attributes[a] = parseFloat(i.attributes[a]));
                },
              ),
              ["CAN-SKIP-DATERANGES", "CAN-BLOCK-RELOAD"].forEach(function (a) {
                i.attributes.hasOwnProperty(a) &&
                  (i.attributes[a] = /YES/.test(i.attributes[a]));
              }),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-PART-INF:(.*)$/.exec(o)), r && r[1])) {
            ((i = { type: "tag", tagType: "part-inf" }),
              (i.attributes = U(r[1])),
              ["PART-TARGET"].forEach(function (a) {
                i.attributes.hasOwnProperty(a) &&
                  (i.attributes[a] = parseFloat(i.attributes[a]));
              }),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-PRELOAD-HINT:(.*)$/.exec(o)), r && r[1])) {
            ((i = { type: "tag", tagType: "preload-hint" }),
              (i.attributes = U(r[1])),
              ["BYTERANGE-START", "BYTERANGE-LENGTH"].forEach(function (a) {
                if (i.attributes.hasOwnProperty(a)) {
                  i.attributes[a] = parseInt(i.attributes[a], 10);
                  let s = a === "BYTERANGE-LENGTH" ? "length" : "offset";
                  ((i.attributes.byterange = i.attributes.byterange || {}),
                    (i.attributes.byterange[s] = i.attributes[a]),
                    delete i.attributes[a]);
                }
              }),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-RENDITION-REPORT:(.*)$/.exec(o)), r && r[1])) {
            ((i = { type: "tag", tagType: "rendition-report" }),
              (i.attributes = U(r[1])),
              ["LAST-MSN", "LAST-PART"].forEach(function (a) {
                i.attributes.hasOwnProperty(a) &&
                  (i.attributes[a] = parseInt(i.attributes[a], 10));
              }),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-DATERANGE:(.*)$/.exec(o)), r && r[1])) {
            ((i = { type: "tag", tagType: "daterange" }),
              (i.attributes = U(r[1])),
              ["ID", "CLASS"].forEach(function (s) {
                i.attributes.hasOwnProperty(s) &&
                  (i.attributes[s] = String(i.attributes[s]));
              }),
              ["START-DATE", "END-DATE"].forEach(function (s) {
                i.attributes.hasOwnProperty(s) &&
                  (i.attributes[s] = new Date(i.attributes[s]));
              }),
              ["DURATION", "PLANNED-DURATION"].forEach(function (s) {
                i.attributes.hasOwnProperty(s) &&
                  (i.attributes[s] = parseFloat(i.attributes[s]));
              }),
              ["END-ON-NEXT"].forEach(function (s) {
                i.attributes.hasOwnProperty(s) &&
                  (i.attributes[s] = /YES/i.test(i.attributes[s]));
              }),
              ["SCTE35-CMD", " SCTE35-OUT", "SCTE35-IN"].forEach(function (s) {
                i.attributes.hasOwnProperty(s) &&
                  (i.attributes[s] = i.attributes[s].toString(16));
              }));
            let a = /^X-([A-Z]+-)+[A-Z]+$/;
            for (let s in i.attributes) {
              if (!a.test(s)) continue;
              let u = /[0-9A-Fa-f]{6}/g.test(i.attributes[s]),
                A = /^\d+(\.\d+)?$/.test(i.attributes[s]);
              i.attributes[s] = u
                ? i.attributes[s].toString(16)
                : A
                  ? parseFloat(i.attributes[s])
                  : String(i.attributes[s]);
            }
            this.trigger("data", i);
            return;
          }
          if (((r = /^#EXT-X-INDEPENDENT-SEGMENTS/.exec(o)), r)) {
            this.trigger("data", {
              type: "tag",
              tagType: "independent-segments",
            });
            return;
          }
          if (((r = /^#EXT-X-I-FRAMES-ONLY/.exec(o)), r)) {
            this.trigger("data", { type: "tag", tagType: "i-frames-only" });
            return;
          }
          if (((r = /^#EXT-X-CONTENT-STEERING:(.*)$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "content-steering" }),
              (i.attributes = U(r[1])),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-I-FRAME-STREAM-INF:(.*)$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "i-frame-playlist" }),
              (i.attributes = U(r[1])),
              i.attributes.URI && (i.uri = i.attributes.URI),
              i.attributes.BANDWIDTH &&
                (i.attributes.BANDWIDTH = parseInt(i.attributes.BANDWIDTH, 10)),
              i.attributes.RESOLUTION &&
                (i.attributes.RESOLUTION = mr(i.attributes.RESOLUTION)),
              i.attributes["AVERAGE-BANDWIDTH"] &&
                (i.attributes["AVERAGE-BANDWIDTH"] = parseInt(
                  i.attributes["AVERAGE-BANDWIDTH"],
                  10,
                )),
              i.attributes["FRAME-RATE"] &&
                (i.attributes["FRAME-RATE"] = parseFloat(
                  i.attributes["FRAME-RATE"],
                )),
              this.trigger("data", i));
            return;
          }
          if (((r = /^#EXT-X-DEFINE:(.*)$/.exec(o)), r)) {
            ((i = { type: "tag", tagType: "define" }),
              (i.attributes = U(r[1])),
              this.trigger("data", i));
            return;
          }
          this.trigger("data", { type: "tag", data: o.slice(4) });
        });
    }
    addParser({ expression: e, customType: r, dataParser: i, segment: n }) {
      (typeof i != "function" && (i = (o) => o),
        this.customParsers.push((o) => {
          if (e.exec(o))
            return (
              this.trigger("data", {
                type: "custom",
                data: i(o),
                customType: r,
                segment: n,
              }),
              !0
            );
        }));
    }
    addTagMapper({ expression: e, map: r }) {
      let i = (n) => (e.test(n) ? r(n) : n);
      this.tagMappers.push(i);
    }
  },
  ji = (t) => t.toLowerCase().replace(/-(\w)/g, (e) => e[1].toUpperCase()),
  se = function (t) {
    let e = {};
    return (
      Object.keys(t).forEach(function (r) {
        e[ji(r)] = t[r];
      }),
      e
    );
  },
  Ct = function (t) {
    let { serverControl: e, targetDuration: r, partTargetDuration: i } = t;
    if (!e) return;
    let n = "#EXT-X-SERVER-CONTROL",
      o = "holdBack",
      a = "partHoldBack",
      s = r && r * 3,
      u = i && i * 2;
    (r &&
      !e.hasOwnProperty(o) &&
      ((e[o] = s),
      this.trigger("info", {
        message: `${n} defaulting HOLD-BACK to targetDuration * 3 (${s}).`,
      })),
      s &&
        e[o] < s &&
        (this.trigger("warn", {
          message: `${n} clamping HOLD-BACK (${e[o]}) to targetDuration * 3 (${s})`,
        }),
        (e[o] = s)),
      i &&
        !e.hasOwnProperty(a) &&
        ((e[a] = i * 3),
        this.trigger("info", {
          message: `${n} defaulting PART-HOLD-BACK to partTargetDuration * 3 (${e[a]}).`,
        })),
      i &&
        e[a] < u &&
        (this.trigger("warn", {
          message: `${n} clamping PART-HOLD-BACK (${e[a]}) to partTargetDuration * 2 (${u}).`,
        }),
        (e[a] = u)));
  },
  Oe = class extends Ze {
    constructor(e = {}) {
      (super(),
        (this.lineStream = new vt()),
        (this.parseStream = new Tt()),
        this.lineStream.pipe(this.parseStream),
        (this.mainDefinitions = e.mainDefinitions || {}),
        (this.params = new URL(e.uri, "https://a.com").searchParams),
        (this.lastProgramDateTime = null));
      let r = this,
        i = [],
        n = {},
        o,
        a,
        s = !1,
        u = function () {},
        A = { AUDIO: {}, VIDEO: {}, "CLOSED-CAPTIONS": {}, SUBTITLES: {} },
        l = "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed",
        d = 0;
      this.manifest = {
        allowCache: !0,
        discontinuityStarts: [],
        dateRanges: [],
        iFramePlaylists: [],
        segments: [],
      };
      let f = 0,
        _ = 0,
        h = {};
      (this.on("end", () => {
        n.uri ||
          (!n.parts && !n.preloadHints) ||
          (!n.map && o && (n.map = o),
          !n.key && a && (n.key = a),
          !n.timeline && typeof d == "number" && (n.timeline = d),
          (this.manifest.preloadSegment = n));
      }),
        this.parseStream.on("data", function (c) {
          let g, y;
          if (r.manifest.definitions) {
            for (let p in r.manifest.definitions)
              if (
                (c.uri &&
                  (c.uri = c.uri.replace(`{$${p}}`, r.manifest.definitions[p])),
                c.attributes)
              )
                for (let m in c.attributes)
                  typeof c.attributes[m] == "string" &&
                    (c.attributes[m] = c.attributes[m].replace(
                      `{$${p}}`,
                      r.manifest.definitions[p],
                    ));
          }
          ({
            tag() {
              (
                ({
                  version() {
                    c.version && (this.manifest.version = c.version);
                  },
                  "allow-cache"() {
                    ((this.manifest.allowCache = c.allowed),
                      "allowed" in c ||
                        (this.trigger("info", {
                          message: "defaulting allowCache to YES",
                        }),
                        (this.manifest.allowCache = !0)));
                  },
                  byterange() {
                    let p = {};
                    ("length" in c &&
                      ((n.byterange = p),
                      (p.length = c.length),
                      "offset" in c || (c.offset = f)),
                      "offset" in c &&
                        ((n.byterange = p), (p.offset = c.offset)),
                      (f = p.offset + p.length));
                  },
                  endlist() {
                    this.manifest.endList = !0;
                  },
                  inf() {
                    ("mediaSequence" in this.manifest ||
                      ((this.manifest.mediaSequence = 0),
                      this.trigger("info", {
                        message: "defaulting media sequence to zero",
                      })),
                      "discontinuitySequence" in this.manifest ||
                        ((this.manifest.discontinuitySequence = 0),
                        this.trigger("info", {
                          message: "defaulting discontinuity sequence to zero",
                        })),
                      c.title && (n.title = c.title),
                      c.duration > 0 && (n.duration = c.duration),
                      c.duration === 0 &&
                        ((n.duration = 0.01),
                        this.trigger("info", {
                          message:
                            "updating zero segment duration to a small value",
                        })),
                      (this.manifest.segments = i));
                  },
                  key() {
                    if (!c.attributes) {
                      this.trigger("warn", {
                        message:
                          "ignoring key declaration without attribute list",
                      });
                      return;
                    }
                    if (c.attributes.METHOD === "NONE") {
                      a = null;
                      return;
                    }
                    if (!c.attributes.URI) {
                      this.trigger("warn", {
                        message: "ignoring key declaration without URI",
                      });
                      return;
                    }
                    if (
                      c.attributes.KEYFORMAT ===
                      "com.apple.streamingkeydelivery"
                    ) {
                      ((this.manifest.contentProtection =
                        this.manifest.contentProtection || {}),
                        (this.manifest.contentProtection["com.apple.fps.1_0"] =
                          { attributes: c.attributes }));
                      return;
                    }
                    if (c.attributes.KEYFORMAT === "com.microsoft.playready") {
                      ((this.manifest.contentProtection =
                        this.manifest.contentProtection || {}),
                        (this.manifest.contentProtection[
                          "com.microsoft.playready"
                        ] = { uri: c.attributes.URI }));
                      return;
                    }
                    if (c.attributes.KEYFORMAT === l) {
                      if (
                        [
                          "SAMPLE-AES",
                          "SAMPLE-AES-CTR",
                          "SAMPLE-AES-CENC",
                        ].indexOf(c.attributes.METHOD) === -1
                      ) {
                        this.trigger("warn", {
                          message: "invalid key method provided for Widevine",
                        });
                        return;
                      }
                      if (
                        (c.attributes.METHOD === "SAMPLE-AES-CENC" &&
                          this.trigger("warn", {
                            message:
                              "SAMPLE-AES-CENC is deprecated, please use SAMPLE-AES-CTR instead",
                          }),
                        c.attributes.URI.substring(0, 23) !==
                          "data:text/plain;base64,")
                      ) {
                        this.trigger("warn", {
                          message: "invalid key URI provided for Widevine",
                        });
                        return;
                      }
                      if (!(
                        c.attributes.KEYID &&
                        c.attributes.KEYID.substring(0, 2) === "0x"
                      )) {
                        this.trigger("warn", {
                          message: "invalid key ID provided for Widevine",
                        });
                        return;
                      }
                      ((this.manifest.contentProtection =
                        this.manifest.contentProtection || {}),
                        (this.manifest.contentProtection["com.widevine.alpha"] =
                          {
                            attributes: {
                              schemeIdUri: c.attributes.KEYFORMAT,
                              keyId: c.attributes.KEYID.substring(2),
                            },
                            pssh: Et(c.attributes.URI.split(",")[1]),
                          }));
                      return;
                    }
                    (c.attributes.METHOD ||
                      this.trigger("warn", {
                        message: "defaulting key method to AES-128",
                      }),
                      (a = {
                        method: c.attributes.METHOD || "AES-128",
                        uri: c.attributes.URI,
                      }),
                      typeof c.attributes.IV < "u" && (a.iv = c.attributes.IV));
                  },
                  "media-sequence"() {
                    if (!isFinite(c.number)) {
                      this.trigger("warn", {
                        message: "ignoring invalid media sequence: " + c.number,
                      });
                      return;
                    }
                    this.manifest.mediaSequence = c.number;
                  },
                  "discontinuity-sequence"() {
                    if (!isFinite(c.number)) {
                      this.trigger("warn", {
                        message:
                          "ignoring invalid discontinuity sequence: " +
                          c.number,
                      });
                      return;
                    }
                    ((this.manifest.discontinuitySequence = c.number),
                      (d = c.number));
                  },
                  "playlist-type"() {
                    if (!/VOD|EVENT/.test(c.playlistType)) {
                      this.trigger("warn", {
                        message:
                          "ignoring unknown playlist type: " + c.playlist,
                      });
                      return;
                    }
                    this.manifest.playlistType = c.playlistType;
                  },
                  map() {
                    ((o = {}),
                      c.uri && (o.uri = c.uri),
                      c.byterange && (o.byterange = c.byterange),
                      a && (o.key = a));
                  },
                  "stream-inf"() {
                    if (
                      ((this.manifest.playlists = i),
                      (this.manifest.mediaGroups =
                        this.manifest.mediaGroups || A),
                      !c.attributes)
                    ) {
                      this.trigger("warn", {
                        message: "ignoring empty stream-inf attributes",
                      });
                      return;
                    }
                    (n.attributes || (n.attributes = {}),
                      de(n.attributes, c.attributes));
                  },
                  media() {
                    if (
                      ((this.manifest.mediaGroups =
                        this.manifest.mediaGroups || A),
                      !(
                        c.attributes &&
                        c.attributes.TYPE &&
                        c.attributes["GROUP-ID"] &&
                        c.attributes.NAME
                      ))
                    ) {
                      this.trigger("warn", {
                        message: "ignoring incomplete or missing media group",
                      });
                      return;
                    }
                    let p = this.manifest.mediaGroups[c.attributes.TYPE];
                    ((p[c.attributes["GROUP-ID"]] =
                      p[c.attributes["GROUP-ID"]] || {}),
                      (g = p[c.attributes["GROUP-ID"]]),
                      (y = { default: /yes/i.test(c.attributes.DEFAULT) }),
                      y.default
                        ? (y.autoselect = !0)
                        : (y.autoselect = /yes/i.test(c.attributes.AUTOSELECT)),
                      c.attributes.LANGUAGE &&
                        (y.language = c.attributes.LANGUAGE),
                      c.attributes.URI && (y.uri = c.attributes.URI),
                      c.attributes["INSTREAM-ID"] &&
                        (y.instreamId = c.attributes["INSTREAM-ID"]),
                      c.attributes.CHARACTERISTICS &&
                        (y.characteristics = c.attributes.CHARACTERISTICS),
                      c.attributes.FORCED &&
                        (y.forced = /yes/i.test(c.attributes.FORCED)),
                      (g[c.attributes.NAME] = y));
                  },
                  discontinuity() {
                    ((d += 1),
                      (n.discontinuity = !0),
                      this.manifest.discontinuityStarts.push(i.length));
                  },
                  "program-date-time"() {
                    (typeof this.manifest.dateTimeString > "u" &&
                      ((this.manifest.dateTimeString = c.dateTimeString),
                      (this.manifest.dateTimeObject = c.dateTimeObject)),
                      (n.dateTimeString = c.dateTimeString),
                      (n.dateTimeObject = c.dateTimeObject));
                    let { lastProgramDateTime: p } = this;
                    ((this.lastProgramDateTime = new Date(
                      c.dateTimeString,
                    ).getTime()),
                      p === null &&
                        this.manifest.segments.reduceRight(
                          (m, w) => (
                            (w.programDateTime = m - w.duration * 1e3),
                            w.programDateTime
                          ),
                          this.lastProgramDateTime,
                        ));
                  },
                  targetduration() {
                    if (!isFinite(c.duration) || c.duration < 0) {
                      this.trigger("warn", {
                        message:
                          "ignoring invalid target duration: " + c.duration,
                      });
                      return;
                    }
                    ((this.manifest.targetDuration = c.duration),
                      Ct.call(this, this.manifest));
                  },
                  start() {
                    if (!c.attributes || isNaN(c.attributes["TIME-OFFSET"])) {
                      this.trigger("warn", {
                        message:
                          "ignoring start declaration without appropriate attribute list",
                      });
                      return;
                    }
                    this.manifest.start = {
                      timeOffset: c.attributes["TIME-OFFSET"],
                      precise: c.attributes.PRECISE,
                    };
                  },
                  "cue-out"() {
                    n.cueOut = c.data;
                  },
                  "cue-out-cont"() {
                    n.cueOutCont = c.data;
                  },
                  "cue-in"() {
                    n.cueIn = c.data;
                  },
                  skip() {
                    ((this.manifest.skip = se(c.attributes)),
                      this.warnOnMissingAttributes_(
                        "#EXT-X-SKIP",
                        c.attributes,
                        ["SKIPPED-SEGMENTS"],
                      ));
                  },
                  part() {
                    s = !0;
                    let p = this.manifest.segments.length,
                      m = se(c.attributes);
                    ((n.parts = n.parts || []),
                      n.parts.push(m),
                      m.byterange &&
                        (m.byterange.hasOwnProperty("offset") ||
                          (m.byterange.offset = _),
                        (_ = m.byterange.offset + m.byterange.length)));
                    let w = n.parts.length - 1;
                    (this.warnOnMissingAttributes_(
                      `#EXT-X-PART #${w} for segment #${p}`,
                      c.attributes,
                      ["URI", "DURATION"],
                    ),
                      this.manifest.renditionReports &&
                        this.manifest.renditionReports.forEach((T, E) => {
                          T.hasOwnProperty("lastPart") ||
                            this.trigger("warn", {
                              message: `#EXT-X-RENDITION-REPORT #${E} lacks required attribute(s): LAST-PART`,
                            });
                        }));
                  },
                  "server-control"() {
                    let p = (this.manifest.serverControl = se(c.attributes));
                    (p.hasOwnProperty("canBlockReload") ||
                      ((p.canBlockReload = !1),
                      this.trigger("info", {
                        message:
                          "#EXT-X-SERVER-CONTROL defaulting CAN-BLOCK-RELOAD to false",
                      })),
                      Ct.call(this, this.manifest),
                      p.canSkipDateranges &&
                        !p.hasOwnProperty("canSkipUntil") &&
                        this.trigger("warn", {
                          message:
                            "#EXT-X-SERVER-CONTROL lacks required attribute CAN-SKIP-UNTIL which is required when CAN-SKIP-DATERANGES is set",
                        }));
                  },
                  "preload-hint"() {
                    let p = this.manifest.segments.length,
                      m = se(c.attributes),
                      w = m.type && m.type === "PART";
                    ((n.preloadHints = n.preloadHints || []),
                      n.preloadHints.push(m),
                      m.byterange &&
                        (m.byterange.hasOwnProperty("offset") ||
                          ((m.byterange.offset = w ? _ : 0),
                          w && (_ = m.byterange.offset + m.byterange.length))));
                    let T = n.preloadHints.length - 1;
                    if (
                      (this.warnOnMissingAttributes_(
                        `#EXT-X-PRELOAD-HINT #${T} for segment #${p}`,
                        c.attributes,
                        ["TYPE", "URI"],
                      ),
                      !!m.type)
                    )
                      for (let E = 0; E < n.preloadHints.length - 1; E++) {
                        let S = n.preloadHints[E];
                        S.type &&
                          S.type === m.type &&
                          this.trigger("warn", {
                            message: `#EXT-X-PRELOAD-HINT #${T} for segment #${p} has the same TYPE ${m.type} as preload hint #${E}`,
                          });
                      }
                  },
                  "rendition-report"() {
                    let p = se(c.attributes);
                    ((this.manifest.renditionReports =
                      this.manifest.renditionReports || []),
                      this.manifest.renditionReports.push(p));
                    let m = this.manifest.renditionReports.length - 1,
                      w = ["LAST-MSN", "URI"];
                    (s && w.push("LAST-PART"),
                      this.warnOnMissingAttributes_(
                        `#EXT-X-RENDITION-REPORT #${m}`,
                        c.attributes,
                        w,
                      ));
                  },
                  "part-inf"() {
                    ((this.manifest.partInf = se(c.attributes)),
                      this.warnOnMissingAttributes_(
                        "#EXT-X-PART-INF",
                        c.attributes,
                        ["PART-TARGET"],
                      ),
                      this.manifest.partInf.partTarget &&
                        (this.manifest.partTargetDuration =
                          this.manifest.partInf.partTarget),
                      Ct.call(this, this.manifest));
                  },
                  daterange() {
                    this.manifest.dateRanges.push(se(c.attributes));
                    let p = this.manifest.dateRanges.length - 1;
                    this.warnOnMissingAttributes_(
                      `#EXT-X-DATERANGE #${p}`,
                      c.attributes,
                      ["ID", "START-DATE"],
                    );
                    let m = this.manifest.dateRanges[p];
                    (m.endDate &&
                      m.startDate &&
                      new Date(m.endDate) < new Date(m.startDate) &&
                      this.trigger("warn", {
                        message:
                          "EXT-X-DATERANGE END-DATE must be equal to or later than the value of the START-DATE",
                      }),
                      m.duration &&
                        m.duration < 0 &&
                        this.trigger("warn", {
                          message:
                            "EXT-X-DATERANGE DURATION must not be negative",
                        }),
                      m.plannedDuration &&
                        m.plannedDuration < 0 &&
                        this.trigger("warn", {
                          message:
                            "EXT-X-DATERANGE PLANNED-DURATION must not be negative",
                        }));
                    let w = !!m.endOnNext;
                    if (
                      (w &&
                        !m.class &&
                        this.trigger("warn", {
                          message:
                            "EXT-X-DATERANGE with an END-ON-NEXT=YES attribute must have a CLASS attribute",
                        }),
                      w &&
                        (m.duration || m.endDate) &&
                        this.trigger("warn", {
                          message:
                            "EXT-X-DATERANGE with an END-ON-NEXT=YES attribute must not contain DURATION or END-DATE attributes",
                        }),
                      m.duration && m.endDate)
                    ) {
                      let E = m.startDate.getTime() + m.duration * 1e3;
                      this.manifest.dateRanges[p].endDate = new Date(E);
                    }
                    if (!h[m.id]) h[m.id] = m;
                    else {
                      for (let E in h[m.id])
                        if (
                          m[E] &&
                          JSON.stringify(h[m.id][E]) !== JSON.stringify(m[E])
                        ) {
                          this.trigger("warn", {
                            message:
                              "EXT-X-DATERANGE tags with the same ID in a playlist must have the same attributes values",
                          });
                          break;
                        }
                      let T = this.manifest.dateRanges.findIndex(
                        (E) => E.id === m.id,
                      );
                      ((this.manifest.dateRanges[T] = de(
                        this.manifest.dateRanges[T],
                        m,
                      )),
                        (h[m.id] = de(h[m.id], m)),
                        this.manifest.dateRanges.pop());
                    }
                  },
                  "independent-segments"() {
                    this.manifest.independentSegments = !0;
                  },
                  "i-frames-only"() {
                    ((this.manifest.iFramesOnly = !0),
                      this.requiredCompatibilityversion(
                        this.manifest.version,
                        4,
                      ));
                  },
                  "content-steering"() {
                    ((this.manifest.contentSteering = se(c.attributes)),
                      this.warnOnMissingAttributes_(
                        "#EXT-X-CONTENT-STEERING",
                        c.attributes,
                        ["SERVER-URI"],
                      ));
                  },
                  define() {
                    this.manifest.definitions = this.manifest.definitions || {};
                    let p = (m, w) => {
                      if (m in this.manifest.definitions) {
                        this.trigger("error", {
                          message: `EXT-X-DEFINE: Duplicate name ${m}`,
                        });
                        return;
                      }
                      this.manifest.definitions[m] = w;
                    };
                    if ("QUERYPARAM" in c.attributes) {
                      if ("NAME" in c.attributes || "IMPORT" in c.attributes) {
                        this.trigger("error", {
                          message: "EXT-X-DEFINE: Invalid attributes",
                        });
                        return;
                      }
                      let m = this.params.get(c.attributes.QUERYPARAM);
                      if (!m) {
                        this.trigger("error", {
                          message: `EXT-X-DEFINE: No query param ${c.attributes.QUERYPARAM}`,
                        });
                        return;
                      }
                      p(c.attributes.QUERYPARAM, decodeURIComponent(m));
                      return;
                    }
                    if ("NAME" in c.attributes) {
                      if ("IMPORT" in c.attributes) {
                        this.trigger("error", {
                          message: "EXT-X-DEFINE: Invalid attributes",
                        });
                        return;
                      }
                      if (
                        !("VALUE" in c.attributes) ||
                        typeof c.attributes.VALUE != "string"
                      ) {
                        this.trigger("error", {
                          message: `EXT-X-DEFINE: No value for ${c.attributes.NAME}`,
                        });
                        return;
                      }
                      p(c.attributes.NAME, c.attributes.VALUE);
                      return;
                    }
                    if ("IMPORT" in c.attributes) {
                      if (!this.mainDefinitions[c.attributes.IMPORT]) {
                        this.trigger("error", {
                          message: `EXT-X-DEFINE: No value ${c.attributes.IMPORT} to import, or IMPORT used on main playlist`,
                        });
                        return;
                      }
                      p(
                        c.attributes.IMPORT,
                        this.mainDefinitions[c.attributes.IMPORT],
                      );
                      return;
                    }
                    this.trigger("error", {
                      message: "EXT-X-DEFINE: No attribute",
                    });
                  },
                  "i-frame-playlist"() {
                    (this.manifest.iFramePlaylists.push({
                      attributes: c.attributes,
                      uri: c.uri,
                      timeline: d,
                    }),
                      this.warnOnMissingAttributes_(
                        "#EXT-X-I-FRAME-STREAM-INF",
                        c.attributes,
                        ["BANDWIDTH", "URI"],
                      ));
                  },
                })[c.tagType] || u
              ).call(r);
            },
            uri() {
              ((n.uri = c.uri),
                i.push(n),
                this.manifest.targetDuration &&
                  !("duration" in n) &&
                  (this.trigger("warn", {
                    message:
                      "defaulting segment duration to the target duration",
                  }),
                  (n.duration = this.manifest.targetDuration)),
                a && (n.key = a),
                (n.timeline = d),
                o && (n.map = o),
                (_ = 0),
                this.lastProgramDateTime !== null &&
                  ((n.programDateTime = this.lastProgramDateTime),
                  (this.lastProgramDateTime += n.duration * 1e3)),
                (n = {}));
            },
            comment() {},
            custom() {
              c.segment
                ? ((n.custom = n.custom || {}),
                  (n.custom[c.customType] = c.data))
                : ((this.manifest.custom = this.manifest.custom || {}),
                  (this.manifest.custom[c.customType] = c.data));
            },
          })[c.type].call(r);
        }));
    }
    requiredCompatibilityversion(e, r) {
      (e < r || !e) &&
        this.trigger("warn", {
          message: `manifest must be at least version ${r}`,
        });
    }
    warnOnMissingAttributes_(e, r, i) {
      let n = [];
      (i.forEach(function (o) {
        r.hasOwnProperty(o) || n.push(o);
      }),
        n.length &&
          this.trigger("warn", {
            message: `${e} lacks required attribute(s): ${n.join(", ")}`,
          }));
    }
    push(e) {
      this.lineStream.push(e);
    }
    end() {
      (this.lineStream.push(`
`),
        this.manifest.dateRanges.length &&
          this.lastProgramDateTime === null &&
          this.trigger("warn", {
            message:
              "A playlist with EXT-X-DATERANGE tag must contain atleast one EXT-X-PROGRAM-DATE-TIME tag",
          }),
        (this.lastProgramDateTime = null),
        this.trigger("end"));
    }
    addParser(e) {
      this.parseStream.addParser(e);
    }
    addTagMapper(e) {
      this.parseStream.addTagMapper(e);
    }
  };
var Vl = new Error("timeout while waiting for mutex to become available"),
  Nl = new Error("mutex already locked"),
  zi = new Error("request for lock canceled"),
  qi = function (t, e, r, i) {
    function n(o) {
      return o instanceof r
        ? o
        : new r(function (a) {
            a(o);
          });
    }
    return new (r || (r = Promise))(function (o, a) {
      function s(l) {
        try {
          A(i.next(l));
        } catch (d) {
          a(d);
        }
      }
      function u(l) {
        try {
          A(i.throw(l));
        } catch (d) {
          a(d);
        }
      }
      function A(l) {
        l.done ? o(l.value) : n(l.value).then(s, u);
      }
      A((i = i.apply(t, e || [])).next());
    });
  },
  je = class {
    constructor(e, r = zi) {
      ((this._value = e),
        (this._cancelError = r),
        (this._queue = []),
        (this._weightedWaiters = []));
    }
    acquire(e = 1, r = 0) {
      if (e <= 0) throw new Error(`invalid weight ${e}: must be positive`);
      return new Promise((i, n) => {
        let o = { resolve: i, reject: n, weight: e, priority: r },
          a = _r(this._queue, (s) => r <= s.priority);
        a === -1 && e <= this._value
          ? this._dispatchItem(o)
          : this._queue.splice(a + 1, 0, o);
      });
    }
    runExclusive(e) {
      return qi(this, arguments, void 0, function* (r, i = 1, n = 0) {
        let [o, a] = yield this.acquire(i, n);
        try {
          return yield r(o);
        } finally {
          a();
        }
      });
    }
    waitForUnlock(e = 1, r = 0) {
      if (e <= 0) throw new Error(`invalid weight ${e}: must be positive`);
      return this._couldLockImmediately(e, r)
        ? Promise.resolve()
        : new Promise((i) => {
            (this._weightedWaiters[e - 1] ||
              (this._weightedWaiters[e - 1] = []),
              $i(this._weightedWaiters[e - 1], { resolve: i, priority: r }));
          });
    }
    isLocked() {
      return this._value <= 0;
    }
    getValue() {
      return this._value;
    }
    setValue(e) {
      ((this._value = e), this._dispatchQueue());
    }
    release(e = 1) {
      if (e <= 0) throw new Error(`invalid weight ${e}: must be positive`);
      ((this._value += e), this._dispatchQueue());
    }
    cancel() {
      (this._queue.forEach((e) => e.reject(this._cancelError)),
        (this._queue = []));
    }
    _dispatchQueue() {
      for (
        this._drainUnlockWaiters();
        this._queue.length > 0 && this._queue[0].weight <= this._value;
      )
        (this._dispatchItem(this._queue.shift()), this._drainUnlockWaiters());
    }
    _dispatchItem(e) {
      let r = this._value;
      ((this._value -= e.weight), e.resolve([r, this._newReleaser(e.weight)]));
    }
    _newReleaser(e) {
      let r = !1;
      return () => {
        r || ((r = !0), this.release(e));
      };
    }
    _drainUnlockWaiters() {
      if (this._queue.length === 0)
        for (let e = this._value; e > 0; e--) {
          let r = this._weightedWaiters[e - 1];
          r &&
            (r.forEach((i) => i.resolve()),
            (this._weightedWaiters[e - 1] = []));
        }
      else {
        let e = this._queue[0].priority;
        for (let r = this._value; r > 0; r--) {
          let i = this._weightedWaiters[r - 1];
          if (!i) continue;
          let n = i.findIndex((o) => o.priority <= e);
          (n === -1 ? i : i.splice(0, n)).forEach((o) => o.resolve());
        }
      }
    }
    _couldLockImmediately(e, r) {
      return (
        (this._queue.length === 0 || this._queue[0].priority < r) &&
        e <= this._value
      );
    }
  };
function $i(t, e) {
  let r = _r(t, (i) => e.priority <= i.priority);
  t.splice(r + 1, 0, e);
}
function _r(t, e) {
  for (let r = t.length - 1; r >= 0; r--) if (e(t[r])) return r;
  return -1;
}
function J(t, e) {
  let r = (BigInt(e) << BigInt(32)) | BigInt(t);
  return BigInt(r);
}
function ze(t) {
  let e = Number(t & 0xffffffffn),
    r = Number(t >> 32n);
  return { lo: e, hi: r };
}
function hr(t) {
  let e, r;
  return (
    t.av.audio && t.av.audio.packets.length && (e = t.av.audio.packets[0]),
    t.av.video && t.av.video.packets.length && (r = t.av.video.packets[0]),
    !e || !r ? !1 : yr(e, r)
  );
}
function gr(t, e) {
  let r, i;
  return (
    t.av.audio && t.av.audio.packets.length && (r = t.av.audio.packets[0]),
    e.av.video && e.av.video.packets.length && (i = e.av.video.packets[0]),
    !r || !i ? !1 : yr(r, i)
  );
}
function yr(t, e) {
  if (
    !t.time_base_num ||
    !t.time_base_den ||
    !e.time_base_num ||
    !e.time_base_den
  )
    return !1;
  let r = J(t.pts, t.ptshi),
    i = J(t.duration, t.durationhi),
    n = J(e.pts, e.ptshi),
    o = J(e.duration, e.durationhi);
  if (i == 0n || o == 0n) return !1;
  let a = 250000000n,
    s = 1000000000n,
    u = (r * BigInt(t.time_base_num) * s) / BigInt(t.time_base_den),
    A = (n * BigInt(e.time_base_num) * s) / BigInt(e.time_base_den),
    l = u - A;
  return (l < 0 ? -l : l) > a;
}
function be(t) {
  let e = t[0];
  if (J(e.pts, e.ptshi) == 0n) return Ae(t);
  let i = 0n,
    n = 0n;
  ((e.dts = 0), (e.dtshi = 0), (e.pts = 0), (e.ptshi = 0));
  let o = J(e.duration, e.durationhi);
  for (let a = 1; a < t.length; ++a) {
    let s = t[a],
      u = i + o,
      A = n + o;
    ((i = u), (n = A), (o = J(s.duration, s.durationhi)));
    let { lo: l, hi: d } = ze(u),
      { lo: f, hi: _ } = ze(A);
    ((s.dts = l), (s.dtshi = d), (s.pts = f), (s.ptshi = _));
  }
  return {
    last_dts: i,
    last_pts: n,
    last_duration: o,
    force_recompute_timings: !0,
  };
}
function Ae(t) {
  let e = t.length - 1,
    r = t[e].dts,
    i = t[e].dtshi || 0,
    n = J(r, i),
    o = t[e].pts,
    a = t[e].ptshi || 0,
    s = J(o, a),
    u = J(t[e].duration, t[e].durationhi);
  return { last_dts: n, last_pts: s, last_duration: u };
}
function Ee(t, e) {
  let { last_dts: r, last_pts: i, last_duration: n } = e,
    o = t[0],
    a = J(o.dts, o.dtshi || 0),
    s = J(o.pts, o.ptshi || 0);
  if ((!e.force_recompute_timings && a > r && s > i) || n == 0n) return Ae(t);
  for (let u of t) {
    let A = r + n,
      l = i + n;
    ((r = A), (i = l), (n = J(u.duration, u.durationhi)));
    let { lo: d, hi: f } = ze(A),
      { lo: _, hi: h } = ze(l);
    ((u.dts = d), (u.dtshi = f), (u.pts = _), (u.ptshi = h));
  }
  return {
    last_dts: r,
    last_pts: i,
    last_duration: n,
    force_recompute_timings: e.force_recompute_timings,
  };
}
async function wr(t, e, r) {
  if (r.length !== 16) throw new Error("IV must be 16 bytes (128 bits).");
  if (e.length !== 16) throw new Error("Key must be 16 bytes (128 bits).");
  try {
    let i = await crypto.subtle.importKey("raw", e, { name: "AES-CBC" }, !1, [
        "decrypt",
      ]),
      n = await crypto.subtle.decrypt({ name: "AES-CBC", iv: r }, i, t);
    return v(new Uint8Array(n));
  } catch {
    return C({ type: "decryption_failed" });
  }
}
var qe = class {
  constructor() {
    this.map = new Map();
  }
  getInitKey(e) {
    return e.byte_range
      ? `${e.url}-${e.byte_range.offset}-${e.byte_range.length}`
      : `${e.url}`;
  }
  has(e) {
    return this.map.has(this.getInitKey(e));
  }
  set(e, r) {
    return this.map.set(this.getInitKey(e), r);
  }
  get(e) {
    return this.map.get(this.getInitKey(e));
  }
};
var br = 3e4;
async function ie(...t) {
  let e;
  try {
    e = await fetch(...t);
  } catch (r) {
    return r instanceof DOMException && r.name == "AbortError"
      ? C(ce())
      : C(F(r.toString()));
  }
  return e.status >= 400 && e.status <= 599
    ? C(Je(e.status))
    : e.ok
      ? e.body != null
        ? v(e)
        : C(F("No body"))
      : C(F(`Unkown failure - status ${e.status}`));
}
async function fe(t) {
  try {
    let e,
      r = new Promise((n) => {
        e = setTimeout(() => {
          n(C(F("Timeout")));
        }, br);
      }),
      i = t.read().then((n) => (clearTimeout(e), v(n)));
    return await Promise.race([r, i]);
  } catch (e) {
    return e instanceof DOMException && e.name == "AbortError"
      ? C(ce())
      : C(F(e.toString()));
  }
}
async function Er(t) {
  try {
    let e = new Promise((i) => setTimeout(() => i(C(F("Timeout"))), br)),
      r = t.text().then((i) => v(i));
    return await Promise.race([e, r]);
  } catch (e) {
    return e instanceof DOMException && e.name == "AbortError"
      ? C(ce())
      : C(F(e.toString()));
  }
}
var Z = { Audio: 0, Video: 1 };
var tn = ["mp4", "webm", "mkv"],
  rn = ["mp3", "m4a", "ogg"],
  nn = [...tn, ...rn];
var Ir = [
    "am",
    "ar",
    "ar-EG",
    "ar-SA",
    "ar-MA",
    "ha",
    "he",
    "mt",
    "om",
    "so",
    "ti",
    "ceb",
    "fil",
    "id",
    "jv",
    "mg",
    "mi",
    "ms",
    "haw",
    "sm",
    "su",
    "to",
    "kn",
    "ml",
    "ta",
    "te",
    "af",
    "da",
    "de",
    "de-AT",
    "de-CH",
    "en",
    "en-AU",
    "en-CA",
    "en-GB",
    "en-IE",
    "en-IN",
    "en-NZ",
    "en-US",
    "en-ZA",
    "fy",
    "is",
    "lb",
    "nb",
    "nl",
    "nl-BE",
    "nn",
    "sv",
    "yi",
    "as",
    "bn",
    "bn-IN",
    "fa",
    "fa-AF",
    "gu",
    "hi",
    "ks",
    "ku",
    "mr",
    "ne",
    "or",
    "pa",
    "ps",
    "sd",
    "si",
    "tg",
    "ur",
    "ca",
    "co",
    "es",
    "es-419",
    "es-PE",
    "es-CR",
    "es-HN",
    "es-AR",
    "es-CL",
    "es-CO",
    "es-ES",
    "es-MX",
    "fr",
    "fr-BE",
    "fr-CA",
    "fr-CH",
    "gl",
    "ht",
    "it",
    "it-CH",
    "oc",
    "pt",
    "pt-BR",
    "pt-PT",
    "rm",
    "ro",
    "sc",
    "wa",
    "br",
    "cy",
    "ga",
    "gd",
    "gv",
    "kw",
    "be",
    "bg",
    "bs",
    "cs",
    "hr",
    "mk",
    "pl",
    "ru",
    "sk",
    "sl",
    "sr-Cyrl",
    "sr-Latn",
    "uk",
    "lt",
    "lv",
    "et",
    "fi",
    "hu",
    "se",
    "az",
    "az-Latn",
    "az-Cyrl",
    "ba",
    "cv",
    "kk",
    "ky",
    "tk",
    "tr",
    "tt",
    "ug",
    "uz",
    "uz-Latn",
    "uz-Cyrl",
    "mn",
    "mn-Cyrl",
    "mn-Mong",
    "bo",
    "dz",
    "my",
    "yue",
    "zh",
    "zh-Hans",
    "zh-CN",
    "zh-SG",
    "zh-Hant",
    "zh-HK",
    "zh-TW",
    "ja",
    "ko",
    "km",
    "lo",
    "th",
    "vi",
    "hy",
    "ka",
    "ak",
    "ee",
    "ig",
    "kg",
    "ki",
    "ln",
    "lg",
    "nd",
    "ny",
    "rn",
    "rw",
    "sn",
    "st",
    "sw",
    "tn",
    "ts",
    "tw",
    "wo",
    "xh",
    "yo",
    "zu",
    "lu",
    "el",
    "sq",
    "eu",
    "ay",
    "gn",
    "nv",
    "qu",
    "mul",
  ],
  iu = new Set(Ir),
  sn = new Map([
    ["af", "afr"],
    ["ak", "aka"],
    ["am", "amh"],
    ["ar", "ara"],
    ["as", "asm"],
    ["ay", "aym"],
    ["az", "aze"],
    ["ba", "bak"],
    ["be", "bel"],
    ["bg", "bul"],
    ["bn", "ben"],
    ["bo", "bod"],
    ["br", "bre"],
    ["bs", "bos"],
    ["ca", "cat"],
    ["co", "cos"],
    ["cs", "ces"],
    ["cv", "chv"],
    ["cy", "cym"],
    ["da", "dan"],
    ["de", "deu"],
    ["dz", "dzo"],
    ["ee", "ewe"],
    ["el", "ell"],
    ["en", "eng"],
    ["es", "spa"],
    ["et", "est"],
    ["eu", "eus"],
    ["fa", "fas"],
    ["fi", "fin"],
    ["fr", "fra"],
    ["fy", "fry"],
    ["ga", "gle"],
    ["gd", "gla"],
    ["gl", "glg"],
    ["gn", "grn"],
    ["gu", "guj"],
    ["gv", "glv"],
    ["ha", "hau"],
    ["he", "heb"],
    ["hi", "hin"],
    ["hr", "hrv"],
    ["ht", "hat"],
    ["hu", "hun"],
    ["hy", "hye"],
    ["id", "ind"],
    ["ig", "ibo"],
    ["is", "isl"],
    ["it", "ita"],
    ["ja", "jpn"],
    ["jv", "jav"],
    ["ka", "kat"],
    ["kg", "kon"],
    ["ki", "kik"],
    ["kk", "kaz"],
    ["km", "khm"],
    ["kn", "kan"],
    ["ko", "kor"],
    ["ks", "kas"],
    ["ku", "kur"],
    ["kw", "cor"],
    ["ky", "kir"],
    ["lb", "ltz"],
    ["lg", "lug"],
    ["ln", "lin"],
    ["lo", "lao"],
    ["lt", "lit"],
    ["lu", "lub"],
    ["lv", "lav"],
    ["mg", "mlg"],
    ["mi", "mri"],
    ["mk", "mkd"],
    ["ml", "mal"],
    ["mn", "mon"],
    ["mr", "mar"],
    ["ms", "msa"],
    ["mt", "mlt"],
    ["my", "mya"],
    ["nb", "nob"],
    ["nd", "nde"],
    ["ne", "nep"],
    ["nl", "nld"],
    ["nn", "nno"],
    ["ny", "nya"],
    ["oc", "oci"],
    ["om", "orm"],
    ["or", "ori"],
    ["pa", "pan"],
    ["pl", "pol"],
    ["ps", "pus"],
    ["pt", "por"],
    ["qu", "que"],
    ["rm", "roh"],
    ["rn", "run"],
    ["ro", "ron"],
    ["ru", "rus"],
    ["rw", "kin"],
    ["sc", "srd"],
    ["sd", "snd"],
    ["se", "sme"],
    ["si", "sin"],
    ["sk", "slk"],
    ["sl", "slv"],
    ["sm", "smo"],
    ["sn", "sna"],
    ["so", "som"],
    ["sq", "sqi"],
    ["st", "sot"],
    ["su", "sun"],
    ["sv", "swe"],
    ["sw", "swa"],
    ["ta", "tam"],
    ["te", "tel"],
    ["tg", "tgk"],
    ["th", "tha"],
    ["ti", "tir"],
    ["tk", "tuk"],
    ["tn", "tsn"],
    ["to", "ton"],
    ["tr", "tur"],
    ["ts", "tso"],
    ["tt", "tat"],
    ["tw", "twi"],
    ["ug", "uig"],
    ["uk", "ukr"],
    ["ur", "urd"],
    ["uz", "uzb"],
    ["vi", "vie"],
    ["wa", "wln"],
    ["wo", "wol"],
    ["xh", "xho"],
    ["yi", "yid"],
    ["yo", "yor"],
    ["zh", "zho"],
    ["zu", "zul"],
    ["ceb", "ceb"],
    ["fil", "fil"],
    ["haw", "haw"],
    ["yue", "yue"],
    ["ar-EG", "ara"],
    ["ar-SA", "ara"],
    ["ar-MA", "ara"],
    ["bn-IN", "ben"],
    ["de-AT", "deu"],
    ["de-CH", "deu"],
    ["en-AU", "eng"],
    ["en-CA", "eng"],
    ["en-GB", "eng"],
    ["en-IE", "eng"],
    ["en-IN", "eng"],
    ["en-NZ", "eng"],
    ["en-US", "eng"],
    ["en-ZA", "eng"],
    ["es-419", "spa"],
    ["es-AR", "spa"],
    ["es-CL", "spa"],
    ["es-PE", "spa"],
    ["es-CR", "spa"],
    ["es-HN", "spa"],
    ["es-CO", "spa"],
    ["es-ES", "spa"],
    ["es-MX", "spa"],
    ["fa-AF", "fas"],
    ["fr-BE", "fra"],
    ["fr-CA", "fra"],
    ["fr-CH", "fra"],
    ["it-CH", "ita"],
    ["nl-BE", "nld"],
    ["pt-BR", "por"],
    ["pt-PT", "por"],
    ["az-Latn", "aze"],
    ["az-Cyrl", "aze"],
    ["mn-Cyrl", "mon"],
    ["mn-Mong", "mon"],
    ["sr-Cyrl", "srp"],
    ["sr-Latn", "srp"],
    ["uz-Latn", "uzb"],
    ["uz-Cyrl", "uzb"],
    ["zh-Hans", "zho"],
    ["zh-CN", "zho"],
    ["zh-SG", "zho"],
    ["zh-Hant", "zho"],
    ["zh-HK", "zho"],
    ["zh-TW", "zho"],
    ["mul", "mul"],
  ]);
function Cr(t) {
  let e = t.toLowerCase().split("-")[0];
  return sn.get(e) ?? "und";
}
var nu = (() => {
  let t = (e) => {
    try {
      return (
        new Intl.DisplayNames([navigator.language], {
          type: "language",
          fallback: "none",
        }).of(e) ?? e
      );
    } catch {
      return e;
    }
  };
  return new Map(
    Ir.map((e) => ({ code: e, native_name: t(e) }))
      .sort((e, r) => e.native_name.localeCompare(r.native_name))
      .map((e) => [e.code, e]),
  );
})();
function vr(t) {
  let e = new Date(new Date().getTime() - 6e5);
  return !t.dateTimeObject && !t.programDateTime
    ? !1
    : typeof t.dateTimeObject == "object"
      ? t.dateTimeObject > e
      : typeof t.programDateTime == "number"
        ? t.programDateTime > e.getTime()
        : !1;
}
var An = 0.35,
  et = 5,
  ln = 1500,
  un = 500,
  cn = 4,
  Fr = 5,
  ue = new L(),
  b = await ye.LibAV({ noworker: !0 });
b.onwrite = ue.onwrite.bind(ue);
async function le(t) {
  (await b.avformat_close_input_js(t.fmt_ctx),
    await b.av_packet_free_js(t.pkt),
    await b.unlink(t.filename_tmp));
}
async function St(t, e, r) {
  let i = new Headers(e.headers);
  r && i.set("Range", `bytes=${r.offset}-${r.offset + r.length - 1}`);
  let n = await ie(t, { headers: i, signal: e.signal, cache: e.cache });
  if (n.isErr()) return n;
  e.known_segments_url.add(t);
  let o = n.value,
    a = new Uint8Array();
  {
    let s = o.body.getReader();
    for (;;) {
      let u = await fe(s);
      if (u.isErr()) return u;
      let { done: A, value: l } = u.value;
      if (A) break;
      let d = a.length;
      ((a = new Uint8Array(a.buffer.transfer(a.length + l.length))),
        a.set(l, d),
        e.progress_tracker?.add_bytes(l.length));
    }
  }
  return v(new Uint8Array(a));
}
async function Tr(t, e, r, i, n) {
  if (!i.has(e)) {
    let a = await St(e, n, void 0);
    if (a.isErr()) return a;
    i.set(e, a.value);
  }
  let o = await wr(t, i.get(e), r);
  return v(o);
}
async function dn(t, e) {
  let r = await St(t.url, e.fetch_args, t.byte_range);
  if (r.isErr()) return r;
  let i = r.value;
  if (t.encryption?.url) {
    let o = await Tr(
      i,
      t.encryption.url,
      t.encryption.iv,
      e.keys,
      e.fetch_args,
    );
    if (o.isErr() || o.value.isErr()) return o;
    i = o.value.value;
  }
  if (!t.init) return v(v(i));
  if (!e.inits.has(t.init)) {
    let o = await St(t.init.url, e.fetch_args, t.init.byte_range);
    if (o.isErr()) return o;
    let a = o.value;
    if (t.init.encryption) {
      let s = await Tr(
        a,
        t.init.encryption.url,
        t.init.encryption.iv,
        e.keys,
        e.fetch_args,
      );
      if (s.isErr() || s.value.isErr()) return s;
      a = s.value.value;
    }
    e.inits.set(t.init, new Uint8Array(a));
  }
  let n = new Uint8Array([...e.inits.get(t.init), ...i]);
  return v(v(n));
}
function $e(t, e, r, i) {
  return t.semaphore.runExclusive(() => Ie(e, t, i, !1), 1, r);
}
async function Sr(t, e, r) {
  try {
    let i = await dn(t, e);
    if (i.isErr()) return i;
    if (i.value.isErr()) return v(C(i.value.error));
    let n = i.value.value,
      o = mt(n);
    o >= 0 && (n = n.subarray(o, n.length));
    let a = `${crypto.randomUUID()}.tmp`;
    await b.writeFile(a, n);
    let [s, u] = await b.ff_init_demuxer_file(a),
      A = u.find((y) => y.codec_type === b.AVMEDIA_TYPE_VIDEO);
    if (!A && r == Z.Video) return v(C({ type: "bad_segment" }));
    let l = u.find((y) => y.codec_type === b.AVMEDIA_TYPE_AUDIO);
    if (!l && r == Z.Audio) return v(C({ type: "bad_segment" }));
    let d = await b.av_packet_alloc(),
      [f, _] = await b.ff_read_frame_multi(s, d);
    if (f !== b.AVERROR_EOF) return v(C({ type: "bad_segment" }));
    let h, c;
    if (l) {
      c = _[l.index];
      for (let y of c) y.stream_index = 0;
    }
    if (A) {
      h = _[A.index];
      for (let y of h)
        l || e.expect_two_streams ? (y.stream_index = 1) : (y.stream_index = 0);
    }
    let g;
    return (
      l && A
        ? (g = {
            video: { stream: A, packets: h },
            audio: { stream: l, packets: c },
          })
        : A
          ? (g = { video: { stream: A, packets: h }, audio: !1 })
          : (g = { video: !1, audio: { stream: l, packets: c } }),
      v(v({ av: g, pkt: d, fmt_ctx: s, filename_tmp: a, is_live: t.is_live }))
    );
  } catch {
    return v(C({ type: "bad_segment" }));
  }
}
function Dr(t) {
  if ("byterange" in t && "length" in t.byterange && "offset" in t.byterange) {
    let r = t.byterange,
      i = r.offset,
      n = r.length;
    return { offset: i, length: n };
  }
}
function fn(t) {
  let e = new Uint8Array(16);
  return (new DataView(e.buffer).setUint32(12, t, !1), e);
}
function pn(t) {
  let e = new Uint8Array(t.length * 4);
  for (let r = 0; r < t.length; r++) {
    let i = t[r],
      n = r * 4;
    ((e[n + 0] = (i >>> 24) & 255),
      (e[n + 1] = (i >>> 16) & 255),
      (e[n + 2] = (i >>> 8) & 255),
      (e[n + 3] = i & 255));
  }
  return e;
}
async function ne(t, e, r, i, n) {
  let o = C(F(""));
  for (
    let l = 0;
    l < Fr &&
    ((o = await ie(t, { headers: e, signal: r, cache: i })), !o.isOk());
    ++l
  )
    if (o.error.user_abort) break;
  if (o.isErr()) return o;
  let a = await Er(o.value);
  if (a.isErr()) return a;
  let s = null;
  try {
    let l = new Oe();
    (l.push(a.value), l.end(), (s = l.manifest));
  } catch {}
  let u = s.mediaSequence;
  !s && Array.isArray(s.segments) && M("Parsing error");
  let A = s.segments.map((l) => {
    let d = l.uri,
      f = vr(l),
      _ = new URL(d, t);
    n && t.search && (_.search = t.search);
    let h = { url: _.href, is_live: f, sequence_number: u };
    if (
      (typeof l.duration == "number" && (h.duration_s = l.duration),
      l.key?.method == "AES-128")
    ) {
      let y = l.key?.uri,
        p;
      (!l.key.iv &&
      (!l.attributes?.KEYFORMAT || l.attributes.KEYFORMAT == "identity")
        ? (p = fn(u))
        : (p = pn(l.key.iv)),
        (h.encryption = { url: new URL(y, t).href, iv: p }));
    }
    let c = Dr(l);
    c && (h.byte_range = c);
    let g = l.map;
    if (g && "uri" in g) {
      let y = g.uri,
        p = new URL(y, t).href;
      if (((h.init = { url: p }), l.map.key?.method == "AES-128")) {
        let w = l.map.key.uri,
          T = l.map.key.iv;
        ((T = new Uint8Array(T.buffer)),
          (h.init.encryption = { url: new URL(w, t).href, iv: T }));
      }
      let m = Dr(g);
      m && (h.init.byte_range = m);
    }
    return (u++, h);
  });
  return v(A);
}
async function Dt(t, e, r) {
  let i = await b.av_write_trailer(t);
  if (i != 0) {
    let n = await b.strerror(i);
    return C(n);
  }
  return (
    await b.ff_free_muxer(t, e),
    await ue.close(r),
    await b.unlink(r),
    v(r)
  );
}
async function Ft(t, e, r, i) {
  if (t.isErr() || t.value == "skip" || !t.value.is_live) return !1;
  let n = await i();
  return n.isErr()
    ? !1
    : n.value == !0
      ? (e.progress_tracker?.dont_trust_percent(), (r.value = et), !0)
      : r.value > 0
        ? (r.value--, await new Promise((o) => setTimeout(o, ln)), !0)
        : !1;
}
async function Ie(t, e, r, i) {
  let n = await Sr(t, e, r);
  for (let a = 0; a < Fr - 1 && !(n.isOk() || n.error.user_abort); a++)
    (await new Promise((s) => setTimeout(s, un * a)), (n = await Sr(t, e, r)));
  if (n.isErr()) return n;
  if (n.value.isOk())
    return (
      t.duration_s &&
        ((e.duration_s += t.duration_s),
        e.fetch_args.progress_tracker?.set_duration_in_s(e.duration_s)),
      v(n.value.value)
    );
  let o = n.value.error;
  if (o.type == "bad_segment")
    return (
      e.failures.count++,
      i
        ? C(F("Required segment was invalid, aborting download."))
        : e.failures.count / e.total_segments > An
          ? C(F("Too many invalid segments, aborting download."))
          : v("skip")
    );
  if (o.type == "decryption_failed") return C(F("Decryption failed."));
  (o.type, M("unreachable"));
}
async function xr(t, e) {
  let r = await ne(t.url, t.headers, e, t.cache, t.carry_get_params);
  if (r.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: r.error,
    };
  let i = r.value,
    n = i[0];
  n || M("Video Media Manifest does not contain video URLs");
  let o = tt(t, e, i.length, !1);
  await ue.open(o.output_filename);
  let a = n.is_live,
    s;
  a ? (s = i.length - 1) : (s = Math.floor(i.length / 2));
  let u = await Ie(i[s], o, Z.Video, !0);
  if (u.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: u.error,
    };
  u.value == "skip" && M("Can't skip segment early");
  let A = u.value;
  A.av.video || M("No video for preview");
  let l = [];
  if (A.av.audio) {
    let g = A.av.audio.stream;
    l.push([g.codecpar, g.time_base_num, g.time_base_den]);
  }
  if (A.av.video) {
    let g = A.av.video.stream;
    l.push([g.codecpar, g.time_base_num, g.time_base_den]);
  } else M("No video for preview");
  let d = { filename: o.output_filename, open: !0, codecpars: !0, device: !0 },
    [f, , _] = await b.ff_init_muxer(d, l),
    h = await b.av_opt_set(f, "avoid_negative_ts", "make_zero", 0);
  (Ve(b, h),
    (h = await b.avformat_write_header(f, 0)),
    Re(b, h),
    await b.ff_write_multi(f, A.pkt, A.av.video.packets),
    A.av.audio && (await b.ff_write_multi(f, A.pkt, A.av.audio.packets)),
    await le(A));
  let c = await Dt(f, _, o.output_filename);
  return (
    c.isErr() && M(c.error),
    {
      aborted_no_partial: !1,
      internal_filename: c.value,
      internal_bloburl: void 0,
      download_id: t.download_id,
      ending_reason: "end_of_file",
    }
  );
}
function tt(t, e, r, i) {
  let n = t.throttle ? 1 : cn;
  return {
    semaphore: new je(n),
    inits: new qe(),
    keys: new Map(),
    fetch_args: {
      signal: e,
      headers: t.headers,
      known_segments_url: new Set(),
      progress_tracker: new z(t.download_id),
      cache: t.cache,
    },
    failures: { count: 0 },
    muxer: t.muxer,
    output_filename: `${t.download_id}.${t.extension}`,
    expect_two_streams: i,
    total_segments: r,
    duration_s: 0,
  };
}
async function Br(t, e) {
  let r = await ne(t.url, t.headers, e, t.cache, t.carry_get_params);
  if (r.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: r.error,
    };
  let i = r.value;
  i.length == 0 && M("Video Media Manifest does not contain video URLs");
  let n = await ne(t.url_audio, t.headers, e, t.cache, t.carry_get_params);
  if (n.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: n.error,
    };
  let o = n.value;
  o.length == 0 && M("Media Manifest does not contain audio URLs");
  let a = tt(t, e, i.length + o.length, !0);
  await ue.open(a.output_filename);
  let s = await Ie(i[0], a, Z.Video, !0),
    u = await Ie(o[0], a, Z.Audio, !0);
  if (s.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: s.error,
    };
  let A = s.value;
  if (A == "skip")
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: F("First segment was invalid and skipped, aborting."),
    };
  if (u.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: u.error,
    };
  let l = u.value;
  if (l == "skip")
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: F("First segment was invalid and skipped, aborting."),
    };
  (i.shift(), o.shift());
  let d = [];
  if (l.av.audio) {
    let I = l.av.audio.stream;
    d.push([I.codecpar, I.time_base_num, I.time_base_den]);
  }
  if (A.av.video) {
    let I = A.av.video.stream;
    d.push([I.codecpar, I.time_base_num, I.time_base_den]);
  }
  let f = t.muxer == "mkv" ? "matroska" : t.muxer,
    _ = {
      filename: a.output_filename,
      open: !0,
      codecpars: !0,
      device: !0,
      format_name: f,
    },
    [h, , c] = await b.ff_init_muxer(_, d),
    g = await b.av_opt_set(h, "avoid_negative_ts", "make_zero", 0);
  (Ve(b, g), (g = await b.avformat_write_header(h, 0)), Re(b, g));
  let y = gr(l, A),
    p;
  A.av.video &&
    ((p = y ? be(A.av.video.packets) : Ae(A.av.video.packets)),
    await b.ff_write_multi(h, A.pkt, A.av.video.packets));
  let m;
  (l.av.audio &&
    ((m = y ? be(l.av.audio.packets) : Ae(l.av.audio.packets)),
    await b.ff_write_multi(h, l.pkt, l.av.audio.packets)),
    await le(A),
    await le(l));
  let w = C(F("not started")),
    T = { value: et },
    E = !1;
  for (;;) {
    let I = [],
      X = Math.max(i.length, o.length);
    for (let N = 0; N < X; N++) {
      let x = X - N;
      if (N < i.length) {
        let he = $e(a, i[N], x, Z.Video);
        I.push(he);
      }
      if (N < o.length) {
        let he = $e(a, o[N], x, Z.Audio);
        I.push(he);
      }
    }
    let q = -1;
    for (; I.length > 0 && (q++, (w = await I.shift()), !w.isErr());) {
      if (w.value == "skip") continue;
      let x = w.value;
      (x.av.video
        ? ((p = Ee(x.av.video.packets, p)),
          await b.ff_write_multi(h, x.pkt, x.av.video.packets))
        : x.av.audio &&
          ((m = Ee(x.av.audio.packets, m)),
          await b.ff_write_multi(h, x.pkt, x.av.audio.packets)),
        a.fetch_args.progress_tracker?.set_percent(
          100 * (q / a.total_segments),
        ),
        await le(x));
    }
    if (
      ((E = await Ft(w, a.fetch_args, T, async () => {
        let N = await ne(t.url, t.headers, e, t.cache, t.carry_get_params);
        if (N.isErr()) return N;
        let x = await ne(
          t.url_audio,
          t.headers,
          e,
          t.cache,
          t.carry_get_params,
        );
        if (x.isErr()) return x;
        ((i = N.value.filter(
          ({ url: xe }) => !a.fetch_args.known_segments_url.has(xe),
        )),
          (o = x.value.filter(
            ({ url: xe }) => !a.fetch_args.known_segments_url.has(xe),
          )));
        let he = i.length > 0 || o.length > 0;
        return v(he);
      })),
      !E)
    )
      break;
  }
  let S = await Dt(h, c, a.output_filename);
  return (
    S.isErr() && M(S.error),
    {
      aborted_no_partial: !1,
      internal_filename: S.value,
      internal_bloburl: await Q(t, S.value),
      download_id: t.download_id,
      ending_reason: w.isOk() ? "end_of_file" : w.error,
    }
  );
}
async function Rr(t, e) {
  let r = await ne(t.url, t.headers, e, t.cache, t.carry_get_params);
  if (r.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: r.error,
    };
  let i = r.value;
  i.length == 0 && M("Video Media Manifest does not contain video URLs");
  let n = tt(t, e, i.length, !1);
  await ue.open(n.output_filename);
  let o = await Ie(i[0], n, Z.Video, !0);
  if (o.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: o.error,
    };
  let a = o.value;
  if (a == "skip")
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: F("First segment was invalid and skipped, aborting."),
    };
  i.shift();
  let s = [];
  if (a.av.audio) {
    let w = a.av.audio.stream;
    s.push([w.codecpar, w.time_base_num, w.time_base_den]);
  }
  if (a.av.video) {
    let w = a.av.video.stream;
    s.push([w.codecpar, w.time_base_num, w.time_base_den]);
  }
  let u = t.muxer == "mkv" ? "matroska" : t.muxer,
    A = {
      filename: n.output_filename,
      open: !0,
      codecpars: !0,
      device: !0,
      format_name: u,
    },
    [l, , d] = await b.ff_init_muxer(A, s),
    f = await b.av_opt_set(l, "avoid_negative_ts", "make_zero", 0);
  (Ve(b, f), (f = await b.avformat_write_header(l, 0)), Re(b, f));
  let _ = hr(a),
    h;
  a.av.video &&
    ((h = _ ? be(a.av.video.packets) : Ae(a.av.video.packets)),
    await b.ff_write_multi(l, a.pkt, a.av.video.packets));
  let c;
  (a.av.audio &&
    ((c = _ ? be(a.av.audio.packets) : Ae(a.av.audio.packets)),
    await b.ff_write_multi(l, a.pkt, a.av.audio.packets)),
    await le(a));
  let g = C(F("not started")),
    y = { value: et },
    p = !1;
  for (;;) {
    let w = [];
    for (let E = 0; E < i.length; E++) {
      let S = i.length - E,
        I = $e(n, i[E], S, Z.Video);
      w.push(I);
    }
    let T = -1;
    for (; w.length > 0 && (T++, (g = await w.shift()), !g.isErr());) {
      if (g.value == "skip") continue;
      let S = g.value;
      (S.av.video &&
        ((h = Ee(S.av.video.packets, h)),
        await b.ff_write_multi(l, S.pkt, S.av.video.packets)),
        S.av.audio &&
          ((c = Ee(S.av.audio.packets, c)),
          await b.ff_write_multi(l, S.pkt, S.av.audio.packets)),
        n.fetch_args.progress_tracker?.set_percent(
          100 * (T / n.total_segments),
        ),
        await le(S));
    }
    if (
      !g ||
      ((p = await Ft(g, n.fetch_args, y, async () => {
        let E = await ne(t.url, t.headers, e, t.cache, t.carry_get_params);
        return E.isErr()
          ? E
          : ((i = E.value.filter(
              ({ url: S }) => !n.fetch_args.known_segments_url.has(S),
            )),
            v(i.length > 0));
      })),
      !p)
    )
      break;
  }
  let m = await Dt(l, d, n.output_filename);
  return (
    m.isErr() && M(m.error),
    {
      aborted_no_partial: !1,
      internal_filename: m.value,
      internal_bloburl: await Q(t, m.value),
      download_id: t.download_id,
      ending_reason: g.isOk() ? "end_of_file" : g.error,
    }
  );
}
async function Vr(t, e) {
  let n = t.url,
    o = await ne(n, t.headers, e, t.cache, t.carry_get_params);
  if (o.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: o.error,
    };
  let a = o.value;
  a.length == 0 && M("Audio Media Manifest does not contain audio URLs");
  let s = tt(t, e, a.length, !1),
    u = await Ie(a[0], s, Z.Audio, !0);
  if (u.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: u.error,
    };
  let A = u.value;
  if (A == "skip")
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: F("First segment was invalid and skipped, aborting."),
    };
  a.shift();
  let l;
  (A.av.audio && (l = be(A.av.audio.packets)),
    A.av.audio || M("No audio stream found"));
  let d = A.av.audio.stream,
    [, f, _, h] = await b.ff_init_decoder(d.codec_id, d.codecpar),
    c = await b.ff_decode_multi(f, _, h, A.av.audio.packets, { fin: !1 }),
    g = "aresample=isf=s16p:osf=fltp,asetnsamples=n=1152:p=0",
    [y, p, m] = await b.ff_init_filter_graph(
      g,
      {
        sample_rate: c[0].sample_rate,
        sample_fmt: c[0].format,
        channel_layout: c[0].channel_layout,
      },
      {
        sample_rate: 44100,
        sample_fmt: b.AV_SAMPLE_FMT_FLTP,
        channel_layout: c[0].channel_layout,
      },
    ),
    w = await b.ff_filter_multi(p, m, h, c, { fin: !1 }),
    [T, E, S, I, X] = await b.ff_init_encoder("libmp3lame", {
      ctx: {
        bit_rate: 128e3,
        sample_fmt: b.AV_SAMPLE_FMT_FLTP,
        sample_rate: 44100,
        channel_layout: c[0].channel_layout,
        channels: c[0].channels,
      },
      time_base: [1, 44100],
    }),
    q = await b.ff_encode_multi(E, S, I, w, !1);
  await ue.open(s.output_filename);
  let N = {
      filename: s.output_filename,
      open: !0,
      codecpars: !1,
      device: !0,
      format_name: "mp3",
    },
    [x, he, xe, [No]] = await b.ff_init_muxer(N, [[E, 1, 44100]]),
    ge = await b.av_opt_set(x, "avoid_negative_ts", "make_zero", 0);
  (Ve(b, ge),
    (ge = await b.avformat_write_header(x, 0)),
    Re(b, ge),
    await b.ff_write_multi(x, I, q),
    await le(A));
  let oe = C(F("not started")),
    Di = { value: et },
    qt = !1;
  for (;;) {
    let Be = [];
    for (let j = 0; j < a.length; j++) {
      let te = a.length - j,
        ut = $e(s, a[j], te, Z.Audio);
      Be.push(ut);
    }
    let lt = -1;
    for (; Be.length > 0 && (lt++, (oe = await Be.shift()), !oe.isErr());) {
      if (oe.value == "skip") continue;
      let te = oe.value;
      (te.av.audio || M(`No audio found in segment ${lt + 1}`),
        (l = Ee(te.av.audio.packets, l)));
      let ut = await b.ff_decode_multi(f, _, h, te.av.audio.packets, {
          fin: !1,
        }),
        Fi = await b.ff_filter_multi(p, m, h, ut, { fin: !1 }),
        xi = await b.ff_encode_multi(E, S, I, Fi, !1);
      (await b.ff_write_multi(x, te.pkt, xi),
        s.fetch_args.progress_tracker?.set_percent(
          100 * (lt / s.total_segments),
        ),
        await le(te));
    }
    if (!oe) break;
    if (
      ((qt = await Ft(oe, s.fetch_args, Di, async () => {
        let j = await ne(n, t.headers, e, t.cache, t.carry_get_params);
        return j.isErr()
          ? j
          : ((a = j.value.filter(
              ({ url: te }) => !s.fetch_args.known_segments_url.has(te),
            )),
            v(a.length > 0));
      })),
      !qt)
    ) {
      let j = await b.ff_encode_multi(E, S, I, [], !0);
      await b.ff_write_multi(x, 0, j);
      break;
    }
  }
  if (((ge = await b.av_write_trailer(x)), ge != 0)) {
    let Be = await b.strerror(ge);
    M(Be);
  }
  return (
    await b.ff_free_decoder(f, _, h),
    await b.avfilter_graph_free_js(y),
    await b.ff_free_encoder(E, S, I),
    await b.ff_free_muxer(x, xe),
    await ue.close(s.output_filename),
    await b.unlink(s.output_filename),
    {
      internal_filename: s.output_filename,
      aborted_no_partial: !1,
      internal_bloburl: await Q(t, s.output_filename),
      download_id: t.download_id,
      ending_reason: oe.isOk() ? "end_of_file" : oe.error,
    }
  );
}
async function Nr(t, e) {
  let r = `${t.download_id}.${t.muxer}`;
  return await G(t, e, r, void 0, [
    "-analyzeduration",
    "10M",
    "-f",
    "hls",
    "-i",
    `jsfetch:${t.url}`,
    "-c:a",
    "libmp3lame",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
async function Mr(t, e) {
  let r = `${t.download_id}.${t.muxer}`;
  return await G(t, e, r, void 0, [
    "-analyzeduration",
    "10M",
    "-f",
    "hls",
    "-i",
    `jsfetch:${t.url}`,
    "-c",
    "copy",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
async function Pr(t, e) {
  let r = `${t.download_id}.${t.muxer}`;
  return await G(t, e, r, void 0, [
    "-analyzeduration",
    "10M",
    "-f",
    "hls",
    "-i",
    `jsfetch:${t.url}`,
    "-i",
    `jsfetch:${t.url_audio}`,
    "-c",
    "copy",
    "-map",
    "0:v:0",
    "-map",
    "1:a:0?",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
function kr(t) {
  if (!t.headers.get("content-length")) return B;
  let e = t.headers.get("content-length"),
    r = parseInt(e);
  return r <= 0 ? B : P(r);
}
function Or(t, e) {
  let r = `${t.download_id}.${t.muxer}`;
  return G(t, e, r, void 0, [
    "-analyzeduration",
    "1M",
    "-ss",
    "0",
    "-i",
    `jsfetch:${t.url}`,
    "-t",
    "5",
    "-c",
    "copy",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
async function Lr(t, e) {
  let r = `${t.download_id}.${t.muxer}`;
  return await G(t, e, r, void 0, [
    "-analyzeduration",
    "10M",
    "-i",
    `jsfetch:${t.url}`,
    "-c",
    "copy",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
async function Gr(t, e) {
  let r = `${t.download_id}.${t.muxer}`;
  return await G(t, e, r, void 0, [
    "-analyzeduration",
    "10M",
    "-i",
    `jsfetch:${t.url}`,
    "-i",
    `jsfetch:${t.url_audio}`,
    "-c",
    "copy",
    "-map",
    "0:v:0",
    "-map",
    "1:a:0?",
    "-avoid_negative_ts",
    "make_zero",
    "-y",
    r,
  ]);
}
async function Ur(t, e) {
  let r = `${t.download_id}.${t.muxer}`;
  try {
    return await G(t, e, r, void 0, [
      "-analyzeduration",
      "10M",
      "-i",
      `jsfetch:${t.url}`,
      "-map",
      "0:a:0",
      "-af",
      "aresample",
      "-c:a",
      "libmp3lame",
      "-avoid_negative_ts",
      "make_zero",
      "-y",
      r,
    ]);
  } catch (i) {
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: {
        user_abort: !1,
        percentage_incomplete: !1,
        e4XX_5XX_failure: !1,
        other_failure: !0,
        message: `Failed to download audio http media ${i}`,
      },
    };
  }
}
async function Ce(t, e, r, i, n, { headers: o, download_id: a, cache: s }) {
  let u = await ie(i, { headers: o, signal: n, cache: s });
  if (u.isErr())
    return { aborted_no_partial: !0, download_id: a, ending_reason: u.error };
  let A = u.value.body.getReader(),
    l = kr(u.value),
    d;
  l.isSome() && (d = l.value);
  let f = 0;
  for (;;) {
    let _ = await fe(A);
    if (_.isErr())
      return { aborted_no_partial: !0, download_id: a, ending_reason: _.error };
    let { done: h, value: c } = _.value;
    if (h) break;
    (t.onwrite(e, f, c),
      (f += c.length),
      d
        ? r.set_progress({
            percent: { is_known: !0, value: 100 * (f / d) },
            fetched_bytes_count: f,
            status: "downloading",
            output_duration_s: 0,
          })
        : r.set_progress({
            percent: { is_known: !1 },
            fetched_bytes_count: f,
            status: "downloading",
            output_duration_s: 0,
          }));
  }
  return {
    aborted_no_partial: !1,
    download_id: a,
    ending_reason: "end_of_file",
    internal_filename: e,
    internal_bloburl: void 0,
  };
}
async function Yr(t, e) {
  let r = `${t.download_id}.${t.extension}`,
    i = new L();
  await i.open(r);
  let n = new z(t.download_id),
    o = await Ce(i, r, n, t.url, e, t);
  return (
    await i.close(r),
    o.aborted_no_partial ? i.remove(r) : (o.internal_bloburl = await Q(t, r)),
    o
  );
}
var Qr =
    ":A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD",
  gn = Qr + "\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040",
  yn = "[" + Qr + "][" + gn + "]*",
  wn = new RegExp("^" + yn + "$");
function rt(t, e) {
  let r = [],
    i = e.exec(t);
  for (; i;) {
    let n = [];
    n.startIndex = e.lastIndex - i[0].length;
    let o = i.length;
    for (let a = 0; a < o; a++) n.push(i[a]);
    (r.push(n), (i = e.exec(t)));
  }
  return r;
}
var xt = function (t) {
  let e = wn.exec(t);
  return !(e === null || typeof e > "u");
};
function Kr(t) {
  return typeof t < "u";
}
var Le = [
    "hasOwnProperty",
    "toString",
    "valueOf",
    "__defineGetter__",
    "__defineSetter__",
    "__lookupGetter__",
    "__lookupSetter__",
  ],
  it = ["__proto__", "constructor", "prototype"];
var bn = { allowBooleanAttributes: !1, unpairedTags: [] };
function Zr(t, e) {
  e = Object.assign({}, bn, e);
  let r = [],
    i = !1,
    n = !1;
  t[0] === "\uFEFF" && (t = t.substr(1));
  for (let o = 0; o < t.length; o++)
    if (t[o] === "<" && t[o + 1] === "?") {
      if (((o += 2), (o = Hr(t, o)), o.err)) return o;
    } else if (t[o] === "<") {
      let a = o;
      if ((o++, t[o] === "!")) {
        o = Xr(t, o);
        continue;
      } else {
        let s = !1;
        t[o] === "/" && ((s = !0), o++);
        let u = "";
        for (
          ;
          o < t.length &&
          t[o] !== ">" &&
          t[o] !== " " &&
          t[o] !== "	" &&
          t[o] !==
            `
` &&
          t[o] !== "\r";
          o++
        )
          u += t[o];
        if (
          ((u = u.trim()),
          u[u.length - 1] === "/" && ((u = u.substring(0, u.length - 1)), o--),
          !Fn(u))
        ) {
          let d;
          return (
            u.trim().length === 0
              ? (d = "Invalid space after '<'.")
              : (d = "Tag '" + u + "' is an invalid name."),
            V("InvalidTag", d, Y(t, o))
          );
        }
        let A = Cn(t, o);
        if (A === !1)
          return V(
            "InvalidAttr",
            "Attributes for '" + u + "' have open quote.",
            Y(t, o),
          );
        let l = A.value;
        if (((o = A.index), l[l.length - 1] === "/")) {
          let d = o - l.length;
          l = l.substring(0, l.length - 1);
          let f = Jr(l, e);
          if (f === !0) i = !0;
          else return V(f.err.code, f.err.msg, Y(t, d + f.err.line));
        } else if (s)
          if (A.tagClosed) {
            if (l.trim().length > 0)
              return V(
                "InvalidTag",
                "Closing tag '" +
                  u +
                  "' can't have attributes or invalid starting.",
                Y(t, a),
              );
            if (r.length === 0)
              return V(
                "InvalidTag",
                "Closing tag '" + u + "' has not been opened.",
                Y(t, a),
              );
            {
              let d = r.pop();
              if (u !== d.tagName) {
                let f = Y(t, d.tagStartPos);
                return V(
                  "InvalidTag",
                  "Expected closing tag '" +
                    d.tagName +
                    "' (opened in line " +
                    f.line +
                    ", col " +
                    f.col +
                    ") instead of closing tag '" +
                    u +
                    "'.",
                  Y(t, a),
                );
              }
              r.length == 0 && (n = !0);
            }
          } else
            return V(
              "InvalidTag",
              "Closing tag '" + u + "' doesn't have proper closing.",
              Y(t, o),
            );
        else {
          let d = Jr(l, e);
          if (d !== !0)
            return V(d.err.code, d.err.msg, Y(t, o - l.length + d.err.line));
          if (n === !0)
            return V(
              "InvalidXml",
              "Multiple possible root nodes found.",
              Y(t, o),
            );
          (e.unpairedTags.indexOf(u) !== -1 ||
            r.push({ tagName: u, tagStartPos: a }),
            (i = !0));
        }
        for (o++; o < t.length; o++)
          if (t[o] === "<")
            if (t[o + 1] === "!") {
              (o++, (o = Xr(t, o)));
              continue;
            } else if (t[o + 1] === "?") {
              if (((o = Hr(t, ++o)), o.err)) return o;
            } else break;
          else if (t[o] === "&") {
            let d = Sn(t, o);
            if (d == -1)
              return V("InvalidChar", "char '&' is not expected.", Y(t, o));
            o = d;
          } else if (n === !0 && !Wr(t[o]))
            return V("InvalidXml", "Extra text at the end", Y(t, o));
        t[o] === "<" && o--;
      }
    } else {
      if (Wr(t[o])) continue;
      return V("InvalidChar", "char '" + t[o] + "' is not expected.", Y(t, o));
    }
  if (i) {
    if (r.length == 1)
      return V(
        "InvalidTag",
        "Unclosed tag '" + r[0].tagName + "'.",
        Y(t, r[0].tagStartPos),
      );
    if (r.length > 0)
      return V(
        "InvalidXml",
        "Invalid '" +
          JSON.stringify(
            r.map((o) => o.tagName),
            null,
            4,
          ).replace(/\r?\n/g, "") +
          "' found.",
        { line: 1, col: 1 },
      );
  } else return V("InvalidXml", "Start tag expected.", 1);
  return !0;
}
function Wr(t) {
  return (
    t === " " ||
    t === "	" ||
    t ===
      `
` ||
    t === "\r"
  );
}
function Hr(t, e) {
  let r = e;
  for (; e < t.length; e++)
    if (t[e] == "?" || t[e] == " ") {
      let i = t.substr(r, e - r);
      if (e > 5 && i === "xml")
        return V(
          "InvalidXml",
          "XML declaration allowed only at the start of the document.",
          Y(t, e),
        );
      if (t[e] == "?" && t[e + 1] == ">") {
        e++;
        break;
      } else continue;
    }
  return e;
}
function Xr(t, e) {
  if (t.length > e + 5 && t[e + 1] === "-" && t[e + 2] === "-") {
    for (e += 3; e < t.length; e++)
      if (t[e] === "-" && t[e + 1] === "-" && t[e + 2] === ">") {
        e += 2;
        break;
      }
  } else if (
    t.length > e + 8 &&
    t[e + 1] === "D" &&
    t[e + 2] === "O" &&
    t[e + 3] === "C" &&
    t[e + 4] === "T" &&
    t[e + 5] === "Y" &&
    t[e + 6] === "P" &&
    t[e + 7] === "E"
  ) {
    let r = 1;
    for (e += 8; e < t.length; e++)
      if (t[e] === "<") r++;
      else if (t[e] === ">" && (r--, r === 0)) break;
  } else if (
    t.length > e + 9 &&
    t[e + 1] === "[" &&
    t[e + 2] === "C" &&
    t[e + 3] === "D" &&
    t[e + 4] === "A" &&
    t[e + 5] === "T" &&
    t[e + 6] === "A" &&
    t[e + 7] === "["
  ) {
    for (e += 8; e < t.length; e++)
      if (t[e] === "]" && t[e + 1] === "]" && t[e + 2] === ">") {
        e += 2;
        break;
      }
  }
  return e;
}
var En = '"',
  In = "'";
function Cn(t, e) {
  let r = "",
    i = "",
    n = !1;
  for (; e < t.length; e++) {
    if (t[e] === En || t[e] === In)
      i === "" ? (i = t[e]) : i !== t[e] || (i = "");
    else if (t[e] === ">" && i === "") {
      n = !0;
      break;
    }
    r += t[e];
  }
  return i !== "" ? !1 : { value: r, index: e, tagClosed: n };
}
var vn = new RegExp(
  `(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['"])(([\\s\\S])*?)\\5)?`,
  "g",
);
function Jr(t, e) {
  let r = rt(t, vn),
    i = {};
  for (let n = 0; n < r.length; n++) {
    if (r[n][1].length === 0)
      return V(
        "InvalidAttr",
        "Attribute '" + r[n][2] + "' has no space in starting.",
        Ge(r[n]),
      );
    if (r[n][3] !== void 0 && r[n][4] === void 0)
      return V(
        "InvalidAttr",
        "Attribute '" + r[n][2] + "' is without value.",
        Ge(r[n]),
      );
    if (r[n][3] === void 0 && !e.allowBooleanAttributes)
      return V(
        "InvalidAttr",
        "boolean attribute '" + r[n][2] + "' is not allowed.",
        Ge(r[n]),
      );
    let o = r[n][2];
    if (!Dn(o))
      return V(
        "InvalidAttr",
        "Attribute '" + o + "' is an invalid name.",
        Ge(r[n]),
      );
    if (!Object.prototype.hasOwnProperty.call(i, o)) i[o] = 1;
    else
      return V("InvalidAttr", "Attribute '" + o + "' is repeated.", Ge(r[n]));
  }
  return !0;
}
function Tn(t, e) {
  let r = /\d/;
  for (t[e] === "x" && (e++, (r = /[\da-fA-F]/)); e < t.length; e++) {
    if (t[e] === ";") return e;
    if (!t[e].match(r)) break;
  }
  return -1;
}
function Sn(t, e) {
  if ((e++, t[e] === ";")) return -1;
  if (t[e] === "#") return (e++, Tn(t, e));
  let r = 0;
  for (; e < t.length; e++, r++)
    if (!(t[e].match(/\w/) && r < 20)) {
      if (t[e] === ";") break;
      return -1;
    }
  return e;
}
function V(t, e, r) {
  return { err: { code: t, msg: e, line: r.line || r, col: r.col } };
}
function Dn(t) {
  return xt(t);
}
function Fn(t) {
  return xt(t);
}
function Y(t, e) {
  let r = t.substring(0, e).split(/\r?\n/);
  return { line: r.length, col: r[r.length - 1].length + 1 };
}
function Ge(t) {
  return t.startIndex + t[1].length;
}
var jr = {
    amp: "&",
    AMP: "&",
    lt: "<",
    LT: "<",
    gt: ">",
    GT: ">",
    quot: '"',
    QUOT: '"',
    apos: "'",
    lsquo: "\u2018",
    rsquo: "\u2019",
    ldquo: "\u201C",
    rdquo: "\u201D",
    lsquor: "\u201A",
    rsquor: "\u2019",
    ldquor: "\u201E",
    bdquo: "\u201E",
    comma: ",",
    period: ".",
    colon: ":",
    semi: ";",
    excl: "!",
    quest: "?",
    num: "#",
    dollar: "$",
    percent: "%",
    ast: "*",
    commat: "@",
    lowbar: "_",
    verbar: "|",
    vert: "|",
    sol: "/",
    bsol: "\\",
    lbrace: "{",
    rbrace: "}",
    lbrack: "[",
    rbrack: "]",
    lpar: "(",
    rpar: ")",
    nbsp: "\xA0",
    iexcl: "\xA1",
    cent: "\xA2",
    pound: "\xA3",
    curren: "\xA4",
    yen: "\xA5",
    brvbar: "\xA6",
    sect: "\xA7",
    uml: "\xA8",
    copy: "\xA9",
    COPY: "\xA9",
    ordf: "\xAA",
    laquo: "\xAB",
    not: "\xAC",
    shy: "\xAD",
    reg: "\xAE",
    REG: "\xAE",
    macr: "\xAF",
    deg: "\xB0",
    plusmn: "\xB1",
    sup2: "\xB2",
    sup3: "\xB3",
    acute: "\xB4",
    micro: "\xB5",
    para: "\xB6",
    middot: "\xB7",
    cedil: "\xB8",
    sup1: "\xB9",
    ordm: "\xBA",
    raquo: "\xBB",
    frac14: "\xBC",
    frac12: "\xBD",
    half: "\xBD",
    frac34: "\xBE",
    iquest: "\xBF",
    times: "\xD7",
    div: "\xF7",
    divide: "\xF7",
  },
  zr = {
    Agrave: "\xC0",
    agrave: "\xE0",
    Aacute: "\xC1",
    aacute: "\xE1",
    Acirc: "\xC2",
    acirc: "\xE2",
    Atilde: "\xC3",
    atilde: "\xE3",
    Auml: "\xC4",
    auml: "\xE4",
    Aring: "\xC5",
    aring: "\xE5",
    AElig: "\xC6",
    aelig: "\xE6",
    Ccedil: "\xC7",
    ccedil: "\xE7",
    Egrave: "\xC8",
    egrave: "\xE8",
    Eacute: "\xC9",
    eacute: "\xE9",
    Ecirc: "\xCA",
    ecirc: "\xEA",
    Euml: "\xCB",
    euml: "\xEB",
    Igrave: "\xCC",
    igrave: "\xEC",
    Iacute: "\xCD",
    iacute: "\xED",
    Icirc: "\xCE",
    icirc: "\xEE",
    Iuml: "\xCF",
    iuml: "\xEF",
    ETH: "\xD0",
    eth: "\xF0",
    Ntilde: "\xD1",
    ntilde: "\xF1",
    Ograve: "\xD2",
    ograve: "\xF2",
    Oacute: "\xD3",
    oacute: "\xF3",
    Ocirc: "\xD4",
    ocirc: "\xF4",
    Otilde: "\xD5",
    otilde: "\xF5",
    Ouml: "\xD6",
    ouml: "\xF6",
    Oslash: "\xD8",
    oslash: "\xF8",
    Ugrave: "\xD9",
    ugrave: "\xF9",
    Uacute: "\xDA",
    uacute: "\xFA",
    Ucirc: "\xDB",
    ucirc: "\xFB",
    Uuml: "\xDC",
    uuml: "\xFC",
    Yacute: "\xDD",
    yacute: "\xFD",
    THORN: "\xDE",
    thorn: "\xFE",
    szlig: "\xDF",
    yuml: "\xFF",
    Yuml: "\u0178",
  },
  qr = {
    Amacr: "\u0100",
    amacr: "\u0101",
    Abreve: "\u0102",
    abreve: "\u0103",
    Aogon: "\u0104",
    aogon: "\u0105",
    Cacute: "\u0106",
    cacute: "\u0107",
    Ccirc: "\u0108",
    ccirc: "\u0109",
    Cdot: "\u010A",
    cdot: "\u010B",
    Ccaron: "\u010C",
    ccaron: "\u010D",
    Dcaron: "\u010E",
    dcaron: "\u010F",
    Dstrok: "\u0110",
    dstrok: "\u0111",
    Emacr: "\u0112",
    emacr: "\u0113",
    Ecaron: "\u011A",
    ecaron: "\u011B",
    Edot: "\u0116",
    edot: "\u0117",
    Eogon: "\u0118",
    eogon: "\u0119",
    Gcirc: "\u011C",
    gcirc: "\u011D",
    Gbreve: "\u011E",
    gbreve: "\u011F",
    Gdot: "\u0120",
    gdot: "\u0121",
    Gcedil: "\u0122",
    Hcirc: "\u0124",
    hcirc: "\u0125",
    Hstrok: "\u0126",
    hstrok: "\u0127",
    Itilde: "\u0128",
    itilde: "\u0129",
    Imacr: "\u012A",
    imacr: "\u012B",
    Iogon: "\u012E",
    iogon: "\u012F",
    Idot: "\u0130",
    IJlig: "\u0132",
    ijlig: "\u0133",
    Jcirc: "\u0134",
    jcirc: "\u0135",
    Kcedil: "\u0136",
    kcedil: "\u0137",
    kgreen: "\u0138",
    Lacute: "\u0139",
    lacute: "\u013A",
    Lcedil: "\u013B",
    lcedil: "\u013C",
    Lcaron: "\u013D",
    lcaron: "\u013E",
    Lmidot: "\u013F",
    lmidot: "\u0140",
    Lstrok: "\u0141",
    lstrok: "\u0142",
    Nacute: "\u0143",
    nacute: "\u0144",
    Ncaron: "\u0147",
    ncaron: "\u0148",
    Ncedil: "\u0145",
    ncedil: "\u0146",
    ENG: "\u014A",
    eng: "\u014B",
    Omacr: "\u014C",
    omacr: "\u014D",
    Odblac: "\u0150",
    odblac: "\u0151",
    OElig: "\u0152",
    oelig: "\u0153",
    Racute: "\u0154",
    racute: "\u0155",
    Rcaron: "\u0158",
    rcaron: "\u0159",
    Rcedil: "\u0156",
    rcedil: "\u0157",
    Sacute: "\u015A",
    sacute: "\u015B",
    Scirc: "\u015C",
    scirc: "\u015D",
    Scedil: "\u015E",
    scedil: "\u015F",
    Scaron: "\u0160",
    scaron: "\u0161",
    Tcedil: "\u0162",
    tcedil: "\u0163",
    Tcaron: "\u0164",
    tcaron: "\u0165",
    Tstrok: "\u0166",
    tstrok: "\u0167",
    Utilde: "\u0168",
    utilde: "\u0169",
    Umacr: "\u016A",
    umacr: "\u016B",
    Ubreve: "\u016C",
    ubreve: "\u016D",
    Uring: "\u016E",
    uring: "\u016F",
    Udblac: "\u0170",
    udblac: "\u0171",
    Uogon: "\u0172",
    uogon: "\u0173",
    Wcirc: "\u0174",
    wcirc: "\u0175",
    Ycirc: "\u0176",
    ycirc: "\u0177",
    Zacute: "\u0179",
    zacute: "\u017A",
    Zdot: "\u017B",
    zdot: "\u017C",
    Zcaron: "\u017D",
    zcaron: "\u017E",
  },
  $r = {
    Alpha: "\u0391",
    alpha: "\u03B1",
    Beta: "\u0392",
    beta: "\u03B2",
    Gamma: "\u0393",
    gamma: "\u03B3",
    Delta: "\u0394",
    delta: "\u03B4",
    Epsilon: "\u0395",
    epsilon: "\u03B5",
    epsiv: "\u03F5",
    varepsilon: "\u03F5",
    Zeta: "\u0396",
    zeta: "\u03B6",
    Eta: "\u0397",
    eta: "\u03B7",
    Theta: "\u0398",
    theta: "\u03B8",
    thetasym: "\u03D1",
    vartheta: "\u03D1",
    Iota: "\u0399",
    iota: "\u03B9",
    Kappa: "\u039A",
    kappa: "\u03BA",
    kappav: "\u03F0",
    varkappa: "\u03F0",
    Lambda: "\u039B",
    lambda: "\u03BB",
    Mu: "\u039C",
    mu: "\u03BC",
    Nu: "\u039D",
    nu: "\u03BD",
    Xi: "\u039E",
    xi: "\u03BE",
    Omicron: "\u039F",
    omicron: "\u03BF",
    Pi: "\u03A0",
    pi: "\u03C0",
    piv: "\u03D6",
    varpi: "\u03D6",
    Rho: "\u03A1",
    rho: "\u03C1",
    rhov: "\u03F1",
    varrho: "\u03F1",
    Sigma: "\u03A3",
    sigma: "\u03C3",
    sigmaf: "\u03C2",
    sigmav: "\u03C2",
    varsigma: "\u03C2",
    Tau: "\u03A4",
    tau: "\u03C4",
    Upsilon: "\u03A5",
    upsilon: "\u03C5",
    upsi: "\u03C5",
    Upsi: "\u03D2",
    upsih: "\u03D2",
    Phi: "\u03A6",
    phi: "\u03C6",
    phiv: "\u03D5",
    varphi: "\u03D5",
    Chi: "\u03A7",
    chi: "\u03C7",
    Psi: "\u03A8",
    psi: "\u03C8",
    Omega: "\u03A9",
    omega: "\u03C9",
    ohm: "\u03A9",
    Gammad: "\u03DC",
    gammad: "\u03DD",
    digamma: "\u03DD",
  },
  ei = {
    Afr: "\u{1D504}",
    afr: "\u{1D51E}",
    Acy: "\u0410",
    acy: "\u0430",
    Bcy: "\u0411",
    bcy: "\u0431",
    Vcy: "\u0412",
    vcy: "\u0432",
    Gcy: "\u0413",
    gcy: "\u0433",
    Dcy: "\u0414",
    dcy: "\u0434",
    IEcy: "\u0415",
    iecy: "\u0435",
    IOcy: "\u0401",
    iocy: "\u0451",
    ZHcy: "\u0416",
    zhcy: "\u0436",
    Zcy: "\u0417",
    zcy: "\u0437",
    Icy: "\u0418",
    icy: "\u0438",
    Jcy: "\u0419",
    jcy: "\u0439",
    Kcy: "\u041A",
    kcy: "\u043A",
    Lcy: "\u041B",
    lcy: "\u043B",
    Mcy: "\u041C",
    mcy: "\u043C",
    Ncy: "\u041D",
    ncy: "\u043D",
    Ocy: "\u041E",
    ocy: "\u043E",
    Pcy: "\u041F",
    pcy: "\u043F",
    Rcy: "\u0420",
    rcy: "\u0440",
    Scy: "\u0421",
    scy: "\u0441",
    Tcy: "\u0422",
    tcy: "\u0442",
    Ucy: "\u0423",
    ucy: "\u0443",
    Fcy: "\u0424",
    fcy: "\u0444",
    KHcy: "\u0425",
    khcy: "\u0445",
    TScy: "\u0426",
    tscy: "\u0446",
    CHcy: "\u0427",
    chcy: "\u0447",
    SHcy: "\u0428",
    shcy: "\u0448",
    SHCHcy: "\u0429",
    shchcy: "\u0449",
    HARDcy: "\u042A",
    hardcy: "\u044A",
    Ycy: "\u042B",
    ycy: "\u044B",
    SOFTcy: "\u042C",
    softcy: "\u044C",
    Ecy: "\u042D",
    ecy: "\u044D",
    YUcy: "\u042E",
    yucy: "\u044E",
    YAcy: "\u042F",
    yacy: "\u044F",
    DJcy: "\u0402",
    djcy: "\u0452",
    GJcy: "\u0403",
    gjcy: "\u0453",
    Jukcy: "\u0404",
    jukcy: "\u0454",
    DScy: "\u0405",
    dscy: "\u0455",
    Iukcy: "\u0406",
    iukcy: "\u0456",
    YIcy: "\u0407",
    yicy: "\u0457",
    Jsercy: "\u0408",
    jsercy: "\u0458",
    LJcy: "\u0409",
    ljcy: "\u0459",
    NJcy: "\u040A",
    njcy: "\u045A",
    TSHcy: "\u040B",
    tshcy: "\u045B",
    KJcy: "\u040C",
    kjcy: "\u045C",
    Ubrcy: "\u040E",
    ubrcy: "\u045E",
    DZcy: "\u040F",
    dzcy: "\u045F",
  },
  ti = {
    plus: "+",
    pm: "\xB1",
    times: "\xD7",
    div: "\xF7",
    divide: "\xF7",
    sdot: "\u22C5",
    star: "\u2606",
    starf: "\u2605",
    bigstar: "\u2605",
    lowast: "\u2217",
    ast: "*",
    midast: "*",
    compfn: "\u2218",
    smallcircle: "\u2218",
    bullet: "\u2022",
    bull: "\u2022",
    nbsp: "\xA0",
    hellip: "\u2026",
    mldr: "\u2026",
    prime: "\u2032",
    Prime: "\u2033",
    tprime: "\u2034",
    bprime: "\u2035",
    backprime: "\u2035",
    minus: "\u2212",
    minusd: "\u2238",
    dotminus: "\u2238",
    plusdo: "\u2214",
    dotplus: "\u2214",
    plusmn: "\xB1",
    minusplus: "\u2213",
    mnplus: "\u2213",
    mp: "\u2213",
    setminus: "\u2216",
    smallsetminus: "\u2216",
    Backslash: "\u2216",
    setmn: "\u2216",
    ssetmn: "\u2216",
    lowbar: "_",
    verbar: "|",
    vert: "|",
    VerticalLine: "|",
    colon: ":",
    Colon: "\u2237",
    Proportion: "\u2237",
    ratio: "\u2236",
    equals: "=",
    ne: "\u2260",
    nequiv: "\u2262",
    equiv: "\u2261",
    Congruent: "\u2261",
    sim: "\u223C",
    thicksim: "\u223C",
    thksim: "\u223C",
    sime: "\u2243",
    simeq: "\u2243",
    TildeEqual: "\u2243",
    asymp: "\u2248",
    approx: "\u2248",
    thickapprox: "\u2248",
    thkap: "\u2248",
    TildeTilde: "\u2248",
    ncong: "\u2247",
    cong: "\u2245",
    TildeFullEqual: "\u2245",
    asympeq: "\u224D",
    CupCap: "\u224D",
    bump: "\u224E",
    Bumpeq: "\u224E",
    HumpDownHump: "\u224E",
    bumpe: "\u224F",
    bumpeq: "\u224F",
    HumpEqual: "\u224F",
    le: "\u2264",
    LessEqual: "\u2264",
    ge: "\u2265",
    GreaterEqual: "\u2265",
    lesseqgtr: "\u22DA",
    lesseqqgtr: "\u2A8B",
    greater: ">",
    less: "<",
  },
  ri = {
    alefsym: "\u2135",
    aleph: "\u2135",
    beth: "\u2136",
    gimel: "\u2137",
    daleth: "\u2138",
    forall: "\u2200",
    ForAll: "\u2200",
    part: "\u2202",
    PartialD: "\u2202",
    exist: "\u2203",
    Exists: "\u2203",
    nexist: "\u2204",
    nexists: "\u2204",
    empty: "\u2205",
    emptyset: "\u2205",
    emptyv: "\u2205",
    varnothing: "\u2205",
    nabla: "\u2207",
    Del: "\u2207",
    isin: "\u2208",
    isinv: "\u2208",
    in: "\u2208",
    Element: "\u2208",
    notin: "\u2209",
    notinva: "\u2209",
    ni: "\u220B",
    niv: "\u220B",
    SuchThat: "\u220B",
    ReverseElement: "\u220B",
    notni: "\u220C",
    notniva: "\u220C",
    prod: "\u220F",
    Product: "\u220F",
    coprod: "\u2210",
    Coproduct: "\u2210",
    sum: "\u2211",
    Sum: "\u2211",
    minus: "\u2212",
    mp: "\u2213",
    plusdo: "\u2214",
    dotplus: "\u2214",
    setminus: "\u2216",
    lowast: "\u2217",
    radic: "\u221A",
    Sqrt: "\u221A",
    prop: "\u221D",
    propto: "\u221D",
    Proportional: "\u221D",
    varpropto: "\u221D",
    infin: "\u221E",
    infintie: "\u29DD",
    ang: "\u2220",
    angle: "\u2220",
    angmsd: "\u2221",
    measuredangle: "\u2221",
    angsph: "\u2222",
    mid: "\u2223",
    VerticalBar: "\u2223",
    nmid: "\u2224",
    nsmid: "\u2224",
    npar: "\u2226",
    parallel: "\u2225",
    spar: "\u2225",
    nparallel: "\u2226",
    nspar: "\u2226",
    and: "\u2227",
    wedge: "\u2227",
    or: "\u2228",
    vee: "\u2228",
    cap: "\u2229",
    cup: "\u222A",
    int: "\u222B",
    Integral: "\u222B",
    conint: "\u222E",
    ContourIntegral: "\u222E",
    Conint: "\u222F",
    DoubleContourIntegral: "\u222F",
    Cconint: "\u2230",
    there4: "\u2234",
    therefore: "\u2234",
    Therefore: "\u2234",
    becaus: "\u2235",
    because: "\u2235",
    Because: "\u2235",
    ratio: "\u2236",
    Proportion: "\u2237",
    minusd: "\u2238",
    dotminus: "\u2238",
    mDDot: "\u223A",
    homtht: "\u223B",
    sim: "\u223C",
    bsimg: "\u223D",
    backsim: "\u223D",
    ac: "\u223E",
    mstpos: "\u223E",
    acd: "\u223F",
    VerticalTilde: "\u2240",
    wr: "\u2240",
    wreath: "\u2240",
    nsime: "\u2244",
    nsimeq: "\u2244",
    ncong: "\u2247",
    simne: "\u2246",
    ncongdot: "\u2A6D\u0338",
    ngsim: "\u2275",
    nsim: "\u2241",
    napprox: "\u2249",
    nap: "\u2249",
    ngeq: "\u2271",
    nge: "\u2271",
    nleq: "\u2270",
    nle: "\u2270",
    ngtr: "\u226F",
    ngt: "\u226F",
    nless: "\u226E",
    nlt: "\u226E",
    nprec: "\u2280",
    npr: "\u2280",
    nsucc: "\u2281",
    nsc: "\u2281",
  },
  ii = {
    larr: "\u2190",
    leftarrow: "\u2190",
    LeftArrow: "\u2190",
    uarr: "\u2191",
    uparrow: "\u2191",
    UpArrow: "\u2191",
    rarr: "\u2192",
    rightarrow: "\u2192",
    RightArrow: "\u2192",
    darr: "\u2193",
    downarrow: "\u2193",
    DownArrow: "\u2193",
    harr: "\u2194",
    leftrightarrow: "\u2194",
    LeftRightArrow: "\u2194",
    varr: "\u2195",
    updownarrow: "\u2195",
    UpDownArrow: "\u2195",
    nwarr: "\u2196",
    nwarrow: "\u2196",
    UpperLeftArrow: "\u2196",
    nearr: "\u2197",
    nearrow: "\u2197",
    UpperRightArrow: "\u2197",
    searr: "\u2198",
    searrow: "\u2198",
    LowerRightArrow: "\u2198",
    swarr: "\u2199",
    swarrow: "\u2199",
    LowerLeftArrow: "\u2199",
    lArr: "\u21D0",
    Leftarrow: "\u21D0",
    uArr: "\u21D1",
    Uparrow: "\u21D1",
    rArr: "\u21D2",
    Rightarrow: "\u21D2",
    dArr: "\u21D3",
    Downarrow: "\u21D3",
    hArr: "\u21D4",
    Leftrightarrow: "\u21D4",
    iff: "\u21D4",
    vArr: "\u21D5",
    Updownarrow: "\u21D5",
    lAarr: "\u21DA",
    Lleftarrow: "\u21DA",
    rAarr: "\u21DB",
    Rrightarrow: "\u21DB",
    lrarr: "\u21C6",
    leftrightarrows: "\u21C6",
    rlarr: "\u21C4",
    rightleftarrows: "\u21C4",
    lrhar: "\u21CB",
    leftrightharpoons: "\u21CB",
    ReverseEquilibrium: "\u21CB",
    rlhar: "\u21CC",
    rightleftharpoons: "\u21CC",
    Equilibrium: "\u21CC",
    udarr: "\u21C5",
    UpArrowDownArrow: "\u21C5",
    duarr: "\u21F5",
    DownArrowUpArrow: "\u21F5",
    llarr: "\u21C7",
    leftleftarrows: "\u21C7",
    rrarr: "\u21C9",
    rightrightarrows: "\u21C9",
    ddarr: "\u21CA",
    downdownarrows: "\u21CA",
    har: "\u21BD",
    lhard: "\u21BD",
    leftharpoondown: "\u21BD",
    lharu: "\u21BC",
    leftharpoonup: "\u21BC",
    rhard: "\u21C1",
    rightharpoondown: "\u21C1",
    rharu: "\u21C0",
    rightharpoonup: "\u21C0",
    lsh: "\u21B0",
    Lsh: "\u21B0",
    rsh: "\u21B1",
    Rsh: "\u21B1",
    ldsh: "\u21B2",
    rdsh: "\u21B3",
    hookleftarrow: "\u21A9",
    hookrightarrow: "\u21AA",
    mapstoleft: "\u21A4",
    mapstoup: "\u21A5",
    map: "\u21A6",
    mapsto: "\u21A6",
    mapstodown: "\u21A7",
    crarr: "\u21B5",
    nleftarrow: "\u219A",
    nleftrightarrow: "\u21AE",
    nrightarrow: "\u219B",
    nrarr: "\u219B",
    larrtl: "\u21A2",
    rarrtl: "\u21A3",
    leftarrowtail: "\u21A2",
    rightarrowtail: "\u21A3",
    twoheadleftarrow: "\u219E",
    twoheadrightarrow: "\u21A0",
    Larr: "\u219E",
    Rarr: "\u21A0",
    larrhk: "\u21A9",
    rarrhk: "\u21AA",
    larrlp: "\u21AB",
    looparrowleft: "\u21AB",
    rarrlp: "\u21AC",
    looparrowright: "\u21AC",
    harrw: "\u21AD",
    leftrightsquigarrow: "\u21AD",
    nrarrw: "\u219D\u0338",
    rarrw: "\u219D",
    rightsquigarrow: "\u219D",
    larrbfs: "\u291F",
    rarrbfs: "\u2920",
    nvHarr: "\u2904",
    nvlArr: "\u2902",
    nvrArr: "\u2903",
    larrfs: "\u291D",
    rarrfs: "\u291E",
    Map: "\u2905",
    larrsim: "\u2973",
    rarrsim: "\u2974",
    harrcir: "\u2948",
    Uarrocir: "\u2949",
    lurdshar: "\u294A",
    ldrdhar: "\u2967",
    ldrushar: "\u294B",
    rdldhar: "\u2969",
    lrhard: "\u296D",
    uharr: "\u21BE",
    uharl: "\u21BF",
    dharr: "\u21C2",
    dharl: "\u21C3",
    Uarr: "\u219F",
    Darr: "\u21A1",
    zigrarr: "\u21DD",
    nwArr: "\u21D6",
    neArr: "\u21D7",
    seArr: "\u21D8",
    swArr: "\u21D9",
    nharr: "\u21AE",
    nhArr: "\u21CE",
    nlarr: "\u219A",
    nlArr: "\u21CD",
    nrArr: "\u21CF",
    larrb: "\u21E4",
    LeftArrowBar: "\u21E4",
    rarrb: "\u21E5",
    RightArrowBar: "\u21E5",
  },
  ni = {
    square: "\u25A1",
    Square: "\u25A1",
    squ: "\u25A1",
    squf: "\u25AA",
    squarf: "\u25AA",
    blacksquar: "\u25AA",
    blacksquare: "\u25AA",
    FilledVerySmallSquare: "\u25AA",
    blk34: "\u2593",
    blk12: "\u2592",
    blk14: "\u2591",
    block: "\u2588",
    srect: "\u25AD",
    rect: "\u25AD",
    sdot: "\u22C5",
    sdotb: "\u22A1",
    dotsquare: "\u22A1",
    triangle: "\u25B5",
    tri: "\u25B5",
    trine: "\u25B5",
    utri: "\u25B5",
    triangledown: "\u25BF",
    dtri: "\u25BF",
    tridown: "\u25BF",
    triangleleft: "\u25C3",
    ltri: "\u25C3",
    triangleright: "\u25B9",
    rtri: "\u25B9",
    blacktriangle: "\u25B4",
    utrif: "\u25B4",
    blacktriangledown: "\u25BE",
    dtrif: "\u25BE",
    blacktriangleleft: "\u25C2",
    ltrif: "\u25C2",
    blacktriangleright: "\u25B8",
    rtrif: "\u25B8",
    loz: "\u25CA",
    lozenge: "\u25CA",
    blacklozenge: "\u29EB",
    lozf: "\u29EB",
    bigcirc: "\u25EF",
    xcirc: "\u25EF",
    circ: "\u02C6",
    Circle: "\u25CB",
    cir: "\u25CB",
    o: "\u25CB",
    bullet: "\u2022",
    bull: "\u2022",
    hellip: "\u2026",
    mldr: "\u2026",
    nldr: "\u2025",
    boxh: "\u2500",
    HorizontalLine: "\u2500",
    boxv: "\u2502",
    boxdr: "\u250C",
    boxdl: "\u2510",
    boxur: "\u2514",
    boxul: "\u2518",
    boxvr: "\u251C",
    boxvl: "\u2524",
    boxhd: "\u252C",
    boxhu: "\u2534",
    boxvh: "\u253C",
    boxH: "\u2550",
    boxV: "\u2551",
    boxdR: "\u2552",
    boxDr: "\u2553",
    boxDR: "\u2554",
    boxDl: "\u2555",
    boxdL: "\u2556",
    boxDL: "\u2557",
    boxuR: "\u2558",
    boxUr: "\u2559",
    boxUR: "\u255A",
    boxUl: "\u255C",
    boxuL: "\u255B",
    boxUL: "\u255D",
    boxvR: "\u255E",
    boxVr: "\u255F",
    boxVR: "\u2560",
    boxVl: "\u2562",
    boxvL: "\u2561",
    boxVL: "\u2563",
    boxHd: "\u2564",
    boxhD: "\u2565",
    boxHD: "\u2566",
    boxHu: "\u2567",
    boxhU: "\u2568",
    boxHU: "\u2569",
    boxvH: "\u256A",
    boxVh: "\u256B",
    boxVH: "\u256C",
  },
  oi = {
    excl: "!",
    iexcl: "\xA1",
    brvbar: "\xA6",
    sect: "\xA7",
    uml: "\xA8",
    copy: "\xA9",
    ordf: "\xAA",
    laquo: "\xAB",
    not: "\xAC",
    shy: "\xAD",
    reg: "\xAE",
    macr: "\xAF",
    deg: "\xB0",
    plusmn: "\xB1",
    sup2: "\xB2",
    sup3: "\xB3",
    acute: "\xB4",
    micro: "\xB5",
    para: "\xB6",
    middot: "\xB7",
    cedil: "\xB8",
    sup1: "\xB9",
    ordm: "\xBA",
    raquo: "\xBB",
    frac14: "\xBC",
    frac12: "\xBD",
    frac34: "\xBE",
    iquest: "\xBF",
    nbsp: "\xA0",
    comma: ",",
    period: ".",
    colon: ":",
    semi: ";",
    vert: "|",
    Verbar: "\u2016",
    verbar: "|",
    dblac: "\u02DD",
    circ: "\u02C6",
    caron: "\u02C7",
    breve: "\u02D8",
    dot: "\u02D9",
    ring: "\u02DA",
    ogon: "\u02DB",
    tilde: "\u02DC",
    DiacriticalGrave: "`",
    DiacriticalAcute: "\xB4",
    DiacriticalTilde: "\u02DC",
    DiacriticalDot: "\u02D9",
    DiacriticalDoubleAcute: "\u02DD",
    grave: "`",
  },
  nt = {
    cent: "\xA2",
    pound: "\xA3",
    curren: "\xA4",
    yen: "\xA5",
    euro: "\u20AC",
    dollar: "$",
    fnof: "\u0192",
    inr: "\u20B9",
    af: "\u060B",
    birr: "\u1265\u122D",
    peso: "\u20B1",
    rub: "\u20BD",
    won: "\u20A9",
    yuan: "\xA5",
    cedil: "\xB8",
  },
  ai = {
    frac12: "\xBD",
    half: "\xBD",
    frac13: "\u2153",
    frac14: "\xBC",
    frac15: "\u2155",
    frac16: "\u2159",
    frac18: "\u215B",
    frac23: "\u2154",
    frac25: "\u2156",
    frac34: "\xBE",
    frac35: "\u2157",
    frac38: "\u215C",
    frac45: "\u2158",
    frac56: "\u215A",
    frac58: "\u215D",
    frac78: "\u215E",
    frasl: "\u2044",
  },
  si = {
    trade: "\u2122",
    TRADE: "\u2122",
    telrec: "\u2315",
    target: "\u2316",
    ulcorn: "\u231C",
    ulcorner: "\u231C",
    urcorn: "\u231D",
    urcorner: "\u231D",
    dlcorn: "\u231E",
    llcorner: "\u231E",
    drcorn: "\u231F",
    lrcorner: "\u231F",
    intercal: "\u22BA",
    intcal: "\u22BA",
    oplus: "\u2295",
    CirclePlus: "\u2295",
    ominus: "\u2296",
    CircleMinus: "\u2296",
    otimes: "\u2297",
    CircleTimes: "\u2297",
    osol: "\u2298",
    odot: "\u2299",
    CircleDot: "\u2299",
    oast: "\u229B",
    circledast: "\u229B",
    odash: "\u229D",
    circleddash: "\u229D",
    ocirc: "\u229A",
    circledcirc: "\u229A",
    boxplus: "\u229E",
    plusb: "\u229E",
    boxminus: "\u229F",
    minusb: "\u229F",
    boxtimes: "\u22A0",
    timesb: "\u22A0",
    boxdot: "\u22A1",
    sdotb: "\u22A1",
    veebar: "\u22BB",
    vee: "\u2228",
    barvee: "\u22BD",
    and: "\u2227",
    wedge: "\u2227",
    Cap: "\u22D2",
    Cup: "\u22D3",
    Fork: "\u22D4",
    pitchfork: "\u22D4",
    epar: "\u22D5",
    ltlarr: "\u2976",
    nvap: "\u224D\u20D2",
    nvsim: "\u223C\u20D2",
    nvge: "\u2265\u20D2",
    nvle: "\u2264\u20D2",
    nvlt: "<\u20D2",
    nvgt: ">\u20D2",
    nvltrie: "\u22B4\u20D2",
    nvrtrie: "\u22B5\u20D2",
    Vdash: "\u22A9",
    dashv: "\u22A3",
    vDash: "\u22A8",
    Vvdash: "\u22AA",
    nvdash: "\u22AC",
    nvDash: "\u22AD",
    nVdash: "\u22AE",
    nVDash: "\u22AF",
  },
  xn = {
    ...jr,
    ...zr,
    ...qr,
    ...$r,
    ...ei,
    ...ti,
    ...ri,
    ...ii,
    ...ni,
    ...oi,
    ...nt,
    ...ai,
    ...si,
  },
  Ue = { amp: "&", apos: "'", gt: ">", lt: "<", quot: '"' },
  Bt = {
    nbsp: "\xA0",
    copy: "\xA9",
    reg: "\xAE",
    trade: "\u2122",
    mdash: "\u2014",
    ndash: "\u2013",
    hellip: "\u2026",
    laquo: "\xAB",
    raquo: "\xBB",
    lsquo: "\u2018",
    rsquo: "\u2019",
    ldquo: "\u201C",
    rdquo: "\u201D",
    bull: "\u2022",
    para: "\xB6",
    sect: "\xA7",
    deg: "\xB0",
    frac12: "\xBD",
    frac14: "\xBC",
    frac34: "\xBE",
  };
var Bn = new Set("!?\\\\/[]$%{}^&*()<>|+");
function Ai(t) {
  if (t[0] === "#")
    throw new Error(
      `[EntityReplacer] Invalid character '#' in entity name: "${t}"`,
    );
  for (let e of t)
    if (Bn.has(e))
      throw new Error(
        `[EntityReplacer] Invalid character '${e}' in entity name: "${t}"`,
      );
  return t;
}
function Rt(...t) {
  let e = Object.create(null);
  for (let r of t)
    if (r)
      for (let i of Object.keys(r)) {
        let n = r[i];
        if (typeof n == "string") e[i] = n;
        else if (n && typeof n == "object" && n.val !== void 0) {
          let o = n.val;
          typeof o == "string" && (e[i] = o);
        }
      }
  return e;
}
var pe = "external",
  ot = "base",
  Vt = "all";
function Rn(t) {
  return !t || t === pe
    ? new Set([pe])
    : t === Vt
      ? new Set([Vt])
      : t === ot
        ? new Set([ot])
        : Array.isArray(t)
          ? new Set(t)
          : new Set([pe]);
}
var K = Object.freeze({ allow: 0, leave: 1, remove: 2, throw: 3 }),
  Vn = new Set([9, 10, 13]);
function Nn(t) {
  if (!t) return { xmlVersion: 1, onLevel: K.allow, nullLevel: K.remove };
  let e = t.xmlVersion === 1.1 ? 1.1 : 1,
    r = K[t.onNCR] ?? K.allow,
    i = K[t.nullNCR] ?? K.remove,
    n = Math.max(i, K.remove);
  return { xmlVersion: e, onLevel: r, nullLevel: n };
}
var ve = class {
  constructor(e = {}) {
    ((this._limit = e.limit || {}),
      (this._maxTotalExpansions = this._limit.maxTotalExpansions || 0),
      (this._maxExpandedLength = this._limit.maxExpandedLength || 0),
      (this._postCheck =
        typeof e.postCheck == "function" ? e.postCheck : (i) => i),
      (this._limitTiers = Rn(this._limit.applyLimitsTo ?? pe)),
      (this._numericAllowed = e.numericAllowed ?? !0),
      (this._baseMap = Rt(Ue, e.namedEntities || null)),
      (this._externalMap = Object.create(null)),
      (this._inputMap = Object.create(null)),
      (this._totalExpansions = 0),
      (this._expandedLength = 0),
      (this._removeSet = new Set(
        e.remove && Array.isArray(e.remove) ? e.remove : [],
      )),
      (this._leaveSet = new Set(
        e.leave && Array.isArray(e.leave) ? e.leave : [],
      )));
    let r = Nn(e.ncr);
    ((this._ncrXmlVersion = r.xmlVersion),
      (this._ncrOnLevel = r.onLevel),
      (this._ncrNullLevel = r.nullLevel));
  }
  setExternalEntities(e) {
    if (e) for (let r of Object.keys(e)) Ai(r);
    this._externalMap = Rt(e);
  }
  addExternalEntity(e, r) {
    (Ai(e),
      typeof r == "string" &&
        r.indexOf("&") === -1 &&
        (this._externalMap[e] = r));
  }
  addInputEntities(e) {
    ((this._totalExpansions = 0),
      (this._expandedLength = 0),
      (this._inputMap = Rt(e)));
  }
  reset() {
    return (
      (this._inputMap = Object.create(null)),
      (this._totalExpansions = 0),
      (this._expandedLength = 0),
      this
    );
  }
  setXmlVersion(e) {
    this._ncrXmlVersion = e === 1.1 ? 1.1 : 1;
  }
  decode(e) {
    if (typeof e != "string" || e.length === 0 || e.indexOf("&") === -1)
      return e;
    let r = e,
      i = [],
      n = e.length,
      o = 0,
      a = 0,
      s = this._maxTotalExpansions > 0,
      u = this._maxExpandedLength > 0,
      A = s || u;
    for (; a < n;) {
      if (e.charCodeAt(a) !== 38) {
        a++;
        continue;
      }
      let d = a + 1;
      for (; d < n && e.charCodeAt(d) !== 59 && d - a <= 32;) d++;
      if (d >= n || e.charCodeAt(d) !== 59) {
        a++;
        continue;
      }
      let f = e.slice(a + 1, d);
      if (f.length === 0) {
        a++;
        continue;
      }
      let _, h;
      if (this._removeSet.has(f)) ((_ = ""), h === void 0 && (h = pe));
      else if (this._leaveSet.has(f)) {
        a++;
        continue;
      } else if (f.charCodeAt(0) === 35) {
        let c = this._resolveNCR(f);
        if (c === void 0) {
          a++;
          continue;
        }
        ((_ = c), (h = ot));
      } else {
        let c = this._resolveName(f);
        ((_ = c?.value), (h = c?.tier));
      }
      if (_ === void 0) {
        a++;
        continue;
      }
      if (
        (a > o && i.push(e.slice(o, a)),
        i.push(_),
        (o = d + 1),
        (a = o),
        A && this._tierCounts(h))
      ) {
        if (
          s &&
          (this._totalExpansions++,
          this._totalExpansions > this._maxTotalExpansions)
        )
          throw new Error(
            `[EntityReplacer] Entity expansion count limit exceeded: ${this._totalExpansions} > ${this._maxTotalExpansions}`,
          );
        if (u) {
          let c = _.length - (f.length + 2);
          if (
            c > 0 &&
            ((this._expandedLength += c),
            this._expandedLength > this._maxExpandedLength)
          )
            throw new Error(
              `[EntityReplacer] Expanded content length limit exceeded: ${this._expandedLength} > ${this._maxExpandedLength}`,
            );
        }
      }
    }
    o < n && i.push(e.slice(o));
    let l = i.length === 0 ? e : i.join("");
    return this._postCheck(l, r);
  }
  _tierCounts(e) {
    return this._limitTiers.has(Vt) ? !0 : this._limitTiers.has(e);
  }
  _resolveName(e) {
    if (e in this._inputMap) return { value: this._inputMap[e], tier: pe };
    if (e in this._externalMap)
      return { value: this._externalMap[e], tier: pe };
    if (e in this._baseMap) return { value: this._baseMap[e], tier: ot };
  }
  _classifyNCR(e) {
    return e === 0
      ? this._ncrNullLevel
      : (e >= 55296 && e <= 57343) ||
          (this._ncrXmlVersion === 1 && e >= 1 && e <= 31 && !Vn.has(e))
        ? K.remove
        : -1;
  }
  _applyNCRAction(e, r, i) {
    switch (e) {
      case K.allow:
        return String.fromCodePoint(i);
      case K.remove:
        return "";
      case K.leave:
        return;
      case K.throw:
        throw new Error(
          `[EntityDecoder] Prohibited numeric character reference &${r}; (U+${i.toString(16).toUpperCase().padStart(4, "0")})`,
        );
      default:
        return String.fromCodePoint(i);
    }
  }
  _resolveNCR(e) {
    let r = e.charCodeAt(1),
      i;
    if (
      (r === 120 || r === 88
        ? (i = parseInt(e.slice(2), 16))
        : (i = parseInt(e.slice(1), 10)),
      Number.isNaN(i) || i < 0 || i > 1114111)
    )
      return;
    let n = this._classifyNCR(i);
    if (!this._numericAllowed && n < K.remove) return;
    let o = n === -1 ? this._ncrOnLevel : Math.max(this._ncrOnLevel, n);
    return this._applyNCRAction(o, e, i);
  }
};
var li = (t) => (Le.includes(t) ? "__" + t : t),
  Mn = {
    preserveOrder: !1,
    attributeNamePrefix: "@_",
    attributesGroupName: !1,
    textNodeName: "#text",
    ignoreAttributes: !0,
    removeNSPrefix: !1,
    allowBooleanAttributes: !1,
    parseTagValue: !0,
    parseAttributeValue: !1,
    trimValues: !0,
    cdataPropName: !1,
    numberParseOptions: { hex: !0, leadingZeros: !0, eNotation: !0 },
    tagValueProcessor: function (t, e) {
      return e;
    },
    attributeValueProcessor: function (t, e) {
      return e;
    },
    stopNodes: [],
    alwaysCreateTextNode: !1,
    isArray: () => !1,
    commentPropName: !1,
    unpairedTags: [],
    processEntities: !0,
    htmlEntities: !1,
    entityDecoder: null,
    ignoreDeclaration: !1,
    ignorePiTags: !1,
    transformTagName: !1,
    transformAttributeName: !1,
    updateTag: function (t, e, r) {
      return t;
    },
    captureMetaData: !1,
    maxNestedTags: 100,
    strictReservedNames: !0,
    jPath: !0,
    onDangerousProperty: li,
  };
function Pn(t, e) {
  if (typeof t != "string") return;
  let r = t.toLowerCase();
  if (Le.some((i) => r === i.toLowerCase()))
    throw new Error(
      `[SECURITY] Invalid ${e}: "${t}" is a reserved JavaScript keyword that could cause prototype pollution`,
    );
  if (it.some((i) => r === i.toLowerCase()))
    throw new Error(
      `[SECURITY] Invalid ${e}: "${t}" is a reserved JavaScript keyword that could cause prototype pollution`,
    );
}
function ui(t, e) {
  return typeof t == "boolean"
    ? {
        enabled: t,
        maxEntitySize: 1e4,
        maxExpansionDepth: 1e4,
        maxTotalExpansions: 1 / 0,
        maxExpandedLength: 1e5,
        maxEntityCount: 1e3,
        allowedTags: null,
        tagFilter: null,
        appliesTo: "all",
      }
    : typeof t == "object" && t !== null
      ? {
          enabled: t.enabled !== !1,
          maxEntitySize: Math.max(1, t.maxEntitySize ?? 1e4),
          maxExpansionDepth: Math.max(1, t.maxExpansionDepth ?? 1e4),
          maxTotalExpansions: Math.max(1, t.maxTotalExpansions ?? 1 / 0),
          maxExpandedLength: Math.max(1, t.maxExpandedLength ?? 1e5),
          maxEntityCount: Math.max(1, t.maxEntityCount ?? 1e3),
          allowedTags: t.allowedTags ?? null,
          tagFilter: t.tagFilter ?? null,
          appliesTo: t.appliesTo ?? "all",
        }
      : ui(!0);
}
var ci = function (t) {
  let e = Object.assign({}, Mn, t),
    r = [
      { value: e.attributeNamePrefix, name: "attributeNamePrefix" },
      { value: e.attributesGroupName, name: "attributesGroupName" },
      { value: e.textNodeName, name: "textNodeName" },
      { value: e.cdataPropName, name: "cdataPropName" },
      { value: e.commentPropName, name: "commentPropName" },
    ];
  for (let { value: i, name: n } of r) i && Pn(i, n);
  return (
    e.onDangerousProperty === null && (e.onDangerousProperty = li),
    (e.processEntities = ui(e.processEntities, e.htmlEntities)),
    (e.unpairedTagsSet = new Set(e.unpairedTags)),
    e.stopNodes &&
      Array.isArray(e.stopNodes) &&
      (e.stopNodes = e.stopNodes.map((i) =>
        typeof i == "string" && i.startsWith("*.") ? ".." + i.substring(2) : i,
      )),
    e
  );
};
var at;
typeof Symbol != "function"
  ? (at = "@@xmlMetadata")
  : (at = Symbol("XML Node Metadata"));
var W = class {
  constructor(e) {
    ((this.tagname = e), (this.child = []), (this[":@"] = Object.create(null)));
  }
  add(e, r) {
    (e === "__proto__" && (e = "#__proto__"), this.child.push({ [e]: r }));
  }
  addChild(e, r) {
    (e.tagname === "__proto__" && (e.tagname = "#__proto__"),
      e[":@"] && Object.keys(e[":@"]).length > 0
        ? this.child.push({ [e.tagname]: e.child, ":@": e[":@"] })
        : this.child.push({ [e.tagname]: e.child }),
      r !== void 0 &&
        (this.child[this.child.length - 1][at] = { startIndex: r }));
  }
  static getMetaDataSymbol() {
    return at;
  }
};
var di =
    ":A-Za-z_\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u0486\u0488-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD",
  kn = di + "\\-\\.\\d\xB7\u0300-\u036F\u203F-\u2040",
  fi =
    ":A-Za-z_\xC0-\u02FF\u0370-\u037D\u037F-\u0486\u0488-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}",
  On = fi + "\\-\\.\\d\xB7\u0300-\u036F\u0487\u203F-\u2040",
  pi = (t, e, r = "") => {
    let i = t.replace(":", ""),
      n = e.replace(":", ""),
      o = `[${i}][${n}]*`;
    return {
      name: new RegExp(`^[${t}][${e}]*$`, r),
      ncName: new RegExp(`^${o}$`, r),
      qName: new RegExp(`^${o}(?::${o})?$`, r),
      nmToken: new RegExp(`^[${e}]+$`, r),
      nmTokens: new RegExp(`^[${e}]+(?:\\s+[${e}]+)*$`, r),
    };
  },
  Ln = pi(di, kn),
  Gn = pi(fi, On, "u"),
  Un = (t = "1.0") => (t === "1.1" ? Gn : Ln);
var Nt = (t, { xmlVersion: e = "1.0" } = {}) => Un(e).qName.test(t);
var Qe = class {
    constructor(e, r) {
      ((this.suppressValidationErr = !e),
        (this.options = e),
        (this.xmlVersion = r || 1));
    }
    setXmlVersion(e = 1) {
      this.xmlVersion = e;
    }
    readDocType(e, r) {
      let i = Object.create(null),
        n = 0;
      if (
        e[r + 3] === "O" &&
        e[r + 4] === "C" &&
        e[r + 5] === "T" &&
        e[r + 6] === "Y" &&
        e[r + 7] === "P" &&
        e[r + 8] === "E"
      ) {
        r = r + 9;
        let o = 1,
          a = !1,
          s = !1,
          u = "";
        for (; r < e.length; r++)
          if (e[r] === "<" && !s) {
            if (a && me(e, "!ENTITY", r)) {
              r += 7;
              let A, l;
              if (
                (([A, l, r] = this.readEntityExp(
                  e,
                  r + 1,
                  this.suppressValidationErr,
                )),
                l.indexOf("&") === -1)
              ) {
                if (
                  this.options.enabled !== !1 &&
                  this.options.maxEntityCount != null &&
                  n >= this.options.maxEntityCount
                )
                  throw new Error(
                    `Entity count (${n + 1}) exceeds maximum allowed (${this.options.maxEntityCount})`,
                  );
                ((i[A] = l), n++);
              }
            } else if (a && me(e, "!ELEMENT", r)) {
              r += 8;
              let { index: A } = this.readElementExp(e, r + 1);
              r = A;
            } else if (a && me(e, "!ATTLIST", r)) r += 8;
            else if (a && me(e, "!NOTATION", r)) {
              r += 9;
              let { index: A } = this.readNotationExp(
                e,
                r + 1,
                this.suppressValidationErr,
              );
              r = A;
            } else if (me(e, "!--", r)) s = !0;
            else throw new Error("Invalid DOCTYPE");
            (o++, (u = ""));
          } else if (e[r] === ">") {
            if (
              (s
                ? e[r - 1] === "-" && e[r - 2] === "-" && ((s = !1), o--)
                : o--,
              o === 0)
            )
              break;
          } else e[r] === "[" ? (a = !0) : (u += e[r]);
        if (o !== 0) throw new Error("Unclosed DOCTYPE");
      } else throw new Error("Invalid Tag instead of DOCTYPE");
      return { entities: i, i: r };
    }
    readEntityExp(e, r) {
      r = H(e, r);
      let i = r;
      for (; r < e.length && !/\s/.test(e[r]) && e[r] !== '"' && e[r] !== "'";)
        r++;
      let n = e.substring(i, r);
      if (
        (Ye(n, { xmlVersion: this.xmlVersion }),
        (r = H(e, r)),
        !this.suppressValidationErr)
      ) {
        if (e.substring(r, r + 6).toUpperCase() === "SYSTEM")
          throw new Error("External entities are not supported");
        if (e[r] === "%")
          throw new Error("Parameter entities are not supported");
      }
      let o = "";
      if (
        (([r, o] = this.readIdentifierVal(e, r, "entity")),
        this.options.enabled !== !1 &&
          this.options.maxEntitySize != null &&
          o.length > this.options.maxEntitySize)
      )
        throw new Error(
          `Entity "${n}" size (${o.length}) exceeds maximum allowed size (${this.options.maxEntitySize})`,
        );
      return (r--, [n, o, r]);
    }
    readNotationExp(e, r) {
      r = H(e, r);
      let i = r;
      for (; r < e.length && !/\s/.test(e[r]);) r++;
      let n = e.substring(i, r);
      (!this.suppressValidationErr && Ye(n, { xmlVersion: this.xmlVersion }),
        (r = H(e, r)));
      let o = e.substring(r, r + 6).toUpperCase();
      if (!this.suppressValidationErr && o !== "SYSTEM" && o !== "PUBLIC")
        throw new Error(`Expected SYSTEM or PUBLIC, found "${o}"`);
      ((r += o.length), (r = H(e, r)));
      let a = null,
        s = null;
      if (o === "PUBLIC")
        (([r, a] = this.readIdentifierVal(e, r, "publicIdentifier")),
          (r = H(e, r)),
          (e[r] === '"' || e[r] === "'") &&
            ([r, s] = this.readIdentifierVal(e, r, "systemIdentifier")));
      else if (
        o === "SYSTEM" &&
        (([r, s] = this.readIdentifierVal(e, r, "systemIdentifier")),
        !this.suppressValidationErr && !s)
      )
        throw new Error(
          "Missing mandatory system identifier for SYSTEM notation",
        );
      return {
        notationName: n,
        publicIdentifier: a,
        systemIdentifier: s,
        index: --r,
      };
    }
    readIdentifierVal(e, r, i) {
      let n = "",
        o = e[r];
      if (o !== '"' && o !== "'")
        throw new Error(`Expected quoted string, found "${o}"`);
      r++;
      let a = r;
      for (; r < e.length && e[r] !== o;) r++;
      if (((n = e.substring(a, r)), e[r] !== o))
        throw new Error(`Unterminated ${i} value`);
      return (r++, [r, n]);
    }
    readElementExp(e, r) {
      r = H(e, r);
      let i = r;
      for (; r < e.length && !/\s/.test(e[r]);) r++;
      let n = e.substring(i, r);
      if (
        !this.suppressValidationErr &&
        !Nt(n, { xmlVersion: this.xmlVersion })
      )
        throw new Error(`Invalid element name: "${n}"`);
      r = H(e, r);
      let o = "";
      if (e[r] === "E" && me(e, "MPTY", r)) r += 4;
      else if (e[r] === "A" && me(e, "NY", r)) r += 2;
      else if (e[r] === "(") {
        r++;
        let a = r;
        for (; r < e.length && e[r] !== ")";) r++;
        if (((o = e.substring(a, r)), e[r] !== ")"))
          throw new Error("Unterminated content model");
      } else if (!this.suppressValidationErr)
        throw new Error(`Invalid Element Expression, found "${e[r]}"`);
      return { elementName: n, contentModel: o.trim(), index: r };
    }
    readAttlistExp(e, r) {
      r = H(e, r);
      let i = r;
      for (; r < e.length && !/\s/.test(e[r]);) r++;
      let n = e.substring(i, r);
      for (
        Ye(n, { xmlVersion: this.xmlVersion }), r = H(e, r), i = r;
        r < e.length && !/\s/.test(e[r]);
      )
        r++;
      let o = e.substring(i, r);
      if (!Ye(o, { xmlVersion: this.xmlVersion }))
        throw new Error(`Invalid attribute name: "${o}"`);
      r = H(e, r);
      let a = "";
      if (e.substring(r, r + 8).toUpperCase() === "NOTATION") {
        if (((a = "NOTATION"), (r += 8), (r = H(e, r)), e[r] !== "("))
          throw new Error(`Expected '(', found "${e[r]}"`);
        r++;
        let u = [];
        for (; r < e.length && e[r] !== ")";) {
          let A = r;
          for (; r < e.length && e[r] !== "|" && e[r] !== ")";) r++;
          let l = e.substring(A, r);
          if (((l = l.trim()), !Ye(l, { xmlVersion: this.xmlVersion })))
            throw new Error(`Invalid notation name: "${l}"`);
          (u.push(l), e[r] === "|" && (r++, (r = H(e, r))));
        }
        if (e[r] !== ")") throw new Error("Unterminated list of notations");
        (r++, (a += " (" + u.join("|") + ")"));
      } else {
        let u = r;
        for (; r < e.length && !/\s/.test(e[r]);) r++;
        a += e.substring(u, r);
        let A = [
          "CDATA",
          "ID",
          "IDREF",
          "IDREFS",
          "ENTITY",
          "ENTITIES",
          "NMTOKEN",
          "NMTOKENS",
        ];
        if (!this.suppressValidationErr && !A.includes(a.toUpperCase()))
          throw new Error(`Invalid attribute type: "${a}"`);
      }
      r = H(e, r);
      let s = "";
      return (
        e.substring(r, r + 8).toUpperCase() === "#REQUIRED"
          ? ((s = "#REQUIRED"), (r += 8))
          : e.substring(r, r + 7).toUpperCase() === "#IMPLIED"
            ? ((s = "#IMPLIED"), (r += 7))
            : ([r, s] = this.readIdentifierVal(e, r, "ATTLIST")),
        {
          elementName: n,
          attributeName: o,
          attributeType: a,
          defaultValue: s,
          index: r,
        }
      );
    }
  },
  H = (t, e) => {
    for (; e < t.length && /\s/.test(t[e]);) e++;
    return e;
  };
function me(t, e, r) {
  for (let i = 0; i < e.length; i++) if (e[i] !== t[r + i + 1]) return !1;
  return !0;
}
function Ye(t, e) {
  if (Nt(t, { xmlVersion: e })) return t;
  throw new Error(`Invalid entity name ${t}`);
}
var Yn = /^[-+]?0x[a-fA-F0-9]+$/,
  Qn = /^0b[01]+$/,
  Kn = /^0o[0-7]+$/,
  Wn = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/,
  Hn = {
    hex: !0,
    binary: !1,
    octal: !1,
    leadingZeros: !0,
    decimalPoint: ".",
    eNotation: !0,
    infinity: "original",
  };
function Pt(t, e = {}) {
  if (((e = Object.assign({}, Hn, e)), !t || typeof t != "string")) return t;
  let r = t.trim();
  if (r.length === 0) return t;
  if (e.skipLike !== void 0 && e.skipLike.test(r)) return t;
  if (r === "0") return 0;
  if (e.hex && Yn.test(r)) return Mt(r, 16);
  if (e.binary && Qn.test(r)) return Mt(r, 2);
  if (e.octal && Kn.test(r)) return Mt(r, 8);
  if (isFinite(r)) {
    if (r.includes("e") || r.includes("E")) return Jn(t, r, e);
    {
      let i = Wn.exec(r);
      if (i) {
        let n = i[1] || "",
          o = i[2],
          a = Zn(i[3]),
          s = n ? t[o.length + 1] === "." : t[o.length] === ".";
        if (!e.leadingZeros && (o.length > 1 || (o.length === 1 && !s)))
          return t;
        {
          let u = Number(r),
            A = String(u);
          if (u === 0) return u;
          if (A.search(/[eE]/) !== -1) return e.eNotation ? u : t;
          if (r.indexOf(".") !== -1)
            return A === "0" || A === a || A === `${n}${a}` ? u : t;
          let l = o ? a : r;
          return o
            ? l === A || n + l === A
              ? u
              : t
            : l === A || l === n + A
              ? u
              : t;
        }
      } else return t;
    }
  } else return jn(t, Number(r), e);
}
var Xn = /^([-+])?(0*)(\d*(\.\d*)?[eE][-\+]?\d+)$/;
function Jn(t, e, r) {
  if (!r.eNotation) return t;
  let i = e.match(Xn);
  if (i) {
    let n = i[1] || "",
      o = i[3].indexOf("e") === -1 ? "E" : "e",
      a = i[2],
      s = n ? t[a.length + 1] === o : t[a.length] === o;
    return a.length > 1 && s
      ? t
      : a.length === 1 && (i[3].startsWith(`.${o}`) || i[3][0] === o)
        ? Number(e)
        : a.length > 0
          ? r.leadingZeros && !s
            ? ((e = (i[1] || "") + i[3]), Number(e))
            : t
          : Number(e);
  } else return t;
}
function Zn(t) {
  return (
    t &&
      t.indexOf(".") !== -1 &&
      ((t = t.replace(/0+$/, "")),
      t === "."
        ? (t = "0")
        : t[0] === "."
          ? (t = "0" + t)
          : t[t.length - 1] === "." && (t = t.substring(0, t.length - 1))),
    t
  );
}
function Mt(t, e) {
  let r = t.trim();
  if (((e === 2 || e === 8) && (t = r.substring(2)), parseInt))
    return parseInt(t, e);
  if (Number.parseInt) return Number.parseInt(t, e);
  if (window && window.parseInt) return window.parseInt(t, e);
  throw new Error(
    "parseInt, Number.parseInt, window.parseInt are not supported",
  );
}
function jn(t, e, r) {
  let i = e === 1 / 0;
  switch (r.infinity.toLowerCase()) {
    case "null":
      return null;
    case "infinity":
      return e;
    case "string":
      return i ? "Infinity" : "-Infinity";
    case "original":
    default:
      return t;
  }
}
function kt(t) {
  return typeof t == "function"
    ? t
    : Array.isArray(t)
      ? (e) => {
          for (let r of t)
            if (
              (typeof r == "string" && e === r) ||
              (r instanceof RegExp && r.test(e))
            )
              return !0;
        }
      : () => !1;
}
var _e = class {
  constructor(e, r = {}, i) {
    ((this.pattern = e),
      (this.separator = r.separator || "."),
      (this.segments = this._parse(e)),
      (this.data = i),
      (this._hasDeepWildcard = this.segments.some(
        (n) => n.type === "deep-wildcard",
      )),
      (this._hasAttributeCondition = this.segments.some(
        (n) => n.attrName !== void 0,
      )),
      (this._hasPositionSelector = this.segments.some(
        (n) => n.position !== void 0,
      )));
  }
  _parse(e) {
    let r = [],
      i = 0,
      n = "";
    for (; i < e.length;)
      e[i] === this.separator
        ? i + 1 < e.length && e[i + 1] === this.separator
          ? (n.trim() && (r.push(this._parseSegment(n.trim())), (n = "")),
            r.push({ type: "deep-wildcard" }),
            (i += 2))
          : (n.trim() && r.push(this._parseSegment(n.trim())), (n = ""), i++)
        : ((n += e[i]), i++);
    return (n.trim() && r.push(this._parseSegment(n.trim())), r);
  }
  _parseSegment(e) {
    let r = { type: "tag" },
      i = null,
      n = e,
      o = e.match(/^([^\[]+)(\[[^\]]*\])(.*)$/);
    if (o && ((n = o[1] + o[3]), o[2])) {
      let l = o[2].slice(1, -1);
      l && (i = l);
    }
    let a,
      s = n;
    if (n.includes("::")) {
      let l = n.indexOf("::");
      if (((a = n.substring(0, l).trim()), (s = n.substring(l + 2).trim()), !a))
        throw new Error(`Invalid namespace in pattern: ${e}`);
    }
    let u,
      A = null;
    if (s.includes(":")) {
      let l = s.lastIndexOf(":"),
        d = s.substring(0, l).trim(),
        f = s.substring(l + 1).trim();
      ["first", "last", "odd", "even"].includes(f) || /^nth\(\d+\)$/.test(f)
        ? ((u = d), (A = f))
        : (u = s);
    } else u = s;
    if (!u) throw new Error(`Invalid segment pattern: ${e}`);
    if (((r.tag = u), a && (r.namespace = a), i))
      if (i.includes("=")) {
        let l = i.indexOf("=");
        ((r.attrName = i.substring(0, l).trim()),
          (r.attrValue = i.substring(l + 1).trim()));
      } else r.attrName = i.trim();
    if (A) {
      let l = A.match(/^nth\((\d+)\)$/);
      l
        ? ((r.position = "nth"), (r.positionValue = parseInt(l[1], 10)))
        : (r.position = A);
    }
    return r;
  }
  get length() {
    return this.segments.length;
  }
  hasDeepWildcard() {
    return this._hasDeepWildcard;
  }
  hasAttributeCondition() {
    return this._hasAttributeCondition;
  }
  hasPositionSelector() {
    return this._hasPositionSelector;
  }
  toString() {
    return this.pattern;
  }
};
var Te = class {
  constructor() {
    ((this._byDepthAndTag = new Map()),
      (this._wildcardByDepth = new Map()),
      (this._deepWildcards = []),
      (this._patterns = new Set()),
      (this._sealed = !1));
  }
  add(e) {
    if (this._sealed)
      throw new TypeError(
        "ExpressionSet is sealed. Create a new ExpressionSet to add more expressions.",
      );
    if (this._patterns.has(e.pattern)) return this;
    if ((this._patterns.add(e.pattern), e.hasDeepWildcard()))
      return (this._deepWildcards.push(e), this);
    let r = e.length,
      n = e.segments[e.segments.length - 1]?.tag;
    if (!n || n === "*")
      (this._wildcardByDepth.has(r) || this._wildcardByDepth.set(r, []),
        this._wildcardByDepth.get(r).push(e));
    else {
      let o = `${r}:${n}`;
      (this._byDepthAndTag.has(o) || this._byDepthAndTag.set(o, []),
        this._byDepthAndTag.get(o).push(e));
    }
    return this;
  }
  addAll(e) {
    for (let r of e) this.add(r);
    return this;
  }
  has(e) {
    return this._patterns.has(e.pattern);
  }
  get size() {
    return this._patterns.size;
  }
  seal() {
    return ((this._sealed = !0), this);
  }
  get isSealed() {
    return this._sealed;
  }
  matchesAny(e) {
    return this.findMatch(e) !== null;
  }
  findMatch(e) {
    let r = e.getDepth(),
      i = e.getCurrentTag(),
      n = `${r}:${i}`,
      o = this._byDepthAndTag.get(n);
    if (o) {
      for (let s = 0; s < o.length; s++) if (e.matches(o[s])) return o[s];
    }
    let a = this._wildcardByDepth.get(r);
    if (a) {
      for (let s = 0; s < a.length; s++) if (e.matches(a[s])) return a[s];
    }
    for (let s = 0; s < this._deepWildcards.length; s++)
      if (e.matches(this._deepWildcards[s])) return this._deepWildcards[s];
    return null;
  }
};
var Ot = class {
    constructor(e) {
      this._matcher = e;
    }
    get separator() {
      return this._matcher.separator;
    }
    getCurrentTag() {
      let e = this._matcher.path;
      return e.length > 0 ? e[e.length - 1].tag : void 0;
    }
    getCurrentNamespace() {
      let e = this._matcher.path;
      return e.length > 0 ? e[e.length - 1].namespace : void 0;
    }
    getAttrValue(e) {
      let r = this._matcher.path;
      if (r.length !== 0) return r[r.length - 1].values?.[e];
    }
    hasAttr(e) {
      let r = this._matcher.path;
      if (r.length === 0) return !1;
      let i = r[r.length - 1];
      return i.values !== void 0 && e in i.values;
    }
    getPosition() {
      let e = this._matcher.path;
      return e.length === 0 ? -1 : (e[e.length - 1].position ?? 0);
    }
    getCounter() {
      let e = this._matcher.path;
      return e.length === 0 ? -1 : (e[e.length - 1].counter ?? 0);
    }
    getIndex() {
      return this.getPosition();
    }
    getDepth() {
      return this._matcher.path.length;
    }
    toString(e, r = !0) {
      return this._matcher.toString(e, r);
    }
    toArray() {
      return this._matcher.path.map((e) => e.tag);
    }
    matches(e) {
      return this._matcher.matches(e);
    }
    matchesAny(e) {
      return e.matchesAny(this._matcher);
    }
  },
  Se = class {
    constructor(e = {}) {
      ((this.separator = e.separator || "."),
        (this.path = []),
        (this.siblingStacks = []),
        (this._pathStringCache = null),
        (this._view = new Ot(this)));
    }
    push(e, r = null, i = null) {
      ((this._pathStringCache = null),
        this.path.length > 0 &&
          (this.path[this.path.length - 1].values = void 0));
      let n = this.path.length;
      this.siblingStacks[n] || (this.siblingStacks[n] = new Map());
      let o = this.siblingStacks[n],
        a = i ? `${i}:${e}` : e,
        s = o.get(a) || 0,
        u = 0;
      for (let l of o.values()) u += l;
      o.set(a, s + 1);
      let A = { tag: e, position: u, counter: s };
      (i != null && (A.namespace = i),
        r != null && (A.values = r),
        this.path.push(A));
    }
    pop() {
      if (this.path.length === 0) return;
      this._pathStringCache = null;
      let e = this.path.pop();
      return (
        this.siblingStacks.length > this.path.length + 1 &&
          (this.siblingStacks.length = this.path.length + 1),
        e
      );
    }
    updateCurrent(e) {
      if (this.path.length > 0) {
        let r = this.path[this.path.length - 1];
        e != null && (r.values = e);
      }
    }
    getCurrentTag() {
      return this.path.length > 0
        ? this.path[this.path.length - 1].tag
        : void 0;
    }
    getCurrentNamespace() {
      return this.path.length > 0
        ? this.path[this.path.length - 1].namespace
        : void 0;
    }
    getAttrValue(e) {
      if (this.path.length !== 0)
        return this.path[this.path.length - 1].values?.[e];
    }
    hasAttr(e) {
      if (this.path.length === 0) return !1;
      let r = this.path[this.path.length - 1];
      return r.values !== void 0 && e in r.values;
    }
    getPosition() {
      return this.path.length === 0
        ? -1
        : (this.path[this.path.length - 1].position ?? 0);
    }
    getCounter() {
      return this.path.length === 0
        ? -1
        : (this.path[this.path.length - 1].counter ?? 0);
    }
    getIndex() {
      return this.getPosition();
    }
    getDepth() {
      return this.path.length;
    }
    toString(e, r = !0) {
      let i = e || this.separator;
      if (i === this.separator && r === !0) {
        if (this._pathStringCache !== null) return this._pathStringCache;
        let o = this.path
          .map((a) => (a.namespace ? `${a.namespace}:${a.tag}` : a.tag))
          .join(i);
        return ((this._pathStringCache = o), o);
      }
      return this.path
        .map((o) => (r && o.namespace ? `${o.namespace}:${o.tag}` : o.tag))
        .join(i);
    }
    toArray() {
      return this.path.map((e) => e.tag);
    }
    reset() {
      ((this._pathStringCache = null),
        (this.path = []),
        (this.siblingStacks = []));
    }
    matches(e) {
      let r = e.segments;
      return r.length === 0
        ? !1
        : e.hasDeepWildcard()
          ? this._matchWithDeepWildcard(r)
          : this._matchSimple(r);
    }
    _matchSimple(e) {
      if (this.path.length !== e.length) return !1;
      for (let r = 0; r < e.length; r++)
        if (!this._matchSegment(e[r], this.path[r], r === this.path.length - 1))
          return !1;
      return !0;
    }
    _matchWithDeepWildcard(e) {
      let r = this.path.length - 1,
        i = e.length - 1;
      for (; i >= 0 && r >= 0;) {
        let n = e[i];
        if (n.type === "deep-wildcard") {
          if ((i--, i < 0)) return !0;
          let o = e[i],
            a = !1;
          for (let s = r; s >= 0; s--)
            if (
              this._matchSegment(o, this.path[s], s === this.path.length - 1)
            ) {
              ((r = s - 1), i--, (a = !0));
              break;
            }
          if (!a) return !1;
        } else {
          if (!this._matchSegment(n, this.path[r], r === this.path.length - 1))
            return !1;
          (r--, i--);
        }
      }
      return i < 0;
    }
    _matchSegment(e, r, i) {
      if (
        (e.tag !== "*" && e.tag !== r.tag) ||
        (e.namespace !== void 0 &&
          e.namespace !== "*" &&
          e.namespace !== r.namespace) ||
        (e.attrName !== void 0 &&
          (!i ||
            !r.values ||
            !(e.attrName in r.values) ||
            (e.attrValue !== void 0 &&
              String(r.values[e.attrName]) !== String(e.attrValue))))
      )
        return !1;
      if (e.position !== void 0) {
        if (!i) return !1;
        let n = r.counter ?? 0;
        if (e.position === "first" && n !== 0) return !1;
        if (e.position === "odd" && n % 2 !== 1) return !1;
        if (e.position === "even" && n % 2 !== 0) return !1;
        if (e.position === "nth" && n !== e.positionValue) return !1;
      }
      return !0;
    }
    matchesAny(e) {
      return e.matchesAny(this);
    }
    snapshot() {
      return {
        path: this.path.map((e) => ({ ...e })),
        siblingStacks: this.siblingStacks.map((e) => new Map(e)),
      };
    }
    restore(e) {
      ((this._pathStringCache = null),
        (this.path = e.path.map((r) => ({ ...r }))),
        (this.siblingStacks = e.siblingStacks.map((r) => new Map(r))));
    }
    readOnly() {
      return this._view;
    }
  };
function zn(t, e) {
  if (!t) return {};
  let r = e.attributesGroupName ? t[e.attributesGroupName] : t;
  if (!r) return {};
  let i = {};
  for (let n in r)
    if (n.startsWith(e.attributeNamePrefix)) {
      let o = n.substring(e.attributeNamePrefix.length);
      i[o] = r[n];
    } else i[n] = r[n];
  return i;
}
function qn(t) {
  if (!t || typeof t != "string") return;
  let e = t.indexOf(":");
  if (e !== -1 && e > 0) {
    let r = t.substring(0, e);
    if (r !== "xmlns") return r;
  }
}
var Ke = class {
  constructor(e, r) {
    ((this.options = e),
      (this.currentNode = null),
      (this.tagsNodeStack = []),
      (this.parseXml = io),
      (this.parseTextData = $n),
      (this.resolveNameSpace = eo),
      (this.buildAttributesMap = ro),
      (this.isItStopNode = so),
      (this.replaceEntitiesValue = oo),
      (this.readStopNodeData = uo),
      (this.saveTextToParentTag = ao),
      (this.addChild = no),
      (this.ignoreAttributesFn = kt(this.options.ignoreAttributes)),
      (this.entityExpansionCount = 0),
      (this.currentExpandedLength = 0));
    let i = { ...Ue };
    (this.options.entityDecoder
      ? (this.entityDecoder = this.options.entityDecoder)
      : (typeof this.options.htmlEntities == "object"
          ? (i = this.options.htmlEntities)
          : this.options.htmlEntities === !0 && (i = { ...Bt, ...nt }),
        (this.entityDecoder = new ve({
          namedEntities: { ...i, ...r },
          numericAllowed: this.options.htmlEntities,
          limit: {
            maxTotalExpansions: this.options.processEntities.maxTotalExpansions,
            maxExpandedLength: this.options.processEntities.maxExpandedLength,
            applyLimitsTo: this.options.processEntities.appliesTo,
          },
        }))),
      (this.matcher = new Se()),
      (this.readonlyMatcher = this.matcher.readOnly()),
      (this.isCurrentNodeStopNode = !1),
      (this.stopNodeExpressionsSet = new Te()));
    let n = this.options.stopNodes;
    if (n && n.length > 0) {
      for (let o = 0; o < n.length; o++) {
        let a = n[o];
        typeof a == "string"
          ? this.stopNodeExpressionsSet.add(new _e(a))
          : a instanceof _e && this.stopNodeExpressionsSet.add(a);
      }
      this.stopNodeExpressionsSet.seal();
    }
  }
};
function $n(t, e, r, i, n, o, a) {
  let s = this.options;
  if (t !== void 0 && (s.trimValues && !i && (t = t.trim()), t.length > 0)) {
    a || (t = this.replaceEntitiesValue(t, e, r));
    let u = s.jPath ? r.toString() : r,
      A = s.tagValueProcessor(e, t, u, n, o);
    return A == null
      ? t
      : typeof A != typeof t || A !== t
        ? A
        : s.trimValues || t.trim() === t
          ? Ut(t, s.parseTagValue, s.numberParseOptions)
          : t;
  }
}
function eo(t) {
  if (this.options.removeNSPrefix) {
    let e = t.split(":"),
      r = t.charAt(0) === "/" ? "/" : "";
    if (e[0] === "xmlns") return "";
    e.length === 2 && (t = r + e[1]);
  }
  return t;
}
var to = new RegExp(`([^\\s=]+)\\s*(=\\s*(['"])([\\s\\S]*?)\\3)?`, "gm");
function ro(t, e, r, i = !1) {
  let n = this.options;
  if (i === !0 || (n.ignoreAttributes !== !0 && typeof t == "string")) {
    let o = rt(t, to),
      a = o.length,
      s = {},
      u = new Array(a),
      A = !1,
      l = {};
    for (let _ = 0; _ < a; _++) {
      let h = this.resolveNameSpace(o[_][1]),
        c = o[_][4];
      if (h.length && c !== void 0) {
        let g = c;
        (n.trimValues && (g = g.trim()),
          (g = this.replaceEntitiesValue(g, r, this.readonlyMatcher)),
          (u[_] = g),
          (l[h] = g),
          (A = !0));
      }
    }
    A && typeof e == "object" && e.updateCurrent && e.updateCurrent(l);
    let d = n.jPath ? e.toString() : this.readonlyMatcher,
      f = !1;
    for (let _ = 0; _ < a; _++) {
      let h = this.resolveNameSpace(o[_][1]);
      if (this.ignoreAttributesFn(h, d)) continue;
      let c = n.attributeNamePrefix + h;
      if (h.length)
        if (
          (n.transformAttributeName && (c = n.transformAttributeName(c)),
          (c = mi(c, n)),
          o[_][4] !== void 0)
        ) {
          let g = u[_],
            y = n.attributeValueProcessor(h, g, d);
          (y == null
            ? (s[c] = g)
            : typeof y != typeof g || y !== g
              ? (s[c] = y)
              : (s[c] = Ut(g, n.parseAttributeValue, n.numberParseOptions)),
            (f = !0));
        } else n.allowBooleanAttributes && ((s[c] = !0), (f = !0));
    }
    if (!f) return;
    if (n.attributesGroupName && !n.preserveOrder) {
      let _ = {};
      return ((_[n.attributesGroupName] = s), _);
    }
    return s;
  }
}
var io = function (t) {
  t = t.replace(
    /\r\n?/g,
    `
`,
  );
  let e = new W("!xml"),
    r = e,
    i = "";
  (this.matcher.reset(),
    this.entityDecoder.reset(),
    (this.entityExpansionCount = 0),
    (this.currentExpandedLength = 0));
  let n = this.options,
    o = new Qe(n.processEntities),
    a = t.length;
  for (let s = 0; s < a; s++)
    if (t[s] === "<") {
      let A = t.charCodeAt(s + 1);
      if (A === 47) {
        let l = De(t, ">", s, "Closing Tag is not closed."),
          d = t.substring(s + 2, l).trim();
        if (n.removeNSPrefix) {
          let _ = d.indexOf(":");
          _ !== -1 && (d = d.substr(_ + 1));
        }
        ((d = Lt(n.transformTagName, d, "", n).tagName),
          r && (i = this.saveTextToParentTag(i, r, this.readonlyMatcher)));
        let f = this.matcher.getCurrentTag();
        if (d && n.unpairedTagsSet.has(d))
          throw new Error(
            `Unpaired tag can not be used as closing tag: </${d}>`,
          );
        (f &&
          n.unpairedTagsSet.has(f) &&
          (this.matcher.pop(), this.tagsNodeStack.pop()),
          this.matcher.pop(),
          (this.isCurrentNodeStopNode = !1),
          (r = this.tagsNodeStack.pop()),
          (i = ""),
          (s = l));
      } else if (A === 63) {
        let l = Gt(t, s, !1, "?>");
        if (!l) throw new Error("Pi Tag is not closed.");
        i = this.saveTextToParentTag(i, r, this.readonlyMatcher);
        let d = this.buildAttributesMap(l.tagExp, this.matcher, l.tagName, !0);
        if (d) {
          let f = d[this.options.attributeNamePrefix + "version"];
          (this.entityDecoder.setXmlVersion(Number(f) || 1),
            o.setXmlVersion(Number(f) || 1));
        }
        if (!(
          (n.ignoreDeclaration && l.tagName === "?xml") ||
          n.ignorePiTags
        )) {
          let f = new W(l.tagName);
          (f.add(n.textNodeName, ""),
            l.tagName !== l.tagExp &&
              l.attrExpPresent &&
              n.ignoreAttributes !== !0 &&
              (f[":@"] = d),
            this.addChild(r, f, this.readonlyMatcher, s));
        }
        s = l.closeIndex + 1;
      } else if (
        A === 33 &&
        t.charCodeAt(s + 2) === 45 &&
        t.charCodeAt(s + 3) === 45
      ) {
        let l = De(t, "-->", s + 4, "Comment is not closed.");
        if (n.commentPropName) {
          let d = t.substring(s + 4, l - 2);
          ((i = this.saveTextToParentTag(i, r, this.readonlyMatcher)),
            r.add(n.commentPropName, [{ [n.textNodeName]: d }]));
        }
        s = l;
      } else if (A === 33 && t.charCodeAt(s + 2) === 68) {
        let l = o.readDocType(t, s);
        (this.entityDecoder.addInputEntities(l.entities), (s = l.i));
      } else if (A === 33 && t.charCodeAt(s + 2) === 91) {
        let l = De(t, "]]>", s, "CDATA is not closed.") - 2,
          d = t.substring(s + 9, l);
        i = this.saveTextToParentTag(i, r, this.readonlyMatcher);
        let f = this.parseTextData(
          d,
          r.tagname,
          this.readonlyMatcher,
          !0,
          !1,
          !0,
          !0,
        );
        (f == null && (f = ""),
          n.cdataPropName
            ? r.add(n.cdataPropName, [{ [n.textNodeName]: d }])
            : r.add(n.textNodeName, f),
          (s = l + 2));
      } else {
        let l = Gt(t, s, n.removeNSPrefix);
        if (!l) {
          let E = t.substring(Math.max(0, s - 50), Math.min(a, s + 50));
          throw new Error(
            `readTagExp returned undefined at position ${s}. Context: "${E}"`,
          );
        }
        let d = l.tagName,
          f = l.rawTagName,
          _ = l.tagExp,
          h = l.attrExpPresent,
          c = l.closeIndex;
        if (
          (({ tagName: d, tagExp: _ } = Lt(n.transformTagName, d, _, n)),
          n.strictReservedNames &&
            (d === n.commentPropName ||
              d === n.cdataPropName ||
              d === n.textNodeName ||
              d === n.attributesGroupName))
        )
          throw new Error(`Invalid tag name: ${d}`);
        r &&
          i &&
          r.tagname !== "!xml" &&
          (i = this.saveTextToParentTag(i, r, this.readonlyMatcher, !1));
        let g = r;
        g &&
          n.unpairedTagsSet.has(g.tagname) &&
          ((r = this.tagsNodeStack.pop()), this.matcher.pop());
        let y = !1;
        _.length > 0 &&
          _.lastIndexOf("/") === _.length - 1 &&
          ((y = !0),
          d[d.length - 1] === "/"
            ? ((d = d.substr(0, d.length - 1)), (_ = d))
            : (_ = _.substr(0, _.length - 1)),
          (h = d !== _));
        let p = null,
          m = {},
          w;
        ((w = qn(f)),
          d !== e.tagname && this.matcher.push(d, {}, w),
          d !== _ &&
            h &&
            ((p = this.buildAttributesMap(_, this.matcher, d)),
            p && (m = zn(p, n))),
          d !== e.tagname &&
            (this.isCurrentNodeStopNode = this.isItStopNode()));
        let T = s;
        if (this.isCurrentNodeStopNode) {
          let E = "";
          if (y) s = l.closeIndex;
          else if (n.unpairedTagsSet.has(d)) s = l.closeIndex;
          else {
            let I = this.readStopNodeData(t, f, c + 1);
            if (!I) throw new Error(`Unexpected end of ${f}`);
            ((s = I.i), (E = I.tagContent));
          }
          let S = new W(d);
          (p && (S[":@"] = p),
            S.add(n.textNodeName, E),
            this.matcher.pop(),
            (this.isCurrentNodeStopNode = !1),
            this.addChild(r, S, this.readonlyMatcher, T));
        } else {
          if (y) {
            ({ tagName: d, tagExp: _ } = Lt(n.transformTagName, d, _, n));
            let E = new W(d);
            (p && (E[":@"] = p),
              this.addChild(r, E, this.readonlyMatcher, T),
              this.matcher.pop(),
              (this.isCurrentNodeStopNode = !1));
          } else if (n.unpairedTagsSet.has(d)) {
            let E = new W(d);
            (p && (E[":@"] = p),
              this.addChild(r, E, this.readonlyMatcher, T),
              this.matcher.pop(),
              (this.isCurrentNodeStopNode = !1),
              (s = l.closeIndex));
            continue;
          } else {
            let E = new W(d);
            if (this.tagsNodeStack.length > n.maxNestedTags)
              throw new Error("Maximum nested tags exceeded");
            (this.tagsNodeStack.push(r),
              p && (E[":@"] = p),
              this.addChild(r, E, this.readonlyMatcher, T),
              (r = E));
          }
          ((i = ""), (s = c));
        }
      }
    } else i += t[s];
  return e.child;
};
function no(t, e, r, i) {
  this.options.captureMetaData || (i = void 0);
  let n = this.options.jPath ? r.toString() : r,
    o = this.options.updateTag(e.tagname, n, e[":@"]);
  o === !1 || (typeof o == "string" && (e.tagname = o), t.addChild(e, i));
}
function oo(t, e, r) {
  let i = this.options.processEntities;
  if (!i || !i.enabled) return t;
  if (i.allowedTags) {
    let n = this.options.jPath ? r.toString() : r;
    if (
      !(Array.isArray(i.allowedTags)
        ? i.allowedTags.includes(e)
        : i.allowedTags(e, n))
    )
      return t;
  }
  if (i.tagFilter) {
    let n = this.options.jPath ? r.toString() : r;
    if (!i.tagFilter(e, n)) return t;
  }
  return this.entityDecoder.decode(t);
}
function ao(t, e, r, i) {
  return (
    t &&
      (i === void 0 && (i = e.child.length === 0),
      (t = this.parseTextData(
        t,
        e.tagname,
        r,
        !1,
        e[":@"] ? Object.keys(e[":@"]).length !== 0 : !1,
        i,
      )),
      t !== void 0 && t !== "" && e.add(this.options.textNodeName, t),
      (t = "")),
    t
  );
}
function so() {
  return this.stopNodeExpressionsSet.size === 0
    ? !1
    : this.matcher.matchesAny(this.stopNodeExpressionsSet);
}
function Ao(t, e, r = ">") {
  let i = 0,
    n = t.length,
    o = r.charCodeAt(0),
    a = r.length > 1 ? r.charCodeAt(1) : -1,
    s = "",
    u = e;
  for (let A = e; A < n; A++) {
    let l = t.charCodeAt(A);
    if (i) l === i && (i = 0);
    else if (l === 34 || l === 39) i = l;
    else if (l === o)
      if (a !== -1) {
        if (t.charCodeAt(A + 1) === a)
          return ((s += t.substring(u, A)), { data: s, index: A });
      } else return ((s += t.substring(u, A)), { data: s, index: A });
    else l === 9 && !i && ((s += t.substring(u, A) + " "), (u = A + 1));
  }
}
function De(t, e, r, i) {
  let n = t.indexOf(e, r);
  if (n === -1) throw new Error(i);
  return n + e.length - 1;
}
function lo(t, e, r, i) {
  let n = t.indexOf(e, r);
  if (n === -1) throw new Error(i);
  return n;
}
function Gt(t, e, r, i = ">") {
  let n = Ao(t, e + 1, i);
  if (!n) return;
  let o = n.data,
    a = n.index,
    s = o.search(/\s/),
    u = o,
    A = !0;
  s !== -1 && ((u = o.substring(0, s)), (o = o.substring(s + 1).trimStart()));
  let l = u;
  if (r) {
    let d = u.indexOf(":");
    d !== -1 && ((u = u.substr(d + 1)), (A = u !== n.data.substr(d + 1)));
  }
  return {
    tagName: u,
    tagExp: o,
    closeIndex: a,
    attrExpPresent: A,
    rawTagName: l,
  };
}
function uo(t, e, r) {
  let i = r,
    n = 1,
    o = t.length;
  for (; r < o; r++)
    if (t[r] === "<") {
      let a = t.charCodeAt(r + 1);
      if (a === 47) {
        let s = lo(t, ">", r, `${e} is not closed`);
        if (t.substring(r + 2, s).trim() === e && (n--, n === 0))
          return { tagContent: t.substring(i, r), i: s };
        r = s;
      } else if (a === 63) r = De(t, "?>", r + 1, "StopNode is not closed.");
      else if (
        a === 33 &&
        t.charCodeAt(r + 2) === 45 &&
        t.charCodeAt(r + 3) === 45
      )
        r = De(t, "-->", r + 3, "StopNode is not closed.");
      else if (a === 33 && t.charCodeAt(r + 2) === 91)
        r = De(t, "]]>", r, "StopNode is not closed.") - 2;
      else {
        let s = Gt(t, r, !1);
        s &&
          ((s && s.tagName) === e &&
            s.tagExp[s.tagExp.length - 1] !== "/" &&
            n++,
          (r = s.closeIndex));
      }
    }
}
function Ut(t, e, r) {
  if (e && typeof t == "string") {
    let i = t.trim();
    return i === "true" ? !0 : i === "false" ? !1 : Pt(t, r);
  } else return Kr(t) ? t : "";
}
function Lt(t, e, r, i) {
  if (t) {
    let n = t(e);
    (r === e && (r = n), (e = n));
  }
  return ((e = mi(e, i)), { tagName: e, tagExp: r });
}
function mi(t, e) {
  if (it.includes(t))
    throw new Error(
      `[SECURITY] Invalid name: "${t}" is a reserved JavaScript keyword that could cause prototype pollution`,
    );
  return Le.includes(t) ? e.onDangerousProperty(t) : t;
}
var Yt = W.getMetaDataSymbol();
function co(t, e) {
  if (!t || typeof t != "object") return {};
  if (!e) return t;
  let r = {};
  for (let i in t)
    if (i.startsWith(e)) {
      let n = i.substring(e.length);
      r[n] = t[i];
    } else r[i] = t[i];
  return r;
}
function Qt(t, e, r, i) {
  return _i(t, e, r, i);
}
function _i(t, e, r, i) {
  let n,
    o = {};
  for (let a = 0; a < t.length; a++) {
    let s = t[a],
      u = fo(s);
    if (u !== void 0 && u !== e.textNodeName) {
      let A = co(s[":@"] || {}, e.attributeNamePrefix);
      r.push(u, A);
    }
    if (u === e.textNodeName) n === void 0 ? (n = s[u]) : (n += "" + s[u]);
    else {
      if (u === void 0) continue;
      if (s[u]) {
        let A = _i(s[u], e, r, i),
          l = mo(A, e);
        if (
          (Object.keys(A).length === 0 &&
            e.alwaysCreateTextNode &&
            (A[e.textNodeName] = ""),
          s[":@"]
            ? po(A, s[":@"], i, e)
            : Object.keys(A).length === 1 &&
                A[e.textNodeName] !== void 0 &&
                !e.alwaysCreateTextNode
              ? (A = A[e.textNodeName])
              : Object.keys(A).length === 0 &&
                (e.alwaysCreateTextNode ? (A[e.textNodeName] = "") : (A = "")),
          s[Yt] !== void 0 &&
            typeof A == "object" &&
            A !== null &&
            (A[Yt] = s[Yt]),
          o[u] !== void 0 && Object.prototype.hasOwnProperty.call(o, u))
        )
          (Array.isArray(o[u]) || (o[u] = [o[u]]), o[u].push(A));
        else {
          let d = e.jPath ? i.toString() : i;
          e.isArray(u, d, l) ? (o[u] = [A]) : (o[u] = A);
        }
        u !== void 0 && u !== e.textNodeName && r.pop();
      }
    }
  }
  return (
    typeof n == "string"
      ? n.length > 0 && (o[e.textNodeName] = n)
      : n !== void 0 && (o[e.textNodeName] = n),
    o
  );
}
function fo(t) {
  let e = Object.keys(t);
  for (let r = 0; r < e.length; r++) {
    let i = e[r];
    if (i !== ":@") return i;
  }
}
function po(t, e, r, i) {
  if (e) {
    let n = Object.keys(e),
      o = n.length;
    for (let a = 0; a < o; a++) {
      let s = n[a],
        u = s.startsWith(i.attributeNamePrefix)
          ? s.substring(i.attributeNamePrefix.length)
          : s,
        A = i.jPath ? r.toString() + "." + u : r;
      i.isArray(s, A, !0, !0) ? (t[s] = [e[s]]) : (t[s] = e[s]);
    }
  }
}
function mo(t, e) {
  let { textNodeName: r } = e,
    i = Object.keys(t).length;
  return !!(
    i === 0 ||
    (i === 1 && (t[r] || typeof t[r] == "boolean" || t[r] === 0))
  );
}
var Fe = class {
  constructor(e) {
    ((this.externalEntities = {}), (this.options = ci(e)));
  }
  parse(e, r) {
    if (typeof e != "string" && e.toString) e = e.toString();
    else if (typeof e != "string")
      throw new Error("XML data is accepted in String or Bytes[] form.");
    if (r) {
      r === !0 && (r = {});
      let o = Zr(e, r);
      if (o !== !0) throw Error(`${o.err.msg}:${o.err.line}:${o.err.col}`);
    }
    let i = new Ke(this.options, this.externalEntities),
      n = i.parseXml(e);
    return this.options.preserveOrder || n === void 0
      ? n
      : Qt(n, this.options, i.matcher, i.readonlyMatcher);
  }
  addEntity(e, r) {
    if (r.indexOf("&") !== -1) throw new Error("Entity value can't have '&'");
    if (e.indexOf("&") !== -1 || e.indexOf(";") !== -1)
      throw new Error(
        "An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'",
      );
    if (r === "&") throw new Error("An entity with value '&' is not permitted");
    this.externalEntities[e] = r;
  }
  static getMetaDataSymbol() {
    return W.getMetaDataSymbol();
  }
};
var Kt,
  _o = new Map([
    [0, 65533],
    [128, 8364],
    [130, 8218],
    [131, 402],
    [132, 8222],
    [133, 8230],
    [134, 8224],
    [135, 8225],
    [136, 710],
    [137, 8240],
    [138, 352],
    [139, 8249],
    [140, 338],
    [142, 381],
    [145, 8216],
    [146, 8217],
    [147, 8220],
    [148, 8221],
    [149, 8226],
    [150, 8211],
    [151, 8212],
    [152, 732],
    [153, 8482],
    [154, 353],
    [155, 8250],
    [156, 339],
    [158, 382],
    [159, 376],
  ]),
  Wt =
    (Kt = String.fromCodePoint) !== null && Kt !== void 0
      ? Kt
      : (t) => {
          let e = "";
          return (
            t > 65535 &&
              ((t -= 65536),
              (e += String.fromCharCode(((t >>> 10) & 1023) | 55296)),
              (t = 56320 | (t & 1023))),
            (e += String.fromCharCode(t)),
            e
          );
        };
function Ht(t) {
  var e;
  return (t >= 55296 && t <= 57343) || t > 1114111
    ? 65533
    : (e = _o.get(t)) !== null && e !== void 0
      ? e
      : t;
}
function Xt(t) {
  let e =
      typeof atob == "function"
        ? atob(t)
        : typeof Buffer.from == "function"
          ? Buffer.from(t, "base64").toString("binary")
          : new Buffer(t, "base64").toString("binary"),
    r = e.length & -2,
    i = new Uint16Array(r / 2);
  for (let n = 0, o = 0; n < r; n += 2) {
    let a = e.charCodeAt(n),
      s = e.charCodeAt(n + 1);
    i[o++] = a | (s << 8);
  }
  return i;
}
var Jt = Xt("AAJhZ2xxBwARABMAFQBtAg0AAAAAAA8AcAAmYG8AcwAnYHQAPmB0ADxg9SFvdCJg");
var O;
(function (t) {
  ((t[(t.VALUE_LENGTH = 49152)] = "VALUE_LENGTH"),
    (t[(t.FLAG13 = 8192)] = "FLAG13"),
    (t[(t.BRANCH_LENGTH = 8064)] = "BRANCH_LENGTH"),
    (t[(t.JUMP_TABLE = 127)] = "JUMP_TABLE"));
})(O || (O = {}));
var R;
(function (t) {
  ((t[(t.NUM = 35)] = "NUM"),
    (t[(t.SEMI = 59)] = "SEMI"),
    (t[(t.EQUALS = 61)] = "EQUALS"),
    (t[(t.ZERO = 48)] = "ZERO"),
    (t[(t.NINE = 57)] = "NINE"),
    (t[(t.LOWER_A = 97)] = "LOWER_A"),
    (t[(t.LOWER_F = 102)] = "LOWER_F"),
    (t[(t.LOWER_X = 120)] = "LOWER_X"),
    (t[(t.LOWER_Z = 122)] = "LOWER_Z"),
    (t[(t.UPPER_A = 65)] = "UPPER_A"),
    (t[(t.UPPER_F = 70)] = "UPPER_F"),
    (t[(t.UPPER_Z = 90)] = "UPPER_Z"));
})(R || (R = {}));
var hi = 32;
function Zt(t) {
  return t >= R.ZERO && t <= R.NINE;
}
function go(t) {
  return (
    (t >= R.UPPER_A && t <= R.UPPER_F) || (t >= R.LOWER_A && t <= R.LOWER_F)
  );
}
function yo(t) {
  return (
    (t >= R.UPPER_A && t <= R.UPPER_Z) ||
    (t >= R.LOWER_A && t <= R.LOWER_Z) ||
    Zt(t)
  );
}
function wo(t) {
  return t === R.EQUALS || yo(t);
}
var k;
(function (t) {
  ((t[(t.EntityStart = 0)] = "EntityStart"),
    (t[(t.NumericStart = 1)] = "NumericStart"),
    (t[(t.NumericDecimal = 2)] = "NumericDecimal"),
    (t[(t.NumericHex = 3)] = "NumericHex"),
    (t[(t.NamedEntity = 4)] = "NamedEntity"));
})(k || (k = {}));
var ee;
(function (t) {
  ((t[(t.Legacy = 0)] = "Legacy"),
    (t[(t.Strict = 1)] = "Strict"),
    (t[(t.Attribute = 2)] = "Attribute"));
})(ee || (ee = {}));
var st = class {
  constructor(e, r, i) {
    ((this.decodeTree = e),
      (this.emitCodePoint = r),
      (this.errors = i),
      (this.state = k.EntityStart),
      (this.consumed = 1),
      (this.result = 0),
      (this.treeIndex = 0),
      (this.excess = 1),
      (this.decodeMode = ee.Strict),
      (this.runConsumed = 0));
  }
  startEntity(e) {
    ((this.decodeMode = e),
      (this.state = k.EntityStart),
      (this.result = 0),
      (this.treeIndex = 0),
      (this.excess = 1),
      (this.consumed = 1),
      (this.runConsumed = 0));
  }
  write(e, r) {
    switch (this.state) {
      case k.EntityStart:
        return e.charCodeAt(r) === R.NUM
          ? ((this.state = k.NumericStart),
            (this.consumed += 1),
            this.stateNumericStart(e, r + 1))
          : ((this.state = k.NamedEntity), this.stateNamedEntity(e, r));
      case k.NumericStart:
        return this.stateNumericStart(e, r);
      case k.NumericDecimal:
        return this.stateNumericDecimal(e, r);
      case k.NumericHex:
        return this.stateNumericHex(e, r);
      case k.NamedEntity:
        return this.stateNamedEntity(e, r);
    }
  }
  stateNumericStart(e, r) {
    return r >= e.length
      ? -1
      : (e.charCodeAt(r) | hi) === R.LOWER_X
        ? ((this.state = k.NumericHex),
          (this.consumed += 1),
          this.stateNumericHex(e, r + 1))
        : ((this.state = k.NumericDecimal), this.stateNumericDecimal(e, r));
  }
  stateNumericHex(e, r) {
    for (; r < e.length;) {
      let i = e.charCodeAt(r);
      if (Zt(i) || go(i)) {
        let n = i <= R.NINE ? i - R.ZERO : (i | hi) - R.LOWER_A + 10;
        ((this.result = this.result * 16 + n), this.consumed++, r++);
      } else return this.emitNumericEntity(i, 3);
    }
    return -1;
  }
  stateNumericDecimal(e, r) {
    for (; r < e.length;) {
      let i = e.charCodeAt(r);
      if (Zt(i))
        ((this.result = this.result * 10 + (i - R.ZERO)), this.consumed++, r++);
      else return this.emitNumericEntity(i, 2);
    }
    return -1;
  }
  emitNumericEntity(e, r) {
    var i;
    if (this.consumed <= r)
      return (
        (i = this.errors) === null ||
          i === void 0 ||
          i.absenceOfDigitsInNumericCharacterReference(this.consumed),
        0
      );
    if (e === R.SEMI) this.consumed += 1;
    else if (this.decodeMode === ee.Strict) return 0;
    return (
      this.emitCodePoint(Ht(this.result), this.consumed),
      this.errors &&
        (e !== R.SEMI && this.errors.missingSemicolonAfterCharacterReference(),
        this.errors.validateNumericCharacterReference(this.result)),
      this.consumed
    );
  }
  stateNamedEntity(e, r) {
    let { decodeTree: i } = this,
      n = i[this.treeIndex],
      o = (n & O.VALUE_LENGTH) >> 14;
    for (; r < e.length;) {
      if (o === 0 && (n & O.FLAG13) !== 0) {
        let s = (n & O.BRANCH_LENGTH) >> 7;
        if (this.runConsumed === 0) {
          let u = n & O.JUMP_TABLE;
          if (e.charCodeAt(r) !== u)
            return this.result === 0 ? 0 : this.emitNotTerminatedNamedEntity();
          (r++, this.excess++, this.runConsumed++);
        }
        for (; this.runConsumed < s;) {
          if (r >= e.length) return -1;
          let u = this.runConsumed - 1,
            A = i[this.treeIndex + 1 + (u >> 1)],
            l = u % 2 === 0 ? A & 255 : (A >> 8) & 255;
          if (e.charCodeAt(r) !== l)
            return (
              (this.runConsumed = 0),
              this.result === 0 ? 0 : this.emitNotTerminatedNamedEntity()
            );
          (r++, this.excess++, this.runConsumed++);
        }
        ((this.runConsumed = 0),
          (this.treeIndex += 1 + (s >> 1)),
          (n = i[this.treeIndex]),
          (o = (n & O.VALUE_LENGTH) >> 14));
      }
      if (r >= e.length) break;
      let a = e.charCodeAt(r);
      if (a === R.SEMI && o !== 0 && (n & O.FLAG13) !== 0)
        return this.emitNamedEntityData(
          this.treeIndex,
          o,
          this.consumed + this.excess,
        );
      if (
        ((this.treeIndex = Eo(i, n, this.treeIndex + Math.max(1, o), a)),
        this.treeIndex < 0)
      )
        return this.result === 0 ||
          (this.decodeMode === ee.Attribute && (o === 0 || wo(a)))
          ? 0
          : this.emitNotTerminatedNamedEntity();
      if (
        ((n = i[this.treeIndex]), (o = (n & O.VALUE_LENGTH) >> 14), o !== 0)
      ) {
        if (a === R.SEMI)
          return this.emitNamedEntityData(
            this.treeIndex,
            o,
            this.consumed + this.excess,
          );
        this.decodeMode !== ee.Strict &&
          (n & O.FLAG13) === 0 &&
          ((this.result = this.treeIndex),
          (this.consumed += this.excess),
          (this.excess = 0));
      }
      (r++, this.excess++);
    }
    return -1;
  }
  emitNotTerminatedNamedEntity() {
    var e;
    let { result: r, decodeTree: i } = this,
      n = (i[r] & O.VALUE_LENGTH) >> 14;
    return (
      this.emitNamedEntityData(r, n, this.consumed),
      (e = this.errors) === null ||
        e === void 0 ||
        e.missingSemicolonAfterCharacterReference(),
      this.consumed
    );
  }
  emitNamedEntityData(e, r, i) {
    let { decodeTree: n } = this;
    return (
      this.emitCodePoint(
        r === 1 ? n[e] & ~(O.VALUE_LENGTH | O.FLAG13) : n[e + 1],
        i,
      ),
      r === 3 && this.emitCodePoint(n[e + 2], i),
      i
    );
  }
  end() {
    var e;
    switch (this.state) {
      case k.NamedEntity:
        return this.result !== 0 &&
          (this.decodeMode !== ee.Attribute || this.result === this.treeIndex)
          ? this.emitNotTerminatedNamedEntity()
          : 0;
      case k.NumericDecimal:
        return this.emitNumericEntity(0, 2);
      case k.NumericHex:
        return this.emitNumericEntity(0, 3);
      case k.NumericStart:
        return (
          (e = this.errors) === null ||
            e === void 0 ||
            e.absenceOfDigitsInNumericCharacterReference(this.consumed),
          0
        );
      case k.EntityStart:
        return 0;
    }
  }
};
function bo(t) {
  let e = "",
    r = new st(t, (i) => (e += Wt(i)));
  return function (n, o) {
    let a = 0,
      s = 0;
    for (; (s = n.indexOf("&", s)) >= 0;) {
      ((e += n.slice(a, s)), r.startEntity(o));
      let A = r.write(n, s + 1);
      if (A < 0) {
        a = s + r.end();
        break;
      }
      ((a = s + A), (s = A === 0 ? a + 1 : a));
    }
    let u = e + n.slice(a);
    return ((e = ""), u);
  };
}
function Eo(t, e, r, i) {
  let n = (e & O.BRANCH_LENGTH) >> 7,
    o = e & O.JUMP_TABLE;
  if (n === 0) return o !== 0 && i === o ? r : -1;
  if (o) {
    let A = i - o;
    return A < 0 || A >= n ? -1 : t[r + A] - 1;
  }
  let a = (n + 1) >> 1,
    s = 0,
    u = n - 1;
  for (; s <= u;) {
    let A = (s + u) >>> 1,
      l = A >> 1,
      f = (t[r + l] >> ((A & 1) * 8)) & 255;
    if (f < i) s = A + 1;
    else if (f > i) u = A - 1;
    else return t[r + a + A];
  }
  return -1;
}
var Io = bo(Jt);
function We(t) {
  return Io(t, ee.Strict);
}
var Co =
  String.prototype.codePointAt == null
    ? (t, e) =>
        (t.charCodeAt(e) & 64512) === 55296
          ? (t.charCodeAt(e) - 55296) * 1024 +
            t.charCodeAt(e + 1) -
            56320 +
            65536
          : t.charCodeAt(e)
    : (t, e) => t.codePointAt(e);
var gi;
(function (t) {
  ((t[(t.XML = 0)] = "XML"), (t[(t.HTML = 1)] = "HTML"));
})(gi || (gi = {}));
var yi;
(function (t) {
  ((t[(t.UTF8 = 0)] = "UTF8"),
    (t[(t.ASCII = 1)] = "ASCII"),
    (t[(t.Extensive = 2)] = "Extensive"),
    (t[(t.Attribute = 3)] = "Attribute"),
    (t[(t.Text = 4)] = "Text"));
})(yi || (yi = {}));
var bi = 1048576 * 10;
async function At(t, e, r, i, n, { headers: o, download_id: a, cache: s }, u) {
  let A = u,
    l = 0,
    d = 0;
  for (; !(l >= A);) {
    let f = Math.min(l + bi, A),
      _ = `${i.href}&range=${l}-${f}`;
    l = f + 1;
    let h = await ie(_, { headers: o, signal: n, cache: s });
    if (h.isErr())
      return { aborted_no_partial: !0, download_id: a, ending_reason: h.error };
    let c = h.value.body.getReader();
    for (;;) {
      let g = await fe(c);
      if (g.isErr())
        return {
          aborted_no_partial: !0,
          download_id: a,
          ending_reason: g.error,
        };
      let { done: y, value: p } = g.value;
      if (y) break;
      (t.onwrite(e, d, p),
        (d += p.length),
        r.set_progress({
          percent: { is_known: !0, value: 100 * (d / A) },
          fetched_bytes_count: d,
          status: "downloading",
          output_duration_s: 0,
        }));
    }
  }
  return {
    aborted_no_partial: !1,
    download_id: a,
    ending_reason: "end_of_file",
    internal_filename: e,
    internal_bloburl: void 0,
  };
}
async function Ei(t, e) {
  let r = new z(t.download_id),
    i = `${t.good_basename}.${t.extension}`,
    n = new L();
  await n.open(i);
  let o;
  return (
    t.content_length.isSome()
      ? (o = await At(n, i, r, t.url, e, t, t.content_length.value))
      : (o = await Ce(n, i, r, t.url, e, t)),
    await n.close(i),
    o.aborted_no_partial
      ? (n.remove(i), o)
      : await Ti(
          t,
          i,
          B,
          await vi(t.subtitles),
          t.subtitles.map((a) => a.language),
        )
  );
}
async function Ii(t, e) {
  let r = new Pe(t.download_id),
    i = new L(),
    n;
  {
    ((n = `${t.download_id}_audio`), await i.open(n));
    let A;
    if (
      (t.audio_content_length.isSome()
        ? (A = await At(
            i,
            n,
            r,
            t.url_audio,
            e,
            t,
            t.audio_content_length.value,
          ))
        : (A = await Ce(i, n, r, t.url_audio, e, t)),
      await i.close(n),
      A.aborted_no_partial)
    )
      return (i.remove(n), A);
  }
  r.nextStream();
  let o;
  {
    ((o = `${t.download_id}_video`), await i.open(o));
    let A;
    if (
      (t.content_length.isSome()
        ? (A = await At(i, o, r, t.url, e, t, t.content_length.value))
        : (A = await Ce(i, o, r, t.url, e, t)),
      await i.close(o),
      A.aborted_no_partial)
    )
      return (i.remove(o), A);
  }
  let a = n ? P(n) : B,
    s = await vi(t.subtitles),
    u = t.subtitles.isSome() ? P(t.subtitles.value.language) : B;
  return await Ti(t, o, a, s, u);
}
async function Ci(t, e) {
  let r = new L(),
    i = `${t.download_id}.${t.extension}`,
    n = `${t.url.href}&range=0-${bi}`,
    o = 0;
  await r.open(i);
  let a = await ie(n, { headers: t.headers, signal: e, cache: t.cache });
  if (a.isErr())
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: a.error,
    };
  let s = a.value.body.getReader();
  try {
    for (;;) {
      let u = await fe(s);
      if (u.isErr())
        return (
          r.close(i),
          r.remove(i),
          {
            aborted_no_partial: !0,
            download_id: t.download_id,
            ending_reason: u.error,
          }
        );
      let { done: A, value: l } = u.value;
      if (A) break;
      (r.onwrite(i, o, l), (o += l.length));
    }
    return (
      r.close(i),
      {
        aborted_no_partial: !1,
        internal_filename: i,
        internal_bloburl: void 0,
        download_id: t.download_id,
        ending_reason: "end_of_file",
      }
    );
  } catch (u) {
    throw (r.close(i), r.remove(i), u);
  }
}
async function vi(t) {
  if (t.isNone()) return B;
  let e = new L(),
    r;
  {
    let i = await ie(t.value.url);
    if (((r = `${t.value.hash}.vtt`), i.isErr())) return B;
    let n = await i.value.text(),
      o = xo(n);
    ((r = `${t.value.hash}.vtt`),
      await e.open(r),
      await e.onwrite(r, 0, new TextEncoder().encode(o)),
      await e.close(r));
  }
  return r ? P(r) : B;
}
async function Ti(t, e, r, i, n) {
  let o = new L(),
    a = await ye.LibAV({ noworker: !0 });
  a.onwrite = o.onwrite.bind(o);
  let s = await navigator.storage.getDirectory(),
    A = await (await s.getFileHandle(e)).getFile(),
    l = URL.createObjectURL(A),
    d,
    f,
    _;
  r.isSome() &&
    ((d = await s.getFileHandle(r.value)),
    (f = await d.getFile()),
    (_ = URL.createObjectURL(f)));
  let h, c, g;
  i.isSome() &&
    ((h = await s.getFileHandle(i.value)),
    (c = await h.getFile()),
    (g = URL.createObjectURL(c)));
  let y = `${t.download_id}.${t.extension}`;
  (await a.mkwriterdev(y), await o.open(y));
  let p = [];
  (p.push("-i", `jsfetch:${l}`),
    r.isSome() && p.push("-i", `jsfetch:${_}`),
    i.isSome() && p.push("-f", "webvtt", "-i", `jsfetch:${g}`));
  let m = t.muxer == "mp4";
  p.push("-map", "0:v:0");
  let w = 1;
  (r.isSome()
    ? (p.push("-map", `${w}:a:0`), w++)
    : p.push("-map", `${w - 1}:a:0`),
    i.isSome() &&
      n.isSome() &&
      p.push(
        "-map",
        "2:0",
        "-c:s",
        m ? "mov_text" : "copy",
        "-metadata:s:s:0",
        `language=${Cr(n.value)}`,
      ),
    p.push("-c:v", "copy", "-c:a", "copy"),
    p.push("-y", y));
  try {
    let T = await a.ffmpeg(...p);
    return (
      await o.close(y),
      URL.revokeObjectURL(l),
      await s.removeEntry(e),
      r.isSome() && (URL.revokeObjectURL(_), await s.removeEntry(r.value)),
      i.isSome() && (URL.revokeObjectURL(g), await s.removeEntry(i.value)),
      T == 0
        ? {
            aborted_no_partial: !1,
            internal_filename: y,
            internal_bloburl: await Q(t, y),
            download_id: t.download_id,
            ending_reason: "end_of_file",
          }
        : {
            aborted_no_partial: !0,
            download_id: t.download_id,
            ending_reason: F("muxing failed"),
          }
    );
  } catch (T) {
    try {
      (o.remove(y),
        URL.revokeObjectURL(l),
        await s.removeEntry(e),
        r.isSome() && (URL.revokeObjectURL(_), await s.removeEntry(r.value)),
        i.isSome() && (URL.revokeObjectURL(g), await s.removeEntry(i.value)));
    } catch {}
    return {
      aborted_no_partial: !0,
      download_id: t.download_id,
      ending_reason: F(T.toString()),
    };
  }
}
async function Si(t, e) {
  let r = new Pe(t.download_id),
    i = `${t.download_id}_audio`,
    n = new L();
  await n.open(i);
  let o;
  if (
    (t.content_length.isSome()
      ? (o = await At(n, i, r, t.url, e, t, t.content_length.value))
      : (o = await Ce(n, i, r, t.url, e, t)),
    await n.close(i),
    o.aborted_no_partial)
  )
    return (n.remove(i), o);
  r.nextStream();
  let a = await Q(t, i),
    s = `${t.download_id}.mp3`,
    u = await G(t, e, s, r, [
      "-analyzeduration",
      "10M",
      "-i",
      `jsfetch:${a}`,
      "-c:a",
      "libmp3lame",
      "-avoid_negative_ts",
      "make_zero",
      "-y",
      s,
    ]);
  return (URL.revokeObjectURL(a), u);
}
function xo(t) {
  let e = new Fe({
      ignoreAttributes: !1,
      attributeNamePrefix: "@_",
      textNodeName: "#text",
      processEntities: !0,
      trimValues: !1,
      parseTagValue: !1,
      parseAttributeValue: !1,
      tagValueProcessor: (s, u) => We(u),
    }),
    r = [
      `WEBVTT

`,
    ],
    i = e.parse(t),
    n = (s) => {
      if (!s) return 0;
      let u = Number(s);
      return isFinite(u) ? u : 0;
    },
    o = 0,
    a = 0;
  if (i.timedtext?.body?.p) {
    let s = i.timedtext?.body?.p,
      u = [];
    Array.isArray(s) ? (u = s) : s != null && (u = [s]);
    let A = (l) => new Date(l).toISOString().slice(11, 23);
    for (let l of u)
      ((o = n(l["@_t"])),
        (a = n(l["@_d"])),
        r.push(`${A(o)} --> ${A(o + a)}`),
        r.push(`
`),
        l["#text"]
          ? (r.push(l["#text"]),
            r.push(`

`))
          : l.s &&
            (Array.isArray(l.s)
              ? r.push(l.s.map((d) => d["#text"]).join(""))
              : r.push(l.s["#text"]),
            r.push(`

`)));
  }
  return r.join("");
}
async function Ro(t, e) {
  try {
    let r;
    if (t.strategy == "m3u8_audio_only")
      r = t.will_use_jsfetch ? await Nr(t, e) : await Vr(t, e);
    else if (t.strategy == "m3u8_audio_video_one_source")
      r = t.will_use_jsfetch ? await Mr(t, e) : await Rr(t, e);
    else if (t.strategy == "m3u8_audio_video_two_sources")
      r = t.will_use_jsfetch ? await Pr(t, e) : await Br(t, e);
    else if (t.strategy == "m3u8_video_preview") r = await xr(t, e);
    else if (t.strategy == "youtube_audio_only") r = await Si(t, e);
    else if (t.strategy == "youtube_audio_video_one_source") r = await Ei(t, e);
    else if (t.strategy == "youtube_audio_video_two_sources")
      r = await Ii(t, e);
    else if (t.strategy == "youtube_video_preview") r = await Ci(t, e);
    else if (t.strategy == "http_audio_video_one_source") r = await Yr(t, e);
    else if (t.strategy == "http_audio_video_two_sources_jsfetch")
      r = await Gr(t, e);
    else if (t.strategy == "http_audio_video_one_source_jsfetch")
      r = await Lr(t, e);
    else if (t.strategy == "http_strip_audio_jsfetch") r = await Ur(t, e);
    else if (t.strategy == "http_video_preview_jsfetch") r = await Or(t, e);
    else if (t.strategy == "mpd_audio_only") r = await cr(t, e);
    else if (t.strategy == "mpd_audio_video_one_source") r = await ur(t, e);
    else if (t.strategy == "mpd_video_preview") r = await dr(t, e);
    else throw new Error("Unreachable");
    re({ name: "download_result", data: r });
  } catch (r) {
    let i = rr(r);
    throw (
      re({
        name: "download_error",
        data: { download_id: t.download_id, error: i },
      }),
      r
    );
  }
}
function Vo() {
  nr();
  let t = new Map();
  (or(async (e) => {
    if (e.name == "abort_download") {
      let r = t.get(e.data.download_id);
      r && r.abort();
    } else if (e.name == "download") {
      let r = $(e.data.download_args),
        i = new AbortController();
      (t.set(r.download_id, i),
        await Ro(r, i.signal),
        t.delete(r.download_id),
        i.abort(),
        re({
          name: "download_progress",
          data: {
            download_id: r.download_id,
            progress: { status: "finalizing" },
          },
        }));
    } else
      e.name == "revoke_blob_url"
        ? URL.revokeObjectURL(e.data.blob_url)
        : e.name == "is_ready" && re({ name: "is_ready_success", data: null });
  }),
    re({ name: "is_ready_success", data: null }));
}
Vo();
export { Ro as Download };
/*! Bundled license information:

m3u8-parser/dist/m3u8-parser.es.js:
  (*! @name m3u8-parser @version 7.2.0 @license Apache-2.0 *)
*/
