var S = new BroadcastChannel("worker_service");
var n = {
  FromInjectedToService: 0,
  FromContentToService: 1,
  FromServiceToWorker: 2,
  FromWorkerToService: 3,
  FromUntrustedInjectedToTrusted: 4,
  FromTrustedInjectedToUntrusted: 5,
  FromServiceToContent: 6,
  FromServiceToInjected: 7,
  FromServiceToService: 8,
};
function i(o, e = 0) {
  let t = 3735928559 ^ e,
    a = 1103547991 ^ e;
  for (let r = 0, s; r < o.length; r++)
    ((s = o.charCodeAt(r)),
      (t = Math.imul(t ^ s, 2654435761)),
      (a = Math.imul(a ^ s, 1597334677)));
  return (
    (t = Math.imul(t ^ (t >>> 16), 2246822507)),
    (t ^= Math.imul(a ^ (a >>> 13), 3266489909)),
    (a = Math.imul(a ^ (a >>> 16), 2246822507)),
    (a ^= Math.imul(t ^ (t >>> 13), 3266489909)),
    4294967296 * (2097151 & a) + (t >>> 0)
  );
}
var d = new BroadcastChannel(`injected-${i(window.location.href)}`);
function m(o) {
  let e = n.FromUntrustedInjectedToTrusted;
  d.postMessage({ msg: o, channel: e });
}
function l(o) {
  let e = (t) => {
    let a = t.data.msg;
    t.data.channel == n.FromTrustedInjectedToUntrusted && o(a);
  };
  return (
    d.addEventListener("message", e),
    () => {
      d.removeEventListener("message", e);
    }
  );
}
var g = /(?<![a-z0-9])(\d{5,})/i;
function c(o) {
  let e = o.match(g);
  if (e && e.length > 0) return e[0];
}
var T = c(window.location.href);
async function u() {
  if (T) {
    let o = 1;
    for (;;) {
      let e = window.playerConfig;
      if (e) {
        m({ name: "vimeo_on_config", data: { config: e } });
        break;
      } else await new Promise((t) => setTimeout(t, 1e3 * o++));
    }
  }
}
l((o) => {
  o.name == "vimeo_request_config" && u();
});
u();
