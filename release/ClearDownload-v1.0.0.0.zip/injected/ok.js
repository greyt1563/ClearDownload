var bn = Object.create;
var Yt = Object.defineProperty;
var vn = Object.getOwnPropertyDescriptor;
var Tn = Object.getOwnPropertyNames;
var _n = Object.getPrototypeOf,
  Sn = Object.prototype.hasOwnProperty;
var ue = (e, t) => () => (t || e((t = { exports: {} }).exports, t), t.exports);
var wn = (e, t, r, n) => {
  if ((t && typeof t == "object") || typeof t == "function")
    for (let i of Tn(t))
      !Sn.call(e, i) &&
        i !== r &&
        Yt(e, i, {
          get: () => t[i],
          enumerable: !(n = vn(t, i)) || n.enumerable,
        });
  return e;
};
var we = (e, t, r) => (
  (r = e != null ? bn(_n(e)) : {}),
  wn(
    t || !e || !e.__esModule
      ? Yt(r, "default", { value: e, enumerable: !0 })
      : r,
    e,
  )
);
var tt = ue((ou, Qt) => {
  var Ne;
  typeof window < "u"
    ? (Ne = window)
    : typeof global < "u"
      ? (Ne = global)
      : typeof self < "u"
        ? (Ne = self)
        : (Ne = {});
  Qt.exports = Ne;
});
var ir = ue((wt, nr) => {
  (function (e, t) {
    if (typeof define == "function" && define.amd)
      define("webextension-polyfill", ["module"], t);
    else if (typeof wt < "u") t(nr);
    else {
      var r = { exports: {} };
      (t(r), (e.browser = r.exports));
    }
  })(
    typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : wt,
    function (e) {
      "use strict";
      if (!(
        globalThis.chrome &&
        globalThis.chrome.runtime &&
        globalThis.chrome.runtime.id
      ))
        throw new Error(
          "This script should only be loaded in a browser extension.",
        );
      if (
        globalThis.browser &&
        globalThis.browser.runtime &&
        globalThis.browser.runtime.id
      )
        e.exports = globalThis.browser;
      else {
        let t = "The message port closed before a response was received.",
          r = (n) => {
            let i = {
              alarms: {
                clear: { minArgs: 0, maxArgs: 1 },
                clearAll: { minArgs: 0, maxArgs: 0 },
                get: { minArgs: 0, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
              },
              bookmarks: {
                create: { minArgs: 1, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 1 },
                getChildren: { minArgs: 1, maxArgs: 1 },
                getRecent: { minArgs: 1, maxArgs: 1 },
                getSubTree: { minArgs: 1, maxArgs: 1 },
                getTree: { minArgs: 0, maxArgs: 0 },
                move: { minArgs: 2, maxArgs: 2 },
                remove: { minArgs: 1, maxArgs: 1 },
                removeTree: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              browserAction: {
                disable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                enable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                getBadgeBackgroundColor: { minArgs: 1, maxArgs: 1 },
                getBadgeText: { minArgs: 1, maxArgs: 1 },
                getPopup: { minArgs: 1, maxArgs: 1 },
                getTitle: { minArgs: 1, maxArgs: 1 },
                openPopup: { minArgs: 0, maxArgs: 0 },
                setBadgeBackgroundColor: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: !0,
                },
                setBadgeText: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: !0,
                },
                setIcon: { minArgs: 1, maxArgs: 1 },
                setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              browsingData: {
                remove: { minArgs: 2, maxArgs: 2 },
                removeCache: { minArgs: 1, maxArgs: 1 },
                removeCookies: { minArgs: 1, maxArgs: 1 },
                removeDownloads: { minArgs: 1, maxArgs: 1 },
                removeFormData: { minArgs: 1, maxArgs: 1 },
                removeHistory: { minArgs: 1, maxArgs: 1 },
                removeLocalStorage: { minArgs: 1, maxArgs: 1 },
                removePasswords: { minArgs: 1, maxArgs: 1 },
                removePluginData: { minArgs: 1, maxArgs: 1 },
                settings: { minArgs: 0, maxArgs: 0 },
              },
              commands: { getAll: { minArgs: 0, maxArgs: 0 } },
              contextMenus: {
                remove: { minArgs: 1, maxArgs: 1 },
                removeAll: { minArgs: 0, maxArgs: 0 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              cookies: {
                get: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 1, maxArgs: 1 },
                getAllCookieStores: { minArgs: 0, maxArgs: 0 },
                remove: { minArgs: 1, maxArgs: 1 },
                set: { minArgs: 1, maxArgs: 1 },
              },
              devtools: {
                inspectedWindow: {
                  eval: { minArgs: 1, maxArgs: 2, singleCallbackArg: !1 },
                },
                panels: {
                  create: { minArgs: 3, maxArgs: 3, singleCallbackArg: !0 },
                  elements: { createSidebarPane: { minArgs: 1, maxArgs: 1 } },
                },
              },
              downloads: {
                cancel: { minArgs: 1, maxArgs: 1 },
                download: { minArgs: 1, maxArgs: 1 },
                erase: { minArgs: 1, maxArgs: 1 },
                getFileIcon: { minArgs: 1, maxArgs: 2 },
                open: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                pause: { minArgs: 1, maxArgs: 1 },
                removeFile: { minArgs: 1, maxArgs: 1 },
                resume: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
                show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              extension: {
                isAllowedFileSchemeAccess: { minArgs: 0, maxArgs: 0 },
                isAllowedIncognitoAccess: { minArgs: 0, maxArgs: 0 },
              },
              history: {
                addUrl: { minArgs: 1, maxArgs: 1 },
                deleteAll: { minArgs: 0, maxArgs: 0 },
                deleteRange: { minArgs: 1, maxArgs: 1 },
                deleteUrl: { minArgs: 1, maxArgs: 1 },
                getVisits: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
              },
              i18n: {
                detectLanguage: { minArgs: 1, maxArgs: 1 },
                getAcceptLanguages: { minArgs: 0, maxArgs: 0 },
              },
              identity: { launchWebAuthFlow: { minArgs: 1, maxArgs: 1 } },
              idle: { queryState: { minArgs: 1, maxArgs: 1 } },
              management: {
                get: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
                getSelf: { minArgs: 0, maxArgs: 0 },
                setEnabled: { minArgs: 2, maxArgs: 2 },
                uninstallSelf: { minArgs: 0, maxArgs: 1 },
              },
              notifications: {
                clear: { minArgs: 1, maxArgs: 1 },
                create: { minArgs: 1, maxArgs: 2 },
                getAll: { minArgs: 0, maxArgs: 0 },
                getPermissionLevel: { minArgs: 0, maxArgs: 0 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              pageAction: {
                getPopup: { minArgs: 1, maxArgs: 1 },
                getTitle: { minArgs: 1, maxArgs: 1 },
                hide: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setIcon: { minArgs: 1, maxArgs: 1 },
                setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              permissions: {
                contains: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
                remove: { minArgs: 1, maxArgs: 1 },
                request: { minArgs: 1, maxArgs: 1 },
              },
              runtime: {
                getBackgroundPage: { minArgs: 0, maxArgs: 0 },
                getPlatformInfo: { minArgs: 0, maxArgs: 0 },
                openOptionsPage: { minArgs: 0, maxArgs: 0 },
                requestUpdateCheck: { minArgs: 0, maxArgs: 0 },
                sendMessage: { minArgs: 1, maxArgs: 3 },
                sendNativeMessage: { minArgs: 2, maxArgs: 2 },
                setUninstallURL: { minArgs: 1, maxArgs: 1 },
              },
              sessions: {
                getDevices: { minArgs: 0, maxArgs: 1 },
                getRecentlyClosed: { minArgs: 0, maxArgs: 1 },
                restore: { minArgs: 0, maxArgs: 1 },
              },
              storage: {
                local: {
                  clear: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
                managed: {
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                },
                sync: {
                  clear: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
              },
              tabs: {
                captureVisibleTab: { minArgs: 0, maxArgs: 2 },
                create: { minArgs: 1, maxArgs: 1 },
                detectLanguage: { minArgs: 0, maxArgs: 1 },
                discard: { minArgs: 0, maxArgs: 1 },
                duplicate: { minArgs: 1, maxArgs: 1 },
                executeScript: { minArgs: 1, maxArgs: 2 },
                get: { minArgs: 1, maxArgs: 1 },
                getCurrent: { minArgs: 0, maxArgs: 0 },
                getZoom: { minArgs: 0, maxArgs: 1 },
                getZoomSettings: { minArgs: 0, maxArgs: 1 },
                goBack: { minArgs: 0, maxArgs: 1 },
                goForward: { minArgs: 0, maxArgs: 1 },
                highlight: { minArgs: 1, maxArgs: 1 },
                insertCSS: { minArgs: 1, maxArgs: 2 },
                move: { minArgs: 2, maxArgs: 2 },
                query: { minArgs: 1, maxArgs: 1 },
                reload: { minArgs: 0, maxArgs: 2 },
                remove: { minArgs: 1, maxArgs: 1 },
                removeCSS: { minArgs: 1, maxArgs: 2 },
                sendMessage: { minArgs: 2, maxArgs: 3 },
                setZoom: { minArgs: 1, maxArgs: 2 },
                setZoomSettings: { minArgs: 1, maxArgs: 2 },
                update: { minArgs: 1, maxArgs: 2 },
              },
              topSites: { get: { minArgs: 0, maxArgs: 0 } },
              webNavigation: {
                getAllFrames: { minArgs: 1, maxArgs: 1 },
                getFrame: { minArgs: 1, maxArgs: 1 },
              },
              webRequest: {
                handlerBehaviorChanged: { minArgs: 0, maxArgs: 0 },
              },
              windows: {
                create: { minArgs: 0, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 2 },
                getAll: { minArgs: 0, maxArgs: 1 },
                getCurrent: { minArgs: 0, maxArgs: 1 },
                getLastFocused: { minArgs: 0, maxArgs: 1 },
                remove: { minArgs: 1, maxArgs: 1 },
                update: { minArgs: 2, maxArgs: 2 },
              },
            };
            if (Object.keys(i).length === 0)
              throw new Error(
                "api-metadata.json has not been included in browser-polyfill",
              );
            class a extends WeakMap {
              constructor(A, y = void 0) {
                (super(y), (this.createItem = A));
              }
              get(A) {
                return (
                  this.has(A) || this.set(A, this.createItem(A)),
                  super.get(A)
                );
              }
            }
            let u = (p) =>
                p && typeof p == "object" && typeof p.then == "function",
              s =
                (p, A) =>
                (...y) => {
                  n.runtime.lastError
                    ? p.reject(new Error(n.runtime.lastError.message))
                    : A.singleCallbackArg ||
                        (y.length <= 1 && A.singleCallbackArg !== !1)
                      ? p.resolve(y[0])
                      : p.resolve(y);
                },
              l = (p) => (p == 1 ? "argument" : "arguments"),
              o = (p, A) =>
                function (_, ...R) {
                  if (R.length < A.minArgs)
                    throw new Error(
                      `Expected at least ${A.minArgs} ${l(A.minArgs)} for ${p}(), got ${R.length}`,
                    );
                  if (R.length > A.maxArgs)
                    throw new Error(
                      `Expected at most ${A.maxArgs} ${l(A.maxArgs)} for ${p}(), got ${R.length}`,
                    );
                  return new Promise((w, F) => {
                    if (A.fallbackToNoCallback)
                      try {
                        _[p](...R, s({ resolve: w, reject: F }, A));
                      } catch (E) {
                        (console.warn(
                          `${p} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,
                          E,
                        ),
                          _[p](...R),
                          (A.fallbackToNoCallback = !1),
                          (A.noCallback = !0),
                          w());
                      }
                    else
                      A.noCallback
                        ? (_[p](...R), w())
                        : _[p](...R, s({ resolve: w, reject: F }, A));
                  });
                },
              m = (p, A, y) =>
                new Proxy(A, {
                  apply(_, R, w) {
                    return y.call(R, p, ...w);
                  },
                }),
              d = Function.call.bind(Object.prototype.hasOwnProperty),
              g = (p, A = {}, y = {}) => {
                let _ = Object.create(null),
                  R = {
                    has(F, E) {
                      return E in p || E in _;
                    },
                    get(F, E, L) {
                      if (E in _) return _[E];
                      if (!(E in p)) return;
                      let B = p[E];
                      if (typeof B == "function")
                        if (typeof A[E] == "function") B = m(p, p[E], A[E]);
                        else if (d(y, E)) {
                          let Q = o(E, y[E]);
                          B = m(p, p[E], Q);
                        } else B = B.bind(p);
                      else if (
                        typeof B == "object" &&
                        B !== null &&
                        (d(A, E) || d(y, E))
                      )
                        B = g(B, A[E], y[E]);
                      else if (d(y, "*")) B = g(B, A[E], y["*"]);
                      else
                        return (
                          Object.defineProperty(_, E, {
                            configurable: !0,
                            enumerable: !0,
                            get() {
                              return p[E];
                            },
                            set(Q) {
                              p[E] = Q;
                            },
                          }),
                          B
                        );
                      return ((_[E] = B), B);
                    },
                    set(F, E, L, B) {
                      return (E in _ ? (_[E] = L) : (p[E] = L), !0);
                    },
                    defineProperty(F, E, L) {
                      return Reflect.defineProperty(_, E, L);
                    },
                    deleteProperty(F, E) {
                      return Reflect.deleteProperty(_, E);
                    },
                  },
                  w = Object.create(p);
                return new Proxy(w, R);
              },
              D = (p) => ({
                addListener(A, y, ..._) {
                  A.addListener(p.get(y), ..._);
                },
                hasListener(A, y) {
                  return A.hasListener(p.get(y));
                },
                removeListener(A, y) {
                  A.removeListener(p.get(y));
                },
              }),
              b = new a((p) =>
                typeof p != "function"
                  ? p
                  : function (y) {
                      let _ = g(
                        y,
                        {},
                        { getContent: { minArgs: 0, maxArgs: 0 } },
                      );
                      p(_);
                    },
              ),
              c = new a((p) =>
                typeof p != "function"
                  ? p
                  : function (y, _, R) {
                      let w = !1,
                        F,
                        E = new Promise((ae) => {
                          F = function (C) {
                            ((w = !0), ae(C));
                          };
                        }),
                        L;
                      try {
                        L = p(y, _, F);
                      } catch (ae) {
                        L = Promise.reject(ae);
                      }
                      let B = L !== !0 && u(L);
                      if (L !== !0 && !B && !w) return !1;
                      let Q = (ae) => {
                        ae.then(
                          (C) => {
                            R(C);
                          },
                          (C) => {
                            let V;
                            (C &&
                            (C instanceof Error || typeof C.message == "string")
                              ? (V = C.message)
                              : (V = "An unexpected error occurred"),
                              R({
                                __mozWebExtensionPolyfillReject__: !0,
                                message: V,
                              }));
                          },
                        ).catch((C) => {
                          console.error(
                            "Failed to send onMessage rejected reply",
                            C,
                          );
                        });
                      };
                      return (Q(B ? L : E), !0);
                    },
              ),
              v = ({ reject: p, resolve: A }, y) => {
                n.runtime.lastError
                  ? n.runtime.lastError.message === t
                    ? A()
                    : p(new Error(n.runtime.lastError.message))
                  : y && y.__mozWebExtensionPolyfillReject__
                    ? p(new Error(y.message))
                    : A(y);
              },
              T = (p, A, y, ..._) => {
                if (_.length < A.minArgs)
                  throw new Error(
                    `Expected at least ${A.minArgs} ${l(A.minArgs)} for ${p}(), got ${_.length}`,
                  );
                if (_.length > A.maxArgs)
                  throw new Error(
                    `Expected at most ${A.maxArgs} ${l(A.maxArgs)} for ${p}(), got ${_.length}`,
                  );
                return new Promise((R, w) => {
                  let F = v.bind(null, { resolve: R, reject: w });
                  (_.push(F), y.sendMessage(..._));
                });
              },
              h = {
                devtools: { network: { onRequestFinished: D(b) } },
                runtime: {
                  onMessage: D(c),
                  onMessageExternal: D(c),
                  sendMessage: T.bind(null, "sendMessage", {
                    minArgs: 1,
                    maxArgs: 3,
                  }),
                },
                tabs: {
                  sendMessage: T.bind(null, "sendMessage", {
                    minArgs: 2,
                    maxArgs: 3,
                  }),
                },
              },
              f = {
                clear: { minArgs: 1, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 1 },
                set: { minArgs: 1, maxArgs: 1 },
              };
            return (
              (i.privacy = {
                network: { "*": f },
                services: { "*": f },
                websites: { "*": f },
              }),
              g(n, h, i)
            );
          };
        e.exports = r(chrome);
      }
    },
  );
});
var Oe = ue((de) => {
  "use strict";
  function Kn(e, t, r) {
    if (
      (r === void 0 && (r = Array.prototype), e && typeof r.find == "function")
    )
      return r.find.call(e, t);
    for (var n = 0; n < e.length; n++)
      if (Object.prototype.hasOwnProperty.call(e, n)) {
        var i = e[n];
        if (t.call(void 0, i, n, e)) return i;
      }
  }
  function Ct(e, t) {
    return (
      t === void 0 && (t = Object),
      t && typeof t.freeze == "function" ? t.freeze(e) : e
    );
  }
  function Qn(e, t) {
    if (e === null || typeof e != "object")
      throw new TypeError("target is not an object");
    for (var r in t)
      Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    return e;
  }
  var lr = Ct({
      HTML: "text/html",
      isHTML: function (e) {
        return e === lr.HTML;
      },
      XML_APPLICATION: "application/xml",
      XML_TEXT: "text/xml",
      XML_XHTML_APPLICATION: "application/xhtml+xml",
      XML_SVG_IMAGE: "image/svg+xml",
    }),
    cr = Ct({
      HTML: "http://www.w3.org/1999/xhtml",
      isHTML: function (e) {
        return e === cr.HTML;
      },
      SVG: "http://www.w3.org/2000/svg",
      XML: "http://www.w3.org/XML/1998/namespace",
      XMLNS: "http://www.w3.org/2000/xmlns/",
    });
  de.assign = Qn;
  de.find = Kn;
  de.freeze = Ct;
  de.MIME_TYPE = lr;
  de.NAMESPACE = cr;
});
var qt = ue((ie) => {
  var Dr = Oe(),
    J = Dr.find,
    Me = Dr.NAMESPACE;
  function Zn(e) {
    return e !== "";
  }
  function Jn(e) {
    return e ? e.split(/[\t\n\f\r ]+/).filter(Zn) : [];
  }
  function ei(e, t) {
    return (e.hasOwnProperty(t) || (e[t] = !0), e);
  }
  function mr(e) {
    if (!e) return [];
    var t = Jn(e);
    return Object.keys(t.reduce(ei, {}));
  }
  function ti(e) {
    return function (t) {
      return e && e.indexOf(t) !== -1;
    };
  }
  function Fe(e, t) {
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
  }
  function W(e, t) {
    var r = e.prototype;
    if (!(r instanceof t)) {
      let i = function () {};
      var n = i;
      ((i.prototype = t.prototype),
        (i = new i()),
        Fe(r, i),
        (e.prototype = r = i));
    }
    r.constructor != e &&
      (typeof e != "function" && console.error("unknown Class:" + e),
      (r.constructor = e));
  }
  var Y = {},
    j = (Y.ELEMENT_NODE = 1),
    he = (Y.ATTRIBUTE_NODE = 2),
    at = (Y.TEXT_NODE = 3),
    Er = (Y.CDATA_SECTION_NODE = 4),
    yr = (Y.ENTITY_REFERENCE_NODE = 5),
    ri = (Y.ENTITY_NODE = 6),
    Nt = (Y.PROCESSING_INSTRUCTION_NODE = 7),
    It = (Y.COMMENT_NODE = 8),
    br = (Y.DOCUMENT_NODE = 9),
    vr = (Y.DOCUMENT_TYPE_NODE = 10),
    te = (Y.DOCUMENT_FRAGMENT_NODE = 11),
    ni = (Y.NOTATION_NODE = 12),
    z = {},
    k = {},
    Ku = (z.INDEX_SIZE_ERR = ((k[1] = "Index size error"), 1)),
    Qu = (z.DOMSTRING_SIZE_ERR = ((k[2] = "DOMString size error"), 2)),
    $ = (z.HIERARCHY_REQUEST_ERR = ((k[3] = "Hierarchy request error"), 3)),
    Zu = (z.WRONG_DOCUMENT_ERR = ((k[4] = "Wrong document"), 4)),
    ii = (z.INVALID_CHARACTER_ERR = ((k[5] = "Invalid character"), 5)),
    Ju = (z.NO_DATA_ALLOWED_ERR = ((k[6] = "No data allowed"), 6)),
    es = (z.NO_MODIFICATION_ALLOWED_ERR =
      ((k[7] = "No modification allowed"), 7)),
    Tr = (z.NOT_FOUND_ERR = ((k[8] = "Not found"), 8)),
    ts = (z.NOT_SUPPORTED_ERR = ((k[9] = "Not supported"), 9)),
    fr = (z.INUSE_ATTRIBUTE_ERR = ((k[10] = "Attribute in use"), 10)),
    ge = (z.INVALID_STATE_ERR = ((k[11] = "Invalid state"), 11)),
    rs = (z.SYNTAX_ERR = ((k[12] = "Syntax error"), 12)),
    ns = (z.INVALID_MODIFICATION_ERR = ((k[13] = "Invalid modification"), 13)),
    is = (z.NAMESPACE_ERR = ((k[14] = "Invalid namespace"), 14)),
    as = (z.INVALID_ACCESS_ERR = ((k[15] = "Invalid access"), 15));
  function I(e, t) {
    if (t instanceof Error) var r = t;
    else
      ((r = this),
        Error.call(this, k[e]),
        (this.message = k[e]),
        Error.captureStackTrace && Error.captureStackTrace(this, I));
    return ((r.code = e), t && (this.message = this.message + ": " + t), r);
  }
  I.prototype = Error.prototype;
  Fe(z, I);
  function re() {}
  re.prototype = {
    length: 0,
    item: function (e) {
      return e >= 0 && e < this.length ? this[e] : null;
    },
    toString: function (e, t, r) {
      for (
        var n = !!r && !!r.requireWellFormed, i = [], a = 0;
        a < this.length;
        a++
      )
        kt(this[a], i, e, t, null, n);
      return i.join("");
    },
    filter: function (e) {
      return Array.prototype.filter.call(this, e);
    },
    indexOf: function (e) {
      return Array.prototype.indexOf.call(this, e);
    },
  };
  function Ae(e, t) {
    ((this._node = e), (this._refresh = t), Rt(this));
  }
  function Rt(e) {
    var t = e._node._inc || e._node.ownerDocument._inc;
    if (e._inc !== t) {
      var r = e._refresh(e._node);
      if ((Fr(e, "length", r.length), !e.$$length || r.length < e.$$length))
        for (var n = r.length; n in e; n++)
          Object.prototype.hasOwnProperty.call(e, n) && delete e[n];
      (Fe(r, e), (e._inc = t));
    }
  }
  Ae.prototype.item = function (e) {
    return (Rt(this), this[e] || null);
  };
  W(Ae, re);
  function ut() {}
  function _r(e, t) {
    for (var r = e.length; r--;) if (e[r] === t) return r;
  }
  function pr(e, t, r, n) {
    if ((n ? (t[_r(t, n)] = r) : (t[t.length++] = r), e)) {
      r.ownerElement = e;
      var i = e.ownerDocument;
      i && (n && xr(i, e, n), ai(i, e, r));
    }
  }
  function dr(e, t, r) {
    var n = _r(t, r);
    if (n >= 0) {
      for (var i = t.length - 1; n < i;) t[n] = t[++n];
      if (((t.length = i), e)) {
        var a = e.ownerDocument;
        a && (xr(a, e, r), (r.ownerElement = null));
      }
    } else throw new I(Tr, new Error(e.tagName + "@" + r));
  }
  ut.prototype = {
    length: 0,
    item: re.prototype.item,
    getNamedItem: function (e) {
      for (var t = this.length; t--;) {
        var r = this[t];
        if (r.nodeName == e) return r;
      }
    },
    setNamedItem: function (e) {
      var t = e.ownerElement;
      if (t && t != this._ownerElement) throw new I(fr);
      var r = this.getNamedItem(e.nodeName);
      return (pr(this._ownerElement, this, e, r), r);
    },
    setNamedItemNS: function (e) {
      var t = e.ownerElement,
        r;
      if (t && t != this._ownerElement) throw new I(fr);
      return (
        (r = this.getNamedItemNS(e.namespaceURI, e.localName)),
        pr(this._ownerElement, this, e, r),
        r
      );
    },
    removeNamedItem: function (e) {
      var t = this.getNamedItem(e);
      return (dr(this._ownerElement, this, t), t);
    },
    removeNamedItemNS: function (e, t) {
      var r = this.getNamedItemNS(e, t);
      return (dr(this._ownerElement, this, r), r);
    },
    getNamedItemNS: function (e, t) {
      for (var r = this.length; r--;) {
        var n = this[r];
        if (n.localName == t && n.namespaceURI == e) return n;
      }
      return null;
    },
  };
  function Sr() {}
  Sr.prototype = {
    hasFeature: function (e, t) {
      return !0;
    },
    createDocument: function (e, t, r) {
      var n = new Pe();
      if (
        ((n.implementation = this),
        (n.childNodes = new re()),
        (n.doctype = r || null),
        r && n.appendChild(r),
        t)
      ) {
        var i = n.createElementNS(e, t);
        n.appendChild(i);
      }
      return n;
    },
    createDocumentType: function (e, t, r) {
      var n = new ct();
      return (
        (n.name = e),
        (n.nodeName = e),
        (n.publicId = t || ""),
        (n.systemId = r || ""),
        n
      );
    },
  };
  function N() {}
  N.prototype = {
    firstChild: null,
    lastChild: null,
    previousSibling: null,
    nextSibling: null,
    attributes: null,
    parentNode: null,
    childNodes: null,
    ownerDocument: null,
    nodeValue: null,
    namespaceURI: null,
    prefix: null,
    localName: null,
    insertBefore: function (e, t) {
      return ot(this, e, t);
    },
    replaceChild: function (e, t) {
      (ot(this, e, t, Nr), t && this.removeChild(t));
    },
    removeChild: function (e) {
      return Cr(this, e);
    },
    appendChild: function (e) {
      return this.insertBefore(e, null);
    },
    hasChildNodes: function () {
      return this.firstChild != null;
    },
    cloneNode: function (e) {
      return Br(this.ownerDocument || this, this, e);
    },
    normalize: function () {
      U(this, null, {
        enter: function (e) {
          for (var t = e.firstChild; t;) {
            var r = t.nextSibling;
            r !== null && r.nodeType === at && t.nodeType === at
              ? (e.removeChild(r), t.appendData(r.data))
              : (t = r);
          }
          return !0;
        },
      });
    },
    isSupported: function (e, t) {
      return this.ownerDocument.implementation.hasFeature(e, t);
    },
    hasAttributes: function () {
      return this.attributes.length > 0;
    },
    lookupPrefix: function (e) {
      for (var t = this; t;) {
        var r = t._nsMap;
        if (r) {
          for (var n in r)
            if (Object.prototype.hasOwnProperty.call(r, n) && r[n] === e)
              return n;
        }
        t = t.nodeType == he ? t.ownerDocument : t.parentNode;
      }
      return null;
    },
    lookupNamespaceURI: function (e) {
      for (var t = this; t;) {
        var r = t._nsMap;
        if (r && Object.prototype.hasOwnProperty.call(r, e)) return r[e];
        t = t.nodeType == he ? t.ownerDocument : t.parentNode;
      }
      return null;
    },
    isDefaultNamespace: function (e) {
      var t = this.lookupPrefix(e);
      return t == null;
    },
  };
  function wr(e) {
    return (
      (e == "<" && "&lt;") ||
      (e == ">" && "&gt;") ||
      (e == "&" && "&amp;") ||
      (e == '"' && "&quot;") ||
      "&#" + e.charCodeAt() + ";"
    );
  }
  Fe(Y, N);
  Fe(Y, N.prototype);
  function st(e, t) {
    return (
      U(e, null, {
        enter: function (r) {
          return t(r) ? U.STOP : !0;
        },
      }) === U.STOP
    );
  }
  function U(e, t, r) {
    for (var n = [{ node: e, context: t, phase: U.ENTER }]; n.length > 0;) {
      var i = n.pop();
      if (i.phase === U.ENTER) {
        var a = r.enter(i.node, i.context);
        if (a === U.STOP) return U.STOP;
        if ((n.push({ node: i.node, context: a, phase: U.EXIT }), a == null))
          continue;
        for (var u = i.node.lastChild; u;)
          (n.push({ node: u, context: a, phase: U.ENTER }),
            (u = u.previousSibling));
      } else r.exit && r.exit(i.node, i.context);
    }
  }
  U.STOP = Symbol("walkDOM.STOP");
  U.ENTER = 0;
  U.EXIT = 1;
  function Pe() {
    this.ownerDocument = this;
  }
  function ai(e, t, r) {
    e && e._inc++;
    var n = r.namespaceURI;
    n === Me.XMLNS && (t._nsMap[r.prefix ? r.localName : ""] = r.value);
  }
  function xr(e, t, r, n) {
    e && e._inc++;
    var i = r.namespaceURI;
    i === Me.XMLNS && delete t._nsMap[r.prefix ? r.localName : ""];
  }
  function Ot(e, t, r) {
    if (e && e._inc) {
      e._inc++;
      var n = t.childNodes;
      if (r) n[n.length++] = r;
      else {
        for (var i = t.firstChild, a = 0; i;)
          ((n[a++] = i), (i = i.nextSibling));
        ((n.length = a), delete n[n.length]);
      }
    }
  }
  function Cr(e, t) {
    var r = t.previousSibling,
      n = t.nextSibling;
    return (
      r ? (r.nextSibling = n) : (e.firstChild = n),
      n ? (n.previousSibling = r) : (e.lastChild = r),
      (t.parentNode = null),
      (t.previousSibling = null),
      (t.nextSibling = null),
      Ot(e.ownerDocument, e),
      t
    );
  }
  function ui(e) {
    return (
      e &&
      (e.nodeType === N.DOCUMENT_NODE ||
        e.nodeType === N.DOCUMENT_FRAGMENT_NODE ||
        e.nodeType === N.ELEMENT_NODE)
    );
  }
  function si(e) {
    return (
      e &&
      (ee(e) ||
        Mt(e) ||
        ne(e) ||
        e.nodeType === N.DOCUMENT_FRAGMENT_NODE ||
        e.nodeType === N.COMMENT_NODE ||
        e.nodeType === N.PROCESSING_INSTRUCTION_NODE)
    );
  }
  function ne(e) {
    return e && e.nodeType === N.DOCUMENT_TYPE_NODE;
  }
  function ee(e) {
    return e && e.nodeType === N.ELEMENT_NODE;
  }
  function Mt(e) {
    return e && e.nodeType === N.TEXT_NODE;
  }
  function gr(e, t) {
    var r = e.childNodes || [];
    if (J(r, ee) || ne(t)) return !1;
    var n = J(r, ne);
    return !(t && n && r.indexOf(n) > r.indexOf(t));
  }
  function hr(e, t) {
    var r = e.childNodes || [];
    function n(a) {
      return ee(a) && a !== t;
    }
    if (J(r, n)) return !1;
    var i = J(r, ne);
    return !(t && i && r.indexOf(i) > r.indexOf(t));
  }
  function oi(e, t, r) {
    if (!ui(e)) throw new I($, "Unexpected parent node type " + e.nodeType);
    if (r && r.parentNode !== e) throw new I(Tr, "child not in parent");
    if (!si(t) || (ne(t) && e.nodeType !== N.DOCUMENT_NODE))
      throw new I(
        $,
        "Unexpected node type " +
          t.nodeType +
          " for parent node type " +
          e.nodeType,
      );
  }
  function li(e, t, r) {
    var n = e.childNodes || [],
      i = t.childNodes || [];
    if (t.nodeType === N.DOCUMENT_FRAGMENT_NODE) {
      var a = i.filter(ee);
      if (a.length > 1 || J(i, Mt))
        throw new I($, "More than one element or text in fragment");
      if (a.length === 1 && !gr(e, r))
        throw new I(
          $,
          "Element in fragment can not be inserted before doctype",
        );
    }
    if (ee(t) && !gr(e, r))
      throw new I($, "Only one element can be added and only after doctype");
    if (ne(t)) {
      if (J(n, ne)) throw new I($, "Only one doctype is allowed");
      var u = J(n, ee);
      if (r && n.indexOf(u) < n.indexOf(r))
        throw new I($, "Doctype can only be inserted before an element");
      if (!r && u)
        throw new I($, "Doctype can not be appended since element is present");
    }
  }
  function Nr(e, t, r) {
    var n = e.childNodes || [],
      i = t.childNodes || [];
    if (t.nodeType === N.DOCUMENT_FRAGMENT_NODE) {
      var a = i.filter(ee);
      if (a.length > 1 || J(i, Mt))
        throw new I($, "More than one element or text in fragment");
      if (a.length === 1 && !hr(e, r))
        throw new I(
          $,
          "Element in fragment can not be inserted before doctype",
        );
    }
    if (ee(t) && !hr(e, r))
      throw new I($, "Only one element can be added and only after doctype");
    if (ne(t)) {
      let l = function (o) {
        return ne(o) && o !== r;
      };
      var s = l;
      if (J(n, l)) throw new I($, "Only one doctype is allowed");
      var u = J(n, ee);
      if (r && n.indexOf(u) < n.indexOf(r))
        throw new I($, "Doctype can only be inserted before an element");
    }
  }
  function ot(e, t, r, n) {
    (oi(e, t, r), e.nodeType === N.DOCUMENT_NODE && (n || li)(e, t, r));
    var i = t.parentNode;
    if ((i && i.removeChild(t), t.nodeType === te)) {
      var a = t.firstChild;
      if (a == null) return t;
      var u = t.lastChild;
    } else a = u = t;
    var s = r ? r.previousSibling : e.lastChild;
    ((a.previousSibling = s),
      (u.nextSibling = r),
      s ? (s.nextSibling = a) : (e.firstChild = a),
      r == null ? (e.lastChild = u) : (r.previousSibling = u));
    do {
      a.parentNode = e;
      var l = e.ownerDocument || e;
      Be(a, l);
    } while (a !== u && (a = a.nextSibling));
    return (
      Ot(e.ownerDocument || e, e),
      t.nodeType == te && (t.firstChild = t.lastChild = null),
      t
    );
  }
  function Be(e, t) {
    if (e.ownerDocument !== t) {
      if (((e.ownerDocument = t), e.nodeType === j && e.attributes))
        for (var r = 0; r < e.attributes.length; r++) {
          var n = e.attributes.item(r);
          n && (n.ownerDocument = t);
        }
      for (var i = e.firstChild; i;) (Be(i, t), (i = i.nextSibling));
    }
  }
  function ci(e, t) {
    (t.parentNode && t.parentNode.removeChild(t),
      (t.parentNode = e),
      (t.previousSibling = e.lastChild),
      (t.nextSibling = null),
      t.previousSibling
        ? (t.previousSibling.nextSibling = t)
        : (e.firstChild = t),
      (e.lastChild = t),
      Ot(e.ownerDocument, e, t));
    var r = e.ownerDocument || e;
    return (Be(t, r), t);
  }
  Pe.prototype = {
    nodeName: "#document",
    nodeType: br,
    doctype: null,
    documentElement: null,
    _inc: 1,
    insertBefore: function (e, t) {
      if (e.nodeType == te) {
        for (var r = e.firstChild; r;) {
          var n = r.nextSibling;
          (this.insertBefore(r, t), (r = n));
        }
        return e;
      }
      return (
        ot(this, e, t),
        Be(e, this),
        this.documentElement === null &&
          e.nodeType === j &&
          (this.documentElement = e),
        e
      );
    },
    removeChild: function (e) {
      return (
        this.documentElement == e && (this.documentElement = null),
        Cr(this, e)
      );
    },
    replaceChild: function (e, t) {
      (ot(this, e, t, Nr),
        Be(e, this),
        t && this.removeChild(t),
        ee(e) && (this.documentElement = e));
    },
    importNode: function (e, t) {
      return mi(this, e, t);
    },
    getElementById: function (e) {
      var t = null;
      return (
        st(this.documentElement, function (r) {
          if (r.nodeType == j && r.getAttribute("id") == e)
            return ((t = r), !0);
        }),
        t
      );
    },
    getElementsByClassName: function (e) {
      var t = mr(e);
      return new Ae(this, function (r) {
        var n = [];
        return (
          t.length > 0 &&
            st(r.documentElement, function (i) {
              if (i !== r && i.nodeType === j) {
                var a = i.getAttribute("class");
                if (a) {
                  var u = e === a;
                  if (!u) {
                    var s = mr(a);
                    u = t.every(ti(s));
                  }
                  u && n.push(i);
                }
              }
            }),
          n
        );
      });
    },
    createElement: function (e) {
      var t = new me();
      ((t.ownerDocument = this),
        (t.nodeName = e),
        (t.tagName = e),
        (t.localName = e),
        (t.childNodes = new re()));
      var r = (t.attributes = new ut());
      return ((r._ownerElement = t), t);
    },
    createDocumentFragment: function () {
      var e = new mt();
      return ((e.ownerDocument = this), (e.childNodes = new re()), e);
    },
    createTextNode: function (e) {
      var t = new Bt();
      return ((t.ownerDocument = this), t.appendData(e), t);
    },
    createComment: function (e) {
      var t = new Ft();
      return ((t.ownerDocument = this), t.appendData(e), t);
    },
    createCDATASection: function (e) {
      if (e.indexOf("]]>") !== -1) throw new I(ii, 'data contains "]]>"');
      var t = new Pt();
      return ((t.ownerDocument = this), t.appendData(e), t);
    },
    createProcessingInstruction: function (e, t) {
      var r = new Ut();
      return (
        (r.ownerDocument = this),
        (r.tagName = r.nodeName = r.target = e),
        (r.nodeValue = r.data = t),
        r
      );
    },
    createAttribute: function (e) {
      var t = new lt();
      return (
        (t.ownerDocument = this),
        (t.name = e),
        (t.nodeName = e),
        (t.localName = e),
        (t.specified = !0),
        t
      );
    },
    createEntityReference: function (e) {
      var t = new Lt();
      return ((t.ownerDocument = this), (t.nodeName = e), t);
    },
    createElementNS: function (e, t) {
      var r = new me(),
        n = t.split(":"),
        i = (r.attributes = new ut());
      return (
        (r.childNodes = new re()),
        (r.ownerDocument = this),
        (r.nodeName = t),
        (r.tagName = t),
        (r.namespaceURI = e),
        n.length == 2
          ? ((r.prefix = n[0]), (r.localName = n[1]))
          : (r.localName = t),
        (i._ownerElement = r),
        r
      );
    },
    createAttributeNS: function (e, t) {
      var r = new lt(),
        n = t.split(":");
      return (
        (r.ownerDocument = this),
        (r.nodeName = t),
        (r.name = t),
        (r.namespaceURI = e),
        (r.specified = !0),
        n.length == 2
          ? ((r.prefix = n[0]), (r.localName = n[1]))
          : (r.localName = t),
        r
      );
    },
  };
  W(Pe, N);
  function me() {
    this._nsMap = {};
  }
  me.prototype = {
    nodeType: j,
    hasAttribute: function (e) {
      return this.getAttributeNode(e) != null;
    },
    getAttribute: function (e) {
      var t = this.getAttributeNode(e);
      return (t && t.value) || "";
    },
    getAttributeNode: function (e) {
      return this.attributes.getNamedItem(e);
    },
    setAttribute: function (e, t) {
      var r = this.ownerDocument.createAttribute(e);
      ((r.value = r.nodeValue = "" + t), this.setAttributeNode(r));
    },
    removeAttribute: function (e) {
      var t = this.getAttributeNode(e);
      t && this.removeAttributeNode(t);
    },
    appendChild: function (e) {
      return e.nodeType === te ? this.insertBefore(e, null) : ci(this, e);
    },
    setAttributeNode: function (e) {
      return this.attributes.setNamedItem(e);
    },
    setAttributeNodeNS: function (e) {
      return this.attributes.setNamedItemNS(e);
    },
    removeAttributeNode: function (e) {
      return this.attributes.removeNamedItem(e.nodeName);
    },
    removeAttributeNS: function (e, t) {
      var r = this.getAttributeNodeNS(e, t);
      r && this.removeAttributeNode(r);
    },
    hasAttributeNS: function (e, t) {
      return this.getAttributeNodeNS(e, t) != null;
    },
    getAttributeNS: function (e, t) {
      var r = this.getAttributeNodeNS(e, t);
      return (r && r.value) || "";
    },
    setAttributeNS: function (e, t, r) {
      var n = this.ownerDocument.createAttributeNS(e, t);
      ((n.value = n.nodeValue = "" + r), this.setAttributeNode(n));
    },
    getAttributeNodeNS: function (e, t) {
      return this.attributes.getNamedItemNS(e, t);
    },
    getElementsByTagName: function (e) {
      return new Ae(this, function (t) {
        var r = [];
        return (
          st(t, function (n) {
            n !== t &&
              n.nodeType == j &&
              (e === "*" || n.tagName == e) &&
              r.push(n);
          }),
          r
        );
      });
    },
    getElementsByTagNameNS: function (e, t) {
      return new Ae(this, function (r) {
        var n = [];
        return (
          st(r, function (i) {
            i !== r &&
              i.nodeType === j &&
              (e === "*" || i.namespaceURI === e) &&
              (t === "*" || i.localName == t) &&
              n.push(i);
          }),
          n
        );
      });
    },
  };
  Pe.prototype.getElementsByTagName = me.prototype.getElementsByTagName;
  Pe.prototype.getElementsByTagNameNS = me.prototype.getElementsByTagNameNS;
  W(me, N);
  function lt() {}
  lt.prototype.nodeType = he;
  W(lt, N);
  function Le() {}
  Le.prototype = {
    data: "",
    substringData: function (e, t) {
      return this.data.substring(e, e + t);
    },
    appendData: function (e) {
      ((e = this.data + e),
        (this.nodeValue = this.data = e),
        (this.length = e.length));
    },
    insertData: function (e, t) {
      this.replaceData(e, 0, t);
    },
    appendChild: function (e) {
      throw new Error(k[$]);
    },
    deleteData: function (e, t) {
      this.replaceData(e, t, "");
    },
    replaceData: function (e, t, r) {
      var n = this.data.substring(0, e),
        i = this.data.substring(e + t);
      ((r = n + r + i),
        (this.nodeValue = this.data = r),
        (this.length = r.length));
    },
  };
  W(Le, N);
  function Bt() {}
  Bt.prototype = {
    nodeName: "#text",
    nodeType: at,
    splitText: function (e) {
      var t = this.data,
        r = t.substring(e);
      ((t = t.substring(0, e)),
        (this.data = this.nodeValue = t),
        (this.length = t.length));
      var n = this.ownerDocument.createTextNode(r);
      return (
        this.parentNode && this.parentNode.insertBefore(n, this.nextSibling),
        n
      );
    },
  };
  W(Bt, Le);
  function Ft() {}
  Ft.prototype = { nodeName: "#comment", nodeType: It };
  W(Ft, Le);
  function Pt() {}
  Pt.prototype = { nodeName: "#cdata-section", nodeType: Er };
  W(Pt, Le);
  function ct() {}
  ct.prototype.nodeType = vr;
  W(ct, N);
  function Ir() {}
  Ir.prototype.nodeType = ni;
  W(Ir, N);
  function Rr() {}
  Rr.prototype.nodeType = ri;
  W(Rr, N);
  function Lt() {}
  Lt.prototype.nodeType = yr;
  W(Lt, N);
  function mt() {}
  mt.prototype.nodeName = "#document-fragment";
  mt.prototype.nodeType = te;
  W(mt, N);
  function Ut() {}
  Ut.prototype.nodeType = Nt;
  W(Ut, N);
  function Or() {}
  Or.prototype.serializeToString = function (e, t, r, n) {
    return Mr.call(e, t, r, n);
  };
  N.prototype.toString = Mr;
  function Mr(e, t, r) {
    var n = !!r && !!r.requireWellFormed,
      i = [],
      a = (this.nodeType == 9 && this.documentElement) || this,
      u = a.prefix,
      s = a.namespaceURI;
    if (s && u == null) {
      var u = a.lookupPrefix(s);
      if (u == null) var l = [{ namespace: s, prefix: null }];
    }
    return (kt(this, i, e, t, l, n), i.join(""));
  }
  function Ar(e, t, r) {
    var n = e.prefix || "",
      i = e.namespaceURI;
    if (!i || (n === "xml" && i === Me.XML) || i === Me.XMLNS) return !1;
    for (var a = r.length; a--;) {
      var u = r[a];
      if (u.prefix === n) return u.namespace !== i;
    }
    return !0;
  }
  function it(e, t, r) {
    e.push(" ", t, '="', r.replace(/[<>&"\t\n\r]/g, wr), '"');
  }
  function kt(e, t, r, n, i, a) {
    (i || (i = []),
      U(
        e,
        { ns: i, isHTML: r },
        {
          enter: function (u, s) {
            var l = s.ns,
              o = s.isHTML;
            if (n)
              if (((u = n(u)), u)) {
                if (typeof u == "string") return (t.push(u), null);
              } else return null;
            switch (u.nodeType) {
              case j:
                var m = u.attributes,
                  d = m.length,
                  g = u.tagName;
                o = Me.isHTML(u.namespaceURI) || o;
                var D = g;
                if (!o && !u.prefix && u.namespaceURI) {
                  for (var b, c = 0; c < m.length; c++)
                    if (m.item(c).name === "xmlns") {
                      b = m.item(c).value;
                      break;
                    }
                  if (!b)
                    for (var v = l.length - 1; v >= 0; v--) {
                      var T = l[v];
                      if (T.prefix === "" && T.namespace === u.namespaceURI) {
                        b = T.namespace;
                        break;
                      }
                    }
                  if (b !== u.namespaceURI)
                    for (var v = l.length - 1; v >= 0; v--) {
                      var T = l[v];
                      if (T.namespace === u.namespaceURI) {
                        T.prefix && (D = T.prefix + ":" + g);
                        break;
                      }
                    }
                }
                t.push("<", D);
                for (var h = l.slice(), f = 0; f < d; f++) {
                  var p = m.item(f);
                  p.prefix == "xmlns"
                    ? h.push({ prefix: p.localName, namespace: p.value })
                    : p.nodeName == "xmlns" &&
                      h.push({ prefix: "", namespace: p.value });
                }
                for (var f = 0; f < d; f++) {
                  var p = m.item(f);
                  if (Ar(p, o, h)) {
                    var A = p.prefix || "",
                      y = p.namespaceURI;
                    (it(t, A ? "xmlns:" + A : "xmlns", y),
                      h.push({ prefix: A, namespace: y }));
                  }
                  var _ = n ? n(p) : p;
                  _ &&
                    (typeof _ == "string" ? t.push(_) : it(t, _.name, _.value));
                }
                if (g === D && Ar(u, o, h)) {
                  var R = u.prefix || "",
                    y = u.namespaceURI;
                  (it(t, R ? "xmlns:" + R : "xmlns", y),
                    h.push({ prefix: R, namespace: y }));
                }
                var w = u.firstChild;
                if (w || (o && !/^(?:meta|link|img|br|hr|input)$/i.test(g))) {
                  if ((t.push(">"), o && /^script$/i.test(g))) {
                    for (; w;)
                      (w.data ? t.push(w.data) : kt(w, t, o, n, h.slice(), a),
                        (w = w.nextSibling));
                    return (t.push("</", g, ">"), null);
                  }
                  return { ns: h, isHTML: o, tag: D };
                } else return (t.push("/>"), null);
              case br:
              case te:
                return { ns: l.slice(), isHTML: o, tag: null };
              case he:
                return (it(t, u.name, u.value), null);
              case at:
                return (t.push(u.data.replace(/[<&>]/g, wr)), null);
              case Er:
                if (a && u.data.indexOf("]]>") !== -1)
                  throw new I(ge, 'The CDATASection data contains "]]>"');
                return (
                  t.push(
                    "<![CDATA[",
                    u.data.replace(/]]>/g, "]]]]><![CDATA[>"),
                    "]]>",
                  ),
                  null
                );
              case It:
                if (a && u.data.indexOf("-->") !== -1)
                  throw new I(ge, 'The comment node data contains "-->"');
                return (t.push("<!--", u.data, "-->"), null);
              case vr:
                if (a) {
                  if (
                    u.publicId &&
                    !/^("[\x20\r\na-zA-Z0-9\-()+,.\/:=?;!*#@$_%']*"|'[\x20\r\na-zA-Z0-9\-()+,.\/:=?;!*#@$_%'"]*')$/.test(
                      u.publicId,
                    )
                  )
                    throw new I(
                      ge,
                      "DocumentType publicId is not a valid PubidLiteral",
                    );
                  if (u.systemId && !/^("[^"]*"|'[^']*')$/.test(u.systemId))
                    throw new I(
                      ge,
                      "DocumentType systemId is not a valid SystemLiteral",
                    );
                  if (u.internalSubset && u.internalSubset.indexOf("]>") !== -1)
                    throw new I(
                      ge,
                      'DocumentType internalSubset contains "]>"',
                    );
                }
                var F = u.publicId,
                  E = u.systemId;
                if ((t.push("<!DOCTYPE ", u.name), F))
                  (t.push(" PUBLIC ", F),
                    E && E != "." && t.push(" ", E),
                    t.push(">"));
                else if (E && E != ".") t.push(" SYSTEM ", E, ">");
                else {
                  var L = u.internalSubset;
                  (L && t.push(" [", L, "]"), t.push(">"));
                }
                return null;
              case Nt:
                if (a && u.data.indexOf("?>") !== -1)
                  throw new I(
                    ge,
                    'The ProcessingInstruction data contains "?>"',
                  );
                return (t.push("<?", u.target, " ", u.data, "?>"), null);
              case yr:
                return (t.push("&", u.nodeName, ";"), null);
              default:
                return (t.push("??", u.nodeName), null);
            }
          },
          exit: function (u, s) {
            s && s.tag && t.push("</", s.tag, ">");
          },
        },
      ));
  }
  function mi(e, t, r) {
    var n;
    return (
      U(t, null, {
        enter: function (i, a) {
          var u = i.cloneNode(!1);
          ((u.ownerDocument = e),
            (u.parentNode = null),
            a === null ? (n = u) : a.appendChild(u));
          var s = i.nodeType === he || r;
          return s ? u : null;
        },
      }),
      n
    );
  }
  function Br(e, t, r) {
    var n;
    return (
      U(t, null, {
        enter: function (i, a) {
          var u = new i.constructor();
          for (var s in i)
            if (Object.prototype.hasOwnProperty.call(i, s)) {
              var l = i[s];
              typeof l != "object" && l != u[s] && (u[s] = l);
            }
          (i.childNodes && (u.childNodes = new re()), (u.ownerDocument = e));
          var o = r;
          switch (u.nodeType) {
            case j:
              var m = i.attributes,
                d = (u.attributes = new ut()),
                g = m.length;
              d._ownerElement = u;
              for (var D = 0; D < g; D++)
                u.setAttributeNode(Br(e, m.item(D), !0));
              break;
            case he:
              o = !0;
          }
          return (a !== null ? a.appendChild(u) : (n = u), o ? u : null);
        },
      }),
      n
    );
  }
  function Fr(e, t, r) {
    e[t] = r;
  }
  try {
    Object.defineProperty &&
      (Object.defineProperty(Ae.prototype, "length", {
        get: function () {
          return (Rt(this), this.$$length);
        },
      }),
      Object.defineProperty(N.prototype, "textContent", {
        get: function () {
          if (this.nodeType === j || this.nodeType === te) {
            var e = [];
            return (
              U(this, null, {
                enter: function (t) {
                  if (t.nodeType === j || t.nodeType === te) return !0;
                  if (t.nodeType === Nt || t.nodeType === It) return null;
                  e.push(t.nodeValue);
                },
              }),
              e.join("")
            );
          }
          return this.nodeValue;
        },
        set: function (e) {
          switch (this.nodeType) {
            case j:
            case te:
              for (; this.firstChild;) this.removeChild(this.firstChild);
              (e || String(e)) &&
                this.appendChild(this.ownerDocument.createTextNode(e));
              break;
            default:
              ((this.data = e), (this.value = e), (this.nodeValue = e));
          }
        },
      }),
      (Fr = function (e, t, r) {
        e["$$" + t] = r;
      }));
  } catch {}
  ie.DocumentType = ct;
  ie.DOMException = I;
  ie.DOMImplementation = Sr;
  ie.Element = me;
  ie.Node = N;
  ie.NodeList = re;
  ie.walkDOM = U;
  ie.XMLSerializer = Or;
});
var Lr = ue((Ue) => {
  "use strict";
  var Pr = Oe().freeze;
  Ue.XML_ENTITIES = Pr({ amp: "&", apos: "'", gt: ">", lt: "<", quot: '"' });
  Ue.HTML_ENTITIES = Pr({
    Aacute: "\xC1",
    aacute: "\xE1",
    Abreve: "\u0102",
    abreve: "\u0103",
    ac: "\u223E",
    acd: "\u223F",
    acE: "\u223E\u0333",
    Acirc: "\xC2",
    acirc: "\xE2",
    acute: "\xB4",
    Acy: "\u0410",
    acy: "\u0430",
    AElig: "\xC6",
    aelig: "\xE6",
    af: "\u2061",
    Afr: "\u{1D504}",
    afr: "\u{1D51E}",
    Agrave: "\xC0",
    agrave: "\xE0",
    alefsym: "\u2135",
    aleph: "\u2135",
    Alpha: "\u0391",
    alpha: "\u03B1",
    Amacr: "\u0100",
    amacr: "\u0101",
    amalg: "\u2A3F",
    AMP: "&",
    amp: "&",
    And: "\u2A53",
    and: "\u2227",
    andand: "\u2A55",
    andd: "\u2A5C",
    andslope: "\u2A58",
    andv: "\u2A5A",
    ang: "\u2220",
    ange: "\u29A4",
    angle: "\u2220",
    angmsd: "\u2221",
    angmsdaa: "\u29A8",
    angmsdab: "\u29A9",
    angmsdac: "\u29AA",
    angmsdad: "\u29AB",
    angmsdae: "\u29AC",
    angmsdaf: "\u29AD",
    angmsdag: "\u29AE",
    angmsdah: "\u29AF",
    angrt: "\u221F",
    angrtvb: "\u22BE",
    angrtvbd: "\u299D",
    angsph: "\u2222",
    angst: "\xC5",
    angzarr: "\u237C",
    Aogon: "\u0104",
    aogon: "\u0105",
    Aopf: "\u{1D538}",
    aopf: "\u{1D552}",
    ap: "\u2248",
    apacir: "\u2A6F",
    apE: "\u2A70",
    ape: "\u224A",
    apid: "\u224B",
    apos: "'",
    ApplyFunction: "\u2061",
    approx: "\u2248",
    approxeq: "\u224A",
    Aring: "\xC5",
    aring: "\xE5",
    Ascr: "\u{1D49C}",
    ascr: "\u{1D4B6}",
    Assign: "\u2254",
    ast: "*",
    asymp: "\u2248",
    asympeq: "\u224D",
    Atilde: "\xC3",
    atilde: "\xE3",
    Auml: "\xC4",
    auml: "\xE4",
    awconint: "\u2233",
    awint: "\u2A11",
    backcong: "\u224C",
    backepsilon: "\u03F6",
    backprime: "\u2035",
    backsim: "\u223D",
    backsimeq: "\u22CD",
    Backslash: "\u2216",
    Barv: "\u2AE7",
    barvee: "\u22BD",
    Barwed: "\u2306",
    barwed: "\u2305",
    barwedge: "\u2305",
    bbrk: "\u23B5",
    bbrktbrk: "\u23B6",
    bcong: "\u224C",
    Bcy: "\u0411",
    bcy: "\u0431",
    bdquo: "\u201E",
    becaus: "\u2235",
    Because: "\u2235",
    because: "\u2235",
    bemptyv: "\u29B0",
    bepsi: "\u03F6",
    bernou: "\u212C",
    Bernoullis: "\u212C",
    Beta: "\u0392",
    beta: "\u03B2",
    beth: "\u2136",
    between: "\u226C",
    Bfr: "\u{1D505}",
    bfr: "\u{1D51F}",
    bigcap: "\u22C2",
    bigcirc: "\u25EF",
    bigcup: "\u22C3",
    bigodot: "\u2A00",
    bigoplus: "\u2A01",
    bigotimes: "\u2A02",
    bigsqcup: "\u2A06",
    bigstar: "\u2605",
    bigtriangledown: "\u25BD",
    bigtriangleup: "\u25B3",
    biguplus: "\u2A04",
    bigvee: "\u22C1",
    bigwedge: "\u22C0",
    bkarow: "\u290D",
    blacklozenge: "\u29EB",
    blacksquare: "\u25AA",
    blacktriangle: "\u25B4",
    blacktriangledown: "\u25BE",
    blacktriangleleft: "\u25C2",
    blacktriangleright: "\u25B8",
    blank: "\u2423",
    blk12: "\u2592",
    blk14: "\u2591",
    blk34: "\u2593",
    block: "\u2588",
    bne: "=\u20E5",
    bnequiv: "\u2261\u20E5",
    bNot: "\u2AED",
    bnot: "\u2310",
    Bopf: "\u{1D539}",
    bopf: "\u{1D553}",
    bot: "\u22A5",
    bottom: "\u22A5",
    bowtie: "\u22C8",
    boxbox: "\u29C9",
    boxDL: "\u2557",
    boxDl: "\u2556",
    boxdL: "\u2555",
    boxdl: "\u2510",
    boxDR: "\u2554",
    boxDr: "\u2553",
    boxdR: "\u2552",
    boxdr: "\u250C",
    boxH: "\u2550",
    boxh: "\u2500",
    boxHD: "\u2566",
    boxHd: "\u2564",
    boxhD: "\u2565",
    boxhd: "\u252C",
    boxHU: "\u2569",
    boxHu: "\u2567",
    boxhU: "\u2568",
    boxhu: "\u2534",
    boxminus: "\u229F",
    boxplus: "\u229E",
    boxtimes: "\u22A0",
    boxUL: "\u255D",
    boxUl: "\u255C",
    boxuL: "\u255B",
    boxul: "\u2518",
    boxUR: "\u255A",
    boxUr: "\u2559",
    boxuR: "\u2558",
    boxur: "\u2514",
    boxV: "\u2551",
    boxv: "\u2502",
    boxVH: "\u256C",
    boxVh: "\u256B",
    boxvH: "\u256A",
    boxvh: "\u253C",
    boxVL: "\u2563",
    boxVl: "\u2562",
    boxvL: "\u2561",
    boxvl: "\u2524",
    boxVR: "\u2560",
    boxVr: "\u255F",
    boxvR: "\u255E",
    boxvr: "\u251C",
    bprime: "\u2035",
    Breve: "\u02D8",
    breve: "\u02D8",
    brvbar: "\xA6",
    Bscr: "\u212C",
    bscr: "\u{1D4B7}",
    bsemi: "\u204F",
    bsim: "\u223D",
    bsime: "\u22CD",
    bsol: "\\",
    bsolb: "\u29C5",
    bsolhsub: "\u27C8",
    bull: "\u2022",
    bullet: "\u2022",
    bump: "\u224E",
    bumpE: "\u2AAE",
    bumpe: "\u224F",
    Bumpeq: "\u224E",
    bumpeq: "\u224F",
    Cacute: "\u0106",
    cacute: "\u0107",
    Cap: "\u22D2",
    cap: "\u2229",
    capand: "\u2A44",
    capbrcup: "\u2A49",
    capcap: "\u2A4B",
    capcup: "\u2A47",
    capdot: "\u2A40",
    CapitalDifferentialD: "\u2145",
    caps: "\u2229\uFE00",
    caret: "\u2041",
    caron: "\u02C7",
    Cayleys: "\u212D",
    ccaps: "\u2A4D",
    Ccaron: "\u010C",
    ccaron: "\u010D",
    Ccedil: "\xC7",
    ccedil: "\xE7",
    Ccirc: "\u0108",
    ccirc: "\u0109",
    Cconint: "\u2230",
    ccups: "\u2A4C",
    ccupssm: "\u2A50",
    Cdot: "\u010A",
    cdot: "\u010B",
    cedil: "\xB8",
    Cedilla: "\xB8",
    cemptyv: "\u29B2",
    cent: "\xA2",
    CenterDot: "\xB7",
    centerdot: "\xB7",
    Cfr: "\u212D",
    cfr: "\u{1D520}",
    CHcy: "\u0427",
    chcy: "\u0447",
    check: "\u2713",
    checkmark: "\u2713",
    Chi: "\u03A7",
    chi: "\u03C7",
    cir: "\u25CB",
    circ: "\u02C6",
    circeq: "\u2257",
    circlearrowleft: "\u21BA",
    circlearrowright: "\u21BB",
    circledast: "\u229B",
    circledcirc: "\u229A",
    circleddash: "\u229D",
    CircleDot: "\u2299",
    circledR: "\xAE",
    circledS: "\u24C8",
    CircleMinus: "\u2296",
    CirclePlus: "\u2295",
    CircleTimes: "\u2297",
    cirE: "\u29C3",
    cire: "\u2257",
    cirfnint: "\u2A10",
    cirmid: "\u2AEF",
    cirscir: "\u29C2",
    ClockwiseContourIntegral: "\u2232",
    CloseCurlyDoubleQuote: "\u201D",
    CloseCurlyQuote: "\u2019",
    clubs: "\u2663",
    clubsuit: "\u2663",
    Colon: "\u2237",
    colon: ":",
    Colone: "\u2A74",
    colone: "\u2254",
    coloneq: "\u2254",
    comma: ",",
    commat: "@",
    comp: "\u2201",
    compfn: "\u2218",
    complement: "\u2201",
    complexes: "\u2102",
    cong: "\u2245",
    congdot: "\u2A6D",
    Congruent: "\u2261",
    Conint: "\u222F",
    conint: "\u222E",
    ContourIntegral: "\u222E",
    Copf: "\u2102",
    copf: "\u{1D554}",
    coprod: "\u2210",
    Coproduct: "\u2210",
    COPY: "\xA9",
    copy: "\xA9",
    copysr: "\u2117",
    CounterClockwiseContourIntegral: "\u2233",
    crarr: "\u21B5",
    Cross: "\u2A2F",
    cross: "\u2717",
    Cscr: "\u{1D49E}",
    cscr: "\u{1D4B8}",
    csub: "\u2ACF",
    csube: "\u2AD1",
    csup: "\u2AD0",
    csupe: "\u2AD2",
    ctdot: "\u22EF",
    cudarrl: "\u2938",
    cudarrr: "\u2935",
    cuepr: "\u22DE",
    cuesc: "\u22DF",
    cularr: "\u21B6",
    cularrp: "\u293D",
    Cup: "\u22D3",
    cup: "\u222A",
    cupbrcap: "\u2A48",
    CupCap: "\u224D",
    cupcap: "\u2A46",
    cupcup: "\u2A4A",
    cupdot: "\u228D",
    cupor: "\u2A45",
    cups: "\u222A\uFE00",
    curarr: "\u21B7",
    curarrm: "\u293C",
    curlyeqprec: "\u22DE",
    curlyeqsucc: "\u22DF",
    curlyvee: "\u22CE",
    curlywedge: "\u22CF",
    curren: "\xA4",
    curvearrowleft: "\u21B6",
    curvearrowright: "\u21B7",
    cuvee: "\u22CE",
    cuwed: "\u22CF",
    cwconint: "\u2232",
    cwint: "\u2231",
    cylcty: "\u232D",
    Dagger: "\u2021",
    dagger: "\u2020",
    daleth: "\u2138",
    Darr: "\u21A1",
    dArr: "\u21D3",
    darr: "\u2193",
    dash: "\u2010",
    Dashv: "\u2AE4",
    dashv: "\u22A3",
    dbkarow: "\u290F",
    dblac: "\u02DD",
    Dcaron: "\u010E",
    dcaron: "\u010F",
    Dcy: "\u0414",
    dcy: "\u0434",
    DD: "\u2145",
    dd: "\u2146",
    ddagger: "\u2021",
    ddarr: "\u21CA",
    DDotrahd: "\u2911",
    ddotseq: "\u2A77",
    deg: "\xB0",
    Del: "\u2207",
    Delta: "\u0394",
    delta: "\u03B4",
    demptyv: "\u29B1",
    dfisht: "\u297F",
    Dfr: "\u{1D507}",
    dfr: "\u{1D521}",
    dHar: "\u2965",
    dharl: "\u21C3",
    dharr: "\u21C2",
    DiacriticalAcute: "\xB4",
    DiacriticalDot: "\u02D9",
    DiacriticalDoubleAcute: "\u02DD",
    DiacriticalGrave: "`",
    DiacriticalTilde: "\u02DC",
    diam: "\u22C4",
    Diamond: "\u22C4",
    diamond: "\u22C4",
    diamondsuit: "\u2666",
    diams: "\u2666",
    die: "\xA8",
    DifferentialD: "\u2146",
    digamma: "\u03DD",
    disin: "\u22F2",
    div: "\xF7",
    divide: "\xF7",
    divideontimes: "\u22C7",
    divonx: "\u22C7",
    DJcy: "\u0402",
    djcy: "\u0452",
    dlcorn: "\u231E",
    dlcrop: "\u230D",
    dollar: "$",
    Dopf: "\u{1D53B}",
    dopf: "\u{1D555}",
    Dot: "\xA8",
    dot: "\u02D9",
    DotDot: "\u20DC",
    doteq: "\u2250",
    doteqdot: "\u2251",
    DotEqual: "\u2250",
    dotminus: "\u2238",
    dotplus: "\u2214",
    dotsquare: "\u22A1",
    doublebarwedge: "\u2306",
    DoubleContourIntegral: "\u222F",
    DoubleDot: "\xA8",
    DoubleDownArrow: "\u21D3",
    DoubleLeftArrow: "\u21D0",
    DoubleLeftRightArrow: "\u21D4",
    DoubleLeftTee: "\u2AE4",
    DoubleLongLeftArrow: "\u27F8",
    DoubleLongLeftRightArrow: "\u27FA",
    DoubleLongRightArrow: "\u27F9",
    DoubleRightArrow: "\u21D2",
    DoubleRightTee: "\u22A8",
    DoubleUpArrow: "\u21D1",
    DoubleUpDownArrow: "\u21D5",
    DoubleVerticalBar: "\u2225",
    DownArrow: "\u2193",
    Downarrow: "\u21D3",
    downarrow: "\u2193",
    DownArrowBar: "\u2913",
    DownArrowUpArrow: "\u21F5",
    DownBreve: "\u0311",
    downdownarrows: "\u21CA",
    downharpoonleft: "\u21C3",
    downharpoonright: "\u21C2",
    DownLeftRightVector: "\u2950",
    DownLeftTeeVector: "\u295E",
    DownLeftVector: "\u21BD",
    DownLeftVectorBar: "\u2956",
    DownRightTeeVector: "\u295F",
    DownRightVector: "\u21C1",
    DownRightVectorBar: "\u2957",
    DownTee: "\u22A4",
    DownTeeArrow: "\u21A7",
    drbkarow: "\u2910",
    drcorn: "\u231F",
    drcrop: "\u230C",
    Dscr: "\u{1D49F}",
    dscr: "\u{1D4B9}",
    DScy: "\u0405",
    dscy: "\u0455",
    dsol: "\u29F6",
    Dstrok: "\u0110",
    dstrok: "\u0111",
    dtdot: "\u22F1",
    dtri: "\u25BF",
    dtrif: "\u25BE",
    duarr: "\u21F5",
    duhar: "\u296F",
    dwangle: "\u29A6",
    DZcy: "\u040F",
    dzcy: "\u045F",
    dzigrarr: "\u27FF",
    Eacute: "\xC9",
    eacute: "\xE9",
    easter: "\u2A6E",
    Ecaron: "\u011A",
    ecaron: "\u011B",
    ecir: "\u2256",
    Ecirc: "\xCA",
    ecirc: "\xEA",
    ecolon: "\u2255",
    Ecy: "\u042D",
    ecy: "\u044D",
    eDDot: "\u2A77",
    Edot: "\u0116",
    eDot: "\u2251",
    edot: "\u0117",
    ee: "\u2147",
    efDot: "\u2252",
    Efr: "\u{1D508}",
    efr: "\u{1D522}",
    eg: "\u2A9A",
    Egrave: "\xC8",
    egrave: "\xE8",
    egs: "\u2A96",
    egsdot: "\u2A98",
    el: "\u2A99",
    Element: "\u2208",
    elinters: "\u23E7",
    ell: "\u2113",
    els: "\u2A95",
    elsdot: "\u2A97",
    Emacr: "\u0112",
    emacr: "\u0113",
    empty: "\u2205",
    emptyset: "\u2205",
    EmptySmallSquare: "\u25FB",
    emptyv: "\u2205",
    EmptyVerySmallSquare: "\u25AB",
    emsp: "\u2003",
    emsp13: "\u2004",
    emsp14: "\u2005",
    ENG: "\u014A",
    eng: "\u014B",
    ensp: "\u2002",
    Eogon: "\u0118",
    eogon: "\u0119",
    Eopf: "\u{1D53C}",
    eopf: "\u{1D556}",
    epar: "\u22D5",
    eparsl: "\u29E3",
    eplus: "\u2A71",
    epsi: "\u03B5",
    Epsilon: "\u0395",
    epsilon: "\u03B5",
    epsiv: "\u03F5",
    eqcirc: "\u2256",
    eqcolon: "\u2255",
    eqsim: "\u2242",
    eqslantgtr: "\u2A96",
    eqslantless: "\u2A95",
    Equal: "\u2A75",
    equals: "=",
    EqualTilde: "\u2242",
    equest: "\u225F",
    Equilibrium: "\u21CC",
    equiv: "\u2261",
    equivDD: "\u2A78",
    eqvparsl: "\u29E5",
    erarr: "\u2971",
    erDot: "\u2253",
    Escr: "\u2130",
    escr: "\u212F",
    esdot: "\u2250",
    Esim: "\u2A73",
    esim: "\u2242",
    Eta: "\u0397",
    eta: "\u03B7",
    ETH: "\xD0",
    eth: "\xF0",
    Euml: "\xCB",
    euml: "\xEB",
    euro: "\u20AC",
    excl: "!",
    exist: "\u2203",
    Exists: "\u2203",
    expectation: "\u2130",
    ExponentialE: "\u2147",
    exponentiale: "\u2147",
    fallingdotseq: "\u2252",
    Fcy: "\u0424",
    fcy: "\u0444",
    female: "\u2640",
    ffilig: "\uFB03",
    fflig: "\uFB00",
    ffllig: "\uFB04",
    Ffr: "\u{1D509}",
    ffr: "\u{1D523}",
    filig: "\uFB01",
    FilledSmallSquare: "\u25FC",
    FilledVerySmallSquare: "\u25AA",
    fjlig: "fj",
    flat: "\u266D",
    fllig: "\uFB02",
    fltns: "\u25B1",
    fnof: "\u0192",
    Fopf: "\u{1D53D}",
    fopf: "\u{1D557}",
    ForAll: "\u2200",
    forall: "\u2200",
    fork: "\u22D4",
    forkv: "\u2AD9",
    Fouriertrf: "\u2131",
    fpartint: "\u2A0D",
    frac12: "\xBD",
    frac13: "\u2153",
    frac14: "\xBC",
    frac15: "\u2155",
    frac16: "\u2159",
    frac18: "\u215B",
    frac23: "\u2154",
    frac25: "\u2156",
    frac34: "\xBE",
    frac35: "\u2157",
    frac38: "\u215C",
    frac45: "\u2158",
    frac56: "\u215A",
    frac58: "\u215D",
    frac78: "\u215E",
    frasl: "\u2044",
    frown: "\u2322",
    Fscr: "\u2131",
    fscr: "\u{1D4BB}",
    gacute: "\u01F5",
    Gamma: "\u0393",
    gamma: "\u03B3",
    Gammad: "\u03DC",
    gammad: "\u03DD",
    gap: "\u2A86",
    Gbreve: "\u011E",
    gbreve: "\u011F",
    Gcedil: "\u0122",
    Gcirc: "\u011C",
    gcirc: "\u011D",
    Gcy: "\u0413",
    gcy: "\u0433",
    Gdot: "\u0120",
    gdot: "\u0121",
    gE: "\u2267",
    ge: "\u2265",
    gEl: "\u2A8C",
    gel: "\u22DB",
    geq: "\u2265",
    geqq: "\u2267",
    geqslant: "\u2A7E",
    ges: "\u2A7E",
    gescc: "\u2AA9",
    gesdot: "\u2A80",
    gesdoto: "\u2A82",
    gesdotol: "\u2A84",
    gesl: "\u22DB\uFE00",
    gesles: "\u2A94",
    Gfr: "\u{1D50A}",
    gfr: "\u{1D524}",
    Gg: "\u22D9",
    gg: "\u226B",
    ggg: "\u22D9",
    gimel: "\u2137",
    GJcy: "\u0403",
    gjcy: "\u0453",
    gl: "\u2277",
    gla: "\u2AA5",
    glE: "\u2A92",
    glj: "\u2AA4",
    gnap: "\u2A8A",
    gnapprox: "\u2A8A",
    gnE: "\u2269",
    gne: "\u2A88",
    gneq: "\u2A88",
    gneqq: "\u2269",
    gnsim: "\u22E7",
    Gopf: "\u{1D53E}",
    gopf: "\u{1D558}",
    grave: "`",
    GreaterEqual: "\u2265",
    GreaterEqualLess: "\u22DB",
    GreaterFullEqual: "\u2267",
    GreaterGreater: "\u2AA2",
    GreaterLess: "\u2277",
    GreaterSlantEqual: "\u2A7E",
    GreaterTilde: "\u2273",
    Gscr: "\u{1D4A2}",
    gscr: "\u210A",
    gsim: "\u2273",
    gsime: "\u2A8E",
    gsiml: "\u2A90",
    Gt: "\u226B",
    GT: ">",
    gt: ">",
    gtcc: "\u2AA7",
    gtcir: "\u2A7A",
    gtdot: "\u22D7",
    gtlPar: "\u2995",
    gtquest: "\u2A7C",
    gtrapprox: "\u2A86",
    gtrarr: "\u2978",
    gtrdot: "\u22D7",
    gtreqless: "\u22DB",
    gtreqqless: "\u2A8C",
    gtrless: "\u2277",
    gtrsim: "\u2273",
    gvertneqq: "\u2269\uFE00",
    gvnE: "\u2269\uFE00",
    Hacek: "\u02C7",
    hairsp: "\u200A",
    half: "\xBD",
    hamilt: "\u210B",
    HARDcy: "\u042A",
    hardcy: "\u044A",
    hArr: "\u21D4",
    harr: "\u2194",
    harrcir: "\u2948",
    harrw: "\u21AD",
    Hat: "^",
    hbar: "\u210F",
    Hcirc: "\u0124",
    hcirc: "\u0125",
    hearts: "\u2665",
    heartsuit: "\u2665",
    hellip: "\u2026",
    hercon: "\u22B9",
    Hfr: "\u210C",
    hfr: "\u{1D525}",
    HilbertSpace: "\u210B",
    hksearow: "\u2925",
    hkswarow: "\u2926",
    hoarr: "\u21FF",
    homtht: "\u223B",
    hookleftarrow: "\u21A9",
    hookrightarrow: "\u21AA",
    Hopf: "\u210D",
    hopf: "\u{1D559}",
    horbar: "\u2015",
    HorizontalLine: "\u2500",
    Hscr: "\u210B",
    hscr: "\u{1D4BD}",
    hslash: "\u210F",
    Hstrok: "\u0126",
    hstrok: "\u0127",
    HumpDownHump: "\u224E",
    HumpEqual: "\u224F",
    hybull: "\u2043",
    hyphen: "\u2010",
    Iacute: "\xCD",
    iacute: "\xED",
    ic: "\u2063",
    Icirc: "\xCE",
    icirc: "\xEE",
    Icy: "\u0418",
    icy: "\u0438",
    Idot: "\u0130",
    IEcy: "\u0415",
    iecy: "\u0435",
    iexcl: "\xA1",
    iff: "\u21D4",
    Ifr: "\u2111",
    ifr: "\u{1D526}",
    Igrave: "\xCC",
    igrave: "\xEC",
    ii: "\u2148",
    iiiint: "\u2A0C",
    iiint: "\u222D",
    iinfin: "\u29DC",
    iiota: "\u2129",
    IJlig: "\u0132",
    ijlig: "\u0133",
    Im: "\u2111",
    Imacr: "\u012A",
    imacr: "\u012B",
    image: "\u2111",
    ImaginaryI: "\u2148",
    imagline: "\u2110",
    imagpart: "\u2111",
    imath: "\u0131",
    imof: "\u22B7",
    imped: "\u01B5",
    Implies: "\u21D2",
    in: "\u2208",
    incare: "\u2105",
    infin: "\u221E",
    infintie: "\u29DD",
    inodot: "\u0131",
    Int: "\u222C",
    int: "\u222B",
    intcal: "\u22BA",
    integers: "\u2124",
    Integral: "\u222B",
    intercal: "\u22BA",
    Intersection: "\u22C2",
    intlarhk: "\u2A17",
    intprod: "\u2A3C",
    InvisibleComma: "\u2063",
    InvisibleTimes: "\u2062",
    IOcy: "\u0401",
    iocy: "\u0451",
    Iogon: "\u012E",
    iogon: "\u012F",
    Iopf: "\u{1D540}",
    iopf: "\u{1D55A}",
    Iota: "\u0399",
    iota: "\u03B9",
    iprod: "\u2A3C",
    iquest: "\xBF",
    Iscr: "\u2110",
    iscr: "\u{1D4BE}",
    isin: "\u2208",
    isindot: "\u22F5",
    isinE: "\u22F9",
    isins: "\u22F4",
    isinsv: "\u22F3",
    isinv: "\u2208",
    it: "\u2062",
    Itilde: "\u0128",
    itilde: "\u0129",
    Iukcy: "\u0406",
    iukcy: "\u0456",
    Iuml: "\xCF",
    iuml: "\xEF",
    Jcirc: "\u0134",
    jcirc: "\u0135",
    Jcy: "\u0419",
    jcy: "\u0439",
    Jfr: "\u{1D50D}",
    jfr: "\u{1D527}",
    jmath: "\u0237",
    Jopf: "\u{1D541}",
    jopf: "\u{1D55B}",
    Jscr: "\u{1D4A5}",
    jscr: "\u{1D4BF}",
    Jsercy: "\u0408",
    jsercy: "\u0458",
    Jukcy: "\u0404",
    jukcy: "\u0454",
    Kappa: "\u039A",
    kappa: "\u03BA",
    kappav: "\u03F0",
    Kcedil: "\u0136",
    kcedil: "\u0137",
    Kcy: "\u041A",
    kcy: "\u043A",
    Kfr: "\u{1D50E}",
    kfr: "\u{1D528}",
    kgreen: "\u0138",
    KHcy: "\u0425",
    khcy: "\u0445",
    KJcy: "\u040C",
    kjcy: "\u045C",
    Kopf: "\u{1D542}",
    kopf: "\u{1D55C}",
    Kscr: "\u{1D4A6}",
    kscr: "\u{1D4C0}",
    lAarr: "\u21DA",
    Lacute: "\u0139",
    lacute: "\u013A",
    laemptyv: "\u29B4",
    lagran: "\u2112",
    Lambda: "\u039B",
    lambda: "\u03BB",
    Lang: "\u27EA",
    lang: "\u27E8",
    langd: "\u2991",
    langle: "\u27E8",
    lap: "\u2A85",
    Laplacetrf: "\u2112",
    laquo: "\xAB",
    Larr: "\u219E",
    lArr: "\u21D0",
    larr: "\u2190",
    larrb: "\u21E4",
    larrbfs: "\u291F",
    larrfs: "\u291D",
    larrhk: "\u21A9",
    larrlp: "\u21AB",
    larrpl: "\u2939",
    larrsim: "\u2973",
    larrtl: "\u21A2",
    lat: "\u2AAB",
    lAtail: "\u291B",
    latail: "\u2919",
    late: "\u2AAD",
    lates: "\u2AAD\uFE00",
    lBarr: "\u290E",
    lbarr: "\u290C",
    lbbrk: "\u2772",
    lbrace: "{",
    lbrack: "[",
    lbrke: "\u298B",
    lbrksld: "\u298F",
    lbrkslu: "\u298D",
    Lcaron: "\u013D",
    lcaron: "\u013E",
    Lcedil: "\u013B",
    lcedil: "\u013C",
    lceil: "\u2308",
    lcub: "{",
    Lcy: "\u041B",
    lcy: "\u043B",
    ldca: "\u2936",
    ldquo: "\u201C",
    ldquor: "\u201E",
    ldrdhar: "\u2967",
    ldrushar: "\u294B",
    ldsh: "\u21B2",
    lE: "\u2266",
    le: "\u2264",
    LeftAngleBracket: "\u27E8",
    LeftArrow: "\u2190",
    Leftarrow: "\u21D0",
    leftarrow: "\u2190",
    LeftArrowBar: "\u21E4",
    LeftArrowRightArrow: "\u21C6",
    leftarrowtail: "\u21A2",
    LeftCeiling: "\u2308",
    LeftDoubleBracket: "\u27E6",
    LeftDownTeeVector: "\u2961",
    LeftDownVector: "\u21C3",
    LeftDownVectorBar: "\u2959",
    LeftFloor: "\u230A",
    leftharpoondown: "\u21BD",
    leftharpoonup: "\u21BC",
    leftleftarrows: "\u21C7",
    LeftRightArrow: "\u2194",
    Leftrightarrow: "\u21D4",
    leftrightarrow: "\u2194",
    leftrightarrows: "\u21C6",
    leftrightharpoons: "\u21CB",
    leftrightsquigarrow: "\u21AD",
    LeftRightVector: "\u294E",
    LeftTee: "\u22A3",
    LeftTeeArrow: "\u21A4",
    LeftTeeVector: "\u295A",
    leftthreetimes: "\u22CB",
    LeftTriangle: "\u22B2",
    LeftTriangleBar: "\u29CF",
    LeftTriangleEqual: "\u22B4",
    LeftUpDownVector: "\u2951",
    LeftUpTeeVector: "\u2960",
    LeftUpVector: "\u21BF",
    LeftUpVectorBar: "\u2958",
    LeftVector: "\u21BC",
    LeftVectorBar: "\u2952",
    lEg: "\u2A8B",
    leg: "\u22DA",
    leq: "\u2264",
    leqq: "\u2266",
    leqslant: "\u2A7D",
    les: "\u2A7D",
    lescc: "\u2AA8",
    lesdot: "\u2A7F",
    lesdoto: "\u2A81",
    lesdotor: "\u2A83",
    lesg: "\u22DA\uFE00",
    lesges: "\u2A93",
    lessapprox: "\u2A85",
    lessdot: "\u22D6",
    lesseqgtr: "\u22DA",
    lesseqqgtr: "\u2A8B",
    LessEqualGreater: "\u22DA",
    LessFullEqual: "\u2266",
    LessGreater: "\u2276",
    lessgtr: "\u2276",
    LessLess: "\u2AA1",
    lesssim: "\u2272",
    LessSlantEqual: "\u2A7D",
    LessTilde: "\u2272",
    lfisht: "\u297C",
    lfloor: "\u230A",
    Lfr: "\u{1D50F}",
    lfr: "\u{1D529}",
    lg: "\u2276",
    lgE: "\u2A91",
    lHar: "\u2962",
    lhard: "\u21BD",
    lharu: "\u21BC",
    lharul: "\u296A",
    lhblk: "\u2584",
    LJcy: "\u0409",
    ljcy: "\u0459",
    Ll: "\u22D8",
    ll: "\u226A",
    llarr: "\u21C7",
    llcorner: "\u231E",
    Lleftarrow: "\u21DA",
    llhard: "\u296B",
    lltri: "\u25FA",
    Lmidot: "\u013F",
    lmidot: "\u0140",
    lmoust: "\u23B0",
    lmoustache: "\u23B0",
    lnap: "\u2A89",
    lnapprox: "\u2A89",
    lnE: "\u2268",
    lne: "\u2A87",
    lneq: "\u2A87",
    lneqq: "\u2268",
    lnsim: "\u22E6",
    loang: "\u27EC",
    loarr: "\u21FD",
    lobrk: "\u27E6",
    LongLeftArrow: "\u27F5",
    Longleftarrow: "\u27F8",
    longleftarrow: "\u27F5",
    LongLeftRightArrow: "\u27F7",
    Longleftrightarrow: "\u27FA",
    longleftrightarrow: "\u27F7",
    longmapsto: "\u27FC",
    LongRightArrow: "\u27F6",
    Longrightarrow: "\u27F9",
    longrightarrow: "\u27F6",
    looparrowleft: "\u21AB",
    looparrowright: "\u21AC",
    lopar: "\u2985",
    Lopf: "\u{1D543}",
    lopf: "\u{1D55D}",
    loplus: "\u2A2D",
    lotimes: "\u2A34",
    lowast: "\u2217",
    lowbar: "_",
    LowerLeftArrow: "\u2199",
    LowerRightArrow: "\u2198",
    loz: "\u25CA",
    lozenge: "\u25CA",
    lozf: "\u29EB",
    lpar: "(",
    lparlt: "\u2993",
    lrarr: "\u21C6",
    lrcorner: "\u231F",
    lrhar: "\u21CB",
    lrhard: "\u296D",
    lrm: "\u200E",
    lrtri: "\u22BF",
    lsaquo: "\u2039",
    Lscr: "\u2112",
    lscr: "\u{1D4C1}",
    Lsh: "\u21B0",
    lsh: "\u21B0",
    lsim: "\u2272",
    lsime: "\u2A8D",
    lsimg: "\u2A8F",
    lsqb: "[",
    lsquo: "\u2018",
    lsquor: "\u201A",
    Lstrok: "\u0141",
    lstrok: "\u0142",
    Lt: "\u226A",
    LT: "<",
    lt: "<",
    ltcc: "\u2AA6",
    ltcir: "\u2A79",
    ltdot: "\u22D6",
    lthree: "\u22CB",
    ltimes: "\u22C9",
    ltlarr: "\u2976",
    ltquest: "\u2A7B",
    ltri: "\u25C3",
    ltrie: "\u22B4",
    ltrif: "\u25C2",
    ltrPar: "\u2996",
    lurdshar: "\u294A",
    luruhar: "\u2966",
    lvertneqq: "\u2268\uFE00",
    lvnE: "\u2268\uFE00",
    macr: "\xAF",
    male: "\u2642",
    malt: "\u2720",
    maltese: "\u2720",
    Map: "\u2905",
    map: "\u21A6",
    mapsto: "\u21A6",
    mapstodown: "\u21A7",
    mapstoleft: "\u21A4",
    mapstoup: "\u21A5",
    marker: "\u25AE",
    mcomma: "\u2A29",
    Mcy: "\u041C",
    mcy: "\u043C",
    mdash: "\u2014",
    mDDot: "\u223A",
    measuredangle: "\u2221",
    MediumSpace: "\u205F",
    Mellintrf: "\u2133",
    Mfr: "\u{1D510}",
    mfr: "\u{1D52A}",
    mho: "\u2127",
    micro: "\xB5",
    mid: "\u2223",
    midast: "*",
    midcir: "\u2AF0",
    middot: "\xB7",
    minus: "\u2212",
    minusb: "\u229F",
    minusd: "\u2238",
    minusdu: "\u2A2A",
    MinusPlus: "\u2213",
    mlcp: "\u2ADB",
    mldr: "\u2026",
    mnplus: "\u2213",
    models: "\u22A7",
    Mopf: "\u{1D544}",
    mopf: "\u{1D55E}",
    mp: "\u2213",
    Mscr: "\u2133",
    mscr: "\u{1D4C2}",
    mstpos: "\u223E",
    Mu: "\u039C",
    mu: "\u03BC",
    multimap: "\u22B8",
    mumap: "\u22B8",
    nabla: "\u2207",
    Nacute: "\u0143",
    nacute: "\u0144",
    nang: "\u2220\u20D2",
    nap: "\u2249",
    napE: "\u2A70\u0338",
    napid: "\u224B\u0338",
    napos: "\u0149",
    napprox: "\u2249",
    natur: "\u266E",
    natural: "\u266E",
    naturals: "\u2115",
    nbsp: "\xA0",
    nbump: "\u224E\u0338",
    nbumpe: "\u224F\u0338",
    ncap: "\u2A43",
    Ncaron: "\u0147",
    ncaron: "\u0148",
    Ncedil: "\u0145",
    ncedil: "\u0146",
    ncong: "\u2247",
    ncongdot: "\u2A6D\u0338",
    ncup: "\u2A42",
    Ncy: "\u041D",
    ncy: "\u043D",
    ndash: "\u2013",
    ne: "\u2260",
    nearhk: "\u2924",
    neArr: "\u21D7",
    nearr: "\u2197",
    nearrow: "\u2197",
    nedot: "\u2250\u0338",
    NegativeMediumSpace: "\u200B",
    NegativeThickSpace: "\u200B",
    NegativeThinSpace: "\u200B",
    NegativeVeryThinSpace: "\u200B",
    nequiv: "\u2262",
    nesear: "\u2928",
    nesim: "\u2242\u0338",
    NestedGreaterGreater: "\u226B",
    NestedLessLess: "\u226A",
    NewLine: `
`,
    nexist: "\u2204",
    nexists: "\u2204",
    Nfr: "\u{1D511}",
    nfr: "\u{1D52B}",
    ngE: "\u2267\u0338",
    nge: "\u2271",
    ngeq: "\u2271",
    ngeqq: "\u2267\u0338",
    ngeqslant: "\u2A7E\u0338",
    nges: "\u2A7E\u0338",
    nGg: "\u22D9\u0338",
    ngsim: "\u2275",
    nGt: "\u226B\u20D2",
    ngt: "\u226F",
    ngtr: "\u226F",
    nGtv: "\u226B\u0338",
    nhArr: "\u21CE",
    nharr: "\u21AE",
    nhpar: "\u2AF2",
    ni: "\u220B",
    nis: "\u22FC",
    nisd: "\u22FA",
    niv: "\u220B",
    NJcy: "\u040A",
    njcy: "\u045A",
    nlArr: "\u21CD",
    nlarr: "\u219A",
    nldr: "\u2025",
    nlE: "\u2266\u0338",
    nle: "\u2270",
    nLeftarrow: "\u21CD",
    nleftarrow: "\u219A",
    nLeftrightarrow: "\u21CE",
    nleftrightarrow: "\u21AE",
    nleq: "\u2270",
    nleqq: "\u2266\u0338",
    nleqslant: "\u2A7D\u0338",
    nles: "\u2A7D\u0338",
    nless: "\u226E",
    nLl: "\u22D8\u0338",
    nlsim: "\u2274",
    nLt: "\u226A\u20D2",
    nlt: "\u226E",
    nltri: "\u22EA",
    nltrie: "\u22EC",
    nLtv: "\u226A\u0338",
    nmid: "\u2224",
    NoBreak: "\u2060",
    NonBreakingSpace: "\xA0",
    Nopf: "\u2115",
    nopf: "\u{1D55F}",
    Not: "\u2AEC",
    not: "\xAC",
    NotCongruent: "\u2262",
    NotCupCap: "\u226D",
    NotDoubleVerticalBar: "\u2226",
    NotElement: "\u2209",
    NotEqual: "\u2260",
    NotEqualTilde: "\u2242\u0338",
    NotExists: "\u2204",
    NotGreater: "\u226F",
    NotGreaterEqual: "\u2271",
    NotGreaterFullEqual: "\u2267\u0338",
    NotGreaterGreater: "\u226B\u0338",
    NotGreaterLess: "\u2279",
    NotGreaterSlantEqual: "\u2A7E\u0338",
    NotGreaterTilde: "\u2275",
    NotHumpDownHump: "\u224E\u0338",
    NotHumpEqual: "\u224F\u0338",
    notin: "\u2209",
    notindot: "\u22F5\u0338",
    notinE: "\u22F9\u0338",
    notinva: "\u2209",
    notinvb: "\u22F7",
    notinvc: "\u22F6",
    NotLeftTriangle: "\u22EA",
    NotLeftTriangleBar: "\u29CF\u0338",
    NotLeftTriangleEqual: "\u22EC",
    NotLess: "\u226E",
    NotLessEqual: "\u2270",
    NotLessGreater: "\u2278",
    NotLessLess: "\u226A\u0338",
    NotLessSlantEqual: "\u2A7D\u0338",
    NotLessTilde: "\u2274",
    NotNestedGreaterGreater: "\u2AA2\u0338",
    NotNestedLessLess: "\u2AA1\u0338",
    notni: "\u220C",
    notniva: "\u220C",
    notnivb: "\u22FE",
    notnivc: "\u22FD",
    NotPrecedes: "\u2280",
    NotPrecedesEqual: "\u2AAF\u0338",
    NotPrecedesSlantEqual: "\u22E0",
    NotReverseElement: "\u220C",
    NotRightTriangle: "\u22EB",
    NotRightTriangleBar: "\u29D0\u0338",
    NotRightTriangleEqual: "\u22ED",
    NotSquareSubset: "\u228F\u0338",
    NotSquareSubsetEqual: "\u22E2",
    NotSquareSuperset: "\u2290\u0338",
    NotSquareSupersetEqual: "\u22E3",
    NotSubset: "\u2282\u20D2",
    NotSubsetEqual: "\u2288",
    NotSucceeds: "\u2281",
    NotSucceedsEqual: "\u2AB0\u0338",
    NotSucceedsSlantEqual: "\u22E1",
    NotSucceedsTilde: "\u227F\u0338",
    NotSuperset: "\u2283\u20D2",
    NotSupersetEqual: "\u2289",
    NotTilde: "\u2241",
    NotTildeEqual: "\u2244",
    NotTildeFullEqual: "\u2247",
    NotTildeTilde: "\u2249",
    NotVerticalBar: "\u2224",
    npar: "\u2226",
    nparallel: "\u2226",
    nparsl: "\u2AFD\u20E5",
    npart: "\u2202\u0338",
    npolint: "\u2A14",
    npr: "\u2280",
    nprcue: "\u22E0",
    npre: "\u2AAF\u0338",
    nprec: "\u2280",
    npreceq: "\u2AAF\u0338",
    nrArr: "\u21CF",
    nrarr: "\u219B",
    nrarrc: "\u2933\u0338",
    nrarrw: "\u219D\u0338",
    nRightarrow: "\u21CF",
    nrightarrow: "\u219B",
    nrtri: "\u22EB",
    nrtrie: "\u22ED",
    nsc: "\u2281",
    nsccue: "\u22E1",
    nsce: "\u2AB0\u0338",
    Nscr: "\u{1D4A9}",
    nscr: "\u{1D4C3}",
    nshortmid: "\u2224",
    nshortparallel: "\u2226",
    nsim: "\u2241",
    nsime: "\u2244",
    nsimeq: "\u2244",
    nsmid: "\u2224",
    nspar: "\u2226",
    nsqsube: "\u22E2",
    nsqsupe: "\u22E3",
    nsub: "\u2284",
    nsubE: "\u2AC5\u0338",
    nsube: "\u2288",
    nsubset: "\u2282\u20D2",
    nsubseteq: "\u2288",
    nsubseteqq: "\u2AC5\u0338",
    nsucc: "\u2281",
    nsucceq: "\u2AB0\u0338",
    nsup: "\u2285",
    nsupE: "\u2AC6\u0338",
    nsupe: "\u2289",
    nsupset: "\u2283\u20D2",
    nsupseteq: "\u2289",
    nsupseteqq: "\u2AC6\u0338",
    ntgl: "\u2279",
    Ntilde: "\xD1",
    ntilde: "\xF1",
    ntlg: "\u2278",
    ntriangleleft: "\u22EA",
    ntrianglelefteq: "\u22EC",
    ntriangleright: "\u22EB",
    ntrianglerighteq: "\u22ED",
    Nu: "\u039D",
    nu: "\u03BD",
    num: "#",
    numero: "\u2116",
    numsp: "\u2007",
    nvap: "\u224D\u20D2",
    nVDash: "\u22AF",
    nVdash: "\u22AE",
    nvDash: "\u22AD",
    nvdash: "\u22AC",
    nvge: "\u2265\u20D2",
    nvgt: ">\u20D2",
    nvHarr: "\u2904",
    nvinfin: "\u29DE",
    nvlArr: "\u2902",
    nvle: "\u2264\u20D2",
    nvlt: "<\u20D2",
    nvltrie: "\u22B4\u20D2",
    nvrArr: "\u2903",
    nvrtrie: "\u22B5\u20D2",
    nvsim: "\u223C\u20D2",
    nwarhk: "\u2923",
    nwArr: "\u21D6",
    nwarr: "\u2196",
    nwarrow: "\u2196",
    nwnear: "\u2927",
    Oacute: "\xD3",
    oacute: "\xF3",
    oast: "\u229B",
    ocir: "\u229A",
    Ocirc: "\xD4",
    ocirc: "\xF4",
    Ocy: "\u041E",
    ocy: "\u043E",
    odash: "\u229D",
    Odblac: "\u0150",
    odblac: "\u0151",
    odiv: "\u2A38",
    odot: "\u2299",
    odsold: "\u29BC",
    OElig: "\u0152",
    oelig: "\u0153",
    ofcir: "\u29BF",
    Ofr: "\u{1D512}",
    ofr: "\u{1D52C}",
    ogon: "\u02DB",
    Ograve: "\xD2",
    ograve: "\xF2",
    ogt: "\u29C1",
    ohbar: "\u29B5",
    ohm: "\u03A9",
    oint: "\u222E",
    olarr: "\u21BA",
    olcir: "\u29BE",
    olcross: "\u29BB",
    oline: "\u203E",
    olt: "\u29C0",
    Omacr: "\u014C",
    omacr: "\u014D",
    Omega: "\u03A9",
    omega: "\u03C9",
    Omicron: "\u039F",
    omicron: "\u03BF",
    omid: "\u29B6",
    ominus: "\u2296",
    Oopf: "\u{1D546}",
    oopf: "\u{1D560}",
    opar: "\u29B7",
    OpenCurlyDoubleQuote: "\u201C",
    OpenCurlyQuote: "\u2018",
    operp: "\u29B9",
    oplus: "\u2295",
    Or: "\u2A54",
    or: "\u2228",
    orarr: "\u21BB",
    ord: "\u2A5D",
    order: "\u2134",
    orderof: "\u2134",
    ordf: "\xAA",
    ordm: "\xBA",
    origof: "\u22B6",
    oror: "\u2A56",
    orslope: "\u2A57",
    orv: "\u2A5B",
    oS: "\u24C8",
    Oscr: "\u{1D4AA}",
    oscr: "\u2134",
    Oslash: "\xD8",
    oslash: "\xF8",
    osol: "\u2298",
    Otilde: "\xD5",
    otilde: "\xF5",
    Otimes: "\u2A37",
    otimes: "\u2297",
    otimesas: "\u2A36",
    Ouml: "\xD6",
    ouml: "\xF6",
    ovbar: "\u233D",
    OverBar: "\u203E",
    OverBrace: "\u23DE",
    OverBracket: "\u23B4",
    OverParenthesis: "\u23DC",
    par: "\u2225",
    para: "\xB6",
    parallel: "\u2225",
    parsim: "\u2AF3",
    parsl: "\u2AFD",
    part: "\u2202",
    PartialD: "\u2202",
    Pcy: "\u041F",
    pcy: "\u043F",
    percnt: "%",
    period: ".",
    permil: "\u2030",
    perp: "\u22A5",
    pertenk: "\u2031",
    Pfr: "\u{1D513}",
    pfr: "\u{1D52D}",
    Phi: "\u03A6",
    phi: "\u03C6",
    phiv: "\u03D5",
    phmmat: "\u2133",
    phone: "\u260E",
    Pi: "\u03A0",
    pi: "\u03C0",
    pitchfork: "\u22D4",
    piv: "\u03D6",
    planck: "\u210F",
    planckh: "\u210E",
    plankv: "\u210F",
    plus: "+",
    plusacir: "\u2A23",
    plusb: "\u229E",
    pluscir: "\u2A22",
    plusdo: "\u2214",
    plusdu: "\u2A25",
    pluse: "\u2A72",
    PlusMinus: "\xB1",
    plusmn: "\xB1",
    plussim: "\u2A26",
    plustwo: "\u2A27",
    pm: "\xB1",
    Poincareplane: "\u210C",
    pointint: "\u2A15",
    Popf: "\u2119",
    popf: "\u{1D561}",
    pound: "\xA3",
    Pr: "\u2ABB",
    pr: "\u227A",
    prap: "\u2AB7",
    prcue: "\u227C",
    prE: "\u2AB3",
    pre: "\u2AAF",
    prec: "\u227A",
    precapprox: "\u2AB7",
    preccurlyeq: "\u227C",
    Precedes: "\u227A",
    PrecedesEqual: "\u2AAF",
    PrecedesSlantEqual: "\u227C",
    PrecedesTilde: "\u227E",
    preceq: "\u2AAF",
    precnapprox: "\u2AB9",
    precneqq: "\u2AB5",
    precnsim: "\u22E8",
    precsim: "\u227E",
    Prime: "\u2033",
    prime: "\u2032",
    primes: "\u2119",
    prnap: "\u2AB9",
    prnE: "\u2AB5",
    prnsim: "\u22E8",
    prod: "\u220F",
    Product: "\u220F",
    profalar: "\u232E",
    profline: "\u2312",
    profsurf: "\u2313",
    prop: "\u221D",
    Proportion: "\u2237",
    Proportional: "\u221D",
    propto: "\u221D",
    prsim: "\u227E",
    prurel: "\u22B0",
    Pscr: "\u{1D4AB}",
    pscr: "\u{1D4C5}",
    Psi: "\u03A8",
    psi: "\u03C8",
    puncsp: "\u2008",
    Qfr: "\u{1D514}",
    qfr: "\u{1D52E}",
    qint: "\u2A0C",
    Qopf: "\u211A",
    qopf: "\u{1D562}",
    qprime: "\u2057",
    Qscr: "\u{1D4AC}",
    qscr: "\u{1D4C6}",
    quaternions: "\u210D",
    quatint: "\u2A16",
    quest: "?",
    questeq: "\u225F",
    QUOT: '"',
    quot: '"',
    rAarr: "\u21DB",
    race: "\u223D\u0331",
    Racute: "\u0154",
    racute: "\u0155",
    radic: "\u221A",
    raemptyv: "\u29B3",
    Rang: "\u27EB",
    rang: "\u27E9",
    rangd: "\u2992",
    range: "\u29A5",
    rangle: "\u27E9",
    raquo: "\xBB",
    Rarr: "\u21A0",
    rArr: "\u21D2",
    rarr: "\u2192",
    rarrap: "\u2975",
    rarrb: "\u21E5",
    rarrbfs: "\u2920",
    rarrc: "\u2933",
    rarrfs: "\u291E",
    rarrhk: "\u21AA",
    rarrlp: "\u21AC",
    rarrpl: "\u2945",
    rarrsim: "\u2974",
    Rarrtl: "\u2916",
    rarrtl: "\u21A3",
    rarrw: "\u219D",
    rAtail: "\u291C",
    ratail: "\u291A",
    ratio: "\u2236",
    rationals: "\u211A",
    RBarr: "\u2910",
    rBarr: "\u290F",
    rbarr: "\u290D",
    rbbrk: "\u2773",
    rbrace: "}",
    rbrack: "]",
    rbrke: "\u298C",
    rbrksld: "\u298E",
    rbrkslu: "\u2990",
    Rcaron: "\u0158",
    rcaron: "\u0159",
    Rcedil: "\u0156",
    rcedil: "\u0157",
    rceil: "\u2309",
    rcub: "}",
    Rcy: "\u0420",
    rcy: "\u0440",
    rdca: "\u2937",
    rdldhar: "\u2969",
    rdquo: "\u201D",
    rdquor: "\u201D",
    rdsh: "\u21B3",
    Re: "\u211C",
    real: "\u211C",
    realine: "\u211B",
    realpart: "\u211C",
    reals: "\u211D",
    rect: "\u25AD",
    REG: "\xAE",
    reg: "\xAE",
    ReverseElement: "\u220B",
    ReverseEquilibrium: "\u21CB",
    ReverseUpEquilibrium: "\u296F",
    rfisht: "\u297D",
    rfloor: "\u230B",
    Rfr: "\u211C",
    rfr: "\u{1D52F}",
    rHar: "\u2964",
    rhard: "\u21C1",
    rharu: "\u21C0",
    rharul: "\u296C",
    Rho: "\u03A1",
    rho: "\u03C1",
    rhov: "\u03F1",
    RightAngleBracket: "\u27E9",
    RightArrow: "\u2192",
    Rightarrow: "\u21D2",
    rightarrow: "\u2192",
    RightArrowBar: "\u21E5",
    RightArrowLeftArrow: "\u21C4",
    rightarrowtail: "\u21A3",
    RightCeiling: "\u2309",
    RightDoubleBracket: "\u27E7",
    RightDownTeeVector: "\u295D",
    RightDownVector: "\u21C2",
    RightDownVectorBar: "\u2955",
    RightFloor: "\u230B",
    rightharpoondown: "\u21C1",
    rightharpoonup: "\u21C0",
    rightleftarrows: "\u21C4",
    rightleftharpoons: "\u21CC",
    rightrightarrows: "\u21C9",
    rightsquigarrow: "\u219D",
    RightTee: "\u22A2",
    RightTeeArrow: "\u21A6",
    RightTeeVector: "\u295B",
    rightthreetimes: "\u22CC",
    RightTriangle: "\u22B3",
    RightTriangleBar: "\u29D0",
    RightTriangleEqual: "\u22B5",
    RightUpDownVector: "\u294F",
    RightUpTeeVector: "\u295C",
    RightUpVector: "\u21BE",
    RightUpVectorBar: "\u2954",
    RightVector: "\u21C0",
    RightVectorBar: "\u2953",
    ring: "\u02DA",
    risingdotseq: "\u2253",
    rlarr: "\u21C4",
    rlhar: "\u21CC",
    rlm: "\u200F",
    rmoust: "\u23B1",
    rmoustache: "\u23B1",
    rnmid: "\u2AEE",
    roang: "\u27ED",
    roarr: "\u21FE",
    robrk: "\u27E7",
    ropar: "\u2986",
    Ropf: "\u211D",
    ropf: "\u{1D563}",
    roplus: "\u2A2E",
    rotimes: "\u2A35",
    RoundImplies: "\u2970",
    rpar: ")",
    rpargt: "\u2994",
    rppolint: "\u2A12",
    rrarr: "\u21C9",
    Rrightarrow: "\u21DB",
    rsaquo: "\u203A",
    Rscr: "\u211B",
    rscr: "\u{1D4C7}",
    Rsh: "\u21B1",
    rsh: "\u21B1",
    rsqb: "]",
    rsquo: "\u2019",
    rsquor: "\u2019",
    rthree: "\u22CC",
    rtimes: "\u22CA",
    rtri: "\u25B9",
    rtrie: "\u22B5",
    rtrif: "\u25B8",
    rtriltri: "\u29CE",
    RuleDelayed: "\u29F4",
    ruluhar: "\u2968",
    rx: "\u211E",
    Sacute: "\u015A",
    sacute: "\u015B",
    sbquo: "\u201A",
    Sc: "\u2ABC",
    sc: "\u227B",
    scap: "\u2AB8",
    Scaron: "\u0160",
    scaron: "\u0161",
    sccue: "\u227D",
    scE: "\u2AB4",
    sce: "\u2AB0",
    Scedil: "\u015E",
    scedil: "\u015F",
    Scirc: "\u015C",
    scirc: "\u015D",
    scnap: "\u2ABA",
    scnE: "\u2AB6",
    scnsim: "\u22E9",
    scpolint: "\u2A13",
    scsim: "\u227F",
    Scy: "\u0421",
    scy: "\u0441",
    sdot: "\u22C5",
    sdotb: "\u22A1",
    sdote: "\u2A66",
    searhk: "\u2925",
    seArr: "\u21D8",
    searr: "\u2198",
    searrow: "\u2198",
    sect: "\xA7",
    semi: ";",
    seswar: "\u2929",
    setminus: "\u2216",
    setmn: "\u2216",
    sext: "\u2736",
    Sfr: "\u{1D516}",
    sfr: "\u{1D530}",
    sfrown: "\u2322",
    sharp: "\u266F",
    SHCHcy: "\u0429",
    shchcy: "\u0449",
    SHcy: "\u0428",
    shcy: "\u0448",
    ShortDownArrow: "\u2193",
    ShortLeftArrow: "\u2190",
    shortmid: "\u2223",
    shortparallel: "\u2225",
    ShortRightArrow: "\u2192",
    ShortUpArrow: "\u2191",
    shy: "\xAD",
    Sigma: "\u03A3",
    sigma: "\u03C3",
    sigmaf: "\u03C2",
    sigmav: "\u03C2",
    sim: "\u223C",
    simdot: "\u2A6A",
    sime: "\u2243",
    simeq: "\u2243",
    simg: "\u2A9E",
    simgE: "\u2AA0",
    siml: "\u2A9D",
    simlE: "\u2A9F",
    simne: "\u2246",
    simplus: "\u2A24",
    simrarr: "\u2972",
    slarr: "\u2190",
    SmallCircle: "\u2218",
    smallsetminus: "\u2216",
    smashp: "\u2A33",
    smeparsl: "\u29E4",
    smid: "\u2223",
    smile: "\u2323",
    smt: "\u2AAA",
    smte: "\u2AAC",
    smtes: "\u2AAC\uFE00",
    SOFTcy: "\u042C",
    softcy: "\u044C",
    sol: "/",
    solb: "\u29C4",
    solbar: "\u233F",
    Sopf: "\u{1D54A}",
    sopf: "\u{1D564}",
    spades: "\u2660",
    spadesuit: "\u2660",
    spar: "\u2225",
    sqcap: "\u2293",
    sqcaps: "\u2293\uFE00",
    sqcup: "\u2294",
    sqcups: "\u2294\uFE00",
    Sqrt: "\u221A",
    sqsub: "\u228F",
    sqsube: "\u2291",
    sqsubset: "\u228F",
    sqsubseteq: "\u2291",
    sqsup: "\u2290",
    sqsupe: "\u2292",
    sqsupset: "\u2290",
    sqsupseteq: "\u2292",
    squ: "\u25A1",
    Square: "\u25A1",
    square: "\u25A1",
    SquareIntersection: "\u2293",
    SquareSubset: "\u228F",
    SquareSubsetEqual: "\u2291",
    SquareSuperset: "\u2290",
    SquareSupersetEqual: "\u2292",
    SquareUnion: "\u2294",
    squarf: "\u25AA",
    squf: "\u25AA",
    srarr: "\u2192",
    Sscr: "\u{1D4AE}",
    sscr: "\u{1D4C8}",
    ssetmn: "\u2216",
    ssmile: "\u2323",
    sstarf: "\u22C6",
    Star: "\u22C6",
    star: "\u2606",
    starf: "\u2605",
    straightepsilon: "\u03F5",
    straightphi: "\u03D5",
    strns: "\xAF",
    Sub: "\u22D0",
    sub: "\u2282",
    subdot: "\u2ABD",
    subE: "\u2AC5",
    sube: "\u2286",
    subedot: "\u2AC3",
    submult: "\u2AC1",
    subnE: "\u2ACB",
    subne: "\u228A",
    subplus: "\u2ABF",
    subrarr: "\u2979",
    Subset: "\u22D0",
    subset: "\u2282",
    subseteq: "\u2286",
    subseteqq: "\u2AC5",
    SubsetEqual: "\u2286",
    subsetneq: "\u228A",
    subsetneqq: "\u2ACB",
    subsim: "\u2AC7",
    subsub: "\u2AD5",
    subsup: "\u2AD3",
    succ: "\u227B",
    succapprox: "\u2AB8",
    succcurlyeq: "\u227D",
    Succeeds: "\u227B",
    SucceedsEqual: "\u2AB0",
    SucceedsSlantEqual: "\u227D",
    SucceedsTilde: "\u227F",
    succeq: "\u2AB0",
    succnapprox: "\u2ABA",
    succneqq: "\u2AB6",
    succnsim: "\u22E9",
    succsim: "\u227F",
    SuchThat: "\u220B",
    Sum: "\u2211",
    sum: "\u2211",
    sung: "\u266A",
    Sup: "\u22D1",
    sup: "\u2283",
    sup1: "\xB9",
    sup2: "\xB2",
    sup3: "\xB3",
    supdot: "\u2ABE",
    supdsub: "\u2AD8",
    supE: "\u2AC6",
    supe: "\u2287",
    supedot: "\u2AC4",
    Superset: "\u2283",
    SupersetEqual: "\u2287",
    suphsol: "\u27C9",
    suphsub: "\u2AD7",
    suplarr: "\u297B",
    supmult: "\u2AC2",
    supnE: "\u2ACC",
    supne: "\u228B",
    supplus: "\u2AC0",
    Supset: "\u22D1",
    supset: "\u2283",
    supseteq: "\u2287",
    supseteqq: "\u2AC6",
    supsetneq: "\u228B",
    supsetneqq: "\u2ACC",
    supsim: "\u2AC8",
    supsub: "\u2AD4",
    supsup: "\u2AD6",
    swarhk: "\u2926",
    swArr: "\u21D9",
    swarr: "\u2199",
    swarrow: "\u2199",
    swnwar: "\u292A",
    szlig: "\xDF",
    Tab: "	",
    target: "\u2316",
    Tau: "\u03A4",
    tau: "\u03C4",
    tbrk: "\u23B4",
    Tcaron: "\u0164",
    tcaron: "\u0165",
    Tcedil: "\u0162",
    tcedil: "\u0163",
    Tcy: "\u0422",
    tcy: "\u0442",
    tdot: "\u20DB",
    telrec: "\u2315",
    Tfr: "\u{1D517}",
    tfr: "\u{1D531}",
    there4: "\u2234",
    Therefore: "\u2234",
    therefore: "\u2234",
    Theta: "\u0398",
    theta: "\u03B8",
    thetasym: "\u03D1",
    thetav: "\u03D1",
    thickapprox: "\u2248",
    thicksim: "\u223C",
    ThickSpace: "\u205F\u200A",
    thinsp: "\u2009",
    ThinSpace: "\u2009",
    thkap: "\u2248",
    thksim: "\u223C",
    THORN: "\xDE",
    thorn: "\xFE",
    Tilde: "\u223C",
    tilde: "\u02DC",
    TildeEqual: "\u2243",
    TildeFullEqual: "\u2245",
    TildeTilde: "\u2248",
    times: "\xD7",
    timesb: "\u22A0",
    timesbar: "\u2A31",
    timesd: "\u2A30",
    tint: "\u222D",
    toea: "\u2928",
    top: "\u22A4",
    topbot: "\u2336",
    topcir: "\u2AF1",
    Topf: "\u{1D54B}",
    topf: "\u{1D565}",
    topfork: "\u2ADA",
    tosa: "\u2929",
    tprime: "\u2034",
    TRADE: "\u2122",
    trade: "\u2122",
    triangle: "\u25B5",
    triangledown: "\u25BF",
    triangleleft: "\u25C3",
    trianglelefteq: "\u22B4",
    triangleq: "\u225C",
    triangleright: "\u25B9",
    trianglerighteq: "\u22B5",
    tridot: "\u25EC",
    trie: "\u225C",
    triminus: "\u2A3A",
    TripleDot: "\u20DB",
    triplus: "\u2A39",
    trisb: "\u29CD",
    tritime: "\u2A3B",
    trpezium: "\u23E2",
    Tscr: "\u{1D4AF}",
    tscr: "\u{1D4C9}",
    TScy: "\u0426",
    tscy: "\u0446",
    TSHcy: "\u040B",
    tshcy: "\u045B",
    Tstrok: "\u0166",
    tstrok: "\u0167",
    twixt: "\u226C",
    twoheadleftarrow: "\u219E",
    twoheadrightarrow: "\u21A0",
    Uacute: "\xDA",
    uacute: "\xFA",
    Uarr: "\u219F",
    uArr: "\u21D1",
    uarr: "\u2191",
    Uarrocir: "\u2949",
    Ubrcy: "\u040E",
    ubrcy: "\u045E",
    Ubreve: "\u016C",
    ubreve: "\u016D",
    Ucirc: "\xDB",
    ucirc: "\xFB",
    Ucy: "\u0423",
    ucy: "\u0443",
    udarr: "\u21C5",
    Udblac: "\u0170",
    udblac: "\u0171",
    udhar: "\u296E",
    ufisht: "\u297E",
    Ufr: "\u{1D518}",
    ufr: "\u{1D532}",
    Ugrave: "\xD9",
    ugrave: "\xF9",
    uHar: "\u2963",
    uharl: "\u21BF",
    uharr: "\u21BE",
    uhblk: "\u2580",
    ulcorn: "\u231C",
    ulcorner: "\u231C",
    ulcrop: "\u230F",
    ultri: "\u25F8",
    Umacr: "\u016A",
    umacr: "\u016B",
    uml: "\xA8",
    UnderBar: "_",
    UnderBrace: "\u23DF",
    UnderBracket: "\u23B5",
    UnderParenthesis: "\u23DD",
    Union: "\u22C3",
    UnionPlus: "\u228E",
    Uogon: "\u0172",
    uogon: "\u0173",
    Uopf: "\u{1D54C}",
    uopf: "\u{1D566}",
    UpArrow: "\u2191",
    Uparrow: "\u21D1",
    uparrow: "\u2191",
    UpArrowBar: "\u2912",
    UpArrowDownArrow: "\u21C5",
    UpDownArrow: "\u2195",
    Updownarrow: "\u21D5",
    updownarrow: "\u2195",
    UpEquilibrium: "\u296E",
    upharpoonleft: "\u21BF",
    upharpoonright: "\u21BE",
    uplus: "\u228E",
    UpperLeftArrow: "\u2196",
    UpperRightArrow: "\u2197",
    Upsi: "\u03D2",
    upsi: "\u03C5",
    upsih: "\u03D2",
    Upsilon: "\u03A5",
    upsilon: "\u03C5",
    UpTee: "\u22A5",
    UpTeeArrow: "\u21A5",
    upuparrows: "\u21C8",
    urcorn: "\u231D",
    urcorner: "\u231D",
    urcrop: "\u230E",
    Uring: "\u016E",
    uring: "\u016F",
    urtri: "\u25F9",
    Uscr: "\u{1D4B0}",
    uscr: "\u{1D4CA}",
    utdot: "\u22F0",
    Utilde: "\u0168",
    utilde: "\u0169",
    utri: "\u25B5",
    utrif: "\u25B4",
    uuarr: "\u21C8",
    Uuml: "\xDC",
    uuml: "\xFC",
    uwangle: "\u29A7",
    vangrt: "\u299C",
    varepsilon: "\u03F5",
    varkappa: "\u03F0",
    varnothing: "\u2205",
    varphi: "\u03D5",
    varpi: "\u03D6",
    varpropto: "\u221D",
    vArr: "\u21D5",
    varr: "\u2195",
    varrho: "\u03F1",
    varsigma: "\u03C2",
    varsubsetneq: "\u228A\uFE00",
    varsubsetneqq: "\u2ACB\uFE00",
    varsupsetneq: "\u228B\uFE00",
    varsupsetneqq: "\u2ACC\uFE00",
    vartheta: "\u03D1",
    vartriangleleft: "\u22B2",
    vartriangleright: "\u22B3",
    Vbar: "\u2AEB",
    vBar: "\u2AE8",
    vBarv: "\u2AE9",
    Vcy: "\u0412",
    vcy: "\u0432",
    VDash: "\u22AB",
    Vdash: "\u22A9",
    vDash: "\u22A8",
    vdash: "\u22A2",
    Vdashl: "\u2AE6",
    Vee: "\u22C1",
    vee: "\u2228",
    veebar: "\u22BB",
    veeeq: "\u225A",
    vellip: "\u22EE",
    Verbar: "\u2016",
    verbar: "|",
    Vert: "\u2016",
    vert: "|",
    VerticalBar: "\u2223",
    VerticalLine: "|",
    VerticalSeparator: "\u2758",
    VerticalTilde: "\u2240",
    VeryThinSpace: "\u200A",
    Vfr: "\u{1D519}",
    vfr: "\u{1D533}",
    vltri: "\u22B2",
    vnsub: "\u2282\u20D2",
    vnsup: "\u2283\u20D2",
    Vopf: "\u{1D54D}",
    vopf: "\u{1D567}",
    vprop: "\u221D",
    vrtri: "\u22B3",
    Vscr: "\u{1D4B1}",
    vscr: "\u{1D4CB}",
    vsubnE: "\u2ACB\uFE00",
    vsubne: "\u228A\uFE00",
    vsupnE: "\u2ACC\uFE00",
    vsupne: "\u228B\uFE00",
    Vvdash: "\u22AA",
    vzigzag: "\u299A",
    Wcirc: "\u0174",
    wcirc: "\u0175",
    wedbar: "\u2A5F",
    Wedge: "\u22C0",
    wedge: "\u2227",
    wedgeq: "\u2259",
    weierp: "\u2118",
    Wfr: "\u{1D51A}",
    wfr: "\u{1D534}",
    Wopf: "\u{1D54E}",
    wopf: "\u{1D568}",
    wp: "\u2118",
    wr: "\u2240",
    wreath: "\u2240",
    Wscr: "\u{1D4B2}",
    wscr: "\u{1D4CC}",
    xcap: "\u22C2",
    xcirc: "\u25EF",
    xcup: "\u22C3",
    xdtri: "\u25BD",
    Xfr: "\u{1D51B}",
    xfr: "\u{1D535}",
    xhArr: "\u27FA",
    xharr: "\u27F7",
    Xi: "\u039E",
    xi: "\u03BE",
    xlArr: "\u27F8",
    xlarr: "\u27F5",
    xmap: "\u27FC",
    xnis: "\u22FB",
    xodot: "\u2A00",
    Xopf: "\u{1D54F}",
    xopf: "\u{1D569}",
    xoplus: "\u2A01",
    xotime: "\u2A02",
    xrArr: "\u27F9",
    xrarr: "\u27F6",
    Xscr: "\u{1D4B3}",
    xscr: "\u{1D4CD}",
    xsqcup: "\u2A06",
    xuplus: "\u2A04",
    xutri: "\u25B3",
    xvee: "\u22C1",
    xwedge: "\u22C0",
    Yacute: "\xDD",
    yacute: "\xFD",
    YAcy: "\u042F",
    yacy: "\u044F",
    Ycirc: "\u0176",
    ycirc: "\u0177",
    Ycy: "\u042B",
    ycy: "\u044B",
    yen: "\xA5",
    Yfr: "\u{1D51C}",
    yfr: "\u{1D536}",
    YIcy: "\u0407",
    yicy: "\u0457",
    Yopf: "\u{1D550}",
    yopf: "\u{1D56A}",
    Yscr: "\u{1D4B4}",
    yscr: "\u{1D4CE}",
    YUcy: "\u042E",
    yucy: "\u044E",
    Yuml: "\u0178",
    yuml: "\xFF",
    Zacute: "\u0179",
    zacute: "\u017A",
    Zcaron: "\u017D",
    zcaron: "\u017E",
    Zcy: "\u0417",
    zcy: "\u0437",
    Zdot: "\u017B",
    zdot: "\u017C",
    zeetrf: "\u2128",
    ZeroWidthSpace: "\u200B",
    Zeta: "\u0396",
    zeta: "\u03B6",
    Zfr: "\u2128",
    zfr: "\u{1D537}",
    ZHcy: "\u0416",
    zhcy: "\u0436",
    zigrarr: "\u21DD",
    Zopf: "\u2124",
    zopf: "\u{1D56B}",
    Zscr: "\u{1D4B5}",
    zscr: "\u{1D4CF}",
    zwj: "\u200D",
    zwnj: "\u200C",
  });
  Ue.entityMap = Ue.HTML_ENTITIES;
});
var Xr = ue((zt) => {
  var ze = Oe().NAMESPACE,
    Vt =
      /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    Ur = new RegExp(
      "[\\-\\.0-9" +
        Vt.source.slice(1, -1) +
        "\\u00B7\\u0300-\\u036F\\u203F-\\u2040]",
    ),
    kr = new RegExp(
      "^" + Vt.source + Ur.source + "*(?::" + Vt.source + Ur.source + "*)?$",
    ),
    ke = 0,
    le = 1,
    De = 2,
    qe = 3,
    Ee = 4,
    ye = 5,
    Ve = 6,
    ft = 7;
  function be(e, t) {
    ((this.message = e),
      (this.locator = t),
      Error.captureStackTrace && Error.captureStackTrace(this, be));
  }
  be.prototype = new Error();
  be.prototype.name = be.name;
  function zr() {}
  zr.prototype = {
    parse: function (e, t, r) {
      var n = this.domBuilder;
      (n.startDocument(),
        Gr(t, (t = {})),
        fi(e, t, r, n, this.errorHandler),
        n.endDocument());
    },
  };
  function fi(e, t, r, n, i) {
    function a(C) {
      if (C > 65535) {
        C -= 65536;
        var V = 55296 + (C >> 10),
          yn = 56320 + (C & 1023);
        return String.fromCharCode(V, yn);
      } else return String.fromCharCode(C);
    }
    function u(C) {
      var V = C.slice(1, -1);
      return Object.hasOwnProperty.call(r, V)
        ? r[V]
        : V.charAt(0) === "#"
          ? a(parseInt(V.substr(1).replace("x", "0x")))
          : (i.error("entity not found:" + C), C);
    }
    function s(C) {
      if (C > c) {
        var V = e.substring(c, C).replace(/&#?\w+;/g, u);
        (g && l(c), n.characters(V, 0, C - c), (c = C));
      }
    }
    function l(C, V) {
      for (; C >= m && (V = d.exec(e));)
        ((o = V.index), (m = o + V[0].length), g.lineNumber++);
      g.columnNumber = C - o + 1;
    }
    for (
      var o = 0,
        m = 0,
        d = /.*(?:\r\n?|\n)|.*$/g,
        g = n.locator,
        D = [{ currentNSMap: t }],
        b = {},
        c = 0;
      ;
    ) {
      try {
        var v = e.indexOf("<", c);
        if (v < 0) {
          if (!e.substr(c).match(/^\s*$/)) {
            var T = n.doc,
              h = T.createTextNode(e.substr(c));
            (T.appendChild(h), (n.currentElement = h));
          }
          return;
        }
        switch ((v > c && s(v), e.charAt(v + 1))) {
          case "/":
            var E = e.indexOf(">", v + 3),
              f = e.substring(v + 2, E).replace(/[ \t\n\r]+$/g, ""),
              p = D.pop();
            E < 0
              ? ((f = e.substring(v + 2).replace(/[\s<].*/, "")),
                i.error("end tag name: " + f + " is not complete:" + p.tagName),
                (E = v + 1 + f.length))
              : f.match(/\s</) &&
                ((f = f.replace(/[\s<].*/, "")),
                i.error("end tag name: " + f + " maybe not complete"),
                (E = v + 1 + f.length));
            var A = p.localNSMap,
              y = p.tagName == f,
              _ =
                y || (p.tagName && p.tagName.toLowerCase() == f.toLowerCase());
            if (_) {
              if ((n.endElement(p.uri, p.localName, f), A))
                for (var R in A)
                  Object.prototype.hasOwnProperty.call(A, R) &&
                    n.endPrefixMapping(R);
              y ||
                i.fatalError(
                  "end tag name: " +
                    f +
                    " is not match the current start tagName:" +
                    p.tagName,
                );
            } else D.push(p);
            E++;
            break;
          case "?":
            (g && l(v), (E = Ai(e, v, n)));
            break;
          case "!":
            (g && l(v), (E = hi(e, v, n, i)));
            break;
          default:
            g && l(v);
            var w = new Hr(),
              F = D[D.length - 1].currentNSMap,
              E = pi(e, v, w, F, u, i),
              L = w.length;
            if (
              (!w.closed &&
                gi(e, E, w.tagName, b) &&
                ((w.closed = !0),
                r.nbsp || i.warning("unclosed xml attribute")),
              g && L)
            ) {
              for (var B = qr(g, {}), Q = 0; Q < L; Q++) {
                var ae = w[Q];
                (l(ae.offset), (ae.locator = qr(g, {})));
              }
              ((n.locator = B), Vr(w, n, F) && D.push(w), (n.locator = g));
            } else Vr(w, n, F) && D.push(w);
            ze.isHTML(w.uri) && !w.closed
              ? (E = di(e, E, w.tagName, u, n))
              : E++;
        }
      } catch (C) {
        if (C instanceof be) throw C;
        (i.error("element parse error: " + C), (E = -1));
      }
      E > c ? (c = E) : s(Math.max(v, c) + 1);
    }
  }
  function qr(e, t) {
    return (
      (t.lineNumber = e.lineNumber),
      (t.columnNumber = e.columnNumber),
      t
    );
  }
  function pi(e, t, r, n, i, a) {
    function u(D, b, c) {
      (r.attributeNames.hasOwnProperty(D) &&
        a.fatalError("Attribute " + D + " redefined"),
        r.addValue(D, b.replace(/[\t\n\r]/g, " ").replace(/&#?\w+;/g, i), c));
    }
    for (var s, l, o = ++t, m = ke; ;) {
      var d = e.charAt(o);
      switch (d) {
        case "=":
          if (m === le) ((s = e.slice(t, o)), (m = qe));
          else if (m === De) m = qe;
          else throw new Error("attribute equal must after attrName");
          break;
        case "'":
        case '"':
          if (m === qe || m === le)
            if (
              (m === le &&
                (a.warning('attribute value must after "="'),
                (s = e.slice(t, o))),
              (t = o + 1),
              (o = e.indexOf(d, t)),
              o > 0)
            )
              ((l = e.slice(t, o)), u(s, l, t - 1), (m = ye));
            else throw new Error("attribute value no end '" + d + "' match");
          else if (m == Ee)
            ((l = e.slice(t, o)),
              u(s, l, t),
              a.warning('attribute "' + s + '" missed start quot(' + d + ")!!"),
              (t = o + 1),
              (m = ye));
          else throw new Error('attribute value must after "="');
          break;
        case "/":
          switch (m) {
            case ke:
              r.setTagName(e.slice(t, o));
            case ye:
            case Ve:
            case ft:
              ((m = ft), (r.closed = !0));
            case Ee:
            case le:
              break;
            case De:
              r.closed = !0;
              break;
            default:
              throw new Error("attribute invalid close char('/')");
          }
          break;
        case "":
          return (
            a.error("unexpected end of input"),
            m == ke && r.setTagName(e.slice(t, o)),
            o
          );
        case ">":
          switch (m) {
            case ke:
              r.setTagName(e.slice(t, o));
            case ye:
            case Ve:
            case ft:
              break;
            case Ee:
            case le:
              ((l = e.slice(t, o)),
                l.slice(-1) === "/" && ((r.closed = !0), (l = l.slice(0, -1))));
            case De:
              (m === De && (l = s),
                m == Ee
                  ? (a.warning('attribute "' + l + '" missed quot(")!'),
                    u(s, l, t))
                  : ((!ze.isHTML(n[""]) ||
                      !l.match(/^(?:disabled|checked|selected)$/i)) &&
                      a.warning(
                        'attribute "' +
                          l +
                          '" missed value!! "' +
                          l +
                          '" instead!!',
                      ),
                    u(l, l, t)));
              break;
            case qe:
              throw new Error("attribute value missed!!");
          }
          return o;
        case "\x80":
          d = " ";
        default:
          if (d <= " ")
            switch (m) {
              case ke:
                (r.setTagName(e.slice(t, o)), (m = Ve));
                break;
              case le:
                ((s = e.slice(t, o)), (m = De));
                break;
              case Ee:
                var l = e.slice(t, o);
                (a.warning('attribute "' + l + '" missed quot(")!!'),
                  u(s, l, t));
              case ye:
                m = Ve;
                break;
            }
          else
            switch (m) {
              case De:
                var g = r.tagName;
                ((!ze.isHTML(n[""]) ||
                  !s.match(/^(?:disabled|checked|selected)$/i)) &&
                  a.warning(
                    'attribute "' +
                      s +
                      '" missed value!! "' +
                      s +
                      '" instead2!!',
                  ),
                  u(s, s, t),
                  (t = o),
                  (m = le));
                break;
              case ye:
                a.warning('attribute space is required"' + s + '"!!');
              case Ve:
                ((m = le), (t = o));
                break;
              case qe:
                ((m = Ee), (t = o));
                break;
              case ft:
                throw new Error(
                  "elements closed character '/' and '>' must be connected to",
                );
            }
      }
      o++;
    }
  }
  function Vr(e, t, r) {
    for (var n = e.tagName, i = null, d = e.length; d--;) {
      var a = e[d],
        u = a.qName,
        s = a.value,
        g = u.indexOf(":");
      if (g > 0)
        var l = (a.prefix = u.slice(0, g)),
          o = u.slice(g + 1),
          m = l === "xmlns" && o;
      else ((o = u), (l = null), (m = u === "xmlns" && ""));
      ((a.localName = o),
        m !== !1 &&
          (i == null && ((i = {}), Gr(r, (r = {}))),
          (r[m] = i[m] = s),
          (a.uri = ze.XMLNS),
          t.startPrefixMapping(m, s)));
    }
    for (var d = e.length; d--;) {
      a = e[d];
      var l = a.prefix;
      l &&
        (l === "xml" && (a.uri = ze.XML),
        l !== "xmlns" && (a.uri = r[l || ""]));
    }
    var g = n.indexOf(":");
    g > 0
      ? ((l = e.prefix = n.slice(0, g)), (o = e.localName = n.slice(g + 1)))
      : ((l = null), (o = e.localName = n));
    var D = (e.uri = r[l || ""]);
    if ((t.startElement(D, o, n, e), e.closed)) {
      if ((t.endElement(D, o, n), i))
        for (l in i)
          Object.prototype.hasOwnProperty.call(i, l) && t.endPrefixMapping(l);
    } else return ((e.currentNSMap = r), (e.localNSMap = i), !0);
  }
  function di(e, t, r, n, i) {
    if (/^(?:script|textarea)$/i.test(r)) {
      var a = e.indexOf("</" + r + ">", t),
        u = e.substring(t + 1, a);
      if (/[&<]/.test(u))
        return /^script$/i.test(r)
          ? (i.characters(u, 0, u.length), a)
          : ((u = u.replace(/&#?\w+;/g, n)), i.characters(u, 0, u.length), a);
    }
    return t + 1;
  }
  function gi(e, t, r, n) {
    var i = n[r];
    return (
      i == null &&
        ((i = e.lastIndexOf("</" + r + ">")),
        i < t && (i = e.lastIndexOf("</" + r)),
        (n[r] = i)),
      i < t
    );
  }
  function Gr(e, t) {
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
  }
  function hi(e, t, r, n) {
    var i = e.charAt(t + 2);
    switch (i) {
      case "-":
        if (e.charAt(t + 3) === "-") {
          var a = e.indexOf("-->", t + 4);
          return a > t
            ? (r.comment(e, t + 4, a - t - 4), a + 3)
            : (n.error("Unclosed comment"), -1);
        } else return -1;
      default:
        if (e.substr(t + 3, 6) == "CDATA[") {
          var a = e.indexOf("]]>", t + 9);
          return (
            r.startCDATA(),
            r.characters(e, t + 9, a - t - 9),
            r.endCDATA(),
            a + 3
          );
        }
        var u = Di(e, t),
          s = u.length;
        if (s > 1 && /!doctype/i.test(u[0][0])) {
          var l = u[1][0],
            o = !1,
            m = !1;
          s > 3 &&
            (/^public$/i.test(u[2][0])
              ? ((o = u[3][0]), (m = s > 4 && u[4][0]))
              : /^system$/i.test(u[2][0]) && (m = u[3][0]));
          var d = u[s - 1];
          return (r.startDTD(l, o, m), r.endDTD(), d.index + d[0].length);
        }
    }
    return -1;
  }
  function Ai(e, t, r) {
    var n = e.indexOf("?>", t);
    if (n) {
      var i = e.substring(t, n).match(/^<\?(\S*)\s*([\s\S]*?)$/);
      if (i) {
        var a = i[0].length;
        return (r.processingInstruction(i[1], i[2]), n + 2);
      } else return -1;
    }
    return -1;
  }
  function Hr() {
    this.attributeNames = {};
  }
  Hr.prototype = {
    setTagName: function (e) {
      if (!kr.test(e)) throw new Error("invalid tagName:" + e);
      this.tagName = e;
    },
    addValue: function (e, t, r) {
      if (!kr.test(e)) throw new Error("invalid attribute:" + e);
      ((this.attributeNames[e] = this.length),
        (this[this.length++] = { qName: e, value: t, offset: r }));
    },
    length: 0,
    getLocalName: function (e) {
      return this[e].localName;
    },
    getLocator: function (e) {
      return this[e].locator;
    },
    getQName: function (e) {
      return this[e].qName;
    },
    getURI: function (e) {
      return this[e].uri;
    },
    getValue: function (e) {
      return this[e].value;
    },
  };
  function Di(e, t) {
    var r,
      n = [],
      i = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
    for (i.lastIndex = t, i.exec(e); (r = i.exec(e));)
      if ((n.push(r), r[1])) return n;
  }
  zt.XMLReader = zr;
  zt.ParseError = be;
});
var Zr = ue((dt) => {
  var Ei = Oe(),
    yi = qt(),
    $r = Lr(),
    jr = Xr(),
    bi = yi.DOMImplementation,
    Wr = Ei.NAMESPACE,
    vi = jr.ParseError,
    Ti = jr.XMLReader;
  function Kr(e) {
    return e
      .replace(
        /\r[\n\u0085]/g,
        `
`,
      )
      .replace(
        /[\r\u0085\u2028]/g,
        `
`,
      );
  }
  function Qr(e) {
    this.options = e || { locator: {} };
  }
  Qr.prototype.parseFromString = function (e, t) {
    var r = this.options,
      n = new Ti(),
      i = r.domBuilder || new Ge(),
      a = r.errorHandler,
      u = r.locator,
      s = r.xmlns || {},
      l = /\/x?html?$/.test(t),
      o = l ? $r.HTML_ENTITIES : $r.XML_ENTITIES;
    (u && i.setDocumentLocator(u),
      (n.errorHandler = _i(a, i, u)),
      (n.domBuilder = r.domBuilder || i),
      l && (s[""] = Wr.HTML),
      (s.xml = s.xml || Wr.XML));
    var m = r.normalizeLineEndings || Kr;
    return (
      e && typeof e == "string"
        ? n.parse(m(e), s, o)
        : n.errorHandler.error("invalid doc source"),
      i.doc
    );
  };
  function _i(e, t, r) {
    if (!e) {
      if (t instanceof Ge) return t;
      e = t;
    }
    var n = {},
      i = e instanceof Function;
    r = r || {};
    function a(u) {
      var s = e[u];
      (!s &&
        i &&
        (s =
          e.length == 2
            ? function (l) {
                e(u, l);
              }
            : e),
        (n[u] =
          (s &&
            function (l) {
              s("[xmldom " + u + "]	" + l + Gt(r));
            }) ||
          function () {}));
    }
    return (a("warning"), a("error"), a("fatalError"), n);
  }
  function Ge() {
    this.cdata = !1;
  }
  function ve(e, t) {
    ((t.lineNumber = e.lineNumber), (t.columnNumber = e.columnNumber));
  }
  Ge.prototype = {
    startDocument: function () {
      ((this.doc = new bi().createDocument(null, null, null)),
        this.locator && (this.doc.documentURI = this.locator.systemId));
    },
    startElement: function (e, t, r, n) {
      var i = this.doc,
        a = i.createElementNS(e, r || t),
        u = n.length;
      (pt(this, a),
        (this.currentElement = a),
        this.locator && ve(this.locator, a));
      for (var s = 0; s < u; s++) {
        var e = n.getURI(s),
          l = n.getValue(s),
          r = n.getQName(s),
          o = i.createAttributeNS(e, r);
        (this.locator && ve(n.getLocator(s), o),
          (o.value = o.nodeValue = l),
          a.setAttributeNode(o));
      }
    },
    endElement: function (e, t, r) {
      var n = this.currentElement,
        i = n.tagName;
      this.currentElement = n.parentNode;
    },
    startPrefixMapping: function (e, t) {},
    endPrefixMapping: function (e) {},
    processingInstruction: function (e, t) {
      var r = this.doc.createProcessingInstruction(e, t);
      (this.locator && ve(this.locator, r), pt(this, r));
    },
    ignorableWhitespace: function (e, t, r) {},
    characters: function (e, t, r) {
      if (((e = Yr.apply(this, arguments)), e)) {
        if (this.cdata) var n = this.doc.createCDATASection(e);
        else var n = this.doc.createTextNode(e);
        (this.currentElement
          ? this.currentElement.appendChild(n)
          : /^\s*$/.test(e) && this.doc.appendChild(n),
          this.locator && ve(this.locator, n));
      }
    },
    skippedEntity: function (e) {},
    endDocument: function () {
      this.doc.normalize();
    },
    setDocumentLocator: function (e) {
      (this.locator = e) && (e.lineNumber = 0);
    },
    comment: function (e, t, r) {
      e = Yr.apply(this, arguments);
      var n = this.doc.createComment(e);
      (this.locator && ve(this.locator, n), pt(this, n));
    },
    startCDATA: function () {
      this.cdata = !0;
    },
    endCDATA: function () {
      this.cdata = !1;
    },
    startDTD: function (e, t, r) {
      var n = this.doc.implementation;
      if (n && n.createDocumentType) {
        var i = n.createDocumentType(e, t, r);
        (this.locator && ve(this.locator, i),
          pt(this, i),
          (this.doc.doctype = i));
      }
    },
    warning: function (e) {
      console.warn("[xmldom warning]	" + e, Gt(this.locator));
    },
    error: function (e) {
      console.error("[xmldom error]	" + e, Gt(this.locator));
    },
    fatalError: function (e) {
      throw new vi(e, this.locator);
    },
  };
  function Gt(e) {
    if (e)
      return (
        `
@` +
        (e.systemId || "") +
        "#[line:" +
        e.lineNumber +
        ",col:" +
        e.columnNumber +
        "]"
      );
  }
  function Yr(e, t, r) {
    return typeof e == "string"
      ? e.substr(t, r)
      : e.length >= t + r || t
        ? new java.lang.String(e, t, r) + ""
        : e;
  }
  "endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(
    /\w+/g,
    function (e) {
      Ge.prototype[e] = function () {
        return null;
      };
    },
  );
  function pt(e, t) {
    e.currentElement ? e.currentElement.appendChild(t) : e.doc.appendChild(t);
  }
  dt.__DOMHandler = Ge;
  dt.normalizeLineEndings = Kr;
  dt.DOMParser = Qr;
});
var en = ue((gt) => {
  var Jr = qt();
  gt.DOMImplementation = Jr.DOMImplementation;
  gt.XMLSerializer = Jr.XMLSerializer;
  gt.DOMParser = Zr().DOMParser;
});
function se(e) {
  var t = String(e);
  if (t === "[object Object]")
    try {
      t = JSON.stringify(e);
    } catch {}
  return t;
}
var xn = (function () {
    function e() {}
    return (
      (e.prototype.isSome = function () {
        return !1;
      }),
      (e.prototype.isNone = function () {
        return !0;
      }),
      (e.prototype[Symbol.iterator] = function () {
        return {
          next: function () {
            return { done: !0, value: void 0 };
          },
        };
      }),
      (e.prototype.unwrapOr = function (t) {
        return t;
      }),
      (e.prototype.expect = function (t) {
        throw new Error("".concat(t));
      }),
      (e.prototype.unwrap = function () {
        throw new Error("Tried to unwrap None");
      }),
      (e.prototype.map = function (t) {
        return this;
      }),
      (e.prototype.mapOr = function (t, r) {
        return t;
      }),
      (e.prototype.mapOrElse = function (t, r) {
        return t();
      }),
      (e.prototype.or = function (t) {
        return t;
      }),
      (e.prototype.orElse = function (t) {
        return t();
      }),
      (e.prototype.andThen = function (t) {
        return this;
      }),
      (e.prototype.toResult = function (t) {
        return M(t);
      }),
      (e.prototype.toString = function () {
        return "None";
      }),
      (e.prototype.toAsyncOption = function () {
        return new xe(S);
      }),
      e
    );
  })(),
  S = new xn();
Object.freeze(S);
var Cn = (function () {
    function e(t) {
      if (!(this instanceof e)) return new e(t);
      this.value = t;
    }
    return (
      (e.prototype.isSome = function () {
        return !0;
      }),
      (e.prototype.isNone = function () {
        return !1;
      }),
      (e.prototype[Symbol.iterator] = function () {
        var t = Object(this.value);
        return Symbol.iterator in t
          ? t[Symbol.iterator]()
          : {
              next: function () {
                return { done: !0, value: void 0 };
              },
            };
      }),
      (e.prototype.unwrapOr = function (t) {
        return this.value;
      }),
      (e.prototype.expect = function (t) {
        return this.value;
      }),
      (e.prototype.unwrap = function () {
        return this.value;
      }),
      (e.prototype.map = function (t) {
        return x(t(this.value));
      }),
      (e.prototype.mapOr = function (t, r) {
        return r(this.value);
      }),
      (e.prototype.mapOrElse = function (t, r) {
        return r(this.value);
      }),
      (e.prototype.or = function (t) {
        return this;
      }),
      (e.prototype.orElse = function (t) {
        return this;
      }),
      (e.prototype.andThen = function (t) {
        return t(this.value);
      }),
      (e.prototype.toResult = function (t) {
        return G(this.value);
      }),
      (e.prototype.toAsyncOption = function () {
        return new xe(this);
      }),
      (e.prototype.safeUnwrap = function () {
        return this.value;
      }),
      (e.prototype.toString = function () {
        return "Some(".concat(se(this.value), ")");
      }),
      (e.EMPTY = new e(void 0)),
      e
    );
  })(),
  x = Cn,
  We;
(function (e) {
  function t() {
    for (var i = [], a = 0; a < arguments.length; a++) i[a] = arguments[a];
    for (var u = [], s = 0, l = i; s < l.length; s++) {
      var o = l[s];
      if (o.isSome()) u.push(o.value);
      else return o;
    }
    return x(u);
  }
  e.all = t;
  function r() {
    for (var i = [], a = 0; a < arguments.length; a++) i[a] = arguments[a];
    for (var u = 0, s = i; u < s.length; u++) {
      var l = s[u];
      if (l.isSome()) return l;
    }
    return S;
  }
  e.any = r;
  function n(i) {
    return i instanceof x || i === S;
  }
  e.isOption = n;
})(We || (We = {}));
var fe = function (e, t, r) {
    if (r || arguments.length === 2)
      for (var n = 0, i = t.length, a; n < i; n++)
        (a || !(n in t)) &&
          (a || (a = Array.prototype.slice.call(t, 0, n)), (a[n] = t[n]));
    return e.concat(a || Array.prototype.slice.call(t));
  },
  Nn = (function () {
    function e(t) {
      if (!(this instanceof e)) return new e(t);
      this.error = t;
      var r = new Error().stack
        .split(
          `
`,
        )
        .slice(2);
      (r && r.length > 0 && r[0].includes("ErrImpl") && r.shift(),
        (this._stack = r.join(`
`)));
    }
    return (
      (e.prototype.isOk = function () {
        return !1;
      }),
      (e.prototype.isErr = function () {
        return !0;
      }),
      (e.prototype[Symbol.iterator] = function () {
        return {
          next: function () {
            return { done: !0, value: void 0 };
          },
        };
      }),
      (e.prototype.else = function (t) {
        return t;
      }),
      (e.prototype.unwrapOr = function (t) {
        return t;
      }),
      (e.prototype.expect = function (t) {
        throw new Error(
          ""
            .concat(t, " - Error: ")
            .concat(
              se(this.error),
              `
`,
            )
            .concat(this._stack),
          { cause: this.error },
        );
      }),
      (e.prototype.expectErr = function (t) {
        return this.error;
      }),
      (e.prototype.unwrap = function () {
        throw new Error(
          "Tried to unwrap Error: "
            .concat(
              se(this.error),
              `
`,
            )
            .concat(this._stack),
          { cause: this.error },
        );
      }),
      (e.prototype.unwrapErr = function () {
        return this.error;
      }),
      (e.prototype.map = function (t) {
        return this;
      }),
      (e.prototype.andThen = function (t) {
        return this;
      }),
      (e.prototype.mapErr = function (t) {
        return new M(t(this.error));
      }),
      (e.prototype.mapOr = function (t, r) {
        return t;
      }),
      (e.prototype.mapOrElse = function (t, r) {
        return t(this.error);
      }),
      (e.prototype.or = function (t) {
        return t;
      }),
      (e.prototype.orElse = function (t) {
        return t(this.error);
      }),
      (e.prototype.toOption = function () {
        return S;
      }),
      (e.prototype.toString = function () {
        return "Err(".concat(se(this.error), ")");
      }),
      Object.defineProperty(e.prototype, "stack", {
        get: function () {
          return ""
            .concat(
              this,
              `
`,
            )
            .concat(this._stack);
        },
        enumerable: !1,
        configurable: !0,
      }),
      (e.prototype.toAsyncResult = function () {
        return new Ce(this);
      }),
      (e.EMPTY = new e(void 0)),
      e
    );
  })();
var M = Nn,
  In = (function () {
    function e(t) {
      if (!(this instanceof e)) return new e(t);
      this.value = t;
    }
    return (
      (e.prototype.isOk = function () {
        return !0;
      }),
      (e.prototype.isErr = function () {
        return !1;
      }),
      (e.prototype[Symbol.iterator] = function () {
        var t = Object(this.value);
        return Symbol.iterator in t
          ? t[Symbol.iterator]()
          : {
              next: function () {
                return { done: !0, value: void 0 };
              },
            };
      }),
      (e.prototype.else = function (t) {
        return this.value;
      }),
      (e.prototype.unwrapOr = function (t) {
        return this.value;
      }),
      (e.prototype.expect = function (t) {
        return this.value;
      }),
      (e.prototype.expectErr = function (t) {
        throw new Error(t);
      }),
      (e.prototype.unwrap = function () {
        return this.value;
      }),
      (e.prototype.unwrapErr = function () {
        throw new Error("Tried to unwrap Ok: ".concat(se(this.value)), {
          cause: this.value,
        });
      }),
      (e.prototype.map = function (t) {
        return new G(t(this.value));
      }),
      (e.prototype.andThen = function (t) {
        return t(this.value);
      }),
      (e.prototype.mapErr = function (t) {
        return this;
      }),
      (e.prototype.mapOr = function (t, r) {
        return r(this.value);
      }),
      (e.prototype.mapOrElse = function (t, r) {
        return r(this.value);
      }),
      (e.prototype.or = function (t) {
        return this;
      }),
      (e.prototype.orElse = function (t) {
        return this;
      }),
      (e.prototype.toOption = function () {
        return x(this.value);
      }),
      (e.prototype.safeUnwrap = function () {
        return this.value;
      }),
      (e.prototype.toString = function () {
        return "Ok(".concat(se(this.value), ")");
      }),
      (e.prototype.toAsyncResult = function () {
        return new Ce(this);
      }),
      (e.EMPTY = new e(void 0)),
      e
    );
  })();
var G = In,
  Ye;
(function (e) {
  function t(s) {
    for (var l = [], o = 1; o < arguments.length; o++) l[o - 1] = arguments[o];
    for (
      var m = s === void 0 ? [] : Array.isArray(s) ? s : fe([s], l, !0),
        d = [],
        g = 0,
        D = m;
      g < D.length;
      g++
    ) {
      var b = D[g];
      if (b.isOk()) d.push(b.value);
      else return b;
    }
    return new G(d);
  }
  e.all = t;
  function r(s) {
    for (var l = [], o = 1; o < arguments.length; o++) l[o - 1] = arguments[o];
    for (
      var m = s === void 0 ? [] : Array.isArray(s) ? s : fe([s], l, !0),
        d = [],
        g = 0,
        D = m;
      g < D.length;
      g++
    ) {
      var b = D[g];
      if (b.isOk()) return b;
      d.push(b.error);
    }
    return new M(d);
  }
  e.any = r;
  function n(s) {
    try {
      return new G(s());
    } catch (l) {
      return new M(l);
    }
  }
  e.wrap = n;
  function i(s) {
    try {
      return s()
        .then(function (l) {
          return new G(l);
        })
        .catch(function (l) {
          return new M(l);
        });
    } catch (l) {
      return Promise.resolve(new M(l));
    }
  }
  e.wrapAsync = i;
  function a(s) {
    return s.reduce(
      function (l, o) {
        var m = l[0],
          d = l[1];
        return o.isOk()
          ? [fe(fe([], m, !0), [o.value], !1), d]
          : [m, fe(fe([], d, !0), [o.error], !1)];
      },
      [[], []],
    );
  }
  e.partition = a;
  function u(s) {
    return s instanceof M || s instanceof G;
  }
  e.isResult = u;
})(Ye || (Ye = {}));
var je = function (e, t, r, n) {
    function i(a) {
      return a instanceof r
        ? a
        : new r(function (u) {
            u(a);
          });
    }
    return new (r || (r = Promise))(function (a, u) {
      function s(m) {
        try {
          o(n.next(m));
        } catch (d) {
          u(d);
        }
      }
      function l(m) {
        try {
          o(n.throw(m));
        } catch (d) {
          u(d);
        }
      }
      function o(m) {
        m.done ? a(m.value) : i(m.value).then(s, l);
      }
      o((n = n.apply(e, t || [])).next());
    });
  },
  Ke = function (e, t) {
    var r = {
        label: 0,
        sent: function () {
          if (a[0] & 1) throw a[1];
          return a[1];
        },
        trys: [],
        ops: [],
      },
      n,
      i,
      a,
      u;
    return (
      (u = { next: s(0), throw: s(1), return: s(2) }),
      typeof Symbol == "function" &&
        (u[Symbol.iterator] = function () {
          return this;
        }),
      u
    );
    function s(o) {
      return function (m) {
        return l([o, m]);
      };
    }
    function l(o) {
      if (n) throw new TypeError("Generator is already executing.");
      for (; u && ((u = 0), o[0] && (r = 0)), r;)
        try {
          if (
            ((n = 1),
            i &&
              (a =
                o[0] & 2
                  ? i.return
                  : o[0]
                    ? i.throw || ((a = i.return) && a.call(i), 0)
                    : i.next) &&
              !(a = a.call(i, o[1])).done)
          )
            return a;
          switch (((i = 0), a && (o = [o[0] & 2, a.value]), o[0])) {
            case 0:
            case 1:
              a = o;
              break;
            case 4:
              return (r.label++, { value: o[1], done: !1 });
            case 5:
              (r.label++, (i = o[1]), (o = [0]));
              continue;
            case 7:
              ((o = r.ops.pop()), r.trys.pop());
              continue;
            default:
              if (
                ((a = r.trys),
                !(a = a.length > 0 && a[a.length - 1]) &&
                  (o[0] === 6 || o[0] === 2))
              ) {
                r = 0;
                continue;
              }
              if (o[0] === 3 && (!a || (o[1] > a[0] && o[1] < a[3]))) {
                r.label = o[1];
                break;
              }
              if (o[0] === 6 && r.label < a[1]) {
                ((r.label = a[1]), (a = o));
                break;
              }
              if (a && r.label < a[2]) {
                ((r.label = a[2]), r.ops.push(o));
                break;
              }
              (a[2] && r.ops.pop(), r.trys.pop());
              continue;
          }
          o = t.call(e, r);
        } catch (m) {
          ((o = [6, m]), (i = 0));
        } finally {
          n = a = 0;
        }
      if (o[0] & 5) throw o[1];
      return { value: o[0] ? o[1] : void 0, done: !0 };
    }
  },
  Ce = (function () {
    function e(t) {
      this.promise = Promise.resolve(t);
    }
    return (
      (e.prototype.andThen = function (t) {
        var r = this;
        return this.thenInternal(function (n) {
          return je(r, void 0, void 0, function () {
            var i;
            return Ke(this, function (a) {
              return n.isErr()
                ? [2, n]
                : ((i = t(n.value)), [2, i instanceof e ? i.promise : i]);
            });
          });
        });
      }),
      (e.prototype.map = function (t) {
        var r = this;
        return this.thenInternal(function (n) {
          return je(r, void 0, void 0, function () {
            var i;
            return Ke(this, function (a) {
              switch (a.label) {
                case 0:
                  return n.isErr() ? [2, n] : ((i = G), [4, t(n.value)]);
                case 1:
                  return [2, i.apply(void 0, [a.sent()])];
              }
            });
          });
        });
      }),
      (e.prototype.mapErr = function (t) {
        var r = this;
        return this.thenInternal(function (n) {
          return je(r, void 0, void 0, function () {
            var i;
            return Ke(this, function (a) {
              switch (a.label) {
                case 0:
                  return n.isOk() ? [2, n] : ((i = M), [4, t(n.error)]);
                case 1:
                  return [2, i.apply(void 0, [a.sent()])];
              }
            });
          });
        });
      }),
      (e.prototype.or = function (t) {
        return this.orElse(function () {
          return t;
        });
      }),
      (e.prototype.orElse = function (t) {
        var r = this;
        return this.thenInternal(function (n) {
          return je(r, void 0, void 0, function () {
            var i;
            return Ke(this, function (a) {
              return n.isOk()
                ? [2, n]
                : ((i = t(n.error)), [2, i instanceof e ? i.promise : i]);
            });
          });
        });
      }),
      (e.prototype.toOption = function () {
        return new xe(
          this.promise.then(function (t) {
            return t.toOption();
          }),
        );
      }),
      (e.prototype.thenInternal = function (t) {
        return new e(this.promise.then(t));
      }),
      e
    );
  })();
var At = function (e, t, r, n) {
    function i(a) {
      return a instanceof r
        ? a
        : new r(function (u) {
            u(a);
          });
    }
    return new (r || (r = Promise))(function (a, u) {
      function s(m) {
        try {
          o(n.next(m));
        } catch (d) {
          u(d);
        }
      }
      function l(m) {
        try {
          o(n.throw(m));
        } catch (d) {
          u(d);
        }
      }
      function o(m) {
        m.done ? a(m.value) : i(m.value).then(s, l);
      }
      o((n = n.apply(e, t || [])).next());
    });
  },
  Dt = function (e, t) {
    var r = {
        label: 0,
        sent: function () {
          if (a[0] & 1) throw a[1];
          return a[1];
        },
        trys: [],
        ops: [],
      },
      n,
      i,
      a,
      u;
    return (
      (u = { next: s(0), throw: s(1), return: s(2) }),
      typeof Symbol == "function" &&
        (u[Symbol.iterator] = function () {
          return this;
        }),
      u
    );
    function s(o) {
      return function (m) {
        return l([o, m]);
      };
    }
    function l(o) {
      if (n) throw new TypeError("Generator is already executing.");
      for (; u && ((u = 0), o[0] && (r = 0)), r;)
        try {
          if (
            ((n = 1),
            i &&
              (a =
                o[0] & 2
                  ? i.return
                  : o[0]
                    ? i.throw || ((a = i.return) && a.call(i), 0)
                    : i.next) &&
              !(a = a.call(i, o[1])).done)
          )
            return a;
          switch (((i = 0), a && (o = [o[0] & 2, a.value]), o[0])) {
            case 0:
            case 1:
              a = o;
              break;
            case 4:
              return (r.label++, { value: o[1], done: !1 });
            case 5:
              (r.label++, (i = o[1]), (o = [0]));
              continue;
            case 7:
              ((o = r.ops.pop()), r.trys.pop());
              continue;
            default:
              if (
                ((a = r.trys),
                !(a = a.length > 0 && a[a.length - 1]) &&
                  (o[0] === 6 || o[0] === 2))
              ) {
                r = 0;
                continue;
              }
              if (o[0] === 3 && (!a || (o[1] > a[0] && o[1] < a[3]))) {
                r.label = o[1];
                break;
              }
              if (o[0] === 6 && r.label < a[1]) {
                ((r.label = a[1]), (a = o));
                break;
              }
              if (a && r.label < a[2]) {
                ((r.label = a[2]), r.ops.push(o));
                break;
              }
              (a[2] && r.ops.pop(), r.trys.pop());
              continue;
          }
          o = t.call(e, r);
        } catch (m) {
          ((o = [6, m]), (i = 0));
        } finally {
          n = a = 0;
        }
      if (o[0] & 5) throw o[1];
      return { value: o[0] ? o[1] : void 0, done: !0 };
    }
  },
  xe = (function () {
    function e(t) {
      this.promise = Promise.resolve(t);
    }
    return (
      (e.prototype.andThen = function (t) {
        var r = this;
        return this.thenInternal(function (n) {
          return At(r, void 0, void 0, function () {
            var i;
            return Dt(this, function (a) {
              return n.isNone()
                ? [2, n]
                : ((i = t(n.value)), [2, i instanceof e ? i.promise : i]);
            });
          });
        });
      }),
      (e.prototype.map = function (t) {
        var r = this;
        return this.thenInternal(function (n) {
          return At(r, void 0, void 0, function () {
            var i;
            return Dt(this, function (a) {
              switch (a.label) {
                case 0:
                  return n.isNone() ? [2, n] : ((i = x), [4, t(n.value)]);
                case 1:
                  return [2, i.apply(void 0, [a.sent()])];
              }
            });
          });
        });
      }),
      (e.prototype.or = function (t) {
        return this.orElse(function () {
          return t;
        });
      }),
      (e.prototype.orElse = function (t) {
        var r = this;
        return this.thenInternal(function (n) {
          return At(r, void 0, void 0, function () {
            var i;
            return Dt(this, function (a) {
              return n.isSome()
                ? [2, n]
                : ((i = t()), [2, i instanceof e ? i.promise : i]);
            });
          });
        });
      }),
      (e.prototype.toResult = function (t) {
        return new Ce(
          this.promise.then(function (r) {
            return r.toResult(t);
          }),
        );
      }),
      (e.prototype.thenInternal = function (t) {
        return new e(this.promise.then(t));
      }),
      e
    );
  })();
function Et(e, t) {
  let r = new URLSearchParams();
  for (let [n, i] of e) r.set(n, i);
  for (let [n, i] of t) r.set(n, i);
  return r.toString();
}
function K(e, t) {
  try {
    if (e) return x(new URL(e, t));
  } catch {}
  return S;
}
function Z(e) {
  if (typeof e == "string") return { __serde_tag: "primitive", __serde_val: e };
  if (typeof e == "number") return { __serde_tag: "primitive", __serde_val: e };
  if (typeof e == "boolean")
    return { __serde_tag: "primitive", __serde_val: e };
  if (typeof e > "u") return { __serde_tag: "primitive", __serde_val: e };
  if (e == null) return { __serde_tag: "primitive", __serde_val: e };
  if (Array.isArray(e))
    return { __serde_tag: "array", __serde_val: e.map((t) => Z(t)) };
  if (e instanceof URL) return { __serde_tag: "url", __serde_val: e.href };
  if (e instanceof Headers) {
    let t = [];
    return (
      e.forEach((r, n) => {
        t.push([n, r]);
      }),
      { __serde_tag: "headers", __serde_val: t }
    );
  } else {
    if (e instanceof Set)
      return { __serde_tag: "set", __serde_val: [...e.values()].map(Z) };
    if (e instanceof Map)
      return {
        __serde_tag: "map",
        __serde_val: [...e.entries()].map(([t, r]) => [Z(t), Z(r)]),
      };
    if (e instanceof RegExp)
      return { __serde_tag: "regex", __serde_val: [e.source, e.flags] };
    if (We.isOption(e))
      return e.isSome()
        ? { __serde_tag: "some", __serde_val: Z(e.value) }
        : { __serde_tag: "none" };
    if (Ye.isResult(e))
      return e.isOk()
        ? { __serde_tag: "ok", __serde_val: Z(e.value) }
        : { __serde_tag: "err", __serde_val: Z(e.error) };
    if (typeof e == "object") {
      let t = {};
      for (let [r, n] of Object.entries(e)) t[r] = Z(n);
      return { __serde_tag: "object", __serde_val: t };
    } else throw new Error("Unreachable");
  }
}
var Rn = ["mp4", "webm", "mkv"],
  On = ["mp3", "m4a", "ogg"],
  Mn = [...Rn, ...On];
var Bn = [
    { mime_reg: /(avc1|avc3).*/i, demuxer: "mp4", codec: "H264" },
    {
      mime_reg: /(hvc1|hev1|hevc|h265|h\.265).*/i,
      demuxer: "mp4",
      codec: "H265",
    },
    { mime_reg: /mp4v\.20.*/i, demuxer: "mp4", codec: "MP4V" },
    { mime_reg: /av0?1.*/i, demuxer: "webm", codec: "AV1" },
    { mime_reg: /vp0?8.*/i, demuxer: "webm", codec: "VP8" },
    { mime_reg: /vp0?9.*/i, demuxer: "webm", codec: "VP9" },
  ],
  Fn = [
    { mime_reg: /(aac|mp4a.40).*/i, demuxer: "m4a", codec: "AAC" },
    { mime_reg: /(\.?mp3|mp4a\.69|mp4a\.6b).*/i, demuxer: "mp3", codec: "MP3" },
    { mime_reg: /(opus|(mp4a\.ad.*))/i, demuxer: "ogg", codec: "Opus" },
    { mime_reg: /vorbis/i, demuxer: "ogg", codec: "Vorbis" },
  ];
function Qe(e) {
  for (let t of Bn) if (t.mime_reg.test(e)) return x(t.demuxer);
  return S;
}
function jt(e) {
  for (let t of Fn) if (t.mime_reg.test(e)) return x(t.demuxer);
  return S;
}
function Pn(e, t) {
  let a = e.size.map((o) => o.height).unwrapOr(0),
    u = t.size.map((o) => o.height).unwrapOr(0),
    s = e.bitrate.unwrapOr(0),
    l = t.bitrate.unwrapOr(0);
  return a > u ? -1 : a < u ? 1 : s > l ? -1 : s < l ? 1 : 0;
}
function Ze(e) {
  return [...e.values()].sort((t, r) => Pn(t.quality, r.quality));
}
function Je(e) {
  return e.length > 0;
}
var et = (function () {
  function e() {
    this.listeners = {};
  }
  var t = e.prototype;
  return (
    (t.on = function (n, i) {
      (this.listeners[n] || (this.listeners[n] = []),
        this.listeners[n].push(i));
    }),
    (t.off = function (n, i) {
      if (!this.listeners[n]) return !1;
      var a = this.listeners[n].indexOf(i);
      return (
        (this.listeners[n] = this.listeners[n].slice(0)),
        this.listeners[n].splice(a, 1),
        a > -1
      );
    }),
    (t.trigger = function (n) {
      var i = this.listeners[n];
      if (i)
        if (arguments.length === 2)
          for (var a = i.length, u = 0; u < a; ++u)
            i[u].call(this, arguments[1]);
        else
          for (
            var s = Array.prototype.slice.call(arguments, 1),
              l = i.length,
              o = 0;
            o < l;
            ++o
          )
            i[o].apply(this, s);
    }),
    (t.dispose = function () {
      this.listeners = {};
    }),
    (t.pipe = function (n) {
      this.on("data", function (i) {
        n.push(i);
      });
    }),
    e
  );
})();
function ce() {
  return (
    (ce = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var n in r) ({}).hasOwnProperty.call(r, n) && (e[n] = r[n]);
          }
          return e;
        }),
    ce.apply(null, arguments)
  );
}
var yt = we(tt()),
  Un = function (t) {
    return yt.default.atob
      ? yt.default.atob(t)
      : Buffer.from(t, "base64").toString("binary");
  };
function Ie(e) {
  for (var t = Un(e), r = new Uint8Array(t.length), n = 0; n < t.length; n++)
    r[n] = t.charCodeAt(n);
  return r;
}
var Tt = class extends et {
    constructor() {
      (super(), (this.buffer = ""));
    }
    push(t) {
      let r;
      for (
        this.buffer += t,
          r = this.buffer.indexOf(`
`);
        r > -1;
        r = this.buffer.indexOf(`
`)
      )
        (this.trigger("data", this.buffer.substring(0, r)),
          (this.buffer = this.buffer.substring(r + 1)));
    }
  },
  kn = "	",
  bt = function (e) {
    let t = /([0-9.]*)?@?([0-9.]*)?/.exec(e || ""),
      r = {};
    return (
      t[1] && (r.length = parseInt(t[1], 10)),
      t[2] && (r.offset = parseInt(t[2], 10)),
      r
    );
  },
  qn = function () {
    let r = "(?:" + "[^=]*" + ")=(?:" + '"[^"]*"|[^,]*' + ")";
    return new RegExp("(?:^|,)(" + r + ")");
  },
  H = function (e) {
    let t = {};
    if (!e) return t;
    let r = e.split(qn()),
      n = r.length,
      i;
    for (; n--;)
      r[n] !== "" &&
        ((i = /([^=]*)=(.*)/.exec(r[n]).slice(1)),
        (i[0] = i[0].replace(/^\s+|\s+$/g, "")),
        (i[1] = i[1].replace(/^\s+|\s+$/g, "")),
        (i[1] = i[1].replace(/^['"](.*)['"]$/g, "$1")),
        (t[i[0]] = i[1]));
    return t;
  },
  Zt = (e) => {
    let t = e.split("x"),
      r = {};
    return (
      t[0] && (r.width = parseInt(t[0], 10)),
      t[1] && (r.height = parseInt(t[1], 10)),
      r
    );
  },
  _t = class extends et {
    constructor() {
      (super(), (this.customParsers = []), (this.tagMappers = []));
    }
    push(t) {
      let r, n;
      if (((t = t.trim()), t.length === 0)) return;
      if (t[0] !== "#") {
        this.trigger("data", { type: "uri", uri: t });
        return;
      }
      this.tagMappers
        .reduce(
          (a, u) => {
            let s = u(t);
            return s === t ? a : a.concat([s]);
          },
          [t],
        )
        .forEach((a) => {
          for (let u = 0; u < this.customParsers.length; u++)
            if (this.customParsers[u].call(this, a)) return;
          if (a.indexOf("#EXT") !== 0) {
            this.trigger("data", { type: "comment", text: a.slice(1) });
            return;
          }
          if (((a = a.replace("\r", "")), (r = /^#EXTM3U/.exec(a)), r)) {
            this.trigger("data", { type: "tag", tagType: "m3u" });
            return;
          }
          if (((r = /^#EXTINF:([0-9\.]*)?,?(.*)?$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "inf" }),
              r[1] && (n.duration = parseFloat(r[1])),
              r[2] && (n.title = r[2]),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-TARGETDURATION:([0-9.]*)?/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "targetduration" }),
              r[1] && (n.duration = parseInt(r[1], 10)),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-VERSION:([0-9.]*)?/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "version" }),
              r[1] && (n.version = parseInt(r[1], 10)),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-MEDIA-SEQUENCE:(\-?[0-9.]*)?/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "media-sequence" }),
              r[1] && (n.number = parseInt(r[1], 10)),
              this.trigger("data", n));
            return;
          }
          if (
            ((r = /^#EXT-X-DISCONTINUITY-SEQUENCE:(\-?[0-9.]*)?/.exec(a)), r)
          ) {
            ((n = { type: "tag", tagType: "discontinuity-sequence" }),
              r[1] && (n.number = parseInt(r[1], 10)),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-PLAYLIST-TYPE:(.*)?$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "playlist-type" }),
              r[1] && (n.playlistType = r[1]),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-BYTERANGE:(.*)?$/.exec(a)), r)) {
            ((n = ce(bt(r[1]), { type: "tag", tagType: "byterange" })),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-ALLOW-CACHE:(YES|NO)?/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "allow-cache" }),
              r[1] && (n.allowed = !/NO/.test(r[1])),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-MAP:(.*)$/.exec(a)), r)) {
            if (((n = { type: "tag", tagType: "map" }), r[1])) {
              let u = H(r[1]);
              (u.URI && (n.uri = u.URI),
                u.BYTERANGE && (n.byterange = bt(u.BYTERANGE)));
            }
            this.trigger("data", n);
            return;
          }
          if (((r = /^#EXT-X-STREAM-INF:(.*)$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "stream-inf" }),
              r[1] &&
                ((n.attributes = H(r[1])),
                n.attributes.RESOLUTION &&
                  (n.attributes.RESOLUTION = Zt(n.attributes.RESOLUTION)),
                n.attributes.BANDWIDTH &&
                  (n.attributes.BANDWIDTH = parseInt(
                    n.attributes.BANDWIDTH,
                    10,
                  )),
                n.attributes["FRAME-RATE"] &&
                  (n.attributes["FRAME-RATE"] = parseFloat(
                    n.attributes["FRAME-RATE"],
                  )),
                n.attributes["PROGRAM-ID"] &&
                  (n.attributes["PROGRAM-ID"] = parseInt(
                    n.attributes["PROGRAM-ID"],
                    10,
                  ))),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-MEDIA:(.*)$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "media" }),
              r[1] && (n.attributes = H(r[1])),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-ENDLIST/.exec(a)), r)) {
            this.trigger("data", { type: "tag", tagType: "endlist" });
            return;
          }
          if (((r = /^#EXT-X-DISCONTINUITY/.exec(a)), r)) {
            this.trigger("data", { type: "tag", tagType: "discontinuity" });
            return;
          }
          if (((r = /^#EXT-X-PROGRAM-DATE-TIME:(.*)$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "program-date-time" }),
              r[1] &&
                ((n.dateTimeString = r[1]),
                (n.dateTimeObject = new Date(r[1]))),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-KEY:(.*)$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "key" }),
              r[1] &&
                ((n.attributes = H(r[1])),
                n.attributes.IV &&
                  (n.attributes.IV.substring(0, 2).toLowerCase() === "0x" &&
                    (n.attributes.IV = n.attributes.IV.substring(2)),
                  (n.attributes.IV = n.attributes.IV.match(/.{8}/g)),
                  (n.attributes.IV[0] = parseInt(n.attributes.IV[0], 16)),
                  (n.attributes.IV[1] = parseInt(n.attributes.IV[1], 16)),
                  (n.attributes.IV[2] = parseInt(n.attributes.IV[2], 16)),
                  (n.attributes.IV[3] = parseInt(n.attributes.IV[3], 16)),
                  (n.attributes.IV = new Uint32Array(n.attributes.IV)))),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-START:(.*)$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "start" }),
              r[1] &&
                ((n.attributes = H(r[1])),
                (n.attributes["TIME-OFFSET"] = parseFloat(
                  n.attributes["TIME-OFFSET"],
                )),
                (n.attributes.PRECISE = /YES/.test(n.attributes.PRECISE))),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-CUE-OUT-CONT:(.*)?$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "cue-out-cont" }),
              r[1] ? (n.data = r[1]) : (n.data = ""),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-CUE-OUT:(.*)?$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "cue-out" }),
              r[1] ? (n.data = r[1]) : (n.data = ""),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-CUE-IN:?(.*)?$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "cue-in" }),
              r[1] ? (n.data = r[1]) : (n.data = ""),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-SKIP:(.*)$/.exec(a)), r && r[1])) {
            ((n = { type: "tag", tagType: "skip" }),
              (n.attributes = H(r[1])),
              n.attributes.hasOwnProperty("SKIPPED-SEGMENTS") &&
                (n.attributes["SKIPPED-SEGMENTS"] = parseInt(
                  n.attributes["SKIPPED-SEGMENTS"],
                  10,
                )),
              n.attributes.hasOwnProperty("RECENTLY-REMOVED-DATERANGES") &&
                (n.attributes["RECENTLY-REMOVED-DATERANGES"] =
                  n.attributes["RECENTLY-REMOVED-DATERANGES"].split(kn)),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-PART:(.*)$/.exec(a)), r && r[1])) {
            ((n = { type: "tag", tagType: "part" }),
              (n.attributes = H(r[1])),
              ["DURATION"].forEach(function (u) {
                n.attributes.hasOwnProperty(u) &&
                  (n.attributes[u] = parseFloat(n.attributes[u]));
              }),
              ["INDEPENDENT", "GAP"].forEach(function (u) {
                n.attributes.hasOwnProperty(u) &&
                  (n.attributes[u] = /YES/.test(n.attributes[u]));
              }),
              n.attributes.hasOwnProperty("BYTERANGE") &&
                (n.attributes.byterange = bt(n.attributes.BYTERANGE)),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-SERVER-CONTROL:(.*)$/.exec(a)), r && r[1])) {
            ((n = { type: "tag", tagType: "server-control" }),
              (n.attributes = H(r[1])),
              ["CAN-SKIP-UNTIL", "PART-HOLD-BACK", "HOLD-BACK"].forEach(
                function (u) {
                  n.attributes.hasOwnProperty(u) &&
                    (n.attributes[u] = parseFloat(n.attributes[u]));
                },
              ),
              ["CAN-SKIP-DATERANGES", "CAN-BLOCK-RELOAD"].forEach(function (u) {
                n.attributes.hasOwnProperty(u) &&
                  (n.attributes[u] = /YES/.test(n.attributes[u]));
              }),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-PART-INF:(.*)$/.exec(a)), r && r[1])) {
            ((n = { type: "tag", tagType: "part-inf" }),
              (n.attributes = H(r[1])),
              ["PART-TARGET"].forEach(function (u) {
                n.attributes.hasOwnProperty(u) &&
                  (n.attributes[u] = parseFloat(n.attributes[u]));
              }),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-PRELOAD-HINT:(.*)$/.exec(a)), r && r[1])) {
            ((n = { type: "tag", tagType: "preload-hint" }),
              (n.attributes = H(r[1])),
              ["BYTERANGE-START", "BYTERANGE-LENGTH"].forEach(function (u) {
                if (n.attributes.hasOwnProperty(u)) {
                  n.attributes[u] = parseInt(n.attributes[u], 10);
                  let s = u === "BYTERANGE-LENGTH" ? "length" : "offset";
                  ((n.attributes.byterange = n.attributes.byterange || {}),
                    (n.attributes.byterange[s] = n.attributes[u]),
                    delete n.attributes[u]);
                }
              }),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-RENDITION-REPORT:(.*)$/.exec(a)), r && r[1])) {
            ((n = { type: "tag", tagType: "rendition-report" }),
              (n.attributes = H(r[1])),
              ["LAST-MSN", "LAST-PART"].forEach(function (u) {
                n.attributes.hasOwnProperty(u) &&
                  (n.attributes[u] = parseInt(n.attributes[u], 10));
              }),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-DATERANGE:(.*)$/.exec(a)), r && r[1])) {
            ((n = { type: "tag", tagType: "daterange" }),
              (n.attributes = H(r[1])),
              ["ID", "CLASS"].forEach(function (s) {
                n.attributes.hasOwnProperty(s) &&
                  (n.attributes[s] = String(n.attributes[s]));
              }),
              ["START-DATE", "END-DATE"].forEach(function (s) {
                n.attributes.hasOwnProperty(s) &&
                  (n.attributes[s] = new Date(n.attributes[s]));
              }),
              ["DURATION", "PLANNED-DURATION"].forEach(function (s) {
                n.attributes.hasOwnProperty(s) &&
                  (n.attributes[s] = parseFloat(n.attributes[s]));
              }),
              ["END-ON-NEXT"].forEach(function (s) {
                n.attributes.hasOwnProperty(s) &&
                  (n.attributes[s] = /YES/i.test(n.attributes[s]));
              }),
              ["SCTE35-CMD", " SCTE35-OUT", "SCTE35-IN"].forEach(function (s) {
                n.attributes.hasOwnProperty(s) &&
                  (n.attributes[s] = n.attributes[s].toString(16));
              }));
            let u = /^X-([A-Z]+-)+[A-Z]+$/;
            for (let s in n.attributes) {
              if (!u.test(s)) continue;
              let l = /[0-9A-Fa-f]{6}/g.test(n.attributes[s]),
                o = /^\d+(\.\d+)?$/.test(n.attributes[s]);
              n.attributes[s] = l
                ? n.attributes[s].toString(16)
                : o
                  ? parseFloat(n.attributes[s])
                  : String(n.attributes[s]);
            }
            this.trigger("data", n);
            return;
          }
          if (((r = /^#EXT-X-INDEPENDENT-SEGMENTS/.exec(a)), r)) {
            this.trigger("data", {
              type: "tag",
              tagType: "independent-segments",
            });
            return;
          }
          if (((r = /^#EXT-X-I-FRAMES-ONLY/.exec(a)), r)) {
            this.trigger("data", { type: "tag", tagType: "i-frames-only" });
            return;
          }
          if (((r = /^#EXT-X-CONTENT-STEERING:(.*)$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "content-steering" }),
              (n.attributes = H(r[1])),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-I-FRAME-STREAM-INF:(.*)$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "i-frame-playlist" }),
              (n.attributes = H(r[1])),
              n.attributes.URI && (n.uri = n.attributes.URI),
              n.attributes.BANDWIDTH &&
                (n.attributes.BANDWIDTH = parseInt(n.attributes.BANDWIDTH, 10)),
              n.attributes.RESOLUTION &&
                (n.attributes.RESOLUTION = Zt(n.attributes.RESOLUTION)),
              n.attributes["AVERAGE-BANDWIDTH"] &&
                (n.attributes["AVERAGE-BANDWIDTH"] = parseInt(
                  n.attributes["AVERAGE-BANDWIDTH"],
                  10,
                )),
              n.attributes["FRAME-RATE"] &&
                (n.attributes["FRAME-RATE"] = parseFloat(
                  n.attributes["FRAME-RATE"],
                )),
              this.trigger("data", n));
            return;
          }
          if (((r = /^#EXT-X-DEFINE:(.*)$/.exec(a)), r)) {
            ((n = { type: "tag", tagType: "define" }),
              (n.attributes = H(r[1])),
              this.trigger("data", n));
            return;
          }
          this.trigger("data", { type: "tag", data: a.slice(4) });
        });
    }
    addParser({ expression: t, customType: r, dataParser: n, segment: i }) {
      (typeof n != "function" && (n = (a) => a),
        this.customParsers.push((a) => {
          if (t.exec(a))
            return (
              this.trigger("data", {
                type: "custom",
                data: n(a),
                customType: r,
                segment: i,
              }),
              !0
            );
        }));
    }
    addTagMapper({ expression: t, map: r }) {
      let n = (i) => (t.test(i) ? r(i) : i);
      this.tagMappers.push(n);
    }
  },
  Vn = (e) => e.toLowerCase().replace(/-(\w)/g, (t) => t[1].toUpperCase()),
  oe = function (e) {
    let t = {};
    return (
      Object.keys(e).forEach(function (r) {
        t[Vn(r)] = e[r];
      }),
      t
    );
  },
  vt = function (e) {
    let { serverControl: t, targetDuration: r, partTargetDuration: n } = e;
    if (!t) return;
    let i = "#EXT-X-SERVER-CONTROL",
      a = "holdBack",
      u = "partHoldBack",
      s = r && r * 3,
      l = n && n * 2;
    (r &&
      !t.hasOwnProperty(a) &&
      ((t[a] = s),
      this.trigger("info", {
        message: `${i} defaulting HOLD-BACK to targetDuration * 3 (${s}).`,
      })),
      s &&
        t[a] < s &&
        (this.trigger("warn", {
          message: `${i} clamping HOLD-BACK (${t[a]}) to targetDuration * 3 (${s})`,
        }),
        (t[a] = s)),
      n &&
        !t.hasOwnProperty(u) &&
        ((t[u] = n * 3),
        this.trigger("info", {
          message: `${i} defaulting PART-HOLD-BACK to partTargetDuration * 3 (${t[u]}).`,
        })),
      n &&
        t[u] < l &&
        (this.trigger("warn", {
          message: `${i} clamping PART-HOLD-BACK (${t[u]}) to partTargetDuration * 2 (${l}).`,
        }),
        (t[u] = l)));
  },
  Re = class extends et {
    constructor(t = {}) {
      (super(),
        (this.lineStream = new Tt()),
        (this.parseStream = new _t()),
        this.lineStream.pipe(this.parseStream),
        (this.mainDefinitions = t.mainDefinitions || {}),
        (this.params = new URL(t.uri, "https://a.com").searchParams),
        (this.lastProgramDateTime = null));
      let r = this,
        n = [],
        i = {},
        a,
        u,
        s = !1,
        l = function () {},
        o = { AUDIO: {}, VIDEO: {}, "CLOSED-CAPTIONS": {}, SUBTITLES: {} },
        m = "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed",
        d = 0;
      this.manifest = {
        allowCache: !0,
        discontinuityStarts: [],
        dateRanges: [],
        iFramePlaylists: [],
        segments: [],
      };
      let g = 0,
        D = 0,
        b = {};
      (this.on("end", () => {
        i.uri ||
          (!i.parts && !i.preloadHints) ||
          (!i.map && a && (i.map = a),
          !i.key && u && (i.key = u),
          !i.timeline && typeof d == "number" && (i.timeline = d),
          (this.manifest.preloadSegment = i));
      }),
        this.parseStream.on("data", function (c) {
          let v, T;
          if (r.manifest.definitions) {
            for (let h in r.manifest.definitions)
              if (
                (c.uri &&
                  (c.uri = c.uri.replace(`{$${h}}`, r.manifest.definitions[h])),
                c.attributes)
              )
                for (let f in c.attributes)
                  typeof c.attributes[f] == "string" &&
                    (c.attributes[f] = c.attributes[f].replace(
                      `{$${h}}`,
                      r.manifest.definitions[h],
                    ));
          }
          ({
            tag() {
              (
                ({
                  version() {
                    c.version && (this.manifest.version = c.version);
                  },
                  "allow-cache"() {
                    ((this.manifest.allowCache = c.allowed),
                      "allowed" in c ||
                        (this.trigger("info", {
                          message: "defaulting allowCache to YES",
                        }),
                        (this.manifest.allowCache = !0)));
                  },
                  byterange() {
                    let h = {};
                    ("length" in c &&
                      ((i.byterange = h),
                      (h.length = c.length),
                      "offset" in c || (c.offset = g)),
                      "offset" in c &&
                        ((i.byterange = h), (h.offset = c.offset)),
                      (g = h.offset + h.length));
                  },
                  endlist() {
                    this.manifest.endList = !0;
                  },
                  inf() {
                    ("mediaSequence" in this.manifest ||
                      ((this.manifest.mediaSequence = 0),
                      this.trigger("info", {
                        message: "defaulting media sequence to zero",
                      })),
                      "discontinuitySequence" in this.manifest ||
                        ((this.manifest.discontinuitySequence = 0),
                        this.trigger("info", {
                          message: "defaulting discontinuity sequence to zero",
                        })),
                      c.title && (i.title = c.title),
                      c.duration > 0 && (i.duration = c.duration),
                      c.duration === 0 &&
                        ((i.duration = 0.01),
                        this.trigger("info", {
                          message:
                            "updating zero segment duration to a small value",
                        })),
                      (this.manifest.segments = n));
                  },
                  key() {
                    if (!c.attributes) {
                      this.trigger("warn", {
                        message:
                          "ignoring key declaration without attribute list",
                      });
                      return;
                    }
                    if (c.attributes.METHOD === "NONE") {
                      u = null;
                      return;
                    }
                    if (!c.attributes.URI) {
                      this.trigger("warn", {
                        message: "ignoring key declaration without URI",
                      });
                      return;
                    }
                    if (
                      c.attributes.KEYFORMAT ===
                      "com.apple.streamingkeydelivery"
                    ) {
                      ((this.manifest.contentProtection =
                        this.manifest.contentProtection || {}),
                        (this.manifest.contentProtection["com.apple.fps.1_0"] =
                          { attributes: c.attributes }));
                      return;
                    }
                    if (c.attributes.KEYFORMAT === "com.microsoft.playready") {
                      ((this.manifest.contentProtection =
                        this.manifest.contentProtection || {}),
                        (this.manifest.contentProtection[
                          "com.microsoft.playready"
                        ] = { uri: c.attributes.URI }));
                      return;
                    }
                    if (c.attributes.KEYFORMAT === m) {
                      if (
                        [
                          "SAMPLE-AES",
                          "SAMPLE-AES-CTR",
                          "SAMPLE-AES-CENC",
                        ].indexOf(c.attributes.METHOD) === -1
                      ) {
                        this.trigger("warn", {
                          message: "invalid key method provided for Widevine",
                        });
                        return;
                      }
                      if (
                        (c.attributes.METHOD === "SAMPLE-AES-CENC" &&
                          this.trigger("warn", {
                            message:
                              "SAMPLE-AES-CENC is deprecated, please use SAMPLE-AES-CTR instead",
                          }),
                        c.attributes.URI.substring(0, 23) !==
                          "data:text/plain;base64,")
                      ) {
                        this.trigger("warn", {
                          message: "invalid key URI provided for Widevine",
                        });
                        return;
                      }
                      if (!(
                        c.attributes.KEYID &&
                        c.attributes.KEYID.substring(0, 2) === "0x"
                      )) {
                        this.trigger("warn", {
                          message: "invalid key ID provided for Widevine",
                        });
                        return;
                      }
                      ((this.manifest.contentProtection =
                        this.manifest.contentProtection || {}),
                        (this.manifest.contentProtection["com.widevine.alpha"] =
                          {
                            attributes: {
                              schemeIdUri: c.attributes.KEYFORMAT,
                              keyId: c.attributes.KEYID.substring(2),
                            },
                            pssh: Ie(c.attributes.URI.split(",")[1]),
                          }));
                      return;
                    }
                    (c.attributes.METHOD ||
                      this.trigger("warn", {
                        message: "defaulting key method to AES-128",
                      }),
                      (u = {
                        method: c.attributes.METHOD || "AES-128",
                        uri: c.attributes.URI,
                      }),
                      typeof c.attributes.IV < "u" && (u.iv = c.attributes.IV));
                  },
                  "media-sequence"() {
                    if (!isFinite(c.number)) {
                      this.trigger("warn", {
                        message: "ignoring invalid media sequence: " + c.number,
                      });
                      return;
                    }
                    this.manifest.mediaSequence = c.number;
                  },
                  "discontinuity-sequence"() {
                    if (!isFinite(c.number)) {
                      this.trigger("warn", {
                        message:
                          "ignoring invalid discontinuity sequence: " +
                          c.number,
                      });
                      return;
                    }
                    ((this.manifest.discontinuitySequence = c.number),
                      (d = c.number));
                  },
                  "playlist-type"() {
                    if (!/VOD|EVENT/.test(c.playlistType)) {
                      this.trigger("warn", {
                        message:
                          "ignoring unknown playlist type: " + c.playlist,
                      });
                      return;
                    }
                    this.manifest.playlistType = c.playlistType;
                  },
                  map() {
                    ((a = {}),
                      c.uri && (a.uri = c.uri),
                      c.byterange && (a.byterange = c.byterange),
                      u && (a.key = u));
                  },
                  "stream-inf"() {
                    if (
                      ((this.manifest.playlists = n),
                      (this.manifest.mediaGroups =
                        this.manifest.mediaGroups || o),
                      !c.attributes)
                    ) {
                      this.trigger("warn", {
                        message: "ignoring empty stream-inf attributes",
                      });
                      return;
                    }
                    (i.attributes || (i.attributes = {}),
                      ce(i.attributes, c.attributes));
                  },
                  media() {
                    if (
                      ((this.manifest.mediaGroups =
                        this.manifest.mediaGroups || o),
                      !(
                        c.attributes &&
                        c.attributes.TYPE &&
                        c.attributes["GROUP-ID"] &&
                        c.attributes.NAME
                      ))
                    ) {
                      this.trigger("warn", {
                        message: "ignoring incomplete or missing media group",
                      });
                      return;
                    }
                    let h = this.manifest.mediaGroups[c.attributes.TYPE];
                    ((h[c.attributes["GROUP-ID"]] =
                      h[c.attributes["GROUP-ID"]] || {}),
                      (v = h[c.attributes["GROUP-ID"]]),
                      (T = { default: /yes/i.test(c.attributes.DEFAULT) }),
                      T.default
                        ? (T.autoselect = !0)
                        : (T.autoselect = /yes/i.test(c.attributes.AUTOSELECT)),
                      c.attributes.LANGUAGE &&
                        (T.language = c.attributes.LANGUAGE),
                      c.attributes.URI && (T.uri = c.attributes.URI),
                      c.attributes["INSTREAM-ID"] &&
                        (T.instreamId = c.attributes["INSTREAM-ID"]),
                      c.attributes.CHARACTERISTICS &&
                        (T.characteristics = c.attributes.CHARACTERISTICS),
                      c.attributes.FORCED &&
                        (T.forced = /yes/i.test(c.attributes.FORCED)),
                      (v[c.attributes.NAME] = T));
                  },
                  discontinuity() {
                    ((d += 1),
                      (i.discontinuity = !0),
                      this.manifest.discontinuityStarts.push(n.length));
                  },
                  "program-date-time"() {
                    (typeof this.manifest.dateTimeString > "u" &&
                      ((this.manifest.dateTimeString = c.dateTimeString),
                      (this.manifest.dateTimeObject = c.dateTimeObject)),
                      (i.dateTimeString = c.dateTimeString),
                      (i.dateTimeObject = c.dateTimeObject));
                    let { lastProgramDateTime: h } = this;
                    ((this.lastProgramDateTime = new Date(
                      c.dateTimeString,
                    ).getTime()),
                      h === null &&
                        this.manifest.segments.reduceRight(
                          (f, p) => (
                            (p.programDateTime = f - p.duration * 1e3),
                            p.programDateTime
                          ),
                          this.lastProgramDateTime,
                        ));
                  },
                  targetduration() {
                    if (!isFinite(c.duration) || c.duration < 0) {
                      this.trigger("warn", {
                        message:
                          "ignoring invalid target duration: " + c.duration,
                      });
                      return;
                    }
                    ((this.manifest.targetDuration = c.duration),
                      vt.call(this, this.manifest));
                  },
                  start() {
                    if (!c.attributes || isNaN(c.attributes["TIME-OFFSET"])) {
                      this.trigger("warn", {
                        message:
                          "ignoring start declaration without appropriate attribute list",
                      });
                      return;
                    }
                    this.manifest.start = {
                      timeOffset: c.attributes["TIME-OFFSET"],
                      precise: c.attributes.PRECISE,
                    };
                  },
                  "cue-out"() {
                    i.cueOut = c.data;
                  },
                  "cue-out-cont"() {
                    i.cueOutCont = c.data;
                  },
                  "cue-in"() {
                    i.cueIn = c.data;
                  },
                  skip() {
                    ((this.manifest.skip = oe(c.attributes)),
                      this.warnOnMissingAttributes_(
                        "#EXT-X-SKIP",
                        c.attributes,
                        ["SKIPPED-SEGMENTS"],
                      ));
                  },
                  part() {
                    s = !0;
                    let h = this.manifest.segments.length,
                      f = oe(c.attributes);
                    ((i.parts = i.parts || []),
                      i.parts.push(f),
                      f.byterange &&
                        (f.byterange.hasOwnProperty("offset") ||
                          (f.byterange.offset = D),
                        (D = f.byterange.offset + f.byterange.length)));
                    let p = i.parts.length - 1;
                    (this.warnOnMissingAttributes_(
                      `#EXT-X-PART #${p} for segment #${h}`,
                      c.attributes,
                      ["URI", "DURATION"],
                    ),
                      this.manifest.renditionReports &&
                        this.manifest.renditionReports.forEach((A, y) => {
                          A.hasOwnProperty("lastPart") ||
                            this.trigger("warn", {
                              message: `#EXT-X-RENDITION-REPORT #${y} lacks required attribute(s): LAST-PART`,
                            });
                        }));
                  },
                  "server-control"() {
                    let h = (this.manifest.serverControl = oe(c.attributes));
                    (h.hasOwnProperty("canBlockReload") ||
                      ((h.canBlockReload = !1),
                      this.trigger("info", {
                        message:
                          "#EXT-X-SERVER-CONTROL defaulting CAN-BLOCK-RELOAD to false",
                      })),
                      vt.call(this, this.manifest),
                      h.canSkipDateranges &&
                        !h.hasOwnProperty("canSkipUntil") &&
                        this.trigger("warn", {
                          message:
                            "#EXT-X-SERVER-CONTROL lacks required attribute CAN-SKIP-UNTIL which is required when CAN-SKIP-DATERANGES is set",
                        }));
                  },
                  "preload-hint"() {
                    let h = this.manifest.segments.length,
                      f = oe(c.attributes),
                      p = f.type && f.type === "PART";
                    ((i.preloadHints = i.preloadHints || []),
                      i.preloadHints.push(f),
                      f.byterange &&
                        (f.byterange.hasOwnProperty("offset") ||
                          ((f.byterange.offset = p ? D : 0),
                          p && (D = f.byterange.offset + f.byterange.length))));
                    let A = i.preloadHints.length - 1;
                    if (
                      (this.warnOnMissingAttributes_(
                        `#EXT-X-PRELOAD-HINT #${A} for segment #${h}`,
                        c.attributes,
                        ["TYPE", "URI"],
                      ),
                      !!f.type)
                    )
                      for (let y = 0; y < i.preloadHints.length - 1; y++) {
                        let _ = i.preloadHints[y];
                        _.type &&
                          _.type === f.type &&
                          this.trigger("warn", {
                            message: `#EXT-X-PRELOAD-HINT #${A} for segment #${h} has the same TYPE ${f.type} as preload hint #${y}`,
                          });
                      }
                  },
                  "rendition-report"() {
                    let h = oe(c.attributes);
                    ((this.manifest.renditionReports =
                      this.manifest.renditionReports || []),
                      this.manifest.renditionReports.push(h));
                    let f = this.manifest.renditionReports.length - 1,
                      p = ["LAST-MSN", "URI"];
                    (s && p.push("LAST-PART"),
                      this.warnOnMissingAttributes_(
                        `#EXT-X-RENDITION-REPORT #${f}`,
                        c.attributes,
                        p,
                      ));
                  },
                  "part-inf"() {
                    ((this.manifest.partInf = oe(c.attributes)),
                      this.warnOnMissingAttributes_(
                        "#EXT-X-PART-INF",
                        c.attributes,
                        ["PART-TARGET"],
                      ),
                      this.manifest.partInf.partTarget &&
                        (this.manifest.partTargetDuration =
                          this.manifest.partInf.partTarget),
                      vt.call(this, this.manifest));
                  },
                  daterange() {
                    this.manifest.dateRanges.push(oe(c.attributes));
                    let h = this.manifest.dateRanges.length - 1;
                    this.warnOnMissingAttributes_(
                      `#EXT-X-DATERANGE #${h}`,
                      c.attributes,
                      ["ID", "START-DATE"],
                    );
                    let f = this.manifest.dateRanges[h];
                    (f.endDate &&
                      f.startDate &&
                      new Date(f.endDate) < new Date(f.startDate) &&
                      this.trigger("warn", {
                        message:
                          "EXT-X-DATERANGE END-DATE must be equal to or later than the value of the START-DATE",
                      }),
                      f.duration &&
                        f.duration < 0 &&
                        this.trigger("warn", {
                          message:
                            "EXT-X-DATERANGE DURATION must not be negative",
                        }),
                      f.plannedDuration &&
                        f.plannedDuration < 0 &&
                        this.trigger("warn", {
                          message:
                            "EXT-X-DATERANGE PLANNED-DURATION must not be negative",
                        }));
                    let p = !!f.endOnNext;
                    if (
                      (p &&
                        !f.class &&
                        this.trigger("warn", {
                          message:
                            "EXT-X-DATERANGE with an END-ON-NEXT=YES attribute must have a CLASS attribute",
                        }),
                      p &&
                        (f.duration || f.endDate) &&
                        this.trigger("warn", {
                          message:
                            "EXT-X-DATERANGE with an END-ON-NEXT=YES attribute must not contain DURATION or END-DATE attributes",
                        }),
                      f.duration && f.endDate)
                    ) {
                      let y = f.startDate.getTime() + f.duration * 1e3;
                      this.manifest.dateRanges[h].endDate = new Date(y);
                    }
                    if (!b[f.id]) b[f.id] = f;
                    else {
                      for (let y in b[f.id])
                        if (
                          f[y] &&
                          JSON.stringify(b[f.id][y]) !== JSON.stringify(f[y])
                        ) {
                          this.trigger("warn", {
                            message:
                              "EXT-X-DATERANGE tags with the same ID in a playlist must have the same attributes values",
                          });
                          break;
                        }
                      let A = this.manifest.dateRanges.findIndex(
                        (y) => y.id === f.id,
                      );
                      ((this.manifest.dateRanges[A] = ce(
                        this.manifest.dateRanges[A],
                        f,
                      )),
                        (b[f.id] = ce(b[f.id], f)),
                        this.manifest.dateRanges.pop());
                    }
                  },
                  "independent-segments"() {
                    this.manifest.independentSegments = !0;
                  },
                  "i-frames-only"() {
                    ((this.manifest.iFramesOnly = !0),
                      this.requiredCompatibilityversion(
                        this.manifest.version,
                        4,
                      ));
                  },
                  "content-steering"() {
                    ((this.manifest.contentSteering = oe(c.attributes)),
                      this.warnOnMissingAttributes_(
                        "#EXT-X-CONTENT-STEERING",
                        c.attributes,
                        ["SERVER-URI"],
                      ));
                  },
                  define() {
                    this.manifest.definitions = this.manifest.definitions || {};
                    let h = (f, p) => {
                      if (f in this.manifest.definitions) {
                        this.trigger("error", {
                          message: `EXT-X-DEFINE: Duplicate name ${f}`,
                        });
                        return;
                      }
                      this.manifest.definitions[f] = p;
                    };
                    if ("QUERYPARAM" in c.attributes) {
                      if ("NAME" in c.attributes || "IMPORT" in c.attributes) {
                        this.trigger("error", {
                          message: "EXT-X-DEFINE: Invalid attributes",
                        });
                        return;
                      }
                      let f = this.params.get(c.attributes.QUERYPARAM);
                      if (!f) {
                        this.trigger("error", {
                          message: `EXT-X-DEFINE: No query param ${c.attributes.QUERYPARAM}`,
                        });
                        return;
                      }
                      h(c.attributes.QUERYPARAM, decodeURIComponent(f));
                      return;
                    }
                    if ("NAME" in c.attributes) {
                      if ("IMPORT" in c.attributes) {
                        this.trigger("error", {
                          message: "EXT-X-DEFINE: Invalid attributes",
                        });
                        return;
                      }
                      if (
                        !("VALUE" in c.attributes) ||
                        typeof c.attributes.VALUE != "string"
                      ) {
                        this.trigger("error", {
                          message: `EXT-X-DEFINE: No value for ${c.attributes.NAME}`,
                        });
                        return;
                      }
                      h(c.attributes.NAME, c.attributes.VALUE);
                      return;
                    }
                    if ("IMPORT" in c.attributes) {
                      if (!this.mainDefinitions[c.attributes.IMPORT]) {
                        this.trigger("error", {
                          message: `EXT-X-DEFINE: No value ${c.attributes.IMPORT} to import, or IMPORT used on main playlist`,
                        });
                        return;
                      }
                      h(
                        c.attributes.IMPORT,
                        this.mainDefinitions[c.attributes.IMPORT],
                      );
                      return;
                    }
                    this.trigger("error", {
                      message: "EXT-X-DEFINE: No attribute",
                    });
                  },
                  "i-frame-playlist"() {
                    (this.manifest.iFramePlaylists.push({
                      attributes: c.attributes,
                      uri: c.uri,
                      timeline: d,
                    }),
                      this.warnOnMissingAttributes_(
                        "#EXT-X-I-FRAME-STREAM-INF",
                        c.attributes,
                        ["BANDWIDTH", "URI"],
                      ));
                  },
                })[c.tagType] || l
              ).call(r);
            },
            uri() {
              ((i.uri = c.uri),
                n.push(i),
                this.manifest.targetDuration &&
                  !("duration" in i) &&
                  (this.trigger("warn", {
                    message:
                      "defaulting segment duration to the target duration",
                  }),
                  (i.duration = this.manifest.targetDuration)),
                u && (i.key = u),
                (i.timeline = d),
                a && (i.map = a),
                (D = 0),
                this.lastProgramDateTime !== null &&
                  ((i.programDateTime = this.lastProgramDateTime),
                  (this.lastProgramDateTime += i.duration * 1e3)),
                (i = {}));
            },
            comment() {},
            custom() {
              c.segment
                ? ((i.custom = i.custom || {}),
                  (i.custom[c.customType] = c.data))
                : ((this.manifest.custom = this.manifest.custom || {}),
                  (this.manifest.custom[c.customType] = c.data));
            },
          })[c.type].call(r);
        }));
    }
    requiredCompatibilityversion(t, r) {
      (t < r || !t) &&
        this.trigger("warn", {
          message: `manifest must be at least version ${r}`,
        });
    }
    warnOnMissingAttributes_(t, r, n) {
      let i = [];
      (n.forEach(function (a) {
        r.hasOwnProperty(a) || i.push(a);
      }),
        i.length &&
          this.trigger("warn", {
            message: `${t} lacks required attribute(s): ${i.join(", ")}`,
          }));
    }
    push(t) {
      this.lineStream.push(t);
    }
    end() {
      (this.lineStream.push(`
`),
        this.manifest.dateRanges.length &&
          this.lastProgramDateTime === null &&
          this.trigger("warn", {
            message:
              "A playlist with EXT-X-DATERANGE tag must contain atleast one EXT-X-PROGRAM-DATE-TIME tag",
          }),
        (this.lastProgramDateTime = null),
        this.trigger("end"));
    }
    addParser(t) {
      this.parseStream.addParser(t);
    }
    addTagMapper(t) {
      this.parseStream.addTagMapper(t);
    }
  };
var zn = new Set([
  "com.microsoft.playready",
  "com.apple.streamingkeydelivery",
  "com.widevine.alpha",
]);
function rt(e) {
  return Object.keys(e).some((t) => zn.has(t));
}
var Jt = [
    "am",
    "ar",
    "ar-EG",
    "ar-SA",
    "ar-MA",
    "ha",
    "he",
    "mt",
    "om",
    "so",
    "ti",
    "ceb",
    "fil",
    "id",
    "jv",
    "mg",
    "mi",
    "ms",
    "haw",
    "sm",
    "su",
    "to",
    "kn",
    "ml",
    "ta",
    "te",
    "af",
    "da",
    "de",
    "de-AT",
    "de-CH",
    "en",
    "en-AU",
    "en-CA",
    "en-GB",
    "en-IE",
    "en-IN",
    "en-NZ",
    "en-US",
    "en-ZA",
    "fy",
    "is",
    "lb",
    "nb",
    "nl",
    "nl-BE",
    "nn",
    "sv",
    "yi",
    "as",
    "bn",
    "bn-IN",
    "fa",
    "fa-AF",
    "gu",
    "hi",
    "ks",
    "ku",
    "mr",
    "ne",
    "or",
    "pa",
    "ps",
    "sd",
    "si",
    "tg",
    "ur",
    "ca",
    "co",
    "es",
    "es-419",
    "es-PE",
    "es-CR",
    "es-HN",
    "es-AR",
    "es-CL",
    "es-CO",
    "es-ES",
    "es-MX",
    "fr",
    "fr-BE",
    "fr-CA",
    "fr-CH",
    "gl",
    "ht",
    "it",
    "it-CH",
    "oc",
    "pt",
    "pt-BR",
    "pt-PT",
    "rm",
    "ro",
    "sc",
    "wa",
    "br",
    "cy",
    "ga",
    "gd",
    "gv",
    "kw",
    "be",
    "bg",
    "bs",
    "cs",
    "hr",
    "mk",
    "pl",
    "ru",
    "sk",
    "sl",
    "sr-Cyrl",
    "sr-Latn",
    "uk",
    "lt",
    "lv",
    "et",
    "fi",
    "hu",
    "se",
    "az",
    "az-Latn",
    "az-Cyrl",
    "ba",
    "cv",
    "kk",
    "ky",
    "tk",
    "tr",
    "tt",
    "ug",
    "uz",
    "uz-Latn",
    "uz-Cyrl",
    "mn",
    "mn-Cyrl",
    "mn-Mong",
    "bo",
    "dz",
    "my",
    "yue",
    "zh",
    "zh-Hans",
    "zh-CN",
    "zh-SG",
    "zh-Hant",
    "zh-HK",
    "zh-TW",
    "ja",
    "ko",
    "km",
    "lo",
    "th",
    "vi",
    "hy",
    "ka",
    "ak",
    "ee",
    "ig",
    "kg",
    "ki",
    "ln",
    "lg",
    "nd",
    "ny",
    "rn",
    "rw",
    "sn",
    "st",
    "sw",
    "tn",
    "ts",
    "tw",
    "wo",
    "xh",
    "yo",
    "zu",
    "lu",
    "el",
    "sq",
    "eu",
    "ay",
    "gn",
    "nv",
    "qu",
    "mul",
  ],
  Au = new Set(Jt);
function er(e, t, r) {
  let n = new Map();
  for (let a of e) n.set(r(a), a);
  let i;
  for (let a of t) if (((i = n.get(a)), i)) return x(i);
  for (let a of t) {
    let u = a.split("-")[0];
    if (!u) continue;
    let s = n.get(u);
    if (s) return x(s);
    for (let [l, o] of n) if (l.split("-")[0] === u) return x(o);
  }
  return S;
}
var Du = (() => {
  let e = (t) => {
    try {
      return (
        new Intl.DisplayNames([navigator.language], {
          type: "language",
          fallback: "none",
        }).of(t) ?? t
      );
    } catch {
      return t;
    }
  };
  return new Map(
    Jt.map((t) => ({ code: t, native_name: e(t) }))
      .sort((t, r) => t.native_name.localeCompare(r.native_name))
      .map((t) => [t.code, t]),
  );
})();
function Gn(e) {
  let t;
  try {
    let i = new Re();
    (i.push(e), i.end(), (t = i.manifest));
  } catch {}
  if (!t) return M("parse error");
  let r = t.segments;
  return !Array.isArray(r) || r.length == 0
    ? M("not a valid m3u8")
    : r.every((i) => {
          let u = i.uri.split(/[?#]/)[0];
          return u
            ? u
                .substring(u.lastIndexOf(".") + 1)
                .toLowerCase()
                .match(/vtt|srt|webvtt|ttml/)
            : !1;
        })
      ? M("subtitle playlist")
      : G(t);
}
function Hn(e) {
  let t = new Date(new Date().getTime() - 6e5);
  return !e.dateTimeObject && !e.programDateTime
    ? !1
    : typeof e.dateTimeObject == "object"
      ? e.dateTimeObject > t
      : typeof e.programDateTime == "number"
        ? e.programDateTime > t.getTime()
        : !1;
}
function Xn(e) {
  if (
    !Array.isArray(e.segments) ||
    e.segments.some((n) => typeof n.duration != "number")
  )
    return "unknown";
  let t = e.segments[e.segments.length - 1];
  return t && Hn(t)
    ? "live"
    : e.segments.reduce(
        (n, i) => (typeof i.duration == "number" && (n += i.duration), n),
        0,
      );
}
function tr(e, t, r, n = !1, i = !1) {
  let a;
  try {
    let o = new Re();
    (o.push(e), o.end(), (a = o.manifest));
  } catch {}
  if (!a) return M("parse error");
  if (!a.playlists) return M("Not a master M3U8");
  let u = a.playlists,
    s = a.mediaGroups.AUDIO ?? {},
    l = [];
  for (let o of u) {
    if (typeof o.uri != "string") continue;
    let m = "mp4";
    if (o.attributes.CODECS) {
      let T = Qe(o.attributes.CODECS);
      if (T.isNone()) continue;
      m = T.value;
    }
    if (
      (!("FRAME-RATE" in o.attributes) && "RESOLUTION" in o.attributes,
      o.attributes["VIDEO-RANGE"] && o.attributes["VIDEO-RANGE"] == "PQ")
    )
      continue;
    let d = K(o.uri, t.href);
    if (d.isNone()) continue;
    let g = S;
    if (o.attributes.AUDIO) {
      let T = s[o.attributes.AUDIO];
      if (T) {
        if (r.isSome()) {
          let h = er(Object.values(T), r.value, (f) => f.language ?? "");
          if (h.isSome()) g = K(h.value.uri, t.href);
          else {
            let f = Object.values(T).find((p) => p.default);
            g = f ? K(f.uri, t.href) : S;
          }
        } else
          for (let h of Object.values(T))
            if ((h.uri && (g = K(h.uri, t.href)), h.default)) break;
      }
    }
    let D = S,
      b = S;
    (o.attributes.RESOLUTION &&
      (D = x({
        height: o.attributes.RESOLUTION.height,
        width: o.attributes.RESOLUTION.width,
      })),
      o.attributes.BANDWIDTH && (b = x(o.attributes.BANDWIDTH)));
    let c = { size: D, bitrate: b },
      v = d.value;
    if (
      (n
        ? (v.search = Et(v.searchParams, t.searchParams))
        : i && (v.search = ""),
      g.isSome())
    ) {
      let T = g.value;
      (n
        ? (T.search = Et(v.searchParams, t.searchParams))
        : i && (T.search = ""),
        l.push({ demuxer: m, quality: c, av: { video: v, audio: T } }));
    } else l.push({ demuxer: m, quality: c, av: { video: v, audio: !1 } });
  }
  return ((l = Ze(l)), Je(l) ? G(l) : M("Empty playlist"));
}
async function rr(e) {
  let t = e[0].av.video || e[0].av.audio;
  try {
    let n = await (await fetch(t, { signal: AbortSignal.timeout(5e3) })).text(),
      i = Gn(n);
    if (i.isOk()) {
      let a = Xn(i.value),
        u = $n(i.value);
      return { duration: a, has_drm: u };
    }
  } catch {
    console.warn(
      "request timeout while calculating duration & checking for DRM",
    );
  }
  return { duration: "unknown", has_drm: !1 };
}
function $n(e) {
  return e.contentProtection ? rt(e.contentProtection) : !1;
}
function St(e, t = 0) {
  let r = 3735928559 ^ t,
    n = 1103547991 ^ t;
  for (let i = 0, a; i < e.length; i++)
    ((a = e.charCodeAt(i)),
      (r = Math.imul(r ^ a, 2654435761)),
      (n = Math.imul(n ^ a, 1597334677)));
  return (
    (r = Math.imul(r ^ (r >>> 16), 2246822507)),
    (r ^= Math.imul(n ^ (n >>> 13), 3266489909)),
    (n = Math.imul(n ^ (n >>> 16), 2246822507)),
    (n ^= Math.imul(r ^ (r >>> 13), 3266489909)),
    4294967296 * (2097151 & n) + (r >>> 0)
  );
}
var ar = we(ir(), 1);
var Pu = new BroadcastChannel("worker_service");
var xt = {
  FromInjectedToService: 0,
  FromContentToService: 1,
  FromServiceToWorker: 2,
  FromWorkerToService: 3,
  FromUntrustedInjectedToTrusted: 4,
  FromTrustedInjectedToUntrusted: 5,
  FromServiceToContent: 6,
  FromServiceToInjected: 7,
  FromServiceToService: 8,
};
async function Wn(e, t) {
  await ar.default.runtime.sendMessage({ msg: e, channel: t });
}
function ur(e) {
  let t = xt.FromInjectedToService;
  Wn(e, t);
}
var pe = we(tt()),
  sr = "https://example.com",
  jn = function (t, r) {
    if (/^[a-z]+:/i.test(r)) return r;
    /^data:/.test(t) &&
      (t = (pe.default.location && pe.default.location.href) || "");
    var n = /^\/\//.test(t),
      i = !pe.default.location && !/\/\//i.test(t);
    t = new pe.default.URL(t, pe.default.location || sr);
    var a = new URL(r, t);
    return i
      ? a.href.slice(sr.length)
      : n
        ? a.href.slice(a.protocol.length)
        : a.href;
  },
  nt = jn;
var X = we(tt());
var or = function (t, r, n) {
  r.forEach(function (i) {
    for (var a in t.mediaGroups[i])
      for (var u in t.mediaGroups[i][a]) {
        var s = t.mediaGroups[i][a][u];
        n(s, i, a, u);
      }
  });
};
var ln = we(en());
var tn = (e) => !!e && typeof e == "object",
  q = (...e) =>
    e.reduce(
      (t, r) => (
        typeof r != "object" ||
          Object.keys(r).forEach((n) => {
            Array.isArray(t[n]) && Array.isArray(r[n])
              ? (t[n] = t[n].concat(r[n]))
              : tn(t[n]) && tn(r[n])
                ? (t[n] = q(t[n], r[n]))
                : (t[n] = r[n]);
          }),
        t
      ),
      {},
    ),
  cn = (e) => Object.keys(e).map((t) => e[t]),
  Si = (e, t) => {
    let r = [];
    for (let n = e; n < t; n++) r.push(n);
    return r;
  },
  _e = (e) => e.reduce((t, r) => t.concat(r), []),
  mn = (e) => {
    if (!e.length) return [];
    let t = [];
    for (let r = 0; r < e.length; r++) t.push(e[r]);
    return t;
  },
  wi = (e, t) => e.reduce((r, n, i) => (n[t] && r.push(i), r), []),
  xi = (e, t) =>
    cn(
      e.reduce(
        (r, n) => (
          n.forEach((i) => {
            r[t(i)] = i;
          }),
          r
        ),
        {},
      ),
    ),
  He = {
    INVALID_NUMBER_OF_PERIOD: "INVALID_NUMBER_OF_PERIOD",
    INVALID_NUMBER_OF_CONTENT_STEERING: "INVALID_NUMBER_OF_CONTENT_STEERING",
    DASH_EMPTY_MANIFEST: "DASH_EMPTY_MANIFEST",
    DASH_INVALID_XML: "DASH_INVALID_XML",
    NO_BASE_URL: "NO_BASE_URL",
    MISSING_SEGMENT_INFORMATION: "MISSING_SEGMENT_INFORMATION",
    SEGMENT_TIME_UNSPECIFIED: "SEGMENT_TIME_UNSPECIFIED",
    UNSUPPORTED_UTC_TIMING_SCHEME: "UNSUPPORTED_UTC_TIMING_SCHEME",
  },
  Xe = ({
    baseUrl: e = "",
    source: t = "",
    range: r = "",
    indexRange: n = "",
  }) => {
    let i = { uri: t, resolvedUri: nt(e || "", t) };
    if (r || n) {
      let u = (r || n).split("-"),
        s = X.default.BigInt ? X.default.BigInt(u[0]) : parseInt(u[0], 10),
        l = X.default.BigInt ? X.default.BigInt(u[1]) : parseInt(u[1], 10);
      (s < Number.MAX_SAFE_INTEGER && typeof s == "bigint" && (s = Number(s)),
        l < Number.MAX_SAFE_INTEGER && typeof l == "bigint" && (l = Number(l)));
      let o;
      (typeof l == "bigint" || typeof s == "bigint"
        ? (o = X.default.BigInt(l) - X.default.BigInt(s) + X.default.BigInt(1))
        : (o = l - s + 1),
        typeof o == "bigint" && o < Number.MAX_SAFE_INTEGER && (o = Number(o)),
        (i.byterange = { length: o, offset: s }));
    }
    return i;
  },
  Ci = (e) => {
    let t;
    return (
      typeof e.offset == "bigint" || typeof e.length == "bigint"
        ? (t =
            X.default.BigInt(e.offset) +
            X.default.BigInt(e.length) -
            X.default.BigInt(1))
        : (t = e.offset + e.length - 1),
      `${e.offset}-${t}`
    );
  },
  rn = (e) => (
    e && typeof e != "number" && (e = parseInt(e, 10)),
    isNaN(e) ? null : e
  ),
  Ni = {
    static(e) {
      let {
          duration: t,
          timescale: r = 1,
          sourceDuration: n,
          periodDuration: i,
        } = e,
        a = rn(e.endNumber),
        u = t / r;
      return typeof a == "number"
        ? { start: 0, end: a }
        : typeof i == "number"
          ? { start: 0, end: i / u }
          : { start: 0, end: n / u };
    },
    dynamic(e) {
      let {
          NOW: t,
          clientOffset: r,
          availabilityStartTime: n,
          timescale: i = 1,
          duration: a,
          periodStart: u = 0,
          minimumUpdatePeriod: s = 0,
          timeShiftBufferDepth: l = 1 / 0,
        } = e,
        o = rn(e.endNumber),
        m = (t + r) / 1e3,
        d = n + u,
        D = m + s - d,
        b = Math.ceil((D * i) / a),
        c = Math.floor(((m - d - l) * i) / a),
        v = Math.floor(((m - d) * i) / a);
      return {
        start: Math.max(0, c),
        end: typeof o == "number" ? o : Math.min(b, v),
      };
    },
  },
  Ii = (e) => (t) => {
    let {
      duration: r,
      timescale: n = 1,
      periodStart: i,
      startNumber: a = 1,
    } = e;
    return { number: a + t, duration: r / n, timeline: i, time: t * r };
  },
  Xt = (e) => {
    let {
        type: t,
        duration: r,
        timescale: n = 1,
        periodDuration: i,
        sourceDuration: a,
      } = e,
      { start: u, end: s } = Ni[t](e),
      l = Si(u, s).map(Ii(e));
    if (t === "static") {
      let o = l.length - 1,
        m = typeof i == "number" ? i : a;
      l[o].duration = m - (r / n) * o;
    }
    return l;
  },
  fn = (e) => {
    let {
      baseUrl: t,
      initialization: r = {},
      sourceDuration: n,
      indexRange: i = "",
      periodStart: a,
      presentationTime: u,
      number: s = 0,
      duration: l,
    } = e;
    if (!t) throw new Error(He.NO_BASE_URL);
    let o = Xe({ baseUrl: t, source: r.sourceURL, range: r.range }),
      m = Xe({ baseUrl: t, source: t, indexRange: i });
    if (((m.map = o), l)) {
      let d = Xt(e);
      d.length && ((m.duration = d[0].duration), (m.timeline = d[0].timeline));
    } else n && ((m.duration = n), (m.timeline = a));
    return ((m.presentationTime = u || a), (m.number = s), [m]);
  },
  Ri = (e, t, r) => {
    let n = e.sidx.map ? e.sidx.map : null,
      i = e.sidx.duration,
      a = e.timeline || 0,
      u = e.sidx.byterange,
      s = u.offset + u.length,
      l = t.timescale,
      o = t.references.filter((v) => v.referenceType !== 1),
      m = [],
      d = e.endList ? "static" : "dynamic",
      g = e.sidx.timeline,
      D = g,
      b = e.mediaSequence || 0,
      c;
    typeof t.firstOffset == "bigint"
      ? (c = X.default.BigInt(s) + t.firstOffset)
      : (c = s + t.firstOffset);
    for (let v = 0; v < o.length; v++) {
      let T = t.references[v],
        h = T.referencedSize,
        f = T.subsegmentDuration,
        p;
      typeof c == "bigint"
        ? (p = c + X.default.BigInt(h) - X.default.BigInt(1))
        : (p = c + h - 1);
      let A = `${c}-${p}`,
        _ = fn({
          baseUrl: r,
          timescale: l,
          timeline: a,
          periodStart: g,
          presentationTime: D,
          number: b,
          duration: f,
          sourceDuration: i,
          indexRange: A,
          type: d,
        })[0];
      (n && (_.map = n),
        m.push(_),
        typeof c == "bigint" ? (c += X.default.BigInt(h)) : (c += h),
        (D += f / l),
        b++);
    }
    return ((e.segments = m), e);
  },
  Oi = ["AUDIO", "SUBTITLES"],
  Mi = 1 / 60,
  pn = (e) =>
    xi(e, ({ timeline: t }) => t).sort((t, r) =>
      t.timeline > r.timeline ? 1 : -1,
    ),
  Bi = (e, t) => {
    for (let r = 0; r < e.length; r++)
      if (e[r].attributes.NAME === t) return e[r];
    return null;
  },
  nn = (e) => {
    let t = [];
    return (
      or(e, Oi, (r, n, i, a) => {
        t = t.concat(r.playlists || []);
      }),
      t
    );
  },
  an = ({ playlist: e, mediaSequence: t }) => {
    ((e.mediaSequence = t),
      e.segments.forEach((r, n) => {
        r.number = e.mediaSequence + n;
      }));
  },
  Fi = ({ oldPlaylists: e, newPlaylists: t, timelineStarts: r }) => {
    t.forEach((n) => {
      n.discontinuitySequence = r.findIndex(function ({ timeline: l }) {
        return l === n.timeline;
      });
      let i = Bi(e, n.attributes.NAME);
      if (!i || n.sidx) return;
      let a = n.segments[0],
        u = i.segments.findIndex(function (l) {
          return Math.abs(l.presentationTime - a.presentationTime) < Mi;
        });
      if (u === -1) {
        (an({
          playlist: n,
          mediaSequence: i.mediaSequence + i.segments.length,
        }),
          (n.segments[0].discontinuity = !0),
          n.discontinuityStarts.unshift(0),
          ((!i.segments.length && n.timeline > i.timeline) ||
            (i.segments.length &&
              n.timeline > i.segments[i.segments.length - 1].timeline)) &&
            n.discontinuitySequence--);
        return;
      }
      (i.segments[u].discontinuity &&
        !a.discontinuity &&
        ((a.discontinuity = !0),
        n.discontinuityStarts.unshift(0),
        n.discontinuitySequence--),
        an({ playlist: n, mediaSequence: i.segments[u].number }));
    });
  },
  Pi = ({ oldManifest: e, newManifest: t }) => {
    let r = e.playlists.concat(nn(e)),
      n = t.playlists.concat(nn(t));
    return (
      (t.timelineStarts = pn([e.timelineStarts, t.timelineStarts])),
      Fi({
        oldPlaylists: r,
        newPlaylists: n,
        timelineStarts: t.timelineStarts,
      }),
      t
    );
  },
  Li = (e) => e && e.uri + "-" + Ci(e.byterange),
  Ht = (e) => {
    let t = e.reduce(function (n, i) {
        return (
          n[i.attributes.baseUrl] || (n[i.attributes.baseUrl] = []),
          n[i.attributes.baseUrl].push(i),
          n
        );
      }, {}),
      r = [];
    return (
      Object.values(t).forEach((n) => {
        let i = cn(
          n.reduce((a, u) => {
            let s = u.attributes.id + (u.attributes.lang || "");
            return (
              a[s]
                ? (u.segments &&
                    (u.segments[0] && (u.segments[0].discontinuity = !0),
                    a[s].segments.push(...u.segments)),
                  u.attributes.contentProtection &&
                    (a[s].attributes.contentProtection =
                      u.attributes.contentProtection))
                : ((a[s] = u), (a[s].attributes.timelineStarts = [])),
              a[s].attributes.timelineStarts.push({
                start: u.attributes.periodStart,
                timeline: u.attributes.periodStart,
              }),
              a
            );
          }, {}),
        );
        r = r.concat(i);
      }),
      r.map(
        (n) => (
          (n.discontinuityStarts = wi(n.segments || [], "discontinuity")),
          n
        ),
      )
    );
  },
  $t = (e, t) => {
    let r = Li(e.sidx),
      n = r && t[r] && t[r].sidx;
    return (n && Ri(e, n, e.sidx.resolvedUri), e);
  },
  Ui = (e, t = {}) => {
    if (!Object.keys(t).length) return e;
    for (let r in e) e[r] = $t(e[r], t);
    return e;
  },
  ki = (
    {
      attributes: e,
      segments: t,
      sidx: r,
      mediaSequence: n,
      discontinuitySequence: i,
      discontinuityStarts: a,
    },
    u,
  ) => {
    let s = {
      attributes: {
        NAME: e.id,
        BANDWIDTH: e.bandwidth,
        CODECS: e.codecs,
        "PROGRAM-ID": 1,
      },
      uri: "",
      endList: e.type === "static",
      timeline: e.periodStart,
      resolvedUri: e.baseUrl || "",
      targetDuration: e.duration,
      discontinuitySequence: i,
      discontinuityStarts: a,
      timelineStarts: e.timelineStarts,
      mediaSequence: n,
      segments: t,
    };
    return (
      e.contentProtection && (s.contentProtection = e.contentProtection),
      e.serviceLocation && (s.attributes.serviceLocation = e.serviceLocation),
      r && (s.sidx = r),
      u && ((s.attributes.AUDIO = "audio"), (s.attributes.SUBTITLES = "subs")),
      s
    );
  },
  qi = ({
    attributes: e,
    segments: t,
    mediaSequence: r,
    discontinuityStarts: n,
    discontinuitySequence: i,
  }) => {
    typeof t > "u" &&
      ((t = [
        {
          uri: e.baseUrl,
          timeline: e.periodStart,
          resolvedUri: e.baseUrl || "",
          duration: e.sourceDuration,
          number: 0,
        },
      ]),
      (e.duration = e.sourceDuration));
    let a = { NAME: e.id, BANDWIDTH: e.bandwidth, "PROGRAM-ID": 1 };
    e.codecs && (a.CODECS = e.codecs);
    let u = {
      attributes: a,
      uri: "",
      endList: e.type === "static",
      timeline: e.periodStart,
      resolvedUri: e.baseUrl || "",
      targetDuration: e.duration,
      timelineStarts: e.timelineStarts,
      discontinuityStarts: n,
      discontinuitySequence: i,
      mediaSequence: r,
      segments: t,
    };
    return (
      e.serviceLocation && (u.attributes.serviceLocation = e.serviceLocation),
      u
    );
  },
  Vi = (e, t = {}, r = !1) => {
    let n,
      i = e.reduce((a, u) => {
        let s = (u.attributes.role && u.attributes.role.value) || "",
          l = u.attributes.lang || "",
          o = u.attributes.label || "main";
        if (l && !u.attributes.label) {
          let d = s ? ` (${s})` : "";
          o = `${u.attributes.lang}${d}`;
        }
        a[o] ||
          (a[o] = {
            language: l,
            autoselect: !0,
            default: s === "main",
            playlists: [],
            uri: "",
          });
        let m = $t(ki(u, r), t);
        return (
          a[o].playlists.push(m),
          typeof n > "u" && s === "main" && ((n = u), (n.default = !0)),
          a
        );
      }, {});
    if (!n) {
      let a = Object.keys(i)[0];
      i[a].default = !0;
    }
    return i;
  },
  zi = (e, t = {}) =>
    e.reduce((r, n) => {
      let i = n.attributes.label || n.attributes.lang || "text",
        a = n.attributes.lang || "und";
      return (
        r[i] ||
          (r[i] = {
            language: a,
            default: !1,
            autoselect: !1,
            playlists: [],
            uri: "",
          }),
        r[i].playlists.push($t(qi(n), t)),
        r
      );
    }, {}),
  Gi = (e) =>
    e.reduce(
      (t, r) => (
        r &&
          r.forEach((n) => {
            let { channel: i, language: a } = n;
            ((t[a] = {
              autoselect: !1,
              default: !1,
              instreamId: i,
              language: a,
            }),
              n.hasOwnProperty("aspectRatio") &&
                (t[a].aspectRatio = n.aspectRatio),
              n.hasOwnProperty("easyReader") &&
                (t[a].easyReader = n.easyReader),
              n.hasOwnProperty("3D") && (t[a]["3D"] = n["3D"]));
          }),
        t
      ),
      {},
    ),
  Hi = ({ attributes: e, segments: t, sidx: r, discontinuityStarts: n }) => {
    let i = {
      attributes: {
        NAME: e.id,
        AUDIO: "audio",
        SUBTITLES: "subs",
        RESOLUTION: { width: e.width, height: e.height },
        CODECS: e.codecs,
        BANDWIDTH: e.bandwidth,
        "PROGRAM-ID": 1,
      },
      uri: "",
      endList: e.type === "static",
      timeline: e.periodStart,
      resolvedUri: e.baseUrl || "",
      targetDuration: e.duration,
      discontinuityStarts: n,
      timelineStarts: e.timelineStarts,
      segments: t,
    };
    return (
      e.frameRate && (i.attributes["FRAME-RATE"] = e.frameRate),
      e.contentProtection && (i.contentProtection = e.contentProtection),
      e.serviceLocation && (i.attributes.serviceLocation = e.serviceLocation),
      r && (i.sidx = r),
      i
    );
  },
  Xi = ({ attributes: e }) =>
    e.mimeType === "video/mp4" ||
    e.mimeType === "video/webm" ||
    e.contentType === "video",
  $i = ({ attributes: e }) =>
    e.mimeType === "audio/mp4" ||
    e.mimeType === "audio/webm" ||
    e.contentType === "audio",
  Wi = ({ attributes: e }) =>
    e.mimeType === "text/vtt" || e.contentType === "text",
  Yi = (e, t) => {
    e.forEach((r) => {
      ((r.mediaSequence = 0),
        (r.discontinuitySequence = t.findIndex(function ({ timeline: n }) {
          return n === r.timeline;
        })),
        r.segments &&
          r.segments.forEach((n, i) => {
            n.number = i;
          }));
    });
  },
  un = (e) =>
    e
      ? Object.keys(e).reduce((t, r) => {
          let n = e[r];
          return t.concat(n.playlists);
        }, [])
      : [],
  ji = ({
    dashPlaylists: e,
    locations: t,
    contentSteering: r,
    sidxMapping: n = {},
    previousManifest: i,
    eventStream: a,
  }) => {
    if (!e.length) return {};
    let {
        sourceDuration: u,
        type: s,
        suggestedPresentationDelay: l,
        minimumUpdatePeriod: o,
      } = e[0].attributes,
      m = Ht(e.filter(Xi)).map(Hi),
      d = Ht(e.filter($i)),
      g = Ht(e.filter(Wi)),
      D = e.map((p) => p.attributes.captionServices).filter(Boolean),
      b = {
        allowCache: !0,
        discontinuityStarts: [],
        segments: [],
        endList: !0,
        mediaGroups: {
          AUDIO: {},
          VIDEO: {},
          "CLOSED-CAPTIONS": {},
          SUBTITLES: {},
        },
        uri: "",
        duration: u,
        playlists: Ui(m, n),
      };
    (o >= 0 && (b.minimumUpdatePeriod = o * 1e3),
      t && (b.locations = t),
      r && (b.contentSteering = r),
      s === "dynamic" && (b.suggestedPresentationDelay = l),
      a && a.length > 0 && (b.eventStream = a));
    let c = b.playlists.length === 0,
      v = d.length ? Vi(d, n, c) : null,
      T = g.length ? zi(g, n) : null,
      h = m.concat(un(v), un(T)),
      f = h.map(({ timelineStarts: p }) => p);
    return (
      (b.timelineStarts = pn(f)),
      Yi(h, b.timelineStarts),
      v && (b.mediaGroups.AUDIO.audio = v),
      T && (b.mediaGroups.SUBTITLES.subs = T),
      D.length && (b.mediaGroups["CLOSED-CAPTIONS"].cc = Gi(D)),
      i ? Pi({ oldManifest: i, newManifest: b }) : b
    );
  },
  Ki = (e, t, r) => {
    let {
        NOW: n,
        clientOffset: i,
        availabilityStartTime: a,
        timescale: u = 1,
        periodStart: s = 0,
        minimumUpdatePeriod: l = 0,
      } = e,
      o = (n + i) / 1e3,
      m = a + s,
      g = o + l - m;
    return Math.ceil((g * u - t) / r);
  },
  dn = (e, t) => {
    let {
        type: r,
        minimumUpdatePeriod: n = 0,
        media: i = "",
        sourceDuration: a,
        timescale: u = 1,
        startNumber: s = 1,
        periodStart: l,
      } = e,
      o = [],
      m = -1;
    for (let d = 0; d < t.length; d++) {
      let g = t[d],
        D = g.d,
        b = g.r || 0,
        c = g.t || 0;
      (m < 0 && (m = c), c && c > m && (m = c));
      let v;
      if (b < 0) {
        let f = d + 1;
        f === t.length
          ? r === "dynamic" && n > 0 && i.indexOf("$Number$") > 0
            ? (v = Ki(e, m, D))
            : (v = (a * u - m) / D)
          : (v = (t[f].t - m) / D);
      } else v = b + 1;
      let T = s + o.length + v,
        h = s + o.length;
      for (; h < T;)
        (o.push({ number: h, duration: D / u, time: m, timeline: l }),
          (m += D),
          h++);
    }
    return o;
  },
  Qi = /\$([A-z]*)(?:(%0)([0-9]+)d)?\$/g,
  Zi = (e) => (t, r, n, i) => {
    if (t === "$$") return "$";
    if (typeof e[r] > "u") return t;
    let a = "" + e[r];
    return r === "RepresentationID" ||
      (n ? (i = parseInt(i, 10)) : (i = 1), a.length >= i)
      ? a
      : `${new Array(i - a.length + 1).join("0")}${a}`;
  },
  sn = (e, t) => e.replace(Qi, Zi(t)),
  Ji = (e, t) =>
    !e.duration && !t
      ? [
          {
            number: e.startNumber || 1,
            duration: e.sourceDuration,
            time: 0,
            timeline: e.periodStart,
          },
        ]
      : e.duration
        ? Xt(e)
        : dn(e, t),
  ea = (e, t) => {
    let r = { RepresentationID: e.id, Bandwidth: e.bandwidth || 0 },
      { initialization: n = { sourceURL: "", range: "" } } = e,
      i = Xe({
        baseUrl: e.baseUrl,
        source: sn(n.sourceURL, r),
        range: n.range,
      });
    return Ji(e, t).map((u) => {
      ((r.Number = u.number), (r.Time = u.time));
      let s = sn(e.media || "", r),
        l = e.timescale || 1,
        o = e.presentationTimeOffset || 0,
        m = e.periodStart + (u.time - o) / l;
      return {
        uri: s,
        timeline: u.timeline,
        duration: u.duration,
        resolvedUri: nt(e.baseUrl || "", s),
        map: i,
        number: u.number,
        presentationTime: m,
      };
    });
  },
  ta = (e, t) => {
    let { baseUrl: r, initialization: n = {} } = e,
      i = Xe({ baseUrl: r, source: n.sourceURL, range: n.range }),
      a = Xe({ baseUrl: r, source: t.media, range: t.mediaRange });
    return ((a.map = i), a);
  },
  ra = (e, t) => {
    let { duration: r, segmentUrls: n = [], periodStart: i } = e;
    if ((!r && !t) || (r && t)) throw new Error(He.SEGMENT_TIME_UNSPECIFIED);
    let a = n.map((l) => ta(e, l)),
      u;
    return (
      r && (u = Xt(e)),
      t && (u = dn(e, t)),
      u
        .map((l, o) => {
          if (a[o]) {
            let m = a[o],
              d = e.timescale || 1,
              g = e.presentationTimeOffset || 0;
            return (
              (m.timeline = l.timeline),
              (m.duration = l.duration),
              (m.number = l.number),
              (m.presentationTime = i + (l.time - g) / d),
              m
            );
          }
        })
        .filter((l) => l)
    );
  },
  na = ({ attributes: e, segmentInfo: t }) => {
    let r, n;
    t.template
      ? ((n = ea), (r = q(e, t.template)))
      : t.base
        ? ((n = fn), (r = q(e, t.base)))
        : t.list && ((n = ra), (r = q(e, t.list)));
    let i = { attributes: e };
    if (!n) return i;
    let a = n(r, t.segmentTimeline);
    if (r.duration) {
      let { duration: u, timescale: s = 1 } = r;
      r.duration = u / s;
    } else
      a.length
        ? (r.duration = a.reduce(
            (u, s) => Math.max(u, Math.ceil(s.duration)),
            0,
          ))
        : (r.duration = 0);
    return (
      (i.attributes = r),
      (i.segments = a),
      t.base && r.indexRange && ((i.sidx = a[0]), (i.segments = [])),
      i
    );
  },
  ia = (e) => e.map(na),
  O = (e, t) => mn(e.childNodes).filter(({ tagName: r }) => r === t),
  $e = (e) => e.textContent.trim(),
  aa = (e) => parseFloat(e.split("/").reduce((t, r) => t / r)),
  Te = (e) => {
    let s =
      /P(?:(\d*)Y)?(?:(\d*)M)?(?:(\d*)D)?(?:T(?:(\d*)H)?(?:(\d*)M)?(?:([\d.]*)S)?)?/.exec(
        e,
      );
    if (!s) return 0;
    let [l, o, m, d, g, D] = s.slice(1);
    return (
      parseFloat(l || 0) * 31536e3 +
      parseFloat(o || 0) * 2592e3 +
      parseFloat(m || 0) * 86400 +
      parseFloat(d || 0) * 3600 +
      parseFloat(g || 0) * 60 +
      parseFloat(D || 0)
    );
  },
  ua = (e) => (
    /^\d+-\d+-\d+T\d+:\d+:\d+(\.\d+)?$/.test(e) && (e += "Z"),
    Date.parse(e)
  ),
  on = {
    mediaPresentationDuration(e) {
      return Te(e);
    },
    availabilityStartTime(e) {
      return ua(e) / 1e3;
    },
    minimumUpdatePeriod(e) {
      return Te(e);
    },
    suggestedPresentationDelay(e) {
      return Te(e);
    },
    type(e) {
      return e;
    },
    timeShiftBufferDepth(e) {
      return Te(e);
    },
    start(e) {
      return Te(e);
    },
    width(e) {
      return parseInt(e, 10);
    },
    height(e) {
      return parseInt(e, 10);
    },
    bandwidth(e) {
      return parseInt(e, 10);
    },
    frameRate(e) {
      return aa(e);
    },
    startNumber(e) {
      return parseInt(e, 10);
    },
    timescale(e) {
      return parseInt(e, 10);
    },
    presentationTimeOffset(e) {
      return parseInt(e, 10);
    },
    duration(e) {
      let t = parseInt(e, 10);
      return isNaN(t) ? Te(e) : t;
    },
    d(e) {
      return parseInt(e, 10);
    },
    t(e) {
      return parseInt(e, 10);
    },
    r(e) {
      return parseInt(e, 10);
    },
    presentationTime(e) {
      return parseInt(e, 10);
    },
    DEFAULT(e) {
      return e;
    },
  },
  P = (e) =>
    e && e.attributes
      ? mn(e.attributes).reduce((t, r) => {
          let n = on[r.name] || on.DEFAULT;
          return ((t[r.name] = n(r.value)), t);
        }, {})
      : {},
  sa = {
    "urn:uuid:1077efec-c0b2-4d02-ace3-3c1e52e2fb4b": "org.w3.clearkey",
    "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed": "com.widevine.alpha",
    "urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95": "com.microsoft.playready",
    "urn:uuid:f239e769-efa3-4850-9c16-a903c6932efb": "com.adobe.primetime",
    "urn:mpeg:dash:mp4protection:2011": "mp4protection",
  },
  ht = (e, t) =>
    t.length
      ? _e(
          e.map(function (r) {
            return t.map(function (n) {
              let i = $e(n),
                a = nt(r.baseUrl, i),
                u = q(P(n), { baseUrl: a });
              return (
                a !== i &&
                  !u.serviceLocation &&
                  r.serviceLocation &&
                  (u.serviceLocation = r.serviceLocation),
                u
              );
            });
          }),
        )
      : e,
  Wt = (e) => {
    let t = O(e, "SegmentTemplate")[0],
      r = O(e, "SegmentList")[0],
      n = r && O(r, "SegmentURL").map((d) => q({ tag: "SegmentURL" }, P(d))),
      i = O(e, "SegmentBase")[0],
      a = r || t,
      u = a && O(a, "SegmentTimeline")[0],
      s = r || i || t,
      l = s && O(s, "Initialization")[0],
      o = t && P(t);
    o && l
      ? (o.initialization = l && P(l))
      : o &&
        o.initialization &&
        (o.initialization = { sourceURL: o.initialization });
    let m = {
      template: o,
      segmentTimeline: u && O(u, "S").map((d) => P(d)),
      list: r && q(P(r), { segmentUrls: n, initialization: P(l) }),
      base: i && q(P(i), { initialization: P(l) }),
    };
    return (
      Object.keys(m).forEach((d) => {
        m[d] || delete m[d];
      }),
      m
    );
  },
  oa = (e, t, r) => (n) => {
    let i = O(n, "BaseURL"),
      a = ht(t, i),
      u = q(e, P(n)),
      s = Wt(n);
    return a.map((l) => ({ segmentInfo: q(r, s), attributes: q(u, l) }));
  },
  la = (e) =>
    e.reduce((t, r) => {
      let n = P(r);
      n.schemeIdUri && (n.schemeIdUri = n.schemeIdUri.toLowerCase());
      let i = sa[n.schemeIdUri];
      if (i) {
        t[i] = { attributes: n };
        let a = O(r, "cenc:pssh")[0];
        if (a) {
          let u = $e(a);
          t[i].pssh = u && Ie(u);
        }
      }
      return t;
    }, {}),
  ca = (e) => {
    if (e.schemeIdUri === "urn:scte:dash:cc:cea-608:2015")
      return (typeof e.value != "string" ? [] : e.value.split(";")).map((r) => {
        let n, i;
        return (
          (i = r),
          /^CC\d=/.test(r)
            ? ([n, i] = r.split("="))
            : /^CC\d$/.test(r) && (n = r),
          { channel: n, language: i }
        );
      });
    if (e.schemeIdUri === "urn:scte:dash:cc:cea-708:2015")
      return (typeof e.value != "string" ? [] : e.value.split(";")).map((r) => {
        let n = {
          channel: void 0,
          language: void 0,
          aspectRatio: 1,
          easyReader: 0,
          "3D": 0,
        };
        if (/=/.test(r)) {
          let [i, a = ""] = r.split("=");
          ((n.channel = i),
            (n.language = r),
            a.split(",").forEach((u) => {
              let [s, l] = u.split(":");
              s === "lang"
                ? (n.language = l)
                : s === "er"
                  ? (n.easyReader = Number(l))
                  : s === "war"
                    ? (n.aspectRatio = Number(l))
                    : s === "3D" && (n["3D"] = Number(l));
            }));
        } else n.language = r;
        return (n.channel && (n.channel = "SERVICE" + n.channel), n);
      });
  },
  ma = (e) =>
    _e(
      O(e.node, "EventStream").map((t) => {
        let r = P(t),
          n = r.schemeIdUri;
        return O(t, "Event").map((i) => {
          let a = P(i),
            u = a.presentationTime || 0,
            s = r.timescale || 1,
            l = a.duration || 0,
            o = u / s + e.attributes.start;
          return {
            schemeIdUri: n,
            value: r.value,
            id: a.id,
            start: o,
            end: o + l / s,
            messageData: $e(i) || a.messageData,
            contentEncoding: r.contentEncoding,
            presentationTimeOffset: r.presentationTimeOffset || 0,
          };
        });
      }),
    ),
  fa = (e, t, r) => (n) => {
    let i = P(n),
      a = ht(t, O(n, "BaseURL")),
      u = O(n, "Role")[0],
      s = { role: P(u) },
      l = q(e, i, s),
      o = O(n, "Accessibility")[0],
      m = ca(P(o));
    m && (l = q(l, { captionServices: m }));
    let d = O(n, "Label")[0];
    if (d && d.childNodes.length) {
      let v = d.childNodes[0].nodeValue.trim();
      l = q(l, { label: v });
    }
    let g = la(O(n, "ContentProtection"));
    Object.keys(g).length && (l = q(l, { contentProtection: g }));
    let D = Wt(n),
      b = O(n, "Representation"),
      c = q(r, D);
    return _e(b.map(oa(l, a, c)));
  },
  pa = (e, t) => (r, n) => {
    let i = ht(t, O(r.node, "BaseURL")),
      a = q(e, { periodStart: r.attributes.start });
    typeof r.attributes.duration == "number" &&
      (a.periodDuration = r.attributes.duration);
    let u = O(r.node, "AdaptationSet"),
      s = Wt(r.node);
    return _e(u.map(fa(a, i, s)));
  },
  da = (e, t) => {
    if (
      (e.length > 1 &&
        t({
          type: "warn",
          message:
            "The MPD manifest should contain no more than one ContentSteering tag",
        }),
      !e.length)
    )
      return null;
    let r = q({ serverURL: $e(e[0]) }, P(e[0]));
    return ((r.queryBeforeStart = r.queryBeforeStart === "true"), r);
  },
  ga = ({ attributes: e, priorPeriodAttributes: t, mpdType: r }) =>
    typeof e.start == "number"
      ? e.start
      : t && typeof t.start == "number" && typeof t.duration == "number"
        ? t.start + t.duration
        : !t && r === "static"
          ? 0
          : null,
  ha = (e, t = {}) => {
    let {
        manifestUri: r = "",
        NOW: n = Date.now(),
        clientOffset: i = 0,
        eventHandler: a = function () {},
      } = t,
      u = O(e, "Period");
    if (!u.length) throw new Error(He.INVALID_NUMBER_OF_PERIOD);
    let s = O(e, "Location"),
      l = P(e),
      o = ht([{ baseUrl: r }], O(e, "BaseURL")),
      m = O(e, "ContentSteering");
    ((l.type = l.type || "static"),
      (l.sourceDuration = l.mediaPresentationDuration || 0),
      (l.NOW = n),
      (l.clientOffset = i),
      s.length && (l.locations = s.map($e)));
    let d = [];
    return (
      u.forEach((g, D) => {
        let b = P(g),
          c = d[D - 1];
        ((b.start = ga({
          attributes: b,
          priorPeriodAttributes: c ? c.attributes : null,
          mpdType: l.type,
        })),
          d.push({ node: g, attributes: b }));
      }),
      {
        locations: l.locations,
        contentSteeringInfo: da(m, a),
        representationInfo: _e(d.map(pa(l, o))),
        eventStream: _e(d.map(ma)),
      }
    );
  },
  Aa = (e) => {
    if (e === "") throw new Error(He.DASH_EMPTY_MANIFEST);
    let t = new ln.DOMParser(),
      r,
      n;
    try {
      ((r = t.parseFromString(e, "application/xml")),
        (n =
          r && r.documentElement.tagName === "MPD" ? r.documentElement : null));
    } catch {}
    if (!n || (n && n.getElementsByTagName("parsererror").length > 0))
      throw new Error(He.DASH_INVALID_XML);
    return n;
  };
var gn = (e, t = {}) => {
  let r = ha(Aa(e), t),
    n = ia(r.representationInfo);
  return ji({
    dashPlaylists: n,
    locations: r.locations,
    contentSteering: r.contentSteeringInfo,
    sidxMapping: t.sidxMapping,
    previousManifest: t.previousManifest,
    eventStream: r.eventStream,
  });
};
function Da(e) {
  for (let t in e) {
    let r = e[t];
    for (let n in r) {
      let i = r[n];
      if ("playlists" in i) return x(i.playlists);
    }
  }
  return S;
}
function hn(e) {
  try {
    return Ea(e);
  } catch (t) {
    return M(`Error parsing MPD: ${t}`);
  }
}
function Ea(e) {
  let t = gn(e),
    r = t.duration || "unknown",
    n = ya(t),
    i = [],
    a = t.playlists;
  if (a.length == 0) {
    let s = Da(t.mediaGroups.AUDIO);
    s.isSome() && (a = s.value);
  }
  let u = 0;
  for (let s of a) {
    if (!s.attributes.CODECS) continue;
    let l = Qe(s.attributes.CODECS);
    if (l.isNone() && ((l = jt(s.attributes.CODECS)), l.isNone())) continue;
    let o = S;
    s.attributes.RESOLUTION &&
      s.attributes.RESOLUTION.width &&
      s.attributes.RESOLUTION.height &&
      (o = x({
        width: s.attributes.RESOLUTION.width,
        height: s.attributes.RESOLUTION.height,
      }));
    let m;
    s.attributes.BANDWIDTH
      ? (m = { bitrate: x(s.attributes.BANDWIDTH), size: o })
      : (m = { bitrate: S, size: o });
    let d = { quality: m, demuxer: l.value, index: u };
    (i.push(d), u++);
  }
  return ((i = Ze(i)), Je(i) ? G([i, r, n]) : M("No playlists"));
}
function ya(e) {
  for (let t of e.playlists)
    if (t.contentProtection && rt(t.contentProtection)) return !0;
  return !1;
}
var An = !1,
  Dn = "",
  Se;
function ba() {
  let e = window.location.href.match(
    /(?:m\.)?ok\.ru\/(?:video|live|videoembed)\/([^\/]+)/,
  );
  if (e && e.length > 1) {
    Se = e[1];
    return;
  }
  let t = K(window.location.href);
  if (t.isSome()) {
    let r = t.value.searchParams.get("st.mvId");
    r && (Se = r);
  }
}
async function va(e, t) {
  let r = await fetch(t);
  if (!r.ok) return S;
  let n = await r.text(),
    i = hn(n);
  if (i.isErr()) return (console.warn(`MPD playlist error ${i.error}`), S);
  let [a, u, s] = i.value,
    l = {
      type: "mpd_playlist",
      playlist: a,
      has_drm: s,
      hash: `media_hash_${St(t.href)}`,
      discovery_timestamp_ms: Date.now(),
      duration: u,
      is_youtube: !1,
      filename: S,
      sent_headers: new Headers(),
      initiator: K(window.location.href),
      preferred_entry: S,
      title: x(e.title),
      thumbnail_url: K(e.thumbnail_url),
      master_url: t,
      cache: "default",
    };
  return x(l);
}
async function Ta(e, t) {
  let r = await fetch(t);
  if (!r.ok) return S;
  let n = await r.text(),
    i = tr(n, t, S);
  if (i.isOk()) {
    let a = i.value,
      { duration: u } = await rr(a),
      s = {
        is_youtube: !1,
        master_url: t,
        preferred_entry: S,
        initiator: K(window.location.href),
        hash: `media_hash_${St(t.href)}`,
        sent_headers: new Headers(),
        thumbnail_url: K(e.thumbnail_url),
        filename: S,
        title: x(e.title),
        type: "m3u8_playlist",
        playlist: a,
        duration: u,
        discovery_timestamp_ms: Date.now(),
        has_drm: !1,
        cache: "default",
      };
    return x(s);
  }
  return S;
}
function _a() {
  let e = En(document);
  return e ? x(e) : S;
}
async function Sa(e) {
  let t = `https://ok.ru/videoembed/${e}?nochat=1`,
    n = await (await fetch(t)).text(),
    i = wa(n);
  return i ? x(i) : S;
}
function En(e) {
  let t = e.querySelectorAll("div[data-options]");
  for (let r of t) {
    let n = r.getAttribute("data-options");
    if (!n) continue;
    let i = JSON.parse(n);
    if (!i || !i.flashvars || !i.flashvars.metadata) continue;
    let a;
    if (
      (typeof i.flashvars.metadata == "string"
        ? (a = JSON.parse(i.flashvars.metadata))
        : (a = i.flashvars.metadata),
      !a || !a.movie)
    )
      continue;
    let u = a.movie.title,
      s = a.movie.poster,
      l = S;
    a.hlsManifestUrl
      ? (l = x(a.hlsManifestUrl))
      : a.ondemandHls
        ? (l = x(a.ondemandHls))
        : a.hlsMasterPlaylistUrl && (l = x(a.hlsMasterPlaylistUrl));
    let o = S;
    if ((a.dashSepUrl && (o = x(a.dashSepUrl)), !(!u || !s || !l)))
      return { title: u, thumbnail_url: s, m3u8_url: l, dash_url: o };
  }
}
function wa(e) {
  let r = new DOMParser().parseFromString(e, "text/html");
  return En(r);
}
async function xa() {
  if (!An)
    for (An = !0; ;) {
      if ((ba(), !Se || Se == Dn)) {
        await new Promise((t) => setTimeout(t, 300));
        continue;
      }
      Dn = Se;
      let e;
      if (
        (document.location.href.includes("m.ok")
          ? (e = _a())
          : (e = await Sa(Se)),
        e.isSome())
      ) {
        let t = S;
        (e.value.m3u8_url.isSome()
          ? (t = await Ta(e.value, new URL(e.value.m3u8_url.value)))
          : e.value.dash_url.isSome() &&
            (t = await va(e.value, new URL(e.value.dash_url.value))),
          t.isSome() && ur({ name: "on_media", data: { media: Z(t.value) } }));
      }
    }
}
xa();
/*! Bundled license information:

m3u8-parser/dist/m3u8-parser.es.js:
  (*! @name m3u8-parser @version 7.2.0 @license Apache-2.0 *)

mpd-parser/dist/mpd-parser.es.js:
  (*! @name mpd-parser @version 1.3.1 @license Apache-2.0 *)
*/
