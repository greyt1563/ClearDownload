var rn = Object.create;
var Ir = Object.defineProperty;
var tn = Object.getOwnPropertyDescriptor;
var nn = Object.getOwnPropertyNames;
var un = Object.getPrototypeOf,
  on = Object.prototype.hasOwnProperty;
var ue = (e, r) => () => (r || e((r = { exports: {} }).exports, r), r.exports);
var an = (e, r, t, n) => {
  if ((r && typeof r == "object") || typeof r == "function")
    for (let u of nn(r))
      !on.call(e, u) &&
        u !== t &&
        Ir(e, u, {
          get: () => r[u],
          enumerable: !(n = tn(r, u)) || n.enumerable,
        });
  return e;
};
var Ee = (e, r, t) => (
  (t = e != null ? rn(un(e)) : {}),
  an(
    r || !e || !e.__esModule
      ? Ir(t, "default", { value: e, enumerable: !0 })
      : t,
    e,
  )
);
var Mr = ue((ar, Fr) => {
  (function (e, r) {
    if (typeof define == "function" && define.amd)
      define("webextension-polyfill", ["module"], r);
    else if (typeof ar < "u") r(Fr);
    else {
      var t = { exports: {} };
      (r(t), (e.browser = t.exports));
    }
  })(
    typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : ar,
    function (e) {
      "use strict";
      if (!(
        globalThis.chrome &&
        globalThis.chrome.runtime &&
        globalThis.chrome.runtime.id
      ))
        throw new Error(
          "This script should only be loaded in a browser extension.",
        );
      if (
        globalThis.browser &&
        globalThis.browser.runtime &&
        globalThis.browser.runtime.id
      )
        e.exports = globalThis.browser;
      else {
        let r = "The message port closed before a response was received.",
          t = (n) => {
            let u = {
              alarms: {
                clear: { minArgs: 0, maxArgs: 1 },
                clearAll: { minArgs: 0, maxArgs: 0 },
                get: { minArgs: 0, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
              },
              bookmarks: {
                create: { minArgs: 1, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 1 },
                getChildren: { minArgs: 1, maxArgs: 1 },
                getRecent: { minArgs: 1, maxArgs: 1 },
                getSubTree: { minArgs: 1, maxArgs: 1 },
                getTree: { minArgs: 0, maxArgs: 0 },
                move: { minArgs: 2, maxArgs: 2 },
                remove: { minArgs: 1, maxArgs: 1 },
                removeTree: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              browserAction: {
                disable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                enable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                getBadgeBackgroundColor: { minArgs: 1, maxArgs: 1 },
                getBadgeText: { minArgs: 1, maxArgs: 1 },
                getPopup: { minArgs: 1, maxArgs: 1 },
                getTitle: { minArgs: 1, maxArgs: 1 },
                openPopup: { minArgs: 0, maxArgs: 0 },
                setBadgeBackgroundColor: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: !0,
                },
                setBadgeText: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: !0,
                },
                setIcon: { minArgs: 1, maxArgs: 1 },
                setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              browsingData: {
                remove: { minArgs: 2, maxArgs: 2 },
                removeCache: { minArgs: 1, maxArgs: 1 },
                removeCookies: { minArgs: 1, maxArgs: 1 },
                removeDownloads: { minArgs: 1, maxArgs: 1 },
                removeFormData: { minArgs: 1, maxArgs: 1 },
                removeHistory: { minArgs: 1, maxArgs: 1 },
                removeLocalStorage: { minArgs: 1, maxArgs: 1 },
                removePasswords: { minArgs: 1, maxArgs: 1 },
                removePluginData: { minArgs: 1, maxArgs: 1 },
                settings: { minArgs: 0, maxArgs: 0 },
              },
              commands: { getAll: { minArgs: 0, maxArgs: 0 } },
              contextMenus: {
                remove: { minArgs: 1, maxArgs: 1 },
                removeAll: { minArgs: 0, maxArgs: 0 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              cookies: {
                get: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 1, maxArgs: 1 },
                getAllCookieStores: { minArgs: 0, maxArgs: 0 },
                remove: { minArgs: 1, maxArgs: 1 },
                set: { minArgs: 1, maxArgs: 1 },
              },
              devtools: {
                inspectedWindow: {
                  eval: { minArgs: 1, maxArgs: 2, singleCallbackArg: !1 },
                },
                panels: {
                  create: { minArgs: 3, maxArgs: 3, singleCallbackArg: !0 },
                  elements: { createSidebarPane: { minArgs: 1, maxArgs: 1 } },
                },
              },
              downloads: {
                cancel: { minArgs: 1, maxArgs: 1 },
                download: { minArgs: 1, maxArgs: 1 },
                erase: { minArgs: 1, maxArgs: 1 },
                getFileIcon: { minArgs: 1, maxArgs: 2 },
                open: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                pause: { minArgs: 1, maxArgs: 1 },
                removeFile: { minArgs: 1, maxArgs: 1 },
                resume: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
                show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              extension: {
                isAllowedFileSchemeAccess: { minArgs: 0, maxArgs: 0 },
                isAllowedIncognitoAccess: { minArgs: 0, maxArgs: 0 },
              },
              history: {
                addUrl: { minArgs: 1, maxArgs: 1 },
                deleteAll: { minArgs: 0, maxArgs: 0 },
                deleteRange: { minArgs: 1, maxArgs: 1 },
                deleteUrl: { minArgs: 1, maxArgs: 1 },
                getVisits: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
              },
              i18n: {
                detectLanguage: { minArgs: 1, maxArgs: 1 },
                getAcceptLanguages: { minArgs: 0, maxArgs: 0 },
              },
              identity: { launchWebAuthFlow: { minArgs: 1, maxArgs: 1 } },
              idle: { queryState: { minArgs: 1, maxArgs: 1 } },
              management: {
                get: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
                getSelf: { minArgs: 0, maxArgs: 0 },
                setEnabled: { minArgs: 2, maxArgs: 2 },
                uninstallSelf: { minArgs: 0, maxArgs: 1 },
              },
              notifications: {
                clear: { minArgs: 1, maxArgs: 1 },
                create: { minArgs: 1, maxArgs: 2 },
                getAll: { minArgs: 0, maxArgs: 0 },
                getPermissionLevel: { minArgs: 0, maxArgs: 0 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              pageAction: {
                getPopup: { minArgs: 1, maxArgs: 1 },
                getTitle: { minArgs: 1, maxArgs: 1 },
                hide: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setIcon: { minArgs: 1, maxArgs: 1 },
                setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              permissions: {
                contains: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
                remove: { minArgs: 1, maxArgs: 1 },
                request: { minArgs: 1, maxArgs: 1 },
              },
              runtime: {
                getBackgroundPage: { minArgs: 0, maxArgs: 0 },
                getPlatformInfo: { minArgs: 0, maxArgs: 0 },
                openOptionsPage: { minArgs: 0, maxArgs: 0 },
                requestUpdateCheck: { minArgs: 0, maxArgs: 0 },
                sendMessage: { minArgs: 1, maxArgs: 3 },
                sendNativeMessage: { minArgs: 2, maxArgs: 2 },
                setUninstallURL: { minArgs: 1, maxArgs: 1 },
              },
              sessions: {
                getDevices: { minArgs: 0, maxArgs: 1 },
                getRecentlyClosed: { minArgs: 0, maxArgs: 1 },
                restore: { minArgs: 0, maxArgs: 1 },
              },
              storage: {
                local: {
                  clear: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
                managed: {
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                },
                sync: {
                  clear: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
              },
              tabs: {
                captureVisibleTab: { minArgs: 0, maxArgs: 2 },
                create: { minArgs: 1, maxArgs: 1 },
                detectLanguage: { minArgs: 0, maxArgs: 1 },
                discard: { minArgs: 0, maxArgs: 1 },
                duplicate: { minArgs: 1, maxArgs: 1 },
                executeScript: { minArgs: 1, maxArgs: 2 },
                get: { minArgs: 1, maxArgs: 1 },
                getCurrent: { minArgs: 0, maxArgs: 0 },
                getZoom: { minArgs: 0, maxArgs: 1 },
                getZoomSettings: { minArgs: 0, maxArgs: 1 },
                goBack: { minArgs: 0, maxArgs: 1 },
                goForward: { minArgs: 0, maxArgs: 1 },
                highlight: { minArgs: 1, maxArgs: 1 },
                insertCSS: { minArgs: 1, maxArgs: 2 },
                move: { minArgs: 2, maxArgs: 2 },
                query: { minArgs: 1, maxArgs: 1 },
                reload: { minArgs: 0, maxArgs: 2 },
                remove: { minArgs: 1, maxArgs: 1 },
                removeCSS: { minArgs: 1, maxArgs: 2 },
                sendMessage: { minArgs: 2, maxArgs: 3 },
                setZoom: { minArgs: 1, maxArgs: 2 },
                setZoomSettings: { minArgs: 1, maxArgs: 2 },
                update: { minArgs: 1, maxArgs: 2 },
              },
              topSites: { get: { minArgs: 0, maxArgs: 0 } },
              webNavigation: {
                getAllFrames: { minArgs: 1, maxArgs: 1 },
                getFrame: { minArgs: 1, maxArgs: 1 },
              },
              webRequest: {
                handlerBehaviorChanged: { minArgs: 0, maxArgs: 0 },
              },
              windows: {
                create: { minArgs: 0, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 2 },
                getAll: { minArgs: 0, maxArgs: 1 },
                getCurrent: { minArgs: 0, maxArgs: 1 },
                getLastFocused: { minArgs: 0, maxArgs: 1 },
                remove: { minArgs: 1, maxArgs: 1 },
                update: { minArgs: 2, maxArgs: 2 },
              },
            };
            if (Object.keys(u).length === 0)
              throw new Error(
                "api-metadata.json has not been included in browser-polyfill",
              );
            class i extends WeakMap {
              constructor(f, v = void 0) {
                (super(v), (this.createItem = f));
              }
              get(f) {
                return (
                  this.has(f) || this.set(f, this.createItem(f)),
                  super.get(f)
                );
              }
            }
            let o = (p) =>
                p && typeof p == "object" && typeof p.then == "function",
              s =
                (p, f) =>
                (...v) => {
                  n.runtime.lastError
                    ? p.reject(new Error(n.runtime.lastError.message))
                    : f.singleCallbackArg ||
                        (v.length <= 1 && f.singleCallbackArg !== !1)
                      ? p.resolve(v[0])
                      : p.resolve(v);
                },
              l = (p) => (p == 1 ? "argument" : "arguments"),
              a = (p, f) =>
                function (E, ...C) {
                  if (C.length < f.minArgs)
                    throw new Error(
                      `Expected at least ${f.minArgs} ${l(f.minArgs)} for ${p}(), got ${C.length}`,
                    );
                  if (C.length > f.maxArgs)
                    throw new Error(
                      `Expected at most ${f.maxArgs} ${l(f.maxArgs)} for ${p}(), got ${C.length}`,
                    );
                  return new Promise((_, R) => {
                    if (f.fallbackToNoCallback)
                      try {
                        E[p](...C, s({ resolve: _, reject: R }, f));
                      } catch (g) {
                        (console.warn(
                          `${p} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,
                          g,
                        ),
                          E[p](...C),
                          (f.fallbackToNoCallback = !1),
                          (f.noCallback = !0),
                          _());
                      }
                    else
                      f.noCallback
                        ? (E[p](...C), _())
                        : E[p](...C, s({ resolve: _, reject: R }, f));
                  });
                },
              c = (p, f, v) =>
                new Proxy(f, {
                  apply(E, C, _) {
                    return v.call(C, p, ..._);
                  },
                }),
              m = Function.call.bind(Object.prototype.hasOwnProperty),
              d = (p, f = {}, v = {}) => {
                let E = Object.create(null),
                  C = {
                    has(R, g) {
                      return g in p || g in E;
                    },
                    get(R, g, M) {
                      if (g in E) return E[g];
                      if (!(g in p)) return;
                      let O = p[g];
                      if (typeof O == "function")
                        if (typeof f[g] == "function") O = c(p, p[g], f[g]);
                        else if (m(v, g)) {
                          let X = a(g, v[g]);
                          O = c(p, p[g], X);
                        } else O = O.bind(p);
                      else if (
                        typeof O == "object" &&
                        O !== null &&
                        (m(f, g) || m(v, g))
                      )
                        O = d(O, f[g], v[g]);
                      else if (m(v, "*")) O = d(O, f[g], v["*"]);
                      else
                        return (
                          Object.defineProperty(E, g, {
                            configurable: !0,
                            enumerable: !0,
                            get() {
                              return p[g];
                            },
                            set(X) {
                              p[g] = X;
                            },
                          }),
                          O
                        );
                      return ((E[g] = O), O);
                    },
                    set(R, g, M, O) {
                      return (g in E ? (E[g] = M) : (p[g] = M), !0);
                    },
                    defineProperty(R, g, M) {
                      return Reflect.defineProperty(E, g, M);
                    },
                    deleteProperty(R, g) {
                      return Reflect.deleteProperty(E, g);
                    },
                  },
                  _ = Object.create(p);
                return new Proxy(_, C);
              },
              h = (p) => ({
                addListener(f, v, ...E) {
                  f.addListener(p.get(v), ...E);
                },
                hasListener(f, v) {
                  return f.hasListener(p.get(v));
                },
                removeListener(f, v) {
                  f.removeListener(p.get(v));
                },
              }),
              A = new i((p) =>
                typeof p != "function"
                  ? p
                  : function (v) {
                      let E = d(
                        v,
                        {},
                        { getContent: { minArgs: 0, maxArgs: 0 } },
                      );
                      p(E);
                    },
              ),
              D = new i((p) =>
                typeof p != "function"
                  ? p
                  : function (v, E, C) {
                      let _ = !1,
                        R,
                        g = new Promise((ne) => {
                          R = function (S) {
                            ((_ = !0), ne(S));
                          };
                        }),
                        M;
                      try {
                        M = p(v, E, R);
                      } catch (ne) {
                        M = Promise.reject(ne);
                      }
                      let O = M !== !0 && o(M);
                      if (M !== !0 && !O && !_) return !1;
                      let X = (ne) => {
                        ne.then(
                          (S) => {
                            C(S);
                          },
                          (S) => {
                            let q;
                            (S &&
                            (S instanceof Error || typeof S.message == "string")
                              ? (q = S.message)
                              : (q = "An unexpected error occurred"),
                              C({
                                __mozWebExtensionPolyfillReject__: !0,
                                message: q,
                              }));
                          },
                        ).catch((S) => {
                          console.error(
                            "Failed to send onMessage rejected reply",
                            S,
                          );
                        });
                      };
                      return (X(O ? M : g), !0);
                    },
              ),
              y = ({ reject: p, resolve: f }, v) => {
                n.runtime.lastError
                  ? n.runtime.lastError.message === r
                    ? f()
                    : p(new Error(n.runtime.lastError.message))
                  : v && v.__mozWebExtensionPolyfillReject__
                    ? p(new Error(v.message))
                    : f(v);
              },
              B = (p, f, v, ...E) => {
                if (E.length < f.minArgs)
                  throw new Error(
                    `Expected at least ${f.minArgs} ${l(f.minArgs)} for ${p}(), got ${E.length}`,
                  );
                if (E.length > f.maxArgs)
                  throw new Error(
                    `Expected at most ${f.maxArgs} ${l(f.maxArgs)} for ${p}(), got ${E.length}`,
                  );
                return new Promise((C, _) => {
                  let R = y.bind(null, { resolve: C, reject: _ });
                  (E.push(R), v.sendMessage(...E));
                });
              },
              x = {
                devtools: { network: { onRequestFinished: h(A) } },
                runtime: {
                  onMessage: h(D),
                  onMessageExternal: h(D),
                  sendMessage: B.bind(null, "sendMessage", {
                    minArgs: 1,
                    maxArgs: 3,
                  }),
                },
                tabs: {
                  sendMessage: B.bind(null, "sendMessage", {
                    minArgs: 2,
                    maxArgs: 3,
                  }),
                },
              },
              b = {
                clear: { minArgs: 1, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 1 },
                set: { minArgs: 1, maxArgs: 1 },
              };
            return (
              (u.privacy = {
                network: { "*": b },
                services: { "*": b },
                websites: { "*": b },
              }),
              d(n, x, u)
            );
          };
        e.exports = t(chrome);
      }
    },
  );
});
var He = ue((ji, zr) => {
  var Se;
  typeof window < "u"
    ? (Se = window)
    : typeof global < "u"
      ? (Se = global)
      : typeof self < "u"
        ? (Se = self)
        : (Se = {});
  zr.exports = Se;
});
var we = ue((ce) => {
  "use strict";
  function bn(e, r, t) {
    if (
      (t === void 0 && (t = Array.prototype), e && typeof t.find == "function")
    )
      return t.find.call(e, r);
    for (var n = 0; n < e.length; n++)
      if (Object.prototype.hasOwnProperty.call(e, n)) {
        var u = e[n];
        if (r.call(void 0, u, n, e)) return u;
      }
  }
  function mr(e, r) {
    return (
      r === void 0 && (r = Object),
      r && typeof r.freeze == "function" ? r.freeze(e) : e
    );
  }
  function Sn(e, r) {
    if (e === null || typeof e != "object")
      throw new TypeError("target is not an object");
    for (var t in r)
      Object.prototype.hasOwnProperty.call(r, t) && (e[t] = r[t]);
    return e;
  }
  var Wr = mr({
      HTML: "text/html",
      isHTML: function (e) {
        return e === Wr.HTML;
      },
      XML_APPLICATION: "application/xml",
      XML_TEXT: "text/xml",
      XML_XHTML_APPLICATION: "application/xhtml+xml",
      XML_SVG_IMAGE: "image/svg+xml",
    }),
    $r = mr({
      HTML: "http://www.w3.org/1999/xhtml",
      isHTML: function (e) {
        return e === $r.HTML;
      },
      SVG: "http://www.w3.org/2000/svg",
      XML: "http://www.w3.org/XML/1998/namespace",
      XMLNS: "http://www.w3.org/2000/xmlns/",
    });
  ce.assign = Sn;
  ce.find = bn;
  ce.freeze = mr;
  ce.MIME_TYPE = Wr;
  ce.NAMESPACE = $r;
});
var br = ue((te) => {
  var et = we(),
    J = et.find,
    Te = et.NAMESPACE;
  function wn(e) {
    return e !== "";
  }
  function Tn(e) {
    return e ? e.split(/[\t\n\f\r ]+/).filter(wn) : [];
  }
  function xn(e, r) {
    return (e.hasOwnProperty(r) || (e[r] = !0), e);
  }
  function jr(e) {
    if (!e) return [];
    var r = Tn(e);
    return Object.keys(r.reduce(xn, {}));
  }
  function Cn(e) {
    return function (r) {
      return e && e.indexOf(r) !== -1;
    };
  }
  function Ce(e, r) {
    for (var t in e)
      Object.prototype.hasOwnProperty.call(e, t) && (r[t] = e[t]);
  }
  function W(e, r) {
    var t = e.prototype;
    if (!(t instanceof r)) {
      let u = function () {};
      var n = u;
      ((u.prototype = r.prototype),
        (u = new u()),
        Ce(t, u),
        (e.prototype = t = u));
    }
    t.constructor != e &&
      (typeof e != "function" && console.error("unknown Class:" + e),
      (t.constructor = e));
  }
  var $ = {},
    Y = ($.ELEMENT_NODE = 1),
    pe = ($.ATTRIBUTE_NODE = 2),
    je = ($.TEXT_NODE = 3),
    rt = ($.CDATA_SECTION_NODE = 4),
    tt = ($.ENTITY_REFERENCE_NODE = 5),
    Nn = ($.ENTITY_NODE = 6),
    pr = ($.PROCESSING_INSTRUCTION_NODE = 7),
    dr = ($.COMMENT_NODE = 8),
    nt = ($.DOCUMENT_NODE = 9),
    ut = ($.DOCUMENT_TYPE_NODE = 10),
    K = ($.DOCUMENT_FRAGMENT_NODE = 11),
    Bn = ($.NOTATION_NODE = 12),
    V = {},
    P = {},
    Zi = (V.INDEX_SIZE_ERR = ((P[1] = "Index size error"), 1)),
    Ki = (V.DOMSTRING_SIZE_ERR = ((P[2] = "DOMString size error"), 2)),
    H = (V.HIERARCHY_REQUEST_ERR = ((P[3] = "Hierarchy request error"), 3)),
    eo = (V.WRONG_DOCUMENT_ERR = ((P[4] = "Wrong document"), 4)),
    In = (V.INVALID_CHARACTER_ERR = ((P[5] = "Invalid character"), 5)),
    ro = (V.NO_DATA_ALLOWED_ERR = ((P[6] = "No data allowed"), 6)),
    to = (V.NO_MODIFICATION_ALLOWED_ERR =
      ((P[7] = "No modification allowed"), 7)),
    it = (V.NOT_FOUND_ERR = ((P[8] = "Not found"), 8)),
    no = (V.NOT_SUPPORTED_ERR = ((P[9] = "Not supported"), 9)),
    Yr = (V.INUSE_ATTRIBUTE_ERR = ((P[10] = "Attribute in use"), 10)),
    me = (V.INVALID_STATE_ERR = ((P[11] = "Invalid state"), 11)),
    uo = (V.SYNTAX_ERR = ((P[12] = "Syntax error"), 12)),
    io = (V.INVALID_MODIFICATION_ERR = ((P[13] = "Invalid modification"), 13)),
    oo = (V.NAMESPACE_ERR = ((P[14] = "Invalid namespace"), 14)),
    ao = (V.INVALID_ACCESS_ERR = ((P[15] = "Invalid access"), 15));
  function T(e, r) {
    if (r instanceof Error) var t = r;
    else
      ((t = this),
        Error.call(this, P[e]),
        (this.message = P[e]),
        Error.captureStackTrace && Error.captureStackTrace(this, T));
    return ((t.code = e), r && (this.message = this.message + ": " + r), t);
  }
  T.prototype = Error.prototype;
  Ce(V, T);
  function ee() {}
  ee.prototype = {
    length: 0,
    item: function (e) {
      return e >= 0 && e < this.length ? this[e] : null;
    },
    toString: function (e, r, t) {
      for (
        var n = !!t && !!t.requireWellFormed, u = [], i = 0;
        i < this.length;
        i++
      )
        _r(this[i], u, e, r, null, n);
      return u.join("");
    },
    filter: function (e) {
      return Array.prototype.filter.call(this, e);
    },
    indexOf: function (e) {
      return Array.prototype.indexOf.call(this, e);
    },
  };
  function de(e, r) {
    ((this._node = e), (this._refresh = r), fr(this));
  }
  function fr(e) {
    var r = e._node._inc || e._node.ownerDocument._inc;
    if (e._inc !== r) {
      var t = e._refresh(e._node);
      if ((At(e, "length", t.length), !e.$$length || t.length < e.$$length))
        for (var n = t.length; n in e; n++)
          Object.prototype.hasOwnProperty.call(e, n) && delete e[n];
      (Ce(t, e), (e._inc = r));
    }
  }
  de.prototype.item = function (e) {
    return (fr(this), this[e] || null);
  };
  W(de, ee);
  function Ye() {}
  function ot(e, r) {
    for (var t = e.length; t--;) if (e[t] === r) return t;
  }
  function Xr(e, r, t, n) {
    if ((n ? (r[ot(r, n)] = t) : (r[r.length++] = t), e)) {
      t.ownerElement = e;
      var u = e.ownerDocument;
      u && (n && lt(u, e, n), On(u, e, t));
    }
  }
  function Qr(e, r, t) {
    var n = ot(r, t);
    if (n >= 0) {
      for (var u = r.length - 1; n < u;) r[n] = r[++n];
      if (((r.length = u), e)) {
        var i = e.ownerDocument;
        i && (lt(i, e, t), (t.ownerElement = null));
      }
    } else throw new T(it, new Error(e.tagName + "@" + t));
  }
  Ye.prototype = {
    length: 0,
    item: ee.prototype.item,
    getNamedItem: function (e) {
      for (var r = this.length; r--;) {
        var t = this[r];
        if (t.nodeName == e) return t;
      }
    },
    setNamedItem: function (e) {
      var r = e.ownerElement;
      if (r && r != this._ownerElement) throw new T(Yr);
      var t = this.getNamedItem(e.nodeName);
      return (Xr(this._ownerElement, this, e, t), t);
    },
    setNamedItemNS: function (e) {
      var r = e.ownerElement,
        t;
      if (r && r != this._ownerElement) throw new T(Yr);
      return (
        (t = this.getNamedItemNS(e.namespaceURI, e.localName)),
        Xr(this._ownerElement, this, e, t),
        t
      );
    },
    removeNamedItem: function (e) {
      var r = this.getNamedItem(e);
      return (Qr(this._ownerElement, this, r), r);
    },
    removeNamedItemNS: function (e, r) {
      var t = this.getNamedItemNS(e, r);
      return (Qr(this._ownerElement, this, t), t);
    },
    getNamedItemNS: function (e, r) {
      for (var t = this.length; t--;) {
        var n = this[t];
        if (n.localName == r && n.namespaceURI == e) return n;
      }
      return null;
    },
  };
  function at() {}
  at.prototype = {
    hasFeature: function (e, r) {
      return !0;
    },
    createDocument: function (e, r, t) {
      var n = new Ne();
      if (
        ((n.implementation = this),
        (n.childNodes = new ee()),
        (n.doctype = t || null),
        t && n.appendChild(t),
        r)
      ) {
        var u = n.createElementNS(e, r);
        n.appendChild(u);
      }
      return n;
    },
    createDocumentType: function (e, r, t) {
      var n = new Ze();
      return (
        (n.name = e),
        (n.nodeName = e),
        (n.publicId = r || ""),
        (n.systemId = t || ""),
        n
      );
    },
  };
  function w() {}
  w.prototype = {
    firstChild: null,
    lastChild: null,
    previousSibling: null,
    nextSibling: null,
    attributes: null,
    parentNode: null,
    childNodes: null,
    ownerDocument: null,
    nodeValue: null,
    namespaceURI: null,
    prefix: null,
    localName: null,
    insertBefore: function (e, r) {
      return Qe(this, e, r);
    },
    replaceChild: function (e, r) {
      (Qe(this, e, r, mt), r && this.removeChild(r));
    },
    removeChild: function (e) {
      return ct(this, e);
    },
    appendChild: function (e) {
      return this.insertBefore(e, null);
    },
    hasChildNodes: function () {
      return this.firstChild != null;
    },
    cloneNode: function (e) {
      return ht(this.ownerDocument || this, this, e);
    },
    normalize: function () {
      L(this, null, {
        enter: function (e) {
          for (var r = e.firstChild; r;) {
            var t = r.nextSibling;
            t !== null && t.nodeType === je && r.nodeType === je
              ? (e.removeChild(t), r.appendData(t.data))
              : (r = t);
          }
          return !0;
        },
      });
    },
    isSupported: function (e, r) {
      return this.ownerDocument.implementation.hasFeature(e, r);
    },
    hasAttributes: function () {
      return this.attributes.length > 0;
    },
    lookupPrefix: function (e) {
      for (var r = this; r;) {
        var t = r._nsMap;
        if (t) {
          for (var n in t)
            if (Object.prototype.hasOwnProperty.call(t, n) && t[n] === e)
              return n;
        }
        r = r.nodeType == pe ? r.ownerDocument : r.parentNode;
      }
      return null;
    },
    lookupNamespaceURI: function (e) {
      for (var r = this; r;) {
        var t = r._nsMap;
        if (t && Object.prototype.hasOwnProperty.call(t, e)) return t[e];
        r = r.nodeType == pe ? r.ownerDocument : r.parentNode;
      }
      return null;
    },
    isDefaultNamespace: function (e) {
      var r = this.lookupPrefix(e);
      return r == null;
    },
  };
  function st(e) {
    return (
      (e == "<" && "&lt;") ||
      (e == ">" && "&gt;") ||
      (e == "&" && "&amp;") ||
      (e == '"' && "&quot;") ||
      "&#" + e.charCodeAt() + ";"
    );
  }
  Ce($, w);
  Ce($, w.prototype);
  function Xe(e, r) {
    return (
      L(e, null, {
        enter: function (t) {
          return r(t) ? L.STOP : !0;
        },
      }) === L.STOP
    );
  }
  function L(e, r, t) {
    for (var n = [{ node: e, context: r, phase: L.ENTER }]; n.length > 0;) {
      var u = n.pop();
      if (u.phase === L.ENTER) {
        var i = t.enter(u.node, u.context);
        if (i === L.STOP) return L.STOP;
        if ((n.push({ node: u.node, context: i, phase: L.EXIT }), i == null))
          continue;
        for (var o = u.node.lastChild; o;)
          (n.push({ node: o, context: i, phase: L.ENTER }),
            (o = o.previousSibling));
      } else t.exit && t.exit(u.node, u.context);
    }
  }
  L.STOP = Symbol("walkDOM.STOP");
  L.ENTER = 0;
  L.EXIT = 1;
  function Ne() {
    this.ownerDocument = this;
  }
  function On(e, r, t) {
    e && e._inc++;
    var n = t.namespaceURI;
    n === Te.XMLNS && (r._nsMap[t.prefix ? t.localName : ""] = t.value);
  }
  function lt(e, r, t, n) {
    e && e._inc++;
    var u = t.namespaceURI;
    u === Te.XMLNS && delete r._nsMap[t.prefix ? t.localName : ""];
  }
  function gr(e, r, t) {
    if (e && e._inc) {
      e._inc++;
      var n = r.childNodes;
      if (t) n[n.length++] = t;
      else {
        for (var u = r.firstChild, i = 0; u;)
          ((n[i++] = u), (u = u.nextSibling));
        ((n.length = i), delete n[n.length]);
      }
    }
  }
  function ct(e, r) {
    var t = r.previousSibling,
      n = r.nextSibling;
    return (
      t ? (t.nextSibling = n) : (e.firstChild = n),
      n ? (n.previousSibling = t) : (e.lastChild = t),
      (r.parentNode = null),
      (r.previousSibling = null),
      (r.nextSibling = null),
      gr(e.ownerDocument, e),
      r
    );
  }
  function Rn(e) {
    return (
      e &&
      (e.nodeType === w.DOCUMENT_NODE ||
        e.nodeType === w.DOCUMENT_FRAGMENT_NODE ||
        e.nodeType === w.ELEMENT_NODE)
    );
  }
  function Fn(e) {
    return (
      e &&
      (Z(e) ||
        hr(e) ||
        re(e) ||
        e.nodeType === w.DOCUMENT_FRAGMENT_NODE ||
        e.nodeType === w.COMMENT_NODE ||
        e.nodeType === w.PROCESSING_INSTRUCTION_NODE)
    );
  }
  function re(e) {
    return e && e.nodeType === w.DOCUMENT_TYPE_NODE;
  }
  function Z(e) {
    return e && e.nodeType === w.ELEMENT_NODE;
  }
  function hr(e) {
    return e && e.nodeType === w.TEXT_NODE;
  }
  function Jr(e, r) {
    var t = e.childNodes || [];
    if (J(t, Z) || re(r)) return !1;
    var n = J(t, re);
    return !(r && n && t.indexOf(n) > t.indexOf(r));
  }
  function Zr(e, r) {
    var t = e.childNodes || [];
    function n(i) {
      return Z(i) && i !== r;
    }
    if (J(t, n)) return !1;
    var u = J(t, re);
    return !(r && u && t.indexOf(u) > t.indexOf(r));
  }
  function Mn(e, r, t) {
    if (!Rn(e)) throw new T(H, "Unexpected parent node type " + e.nodeType);
    if (t && t.parentNode !== e) throw new T(it, "child not in parent");
    if (!Fn(r) || (re(r) && e.nodeType !== w.DOCUMENT_NODE))
      throw new T(
        H,
        "Unexpected node type " +
          r.nodeType +
          " for parent node type " +
          e.nodeType,
      );
  }
  function Ln(e, r, t) {
    var n = e.childNodes || [],
      u = r.childNodes || [];
    if (r.nodeType === w.DOCUMENT_FRAGMENT_NODE) {
      var i = u.filter(Z);
      if (i.length > 1 || J(u, hr))
        throw new T(H, "More than one element or text in fragment");
      if (i.length === 1 && !Jr(e, t))
        throw new T(
          H,
          "Element in fragment can not be inserted before doctype",
        );
    }
    if (Z(r) && !Jr(e, t))
      throw new T(H, "Only one element can be added and only after doctype");
    if (re(r)) {
      if (J(n, re)) throw new T(H, "Only one doctype is allowed");
      var o = J(n, Z);
      if (t && n.indexOf(o) < n.indexOf(t))
        throw new T(H, "Doctype can only be inserted before an element");
      if (!t && o)
        throw new T(H, "Doctype can not be appended since element is present");
    }
  }
  function mt(e, r, t) {
    var n = e.childNodes || [],
      u = r.childNodes || [];
    if (r.nodeType === w.DOCUMENT_FRAGMENT_NODE) {
      var i = u.filter(Z);
      if (i.length > 1 || J(u, hr))
        throw new T(H, "More than one element or text in fragment");
      if (i.length === 1 && !Zr(e, t))
        throw new T(
          H,
          "Element in fragment can not be inserted before doctype",
        );
    }
    if (Z(r) && !Zr(e, t))
      throw new T(H, "Only one element can be added and only after doctype");
    if (re(r)) {
      let l = function (a) {
        return re(a) && a !== t;
      };
      var s = l;
      if (J(n, l)) throw new T(H, "Only one doctype is allowed");
      var o = J(n, Z);
      if (t && n.indexOf(o) < n.indexOf(t))
        throw new T(H, "Doctype can only be inserted before an element");
    }
  }
  function Qe(e, r, t, n) {
    (Mn(e, r, t), e.nodeType === w.DOCUMENT_NODE && (n || Ln)(e, r, t));
    var u = r.parentNode;
    if ((u && u.removeChild(r), r.nodeType === K)) {
      var i = r.firstChild;
      if (i == null) return r;
      var o = r.lastChild;
    } else i = o = r;
    var s = t ? t.previousSibling : e.lastChild;
    ((i.previousSibling = s),
      (o.nextSibling = t),
      s ? (s.nextSibling = i) : (e.firstChild = i),
      t == null ? (e.lastChild = o) : (t.previousSibling = o));
    do {
      i.parentNode = e;
      var l = e.ownerDocument || e;
      xe(i, l);
    } while (i !== o && (i = i.nextSibling));
    return (
      gr(e.ownerDocument || e, e),
      r.nodeType == K && (r.firstChild = r.lastChild = null),
      r
    );
  }
  function xe(e, r) {
    if (e.ownerDocument !== r) {
      if (((e.ownerDocument = r), e.nodeType === Y && e.attributes))
        for (var t = 0; t < e.attributes.length; t++) {
          var n = e.attributes.item(t);
          n && (n.ownerDocument = r);
        }
      for (var u = e.firstChild; u;) (xe(u, r), (u = u.nextSibling));
    }
  }
  function Pn(e, r) {
    (r.parentNode && r.parentNode.removeChild(r),
      (r.parentNode = e),
      (r.previousSibling = e.lastChild),
      (r.nextSibling = null),
      r.previousSibling
        ? (r.previousSibling.nextSibling = r)
        : (e.firstChild = r),
      (e.lastChild = r),
      gr(e.ownerDocument, e, r));
    var t = e.ownerDocument || e;
    return (xe(r, t), r);
  }
  Ne.prototype = {
    nodeName: "#document",
    nodeType: nt,
    doctype: null,
    documentElement: null,
    _inc: 1,
    insertBefore: function (e, r) {
      if (e.nodeType == K) {
        for (var t = e.firstChild; t;) {
          var n = t.nextSibling;
          (this.insertBefore(t, r), (t = n));
        }
        return e;
      }
      return (
        Qe(this, e, r),
        xe(e, this),
        this.documentElement === null &&
          e.nodeType === Y &&
          (this.documentElement = e),
        e
      );
    },
    removeChild: function (e) {
      return (
        this.documentElement == e && (this.documentElement = null),
        ct(this, e)
      );
    },
    replaceChild: function (e, r) {
      (Qe(this, e, r, mt),
        xe(e, this),
        r && this.removeChild(r),
        Z(e) && (this.documentElement = e));
    },
    importNode: function (e, r) {
      return kn(this, e, r);
    },
    getElementById: function (e) {
      var r = null;
      return (
        Xe(this.documentElement, function (t) {
          if (t.nodeType == Y && t.getAttribute("id") == e)
            return ((r = t), !0);
        }),
        r
      );
    },
    getElementsByClassName: function (e) {
      var r = jr(e);
      return new de(this, function (t) {
        var n = [];
        return (
          r.length > 0 &&
            Xe(t.documentElement, function (u) {
              if (u !== t && u.nodeType === Y) {
                var i = u.getAttribute("class");
                if (i) {
                  var o = e === i;
                  if (!o) {
                    var s = jr(i);
                    o = r.every(Cn(s));
                  }
                  o && n.push(u);
                }
              }
            }),
          n
        );
      });
    },
    createElement: function (e) {
      var r = new ae();
      ((r.ownerDocument = this),
        (r.nodeName = e),
        (r.tagName = e),
        (r.localName = e),
        (r.childNodes = new ee()));
      var t = (r.attributes = new Ye());
      return ((t._ownerElement = r), r);
    },
    createDocumentFragment: function () {
      var e = new Ke();
      return ((e.ownerDocument = this), (e.childNodes = new ee()), e);
    },
    createTextNode: function (e) {
      var r = new Ar();
      return ((r.ownerDocument = this), r.appendData(e), r);
    },
    createComment: function (e) {
      var r = new Dr();
      return ((r.ownerDocument = this), r.appendData(e), r);
    },
    createCDATASection: function (e) {
      if (e.indexOf("]]>") !== -1) throw new T(In, 'data contains "]]>"');
      var r = new yr();
      return ((r.ownerDocument = this), r.appendData(e), r);
    },
    createProcessingInstruction: function (e, r) {
      var t = new Er();
      return (
        (t.ownerDocument = this),
        (t.tagName = t.nodeName = t.target = e),
        (t.nodeValue = t.data = r),
        t
      );
    },
    createAttribute: function (e) {
      var r = new Je();
      return (
        (r.ownerDocument = this),
        (r.name = e),
        (r.nodeName = e),
        (r.localName = e),
        (r.specified = !0),
        r
      );
    },
    createEntityReference: function (e) {
      var r = new vr();
      return ((r.ownerDocument = this), (r.nodeName = e), r);
    },
    createElementNS: function (e, r) {
      var t = new ae(),
        n = r.split(":"),
        u = (t.attributes = new Ye());
      return (
        (t.childNodes = new ee()),
        (t.ownerDocument = this),
        (t.nodeName = r),
        (t.tagName = r),
        (t.namespaceURI = e),
        n.length == 2
          ? ((t.prefix = n[0]), (t.localName = n[1]))
          : (t.localName = r),
        (u._ownerElement = t),
        t
      );
    },
    createAttributeNS: function (e, r) {
      var t = new Je(),
        n = r.split(":");
      return (
        (t.ownerDocument = this),
        (t.nodeName = r),
        (t.name = r),
        (t.namespaceURI = e),
        (t.specified = !0),
        n.length == 2
          ? ((t.prefix = n[0]), (t.localName = n[1]))
          : (t.localName = r),
        t
      );
    },
  };
  W(Ne, w);
  function ae() {
    this._nsMap = {};
  }
  ae.prototype = {
    nodeType: Y,
    hasAttribute: function (e) {
      return this.getAttributeNode(e) != null;
    },
    getAttribute: function (e) {
      var r = this.getAttributeNode(e);
      return (r && r.value) || "";
    },
    getAttributeNode: function (e) {
      return this.attributes.getNamedItem(e);
    },
    setAttribute: function (e, r) {
      var t = this.ownerDocument.createAttribute(e);
      ((t.value = t.nodeValue = "" + r), this.setAttributeNode(t));
    },
    removeAttribute: function (e) {
      var r = this.getAttributeNode(e);
      r && this.removeAttributeNode(r);
    },
    appendChild: function (e) {
      return e.nodeType === K ? this.insertBefore(e, null) : Pn(this, e);
    },
    setAttributeNode: function (e) {
      return this.attributes.setNamedItem(e);
    },
    setAttributeNodeNS: function (e) {
      return this.attributes.setNamedItemNS(e);
    },
    removeAttributeNode: function (e) {
      return this.attributes.removeNamedItem(e.nodeName);
    },
    removeAttributeNS: function (e, r) {
      var t = this.getAttributeNodeNS(e, r);
      t && this.removeAttributeNode(t);
    },
    hasAttributeNS: function (e, r) {
      return this.getAttributeNodeNS(e, r) != null;
    },
    getAttributeNS: function (e, r) {
      var t = this.getAttributeNodeNS(e, r);
      return (t && t.value) || "";
    },
    setAttributeNS: function (e, r, t) {
      var n = this.ownerDocument.createAttributeNS(e, r);
      ((n.value = n.nodeValue = "" + t), this.setAttributeNode(n));
    },
    getAttributeNodeNS: function (e, r) {
      return this.attributes.getNamedItemNS(e, r);
    },
    getElementsByTagName: function (e) {
      return new de(this, function (r) {
        var t = [];
        return (
          Xe(r, function (n) {
            n !== r &&
              n.nodeType == Y &&
              (e === "*" || n.tagName == e) &&
              t.push(n);
          }),
          t
        );
      });
    },
    getElementsByTagNameNS: function (e, r) {
      return new de(this, function (t) {
        var n = [];
        return (
          Xe(t, function (u) {
            u !== t &&
              u.nodeType === Y &&
              (e === "*" || u.namespaceURI === e) &&
              (r === "*" || u.localName == r) &&
              n.push(u);
          }),
          n
        );
      });
    },
  };
  Ne.prototype.getElementsByTagName = ae.prototype.getElementsByTagName;
  Ne.prototype.getElementsByTagNameNS = ae.prototype.getElementsByTagNameNS;
  W(ae, w);
  function Je() {}
  Je.prototype.nodeType = pe;
  W(Je, w);
  function Be() {}
  Be.prototype = {
    data: "",
    substringData: function (e, r) {
      return this.data.substring(e, e + r);
    },
    appendData: function (e) {
      ((e = this.data + e),
        (this.nodeValue = this.data = e),
        (this.length = e.length));
    },
    insertData: function (e, r) {
      this.replaceData(e, 0, r);
    },
    appendChild: function (e) {
      throw new Error(P[H]);
    },
    deleteData: function (e, r) {
      this.replaceData(e, r, "");
    },
    replaceData: function (e, r, t) {
      var n = this.data.substring(0, e),
        u = this.data.substring(e + r);
      ((t = n + t + u),
        (this.nodeValue = this.data = t),
        (this.length = t.length));
    },
  };
  W(Be, w);
  function Ar() {}
  Ar.prototype = {
    nodeName: "#text",
    nodeType: je,
    splitText: function (e) {
      var r = this.data,
        t = r.substring(e);
      ((r = r.substring(0, e)),
        (this.data = this.nodeValue = r),
        (this.length = r.length));
      var n = this.ownerDocument.createTextNode(t);
      return (
        this.parentNode && this.parentNode.insertBefore(n, this.nextSibling),
        n
      );
    },
  };
  W(Ar, Be);
  function Dr() {}
  Dr.prototype = { nodeName: "#comment", nodeType: dr };
  W(Dr, Be);
  function yr() {}
  yr.prototype = { nodeName: "#cdata-section", nodeType: rt };
  W(yr, Be);
  function Ze() {}
  Ze.prototype.nodeType = ut;
  W(Ze, w);
  function pt() {}
  pt.prototype.nodeType = Bn;
  W(pt, w);
  function dt() {}
  dt.prototype.nodeType = Nn;
  W(dt, w);
  function vr() {}
  vr.prototype.nodeType = tt;
  W(vr, w);
  function Ke() {}
  Ke.prototype.nodeName = "#document-fragment";
  Ke.prototype.nodeType = K;
  W(Ke, w);
  function Er() {}
  Er.prototype.nodeType = pr;
  W(Er, w);
  function ft() {}
  ft.prototype.serializeToString = function (e, r, t, n) {
    return gt.call(e, r, t, n);
  };
  w.prototype.toString = gt;
  function gt(e, r, t) {
    var n = !!t && !!t.requireWellFormed,
      u = [],
      i = (this.nodeType == 9 && this.documentElement) || this,
      o = i.prefix,
      s = i.namespaceURI;
    if (s && o == null) {
      var o = i.lookupPrefix(s);
      if (o == null) var l = [{ namespace: s, prefix: null }];
    }
    return (_r(this, u, e, r, l, n), u.join(""));
  }
  function Kr(e, r, t) {
    var n = e.prefix || "",
      u = e.namespaceURI;
    if (!u || (n === "xml" && u === Te.XML) || u === Te.XMLNS) return !1;
    for (var i = t.length; i--;) {
      var o = t[i];
      if (o.prefix === n) return o.namespace !== u;
    }
    return !0;
  }
  function $e(e, r, t) {
    e.push(" ", r, '="', t.replace(/[<>&"\t\n\r]/g, st), '"');
  }
  function _r(e, r, t, n, u, i) {
    (u || (u = []),
      L(
        e,
        { ns: u, isHTML: t },
        {
          enter: function (o, s) {
            var l = s.ns,
              a = s.isHTML;
            if (n)
              if (((o = n(o)), o)) {
                if (typeof o == "string") return (r.push(o), null);
              } else return null;
            switch (o.nodeType) {
              case Y:
                var c = o.attributes,
                  m = c.length,
                  d = o.tagName;
                a = Te.isHTML(o.namespaceURI) || a;
                var h = d;
                if (!a && !o.prefix && o.namespaceURI) {
                  for (var A, D = 0; D < c.length; D++)
                    if (c.item(D).name === "xmlns") {
                      A = c.item(D).value;
                      break;
                    }
                  if (!A)
                    for (var y = l.length - 1; y >= 0; y--) {
                      var B = l[y];
                      if (B.prefix === "" && B.namespace === o.namespaceURI) {
                        A = B.namespace;
                        break;
                      }
                    }
                  if (A !== o.namespaceURI)
                    for (var y = l.length - 1; y >= 0; y--) {
                      var B = l[y];
                      if (B.namespace === o.namespaceURI) {
                        B.prefix && (h = B.prefix + ":" + d);
                        break;
                      }
                    }
                }
                r.push("<", h);
                for (var x = l.slice(), b = 0; b < m; b++) {
                  var p = c.item(b);
                  p.prefix == "xmlns"
                    ? x.push({ prefix: p.localName, namespace: p.value })
                    : p.nodeName == "xmlns" &&
                      x.push({ prefix: "", namespace: p.value });
                }
                for (var b = 0; b < m; b++) {
                  var p = c.item(b);
                  if (Kr(p, a, x)) {
                    var f = p.prefix || "",
                      v = p.namespaceURI;
                    ($e(r, f ? "xmlns:" + f : "xmlns", v),
                      x.push({ prefix: f, namespace: v }));
                  }
                  var E = n ? n(p) : p;
                  E &&
                    (typeof E == "string" ? r.push(E) : $e(r, E.name, E.value));
                }
                if (d === h && Kr(o, a, x)) {
                  var C = o.prefix || "",
                    v = o.namespaceURI;
                  ($e(r, C ? "xmlns:" + C : "xmlns", v),
                    x.push({ prefix: C, namespace: v }));
                }
                var _ = o.firstChild;
                if (_ || (a && !/^(?:meta|link|img|br|hr|input)$/i.test(d))) {
                  if ((r.push(">"), a && /^script$/i.test(d))) {
                    for (; _;)
                      (_.data ? r.push(_.data) : _r(_, r, a, n, x.slice(), i),
                        (_ = _.nextSibling));
                    return (r.push("</", d, ">"), null);
                  }
                  return { ns: x, isHTML: a, tag: h };
                } else return (r.push("/>"), null);
              case nt:
              case K:
                return { ns: l.slice(), isHTML: a, tag: null };
              case pe:
                return ($e(r, o.name, o.value), null);
              case je:
                return (r.push(o.data.replace(/[<&>]/g, st)), null);
              case rt:
                if (i && o.data.indexOf("]]>") !== -1)
                  throw new T(me, 'The CDATASection data contains "]]>"');
                return (
                  r.push(
                    "<![CDATA[",
                    o.data.replace(/]]>/g, "]]]]><![CDATA[>"),
                    "]]>",
                  ),
                  null
                );
              case dr:
                if (i && o.data.indexOf("-->") !== -1)
                  throw new T(me, 'The comment node data contains "-->"');
                return (r.push("<!--", o.data, "-->"), null);
              case ut:
                if (i) {
                  if (
                    o.publicId &&
                    !/^("[\x20\r\na-zA-Z0-9\-()+,.\/:=?;!*#@$_%']*"|'[\x20\r\na-zA-Z0-9\-()+,.\/:=?;!*#@$_%'"]*')$/.test(
                      o.publicId,
                    )
                  )
                    throw new T(
                      me,
                      "DocumentType publicId is not a valid PubidLiteral",
                    );
                  if (o.systemId && !/^("[^"]*"|'[^']*')$/.test(o.systemId))
                    throw new T(
                      me,
                      "DocumentType systemId is not a valid SystemLiteral",
                    );
                  if (o.internalSubset && o.internalSubset.indexOf("]>") !== -1)
                    throw new T(
                      me,
                      'DocumentType internalSubset contains "]>"',
                    );
                }
                var R = o.publicId,
                  g = o.systemId;
                if ((r.push("<!DOCTYPE ", o.name), R))
                  (r.push(" PUBLIC ", R),
                    g && g != "." && r.push(" ", g),
                    r.push(">"));
                else if (g && g != ".") r.push(" SYSTEM ", g, ">");
                else {
                  var M = o.internalSubset;
                  (M && r.push(" [", M, "]"), r.push(">"));
                }
                return null;
              case pr:
                if (i && o.data.indexOf("?>") !== -1)
                  throw new T(
                    me,
                    'The ProcessingInstruction data contains "?>"',
                  );
                return (r.push("<?", o.target, " ", o.data, "?>"), null);
              case tt:
                return (r.push("&", o.nodeName, ";"), null);
              default:
                return (r.push("??", o.nodeName), null);
            }
          },
          exit: function (o, s) {
            s && s.tag && r.push("</", s.tag, ">");
          },
        },
      ));
  }
  function kn(e, r, t) {
    var n;
    return (
      L(r, null, {
        enter: function (u, i) {
          var o = u.cloneNode(!1);
          ((o.ownerDocument = e),
            (o.parentNode = null),
            i === null ? (n = o) : i.appendChild(o));
          var s = u.nodeType === pe || t;
          return s ? o : null;
        },
      }),
      n
    );
  }
  function ht(e, r, t) {
    var n;
    return (
      L(r, null, {
        enter: function (u, i) {
          var o = new u.constructor();
          for (var s in u)
            if (Object.prototype.hasOwnProperty.call(u, s)) {
              var l = u[s];
              typeof l != "object" && l != o[s] && (o[s] = l);
            }
          (u.childNodes && (o.childNodes = new ee()), (o.ownerDocument = e));
          var a = t;
          switch (o.nodeType) {
            case Y:
              var c = u.attributes,
                m = (o.attributes = new Ye()),
                d = c.length;
              m._ownerElement = o;
              for (var h = 0; h < d; h++)
                o.setAttributeNode(ht(e, c.item(h), !0));
              break;
            case pe:
              a = !0;
          }
          return (i !== null ? i.appendChild(o) : (n = o), a ? o : null);
        },
      }),
      n
    );
  }
  function At(e, r, t) {
    e[r] = t;
  }
  try {
    Object.defineProperty &&
      (Object.defineProperty(de.prototype, "length", {
        get: function () {
          return (fr(this), this.$$length);
        },
      }),
      Object.defineProperty(w.prototype, "textContent", {
        get: function () {
          if (this.nodeType === Y || this.nodeType === K) {
            var e = [];
            return (
              L(this, null, {
                enter: function (r) {
                  if (r.nodeType === Y || r.nodeType === K) return !0;
                  if (r.nodeType === pr || r.nodeType === dr) return null;
                  e.push(r.nodeValue);
                },
              }),
              e.join("")
            );
          }
          return this.nodeValue;
        },
        set: function (e) {
          switch (this.nodeType) {
            case Y:
            case K:
              for (; this.firstChild;) this.removeChild(this.firstChild);
              (e || String(e)) &&
                this.appendChild(this.ownerDocument.createTextNode(e));
              break;
            default:
              ((this.data = e), (this.value = e), (this.nodeValue = e));
          }
        },
      }),
      (At = function (e, r, t) {
        e["$$" + r] = t;
      }));
  } catch {}
  te.DocumentType = Ze;
  te.DOMException = T;
  te.DOMImplementation = at;
  te.Element = ae;
  te.Node = w;
  te.NodeList = ee;
  te.walkDOM = L;
  te.XMLSerializer = ft;
});
var yt = ue((Ie) => {
  "use strict";
  var Dt = we().freeze;
  Ie.XML_ENTITIES = Dt({ amp: "&", apos: "'", gt: ">", lt: "<", quot: '"' });
  Ie.HTML_ENTITIES = Dt({
    Aacute: "\xC1",
    aacute: "\xE1",
    Abreve: "\u0102",
    abreve: "\u0103",
    ac: "\u223E",
    acd: "\u223F",
    acE: "\u223E\u0333",
    Acirc: "\xC2",
    acirc: "\xE2",
    acute: "\xB4",
    Acy: "\u0410",
    acy: "\u0430",
    AElig: "\xC6",
    aelig: "\xE6",
    af: "\u2061",
    Afr: "\u{1D504}",
    afr: "\u{1D51E}",
    Agrave: "\xC0",
    agrave: "\xE0",
    alefsym: "\u2135",
    aleph: "\u2135",
    Alpha: "\u0391",
    alpha: "\u03B1",
    Amacr: "\u0100",
    amacr: "\u0101",
    amalg: "\u2A3F",
    AMP: "&",
    amp: "&",
    And: "\u2A53",
    and: "\u2227",
    andand: "\u2A55",
    andd: "\u2A5C",
    andslope: "\u2A58",
    andv: "\u2A5A",
    ang: "\u2220",
    ange: "\u29A4",
    angle: "\u2220",
    angmsd: "\u2221",
    angmsdaa: "\u29A8",
    angmsdab: "\u29A9",
    angmsdac: "\u29AA",
    angmsdad: "\u29AB",
    angmsdae: "\u29AC",
    angmsdaf: "\u29AD",
    angmsdag: "\u29AE",
    angmsdah: "\u29AF",
    angrt: "\u221F",
    angrtvb: "\u22BE",
    angrtvbd: "\u299D",
    angsph: "\u2222",
    angst: "\xC5",
    angzarr: "\u237C",
    Aogon: "\u0104",
    aogon: "\u0105",
    Aopf: "\u{1D538}",
    aopf: "\u{1D552}",
    ap: "\u2248",
    apacir: "\u2A6F",
    apE: "\u2A70",
    ape: "\u224A",
    apid: "\u224B",
    apos: "'",
    ApplyFunction: "\u2061",
    approx: "\u2248",
    approxeq: "\u224A",
    Aring: "\xC5",
    aring: "\xE5",
    Ascr: "\u{1D49C}",
    ascr: "\u{1D4B6}",
    Assign: "\u2254",
    ast: "*",
    asymp: "\u2248",
    asympeq: "\u224D",
    Atilde: "\xC3",
    atilde: "\xE3",
    Auml: "\xC4",
    auml: "\xE4",
    awconint: "\u2233",
    awint: "\u2A11",
    backcong: "\u224C",
    backepsilon: "\u03F6",
    backprime: "\u2035",
    backsim: "\u223D",
    backsimeq: "\u22CD",
    Backslash: "\u2216",
    Barv: "\u2AE7",
    barvee: "\u22BD",
    Barwed: "\u2306",
    barwed: "\u2305",
    barwedge: "\u2305",
    bbrk: "\u23B5",
    bbrktbrk: "\u23B6",
    bcong: "\u224C",
    Bcy: "\u0411",
    bcy: "\u0431",
    bdquo: "\u201E",
    becaus: "\u2235",
    Because: "\u2235",
    because: "\u2235",
    bemptyv: "\u29B0",
    bepsi: "\u03F6",
    bernou: "\u212C",
    Bernoullis: "\u212C",
    Beta: "\u0392",
    beta: "\u03B2",
    beth: "\u2136",
    between: "\u226C",
    Bfr: "\u{1D505}",
    bfr: "\u{1D51F}",
    bigcap: "\u22C2",
    bigcirc: "\u25EF",
    bigcup: "\u22C3",
    bigodot: "\u2A00",
    bigoplus: "\u2A01",
    bigotimes: "\u2A02",
    bigsqcup: "\u2A06",
    bigstar: "\u2605",
    bigtriangledown: "\u25BD",
    bigtriangleup: "\u25B3",
    biguplus: "\u2A04",
    bigvee: "\u22C1",
    bigwedge: "\u22C0",
    bkarow: "\u290D",
    blacklozenge: "\u29EB",
    blacksquare: "\u25AA",
    blacktriangle: "\u25B4",
    blacktriangledown: "\u25BE",
    blacktriangleleft: "\u25C2",
    blacktriangleright: "\u25B8",
    blank: "\u2423",
    blk12: "\u2592",
    blk14: "\u2591",
    blk34: "\u2593",
    block: "\u2588",
    bne: "=\u20E5",
    bnequiv: "\u2261\u20E5",
    bNot: "\u2AED",
    bnot: "\u2310",
    Bopf: "\u{1D539}",
    bopf: "\u{1D553}",
    bot: "\u22A5",
    bottom: "\u22A5",
    bowtie: "\u22C8",
    boxbox: "\u29C9",
    boxDL: "\u2557",
    boxDl: "\u2556",
    boxdL: "\u2555",
    boxdl: "\u2510",
    boxDR: "\u2554",
    boxDr: "\u2553",
    boxdR: "\u2552",
    boxdr: "\u250C",
    boxH: "\u2550",
    boxh: "\u2500",
    boxHD: "\u2566",
    boxHd: "\u2564",
    boxhD: "\u2565",
    boxhd: "\u252C",
    boxHU: "\u2569",
    boxHu: "\u2567",
    boxhU: "\u2568",
    boxhu: "\u2534",
    boxminus: "\u229F",
    boxplus: "\u229E",
    boxtimes: "\u22A0",
    boxUL: "\u255D",
    boxUl: "\u255C",
    boxuL: "\u255B",
    boxul: "\u2518",
    boxUR: "\u255A",
    boxUr: "\u2559",
    boxuR: "\u2558",
    boxur: "\u2514",
    boxV: "\u2551",
    boxv: "\u2502",
    boxVH: "\u256C",
    boxVh: "\u256B",
    boxvH: "\u256A",
    boxvh: "\u253C",
    boxVL: "\u2563",
    boxVl: "\u2562",
    boxvL: "\u2561",
    boxvl: "\u2524",
    boxVR: "\u2560",
    boxVr: "\u255F",
    boxvR: "\u255E",
    boxvr: "\u251C",
    bprime: "\u2035",
    Breve: "\u02D8",
    breve: "\u02D8",
    brvbar: "\xA6",
    Bscr: "\u212C",
    bscr: "\u{1D4B7}",
    bsemi: "\u204F",
    bsim: "\u223D",
    bsime: "\u22CD",
    bsol: "\\",
    bsolb: "\u29C5",
    bsolhsub: "\u27C8",
    bull: "\u2022",
    bullet: "\u2022",
    bump: "\u224E",
    bumpE: "\u2AAE",
    bumpe: "\u224F",
    Bumpeq: "\u224E",
    bumpeq: "\u224F",
    Cacute: "\u0106",
    cacute: "\u0107",
    Cap: "\u22D2",
    cap: "\u2229",
    capand: "\u2A44",
    capbrcup: "\u2A49",
    capcap: "\u2A4B",
    capcup: "\u2A47",
    capdot: "\u2A40",
    CapitalDifferentialD: "\u2145",
    caps: "\u2229\uFE00",
    caret: "\u2041",
    caron: "\u02C7",
    Cayleys: "\u212D",
    ccaps: "\u2A4D",
    Ccaron: "\u010C",
    ccaron: "\u010D",
    Ccedil: "\xC7",
    ccedil: "\xE7",
    Ccirc: "\u0108",
    ccirc: "\u0109",
    Cconint: "\u2230",
    ccups: "\u2A4C",
    ccupssm: "\u2A50",
    Cdot: "\u010A",
    cdot: "\u010B",
    cedil: "\xB8",
    Cedilla: "\xB8",
    cemptyv: "\u29B2",
    cent: "\xA2",
    CenterDot: "\xB7",
    centerdot: "\xB7",
    Cfr: "\u212D",
    cfr: "\u{1D520}",
    CHcy: "\u0427",
    chcy: "\u0447",
    check: "\u2713",
    checkmark: "\u2713",
    Chi: "\u03A7",
    chi: "\u03C7",
    cir: "\u25CB",
    circ: "\u02C6",
    circeq: "\u2257",
    circlearrowleft: "\u21BA",
    circlearrowright: "\u21BB",
    circledast: "\u229B",
    circledcirc: "\u229A",
    circleddash: "\u229D",
    CircleDot: "\u2299",
    circledR: "\xAE",
    circledS: "\u24C8",
    CircleMinus: "\u2296",
    CirclePlus: "\u2295",
    CircleTimes: "\u2297",
    cirE: "\u29C3",
    cire: "\u2257",
    cirfnint: "\u2A10",
    cirmid: "\u2AEF",
    cirscir: "\u29C2",
    ClockwiseContourIntegral: "\u2232",
    CloseCurlyDoubleQuote: "\u201D",
    CloseCurlyQuote: "\u2019",
    clubs: "\u2663",
    clubsuit: "\u2663",
    Colon: "\u2237",
    colon: ":",
    Colone: "\u2A74",
    colone: "\u2254",
    coloneq: "\u2254",
    comma: ",",
    commat: "@",
    comp: "\u2201",
    compfn: "\u2218",
    complement: "\u2201",
    complexes: "\u2102",
    cong: "\u2245",
    congdot: "\u2A6D",
    Congruent: "\u2261",
    Conint: "\u222F",
    conint: "\u222E",
    ContourIntegral: "\u222E",
    Copf: "\u2102",
    copf: "\u{1D554}",
    coprod: "\u2210",
    Coproduct: "\u2210",
    COPY: "\xA9",
    copy: "\xA9",
    copysr: "\u2117",
    CounterClockwiseContourIntegral: "\u2233",
    crarr: "\u21B5",
    Cross: "\u2A2F",
    cross: "\u2717",
    Cscr: "\u{1D49E}",
    cscr: "\u{1D4B8}",
    csub: "\u2ACF",
    csube: "\u2AD1",
    csup: "\u2AD0",
    csupe: "\u2AD2",
    ctdot: "\u22EF",
    cudarrl: "\u2938",
    cudarrr: "\u2935",
    cuepr: "\u22DE",
    cuesc: "\u22DF",
    cularr: "\u21B6",
    cularrp: "\u293D",
    Cup: "\u22D3",
    cup: "\u222A",
    cupbrcap: "\u2A48",
    CupCap: "\u224D",
    cupcap: "\u2A46",
    cupcup: "\u2A4A",
    cupdot: "\u228D",
    cupor: "\u2A45",
    cups: "\u222A\uFE00",
    curarr: "\u21B7",
    curarrm: "\u293C",
    curlyeqprec: "\u22DE",
    curlyeqsucc: "\u22DF",
    curlyvee: "\u22CE",
    curlywedge: "\u22CF",
    curren: "\xA4",
    curvearrowleft: "\u21B6",
    curvearrowright: "\u21B7",
    cuvee: "\u22CE",
    cuwed: "\u22CF",
    cwconint: "\u2232",
    cwint: "\u2231",
    cylcty: "\u232D",
    Dagger: "\u2021",
    dagger: "\u2020",
    daleth: "\u2138",
    Darr: "\u21A1",
    dArr: "\u21D3",
    darr: "\u2193",
    dash: "\u2010",
    Dashv: "\u2AE4",
    dashv: "\u22A3",
    dbkarow: "\u290F",
    dblac: "\u02DD",
    Dcaron: "\u010E",
    dcaron: "\u010F",
    Dcy: "\u0414",
    dcy: "\u0434",
    DD: "\u2145",
    dd: "\u2146",
    ddagger: "\u2021",
    ddarr: "\u21CA",
    DDotrahd: "\u2911",
    ddotseq: "\u2A77",
    deg: "\xB0",
    Del: "\u2207",
    Delta: "\u0394",
    delta: "\u03B4",
    demptyv: "\u29B1",
    dfisht: "\u297F",
    Dfr: "\u{1D507}",
    dfr: "\u{1D521}",
    dHar: "\u2965",
    dharl: "\u21C3",
    dharr: "\u21C2",
    DiacriticalAcute: "\xB4",
    DiacriticalDot: "\u02D9",
    DiacriticalDoubleAcute: "\u02DD",
    DiacriticalGrave: "`",
    DiacriticalTilde: "\u02DC",
    diam: "\u22C4",
    Diamond: "\u22C4",
    diamond: "\u22C4",
    diamondsuit: "\u2666",
    diams: "\u2666",
    die: "\xA8",
    DifferentialD: "\u2146",
    digamma: "\u03DD",
    disin: "\u22F2",
    div: "\xF7",
    divide: "\xF7",
    divideontimes: "\u22C7",
    divonx: "\u22C7",
    DJcy: "\u0402",
    djcy: "\u0452",
    dlcorn: "\u231E",
    dlcrop: "\u230D",
    dollar: "$",
    Dopf: "\u{1D53B}",
    dopf: "\u{1D555}",
    Dot: "\xA8",
    dot: "\u02D9",
    DotDot: "\u20DC",
    doteq: "\u2250",
    doteqdot: "\u2251",
    DotEqual: "\u2250",
    dotminus: "\u2238",
    dotplus: "\u2214",
    dotsquare: "\u22A1",
    doublebarwedge: "\u2306",
    DoubleContourIntegral: "\u222F",
    DoubleDot: "\xA8",
    DoubleDownArrow: "\u21D3",
    DoubleLeftArrow: "\u21D0",
    DoubleLeftRightArrow: "\u21D4",
    DoubleLeftTee: "\u2AE4",
    DoubleLongLeftArrow: "\u27F8",
    DoubleLongLeftRightArrow: "\u27FA",
    DoubleLongRightArrow: "\u27F9",
    DoubleRightArrow: "\u21D2",
    DoubleRightTee: "\u22A8",
    DoubleUpArrow: "\u21D1",
    DoubleUpDownArrow: "\u21D5",
    DoubleVerticalBar: "\u2225",
    DownArrow: "\u2193",
    Downarrow: "\u21D3",
    downarrow: "\u2193",
    DownArrowBar: "\u2913",
    DownArrowUpArrow: "\u21F5",
    DownBreve: "\u0311",
    downdownarrows: "\u21CA",
    downharpoonleft: "\u21C3",
    downharpoonright: "\u21C2",
    DownLeftRightVector: "\u2950",
    DownLeftTeeVector: "\u295E",
    DownLeftVector: "\u21BD",
    DownLeftVectorBar: "\u2956",
    DownRightTeeVector: "\u295F",
    DownRightVector: "\u21C1",
    DownRightVectorBar: "\u2957",
    DownTee: "\u22A4",
    DownTeeArrow: "\u21A7",
    drbkarow: "\u2910",
    drcorn: "\u231F",
    drcrop: "\u230C",
    Dscr: "\u{1D49F}",
    dscr: "\u{1D4B9}",
    DScy: "\u0405",
    dscy: "\u0455",
    dsol: "\u29F6",
    Dstrok: "\u0110",
    dstrok: "\u0111",
    dtdot: "\u22F1",
    dtri: "\u25BF",
    dtrif: "\u25BE",
    duarr: "\u21F5",
    duhar: "\u296F",
    dwangle: "\u29A6",
    DZcy: "\u040F",
    dzcy: "\u045F",
    dzigrarr: "\u27FF",
    Eacute: "\xC9",
    eacute: "\xE9",
    easter: "\u2A6E",
    Ecaron: "\u011A",
    ecaron: "\u011B",
    ecir: "\u2256",
    Ecirc: "\xCA",
    ecirc: "\xEA",
    ecolon: "\u2255",
    Ecy: "\u042D",
    ecy: "\u044D",
    eDDot: "\u2A77",
    Edot: "\u0116",
    eDot: "\u2251",
    edot: "\u0117",
    ee: "\u2147",
    efDot: "\u2252",
    Efr: "\u{1D508}",
    efr: "\u{1D522}",
    eg: "\u2A9A",
    Egrave: "\xC8",
    egrave: "\xE8",
    egs: "\u2A96",
    egsdot: "\u2A98",
    el: "\u2A99",
    Element: "\u2208",
    elinters: "\u23E7",
    ell: "\u2113",
    els: "\u2A95",
    elsdot: "\u2A97",
    Emacr: "\u0112",
    emacr: "\u0113",
    empty: "\u2205",
    emptyset: "\u2205",
    EmptySmallSquare: "\u25FB",
    emptyv: "\u2205",
    EmptyVerySmallSquare: "\u25AB",
    emsp: "\u2003",
    emsp13: "\u2004",
    emsp14: "\u2005",
    ENG: "\u014A",
    eng: "\u014B",
    ensp: "\u2002",
    Eogon: "\u0118",
    eogon: "\u0119",
    Eopf: "\u{1D53C}",
    eopf: "\u{1D556}",
    epar: "\u22D5",
    eparsl: "\u29E3",
    eplus: "\u2A71",
    epsi: "\u03B5",
    Epsilon: "\u0395",
    epsilon: "\u03B5",
    epsiv: "\u03F5",
    eqcirc: "\u2256",
    eqcolon: "\u2255",
    eqsim: "\u2242",
    eqslantgtr: "\u2A96",
    eqslantless: "\u2A95",
    Equal: "\u2A75",
    equals: "=",
    EqualTilde: "\u2242",
    equest: "\u225F",
    Equilibrium: "\u21CC",
    equiv: "\u2261",
    equivDD: "\u2A78",
    eqvparsl: "\u29E5",
    erarr: "\u2971",
    erDot: "\u2253",
    Escr: "\u2130",
    escr: "\u212F",
    esdot: "\u2250",
    Esim: "\u2A73",
    esim: "\u2242",
    Eta: "\u0397",
    eta: "\u03B7",
    ETH: "\xD0",
    eth: "\xF0",
    Euml: "\xCB",
    euml: "\xEB",
    euro: "\u20AC",
    excl: "!",
    exist: "\u2203",
    Exists: "\u2203",
    expectation: "\u2130",
    ExponentialE: "\u2147",
    exponentiale: "\u2147",
    fallingdotseq: "\u2252",
    Fcy: "\u0424",
    fcy: "\u0444",
    female: "\u2640",
    ffilig: "\uFB03",
    fflig: "\uFB00",
    ffllig: "\uFB04",
    Ffr: "\u{1D509}",
    ffr: "\u{1D523}",
    filig: "\uFB01",
    FilledSmallSquare: "\u25FC",
    FilledVerySmallSquare: "\u25AA",
    fjlig: "fj",
    flat: "\u266D",
    fllig: "\uFB02",
    fltns: "\u25B1",
    fnof: "\u0192",
    Fopf: "\u{1D53D}",
    fopf: "\u{1D557}",
    ForAll: "\u2200",
    forall: "\u2200",
    fork: "\u22D4",
    forkv: "\u2AD9",
    Fouriertrf: "\u2131",
    fpartint: "\u2A0D",
    frac12: "\xBD",
    frac13: "\u2153",
    frac14: "\xBC",
    frac15: "\u2155",
    frac16: "\u2159",
    frac18: "\u215B",
    frac23: "\u2154",
    frac25: "\u2156",
    frac34: "\xBE",
    frac35: "\u2157",
    frac38: "\u215C",
    frac45: "\u2158",
    frac56: "\u215A",
    frac58: "\u215D",
    frac78: "\u215E",
    frasl: "\u2044",
    frown: "\u2322",
    Fscr: "\u2131",
    fscr: "\u{1D4BB}",
    gacute: "\u01F5",
    Gamma: "\u0393",
    gamma: "\u03B3",
    Gammad: "\u03DC",
    gammad: "\u03DD",
    gap: "\u2A86",
    Gbreve: "\u011E",
    gbreve: "\u011F",
    Gcedil: "\u0122",
    Gcirc: "\u011C",
    gcirc: "\u011D",
    Gcy: "\u0413",
    gcy: "\u0433",
    Gdot: "\u0120",
    gdot: "\u0121",
    gE: "\u2267",
    ge: "\u2265",
    gEl: "\u2A8C",
    gel: "\u22DB",
    geq: "\u2265",
    geqq: "\u2267",
    geqslant: "\u2A7E",
    ges: "\u2A7E",
    gescc: "\u2AA9",
    gesdot: "\u2A80",
    gesdoto: "\u2A82",
    gesdotol: "\u2A84",
    gesl: "\u22DB\uFE00",
    gesles: "\u2A94",
    Gfr: "\u{1D50A}",
    gfr: "\u{1D524}",
    Gg: "\u22D9",
    gg: "\u226B",
    ggg: "\u22D9",
    gimel: "\u2137",
    GJcy: "\u0403",
    gjcy: "\u0453",
    gl: "\u2277",
    gla: "\u2AA5",
    glE: "\u2A92",
    glj: "\u2AA4",
    gnap: "\u2A8A",
    gnapprox: "\u2A8A",
    gnE: "\u2269",
    gne: "\u2A88",
    gneq: "\u2A88",
    gneqq: "\u2269",
    gnsim: "\u22E7",
    Gopf: "\u{1D53E}",
    gopf: "\u{1D558}",
    grave: "`",
    GreaterEqual: "\u2265",
    GreaterEqualLess: "\u22DB",
    GreaterFullEqual: "\u2267",
    GreaterGreater: "\u2AA2",
    GreaterLess: "\u2277",
    GreaterSlantEqual: "\u2A7E",
    GreaterTilde: "\u2273",
    Gscr: "\u{1D4A2}",
    gscr: "\u210A",
    gsim: "\u2273",
    gsime: "\u2A8E",
    gsiml: "\u2A90",
    Gt: "\u226B",
    GT: ">",
    gt: ">",
    gtcc: "\u2AA7",
    gtcir: "\u2A7A",
    gtdot: "\u22D7",
    gtlPar: "\u2995",
    gtquest: "\u2A7C",
    gtrapprox: "\u2A86",
    gtrarr: "\u2978",
    gtrdot: "\u22D7",
    gtreqless: "\u22DB",
    gtreqqless: "\u2A8C",
    gtrless: "\u2277",
    gtrsim: "\u2273",
    gvertneqq: "\u2269\uFE00",
    gvnE: "\u2269\uFE00",
    Hacek: "\u02C7",
    hairsp: "\u200A",
    half: "\xBD",
    hamilt: "\u210B",
    HARDcy: "\u042A",
    hardcy: "\u044A",
    hArr: "\u21D4",
    harr: "\u2194",
    harrcir: "\u2948",
    harrw: "\u21AD",
    Hat: "^",
    hbar: "\u210F",
    Hcirc: "\u0124",
    hcirc: "\u0125",
    hearts: "\u2665",
    heartsuit: "\u2665",
    hellip: "\u2026",
    hercon: "\u22B9",
    Hfr: "\u210C",
    hfr: "\u{1D525}",
    HilbertSpace: "\u210B",
    hksearow: "\u2925",
    hkswarow: "\u2926",
    hoarr: "\u21FF",
    homtht: "\u223B",
    hookleftarrow: "\u21A9",
    hookrightarrow: "\u21AA",
    Hopf: "\u210D",
    hopf: "\u{1D559}",
    horbar: "\u2015",
    HorizontalLine: "\u2500",
    Hscr: "\u210B",
    hscr: "\u{1D4BD}",
    hslash: "\u210F",
    Hstrok: "\u0126",
    hstrok: "\u0127",
    HumpDownHump: "\u224E",
    HumpEqual: "\u224F",
    hybull: "\u2043",
    hyphen: "\u2010",
    Iacute: "\xCD",
    iacute: "\xED",
    ic: "\u2063",
    Icirc: "\xCE",
    icirc: "\xEE",
    Icy: "\u0418",
    icy: "\u0438",
    Idot: "\u0130",
    IEcy: "\u0415",
    iecy: "\u0435",
    iexcl: "\xA1",
    iff: "\u21D4",
    Ifr: "\u2111",
    ifr: "\u{1D526}",
    Igrave: "\xCC",
    igrave: "\xEC",
    ii: "\u2148",
    iiiint: "\u2A0C",
    iiint: "\u222D",
    iinfin: "\u29DC",
    iiota: "\u2129",
    IJlig: "\u0132",
    ijlig: "\u0133",
    Im: "\u2111",
    Imacr: "\u012A",
    imacr: "\u012B",
    image: "\u2111",
    ImaginaryI: "\u2148",
    imagline: "\u2110",
    imagpart: "\u2111",
    imath: "\u0131",
    imof: "\u22B7",
    imped: "\u01B5",
    Implies: "\u21D2",
    in: "\u2208",
    incare: "\u2105",
    infin: "\u221E",
    infintie: "\u29DD",
    inodot: "\u0131",
    Int: "\u222C",
    int: "\u222B",
    intcal: "\u22BA",
    integers: "\u2124",
    Integral: "\u222B",
    intercal: "\u22BA",
    Intersection: "\u22C2",
    intlarhk: "\u2A17",
    intprod: "\u2A3C",
    InvisibleComma: "\u2063",
    InvisibleTimes: "\u2062",
    IOcy: "\u0401",
    iocy: "\u0451",
    Iogon: "\u012E",
    iogon: "\u012F",
    Iopf: "\u{1D540}",
    iopf: "\u{1D55A}",
    Iota: "\u0399",
    iota: "\u03B9",
    iprod: "\u2A3C",
    iquest: "\xBF",
    Iscr: "\u2110",
    iscr: "\u{1D4BE}",
    isin: "\u2208",
    isindot: "\u22F5",
    isinE: "\u22F9",
    isins: "\u22F4",
    isinsv: "\u22F3",
    isinv: "\u2208",
    it: "\u2062",
    Itilde: "\u0128",
    itilde: "\u0129",
    Iukcy: "\u0406",
    iukcy: "\u0456",
    Iuml: "\xCF",
    iuml: "\xEF",
    Jcirc: "\u0134",
    jcirc: "\u0135",
    Jcy: "\u0419",
    jcy: "\u0439",
    Jfr: "\u{1D50D}",
    jfr: "\u{1D527}",
    jmath: "\u0237",
    Jopf: "\u{1D541}",
    jopf: "\u{1D55B}",
    Jscr: "\u{1D4A5}",
    jscr: "\u{1D4BF}",
    Jsercy: "\u0408",
    jsercy: "\u0458",
    Jukcy: "\u0404",
    jukcy: "\u0454",
    Kappa: "\u039A",
    kappa: "\u03BA",
    kappav: "\u03F0",
    Kcedil: "\u0136",
    kcedil: "\u0137",
    Kcy: "\u041A",
    kcy: "\u043A",
    Kfr: "\u{1D50E}",
    kfr: "\u{1D528}",
    kgreen: "\u0138",
    KHcy: "\u0425",
    khcy: "\u0445",
    KJcy: "\u040C",
    kjcy: "\u045C",
    Kopf: "\u{1D542}",
    kopf: "\u{1D55C}",
    Kscr: "\u{1D4A6}",
    kscr: "\u{1D4C0}",
    lAarr: "\u21DA",
    Lacute: "\u0139",
    lacute: "\u013A",
    laemptyv: "\u29B4",
    lagran: "\u2112",
    Lambda: "\u039B",
    lambda: "\u03BB",
    Lang: "\u27EA",
    lang: "\u27E8",
    langd: "\u2991",
    langle: "\u27E8",
    lap: "\u2A85",
    Laplacetrf: "\u2112",
    laquo: "\xAB",
    Larr: "\u219E",
    lArr: "\u21D0",
    larr: "\u2190",
    larrb: "\u21E4",
    larrbfs: "\u291F",
    larrfs: "\u291D",
    larrhk: "\u21A9",
    larrlp: "\u21AB",
    larrpl: "\u2939",
    larrsim: "\u2973",
    larrtl: "\u21A2",
    lat: "\u2AAB",
    lAtail: "\u291B",
    latail: "\u2919",
    late: "\u2AAD",
    lates: "\u2AAD\uFE00",
    lBarr: "\u290E",
    lbarr: "\u290C",
    lbbrk: "\u2772",
    lbrace: "{",
    lbrack: "[",
    lbrke: "\u298B",
    lbrksld: "\u298F",
    lbrkslu: "\u298D",
    Lcaron: "\u013D",
    lcaron: "\u013E",
    Lcedil: "\u013B",
    lcedil: "\u013C",
    lceil: "\u2308",
    lcub: "{",
    Lcy: "\u041B",
    lcy: "\u043B",
    ldca: "\u2936",
    ldquo: "\u201C",
    ldquor: "\u201E",
    ldrdhar: "\u2967",
    ldrushar: "\u294B",
    ldsh: "\u21B2",
    lE: "\u2266",
    le: "\u2264",
    LeftAngleBracket: "\u27E8",
    LeftArrow: "\u2190",
    Leftarrow: "\u21D0",
    leftarrow: "\u2190",
    LeftArrowBar: "\u21E4",
    LeftArrowRightArrow: "\u21C6",
    leftarrowtail: "\u21A2",
    LeftCeiling: "\u2308",
    LeftDoubleBracket: "\u27E6",
    LeftDownTeeVector: "\u2961",
    LeftDownVector: "\u21C3",
    LeftDownVectorBar: "\u2959",
    LeftFloor: "\u230A",
    leftharpoondown: "\u21BD",
    leftharpoonup: "\u21BC",
    leftleftarrows: "\u21C7",
    LeftRightArrow: "\u2194",
    Leftrightarrow: "\u21D4",
    leftrightarrow: "\u2194",
    leftrightarrows: "\u21C6",
    leftrightharpoons: "\u21CB",
    leftrightsquigarrow: "\u21AD",
    LeftRightVector: "\u294E",
    LeftTee: "\u22A3",
    LeftTeeArrow: "\u21A4",
    LeftTeeVector: "\u295A",
    leftthreetimes: "\u22CB",
    LeftTriangle: "\u22B2",
    LeftTriangleBar: "\u29CF",
    LeftTriangleEqual: "\u22B4",
    LeftUpDownVector: "\u2951",
    LeftUpTeeVector: "\u2960",
    LeftUpVector: "\u21BF",
    LeftUpVectorBar: "\u2958",
    LeftVector: "\u21BC",
    LeftVectorBar: "\u2952",
    lEg: "\u2A8B",
    leg: "\u22DA",
    leq: "\u2264",
    leqq: "\u2266",
    leqslant: "\u2A7D",
    les: "\u2A7D",
    lescc: "\u2AA8",
    lesdot: "\u2A7F",
    lesdoto: "\u2A81",
    lesdotor: "\u2A83",
    lesg: "\u22DA\uFE00",
    lesges: "\u2A93",
    lessapprox: "\u2A85",
    lessdot: "\u22D6",
    lesseqgtr: "\u22DA",
    lesseqqgtr: "\u2A8B",
    LessEqualGreater: "\u22DA",
    LessFullEqual: "\u2266",
    LessGreater: "\u2276",
    lessgtr: "\u2276",
    LessLess: "\u2AA1",
    lesssim: "\u2272",
    LessSlantEqual: "\u2A7D",
    LessTilde: "\u2272",
    lfisht: "\u297C",
    lfloor: "\u230A",
    Lfr: "\u{1D50F}",
    lfr: "\u{1D529}",
    lg: "\u2276",
    lgE: "\u2A91",
    lHar: "\u2962",
    lhard: "\u21BD",
    lharu: "\u21BC",
    lharul: "\u296A",
    lhblk: "\u2584",
    LJcy: "\u0409",
    ljcy: "\u0459",
    Ll: "\u22D8",
    ll: "\u226A",
    llarr: "\u21C7",
    llcorner: "\u231E",
    Lleftarrow: "\u21DA",
    llhard: "\u296B",
    lltri: "\u25FA",
    Lmidot: "\u013F",
    lmidot: "\u0140",
    lmoust: "\u23B0",
    lmoustache: "\u23B0",
    lnap: "\u2A89",
    lnapprox: "\u2A89",
    lnE: "\u2268",
    lne: "\u2A87",
    lneq: "\u2A87",
    lneqq: "\u2268",
    lnsim: "\u22E6",
    loang: "\u27EC",
    loarr: "\u21FD",
    lobrk: "\u27E6",
    LongLeftArrow: "\u27F5",
    Longleftarrow: "\u27F8",
    longleftarrow: "\u27F5",
    LongLeftRightArrow: "\u27F7",
    Longleftrightarrow: "\u27FA",
    longleftrightarrow: "\u27F7",
    longmapsto: "\u27FC",
    LongRightArrow: "\u27F6",
    Longrightarrow: "\u27F9",
    longrightarrow: "\u27F6",
    looparrowleft: "\u21AB",
    looparrowright: "\u21AC",
    lopar: "\u2985",
    Lopf: "\u{1D543}",
    lopf: "\u{1D55D}",
    loplus: "\u2A2D",
    lotimes: "\u2A34",
    lowast: "\u2217",
    lowbar: "_",
    LowerLeftArrow: "\u2199",
    LowerRightArrow: "\u2198",
    loz: "\u25CA",
    lozenge: "\u25CA",
    lozf: "\u29EB",
    lpar: "(",
    lparlt: "\u2993",
    lrarr: "\u21C6",
    lrcorner: "\u231F",
    lrhar: "\u21CB",
    lrhard: "\u296D",
    lrm: "\u200E",
    lrtri: "\u22BF",
    lsaquo: "\u2039",
    Lscr: "\u2112",
    lscr: "\u{1D4C1}",
    Lsh: "\u21B0",
    lsh: "\u21B0",
    lsim: "\u2272",
    lsime: "\u2A8D",
    lsimg: "\u2A8F",
    lsqb: "[",
    lsquo: "\u2018",
    lsquor: "\u201A",
    Lstrok: "\u0141",
    lstrok: "\u0142",
    Lt: "\u226A",
    LT: "<",
    lt: "<",
    ltcc: "\u2AA6",
    ltcir: "\u2A79",
    ltdot: "\u22D6",
    lthree: "\u22CB",
    ltimes: "\u22C9",
    ltlarr: "\u2976",
    ltquest: "\u2A7B",
    ltri: "\u25C3",
    ltrie: "\u22B4",
    ltrif: "\u25C2",
    ltrPar: "\u2996",
    lurdshar: "\u294A",
    luruhar: "\u2966",
    lvertneqq: "\u2268\uFE00",
    lvnE: "\u2268\uFE00",
    macr: "\xAF",
    male: "\u2642",
    malt: "\u2720",
    maltese: "\u2720",
    Map: "\u2905",
    map: "\u21A6",
    mapsto: "\u21A6",
    mapstodown: "\u21A7",
    mapstoleft: "\u21A4",
    mapstoup: "\u21A5",
    marker: "\u25AE",
    mcomma: "\u2A29",
    Mcy: "\u041C",
    mcy: "\u043C",
    mdash: "\u2014",
    mDDot: "\u223A",
    measuredangle: "\u2221",
    MediumSpace: "\u205F",
    Mellintrf: "\u2133",
    Mfr: "\u{1D510}",
    mfr: "\u{1D52A}",
    mho: "\u2127",
    micro: "\xB5",
    mid: "\u2223",
    midast: "*",
    midcir: "\u2AF0",
    middot: "\xB7",
    minus: "\u2212",
    minusb: "\u229F",
    minusd: "\u2238",
    minusdu: "\u2A2A",
    MinusPlus: "\u2213",
    mlcp: "\u2ADB",
    mldr: "\u2026",
    mnplus: "\u2213",
    models: "\u22A7",
    Mopf: "\u{1D544}",
    mopf: "\u{1D55E}",
    mp: "\u2213",
    Mscr: "\u2133",
    mscr: "\u{1D4C2}",
    mstpos: "\u223E",
    Mu: "\u039C",
    mu: "\u03BC",
    multimap: "\u22B8",
    mumap: "\u22B8",
    nabla: "\u2207",
    Nacute: "\u0143",
    nacute: "\u0144",
    nang: "\u2220\u20D2",
    nap: "\u2249",
    napE: "\u2A70\u0338",
    napid: "\u224B\u0338",
    napos: "\u0149",
    napprox: "\u2249",
    natur: "\u266E",
    natural: "\u266E",
    naturals: "\u2115",
    nbsp: "\xA0",
    nbump: "\u224E\u0338",
    nbumpe: "\u224F\u0338",
    ncap: "\u2A43",
    Ncaron: "\u0147",
    ncaron: "\u0148",
    Ncedil: "\u0145",
    ncedil: "\u0146",
    ncong: "\u2247",
    ncongdot: "\u2A6D\u0338",
    ncup: "\u2A42",
    Ncy: "\u041D",
    ncy: "\u043D",
    ndash: "\u2013",
    ne: "\u2260",
    nearhk: "\u2924",
    neArr: "\u21D7",
    nearr: "\u2197",
    nearrow: "\u2197",
    nedot: "\u2250\u0338",
    NegativeMediumSpace: "\u200B",
    NegativeThickSpace: "\u200B",
    NegativeThinSpace: "\u200B",
    NegativeVeryThinSpace: "\u200B",
    nequiv: "\u2262",
    nesear: "\u2928",
    nesim: "\u2242\u0338",
    NestedGreaterGreater: "\u226B",
    NestedLessLess: "\u226A",
    NewLine: `
`,
    nexist: "\u2204",
    nexists: "\u2204",
    Nfr: "\u{1D511}",
    nfr: "\u{1D52B}",
    ngE: "\u2267\u0338",
    nge: "\u2271",
    ngeq: "\u2271",
    ngeqq: "\u2267\u0338",
    ngeqslant: "\u2A7E\u0338",
    nges: "\u2A7E\u0338",
    nGg: "\u22D9\u0338",
    ngsim: "\u2275",
    nGt: "\u226B\u20D2",
    ngt: "\u226F",
    ngtr: "\u226F",
    nGtv: "\u226B\u0338",
    nhArr: "\u21CE",
    nharr: "\u21AE",
    nhpar: "\u2AF2",
    ni: "\u220B",
    nis: "\u22FC",
    nisd: "\u22FA",
    niv: "\u220B",
    NJcy: "\u040A",
    njcy: "\u045A",
    nlArr: "\u21CD",
    nlarr: "\u219A",
    nldr: "\u2025",
    nlE: "\u2266\u0338",
    nle: "\u2270",
    nLeftarrow: "\u21CD",
    nleftarrow: "\u219A",
    nLeftrightarrow: "\u21CE",
    nleftrightarrow: "\u21AE",
    nleq: "\u2270",
    nleqq: "\u2266\u0338",
    nleqslant: "\u2A7D\u0338",
    nles: "\u2A7D\u0338",
    nless: "\u226E",
    nLl: "\u22D8\u0338",
    nlsim: "\u2274",
    nLt: "\u226A\u20D2",
    nlt: "\u226E",
    nltri: "\u22EA",
    nltrie: "\u22EC",
    nLtv: "\u226A\u0338",
    nmid: "\u2224",
    NoBreak: "\u2060",
    NonBreakingSpace: "\xA0",
    Nopf: "\u2115",
    nopf: "\u{1D55F}",
    Not: "\u2AEC",
    not: "\xAC",
    NotCongruent: "\u2262",
    NotCupCap: "\u226D",
    NotDoubleVerticalBar: "\u2226",
    NotElement: "\u2209",
    NotEqual: "\u2260",
    NotEqualTilde: "\u2242\u0338",
    NotExists: "\u2204",
    NotGreater: "\u226F",
    NotGreaterEqual: "\u2271",
    NotGreaterFullEqual: "\u2267\u0338",
    NotGreaterGreater: "\u226B\u0338",
    NotGreaterLess: "\u2279",
    NotGreaterSlantEqual: "\u2A7E\u0338",
    NotGreaterTilde: "\u2275",
    NotHumpDownHump: "\u224E\u0338",
    NotHumpEqual: "\u224F\u0338",
    notin: "\u2209",
    notindot: "\u22F5\u0338",
    notinE: "\u22F9\u0338",
    notinva: "\u2209",
    notinvb: "\u22F7",
    notinvc: "\u22F6",
    NotLeftTriangle: "\u22EA",
    NotLeftTriangleBar: "\u29CF\u0338",
    NotLeftTriangleEqual: "\u22EC",
    NotLess: "\u226E",
    NotLessEqual: "\u2270",
    NotLessGreater: "\u2278",
    NotLessLess: "\u226A\u0338",
    NotLessSlantEqual: "\u2A7D\u0338",
    NotLessTilde: "\u2274",
    NotNestedGreaterGreater: "\u2AA2\u0338",
    NotNestedLessLess: "\u2AA1\u0338",
    notni: "\u220C",
    notniva: "\u220C",
    notnivb: "\u22FE",
    notnivc: "\u22FD",
    NotPrecedes: "\u2280",
    NotPrecedesEqual: "\u2AAF\u0338",
    NotPrecedesSlantEqual: "\u22E0",
    NotReverseElement: "\u220C",
    NotRightTriangle: "\u22EB",
    NotRightTriangleBar: "\u29D0\u0338",
    NotRightTriangleEqual: "\u22ED",
    NotSquareSubset: "\u228F\u0338",
    NotSquareSubsetEqual: "\u22E2",
    NotSquareSuperset: "\u2290\u0338",
    NotSquareSupersetEqual: "\u22E3",
    NotSubset: "\u2282\u20D2",
    NotSubsetEqual: "\u2288",
    NotSucceeds: "\u2281",
    NotSucceedsEqual: "\u2AB0\u0338",
    NotSucceedsSlantEqual: "\u22E1",
    NotSucceedsTilde: "\u227F\u0338",
    NotSuperset: "\u2283\u20D2",
    NotSupersetEqual: "\u2289",
    NotTilde: "\u2241",
    NotTildeEqual: "\u2244",
    NotTildeFullEqual: "\u2247",
    NotTildeTilde: "\u2249",
    NotVerticalBar: "\u2224",
    npar: "\u2226",
    nparallel: "\u2226",
    nparsl: "\u2AFD\u20E5",
    npart: "\u2202\u0338",
    npolint: "\u2A14",
    npr: "\u2280",
    nprcue: "\u22E0",
    npre: "\u2AAF\u0338",
    nprec: "\u2280",
    npreceq: "\u2AAF\u0338",
    nrArr: "\u21CF",
    nrarr: "\u219B",
    nrarrc: "\u2933\u0338",
    nrarrw: "\u219D\u0338",
    nRightarrow: "\u21CF",
    nrightarrow: "\u219B",
    nrtri: "\u22EB",
    nrtrie: "\u22ED",
    nsc: "\u2281",
    nsccue: "\u22E1",
    nsce: "\u2AB0\u0338",
    Nscr: "\u{1D4A9}",
    nscr: "\u{1D4C3}",
    nshortmid: "\u2224",
    nshortparallel: "\u2226",
    nsim: "\u2241",
    nsime: "\u2244",
    nsimeq: "\u2244",
    nsmid: "\u2224",
    nspar: "\u2226",
    nsqsube: "\u22E2",
    nsqsupe: "\u22E3",
    nsub: "\u2284",
    nsubE: "\u2AC5\u0338",
    nsube: "\u2288",
    nsubset: "\u2282\u20D2",
    nsubseteq: "\u2288",
    nsubseteqq: "\u2AC5\u0338",
    nsucc: "\u2281",
    nsucceq: "\u2AB0\u0338",
    nsup: "\u2285",
    nsupE: "\u2AC6\u0338",
    nsupe: "\u2289",
    nsupset: "\u2283\u20D2",
    nsupseteq: "\u2289",
    nsupseteqq: "\u2AC6\u0338",
    ntgl: "\u2279",
    Ntilde: "\xD1",
    ntilde: "\xF1",
    ntlg: "\u2278",
    ntriangleleft: "\u22EA",
    ntrianglelefteq: "\u22EC",
    ntriangleright: "\u22EB",
    ntrianglerighteq: "\u22ED",
    Nu: "\u039D",
    nu: "\u03BD",
    num: "#",
    numero: "\u2116",
    numsp: "\u2007",
    nvap: "\u224D\u20D2",
    nVDash: "\u22AF",
    nVdash: "\u22AE",
    nvDash: "\u22AD",
    nvdash: "\u22AC",
    nvge: "\u2265\u20D2",
    nvgt: ">\u20D2",
    nvHarr: "\u2904",
    nvinfin: "\u29DE",
    nvlArr: "\u2902",
    nvle: "\u2264\u20D2",
    nvlt: "<\u20D2",
    nvltrie: "\u22B4\u20D2",
    nvrArr: "\u2903",
    nvrtrie: "\u22B5\u20D2",
    nvsim: "\u223C\u20D2",
    nwarhk: "\u2923",
    nwArr: "\u21D6",
    nwarr: "\u2196",
    nwarrow: "\u2196",
    nwnear: "\u2927",
    Oacute: "\xD3",
    oacute: "\xF3",
    oast: "\u229B",
    ocir: "\u229A",
    Ocirc: "\xD4",
    ocirc: "\xF4",
    Ocy: "\u041E",
    ocy: "\u043E",
    odash: "\u229D",
    Odblac: "\u0150",
    odblac: "\u0151",
    odiv: "\u2A38",
    odot: "\u2299",
    odsold: "\u29BC",
    OElig: "\u0152",
    oelig: "\u0153",
    ofcir: "\u29BF",
    Ofr: "\u{1D512}",
    ofr: "\u{1D52C}",
    ogon: "\u02DB",
    Ograve: "\xD2",
    ograve: "\xF2",
    ogt: "\u29C1",
    ohbar: "\u29B5",
    ohm: "\u03A9",
    oint: "\u222E",
    olarr: "\u21BA",
    olcir: "\u29BE",
    olcross: "\u29BB",
    oline: "\u203E",
    olt: "\u29C0",
    Omacr: "\u014C",
    omacr: "\u014D",
    Omega: "\u03A9",
    omega: "\u03C9",
    Omicron: "\u039F",
    omicron: "\u03BF",
    omid: "\u29B6",
    ominus: "\u2296",
    Oopf: "\u{1D546}",
    oopf: "\u{1D560}",
    opar: "\u29B7",
    OpenCurlyDoubleQuote: "\u201C",
    OpenCurlyQuote: "\u2018",
    operp: "\u29B9",
    oplus: "\u2295",
    Or: "\u2A54",
    or: "\u2228",
    orarr: "\u21BB",
    ord: "\u2A5D",
    order: "\u2134",
    orderof: "\u2134",
    ordf: "\xAA",
    ordm: "\xBA",
    origof: "\u22B6",
    oror: "\u2A56",
    orslope: "\u2A57",
    orv: "\u2A5B",
    oS: "\u24C8",
    Oscr: "\u{1D4AA}",
    oscr: "\u2134",
    Oslash: "\xD8",
    oslash: "\xF8",
    osol: "\u2298",
    Otilde: "\xD5",
    otilde: "\xF5",
    Otimes: "\u2A37",
    otimes: "\u2297",
    otimesas: "\u2A36",
    Ouml: "\xD6",
    ouml: "\xF6",
    ovbar: "\u233D",
    OverBar: "\u203E",
    OverBrace: "\u23DE",
    OverBracket: "\u23B4",
    OverParenthesis: "\u23DC",
    par: "\u2225",
    para: "\xB6",
    parallel: "\u2225",
    parsim: "\u2AF3",
    parsl: "\u2AFD",
    part: "\u2202",
    PartialD: "\u2202",
    Pcy: "\u041F",
    pcy: "\u043F",
    percnt: "%",
    period: ".",
    permil: "\u2030",
    perp: "\u22A5",
    pertenk: "\u2031",
    Pfr: "\u{1D513}",
    pfr: "\u{1D52D}",
    Phi: "\u03A6",
    phi: "\u03C6",
    phiv: "\u03D5",
    phmmat: "\u2133",
    phone: "\u260E",
    Pi: "\u03A0",
    pi: "\u03C0",
    pitchfork: "\u22D4",
    piv: "\u03D6",
    planck: "\u210F",
    planckh: "\u210E",
    plankv: "\u210F",
    plus: "+",
    plusacir: "\u2A23",
    plusb: "\u229E",
    pluscir: "\u2A22",
    plusdo: "\u2214",
    plusdu: "\u2A25",
    pluse: "\u2A72",
    PlusMinus: "\xB1",
    plusmn: "\xB1",
    plussim: "\u2A26",
    plustwo: "\u2A27",
    pm: "\xB1",
    Poincareplane: "\u210C",
    pointint: "\u2A15",
    Popf: "\u2119",
    popf: "\u{1D561}",
    pound: "\xA3",
    Pr: "\u2ABB",
    pr: "\u227A",
    prap: "\u2AB7",
    prcue: "\u227C",
    prE: "\u2AB3",
    pre: "\u2AAF",
    prec: "\u227A",
    precapprox: "\u2AB7",
    preccurlyeq: "\u227C",
    Precedes: "\u227A",
    PrecedesEqual: "\u2AAF",
    PrecedesSlantEqual: "\u227C",
    PrecedesTilde: "\u227E",
    preceq: "\u2AAF",
    precnapprox: "\u2AB9",
    precneqq: "\u2AB5",
    precnsim: "\u22E8",
    precsim: "\u227E",
    Prime: "\u2033",
    prime: "\u2032",
    primes: "\u2119",
    prnap: "\u2AB9",
    prnE: "\u2AB5",
    prnsim: "\u22E8",
    prod: "\u220F",
    Product: "\u220F",
    profalar: "\u232E",
    profline: "\u2312",
    profsurf: "\u2313",
    prop: "\u221D",
    Proportion: "\u2237",
    Proportional: "\u221D",
    propto: "\u221D",
    prsim: "\u227E",
    prurel: "\u22B0",
    Pscr: "\u{1D4AB}",
    pscr: "\u{1D4C5}",
    Psi: "\u03A8",
    psi: "\u03C8",
    puncsp: "\u2008",
    Qfr: "\u{1D514}",
    qfr: "\u{1D52E}",
    qint: "\u2A0C",
    Qopf: "\u211A",
    qopf: "\u{1D562}",
    qprime: "\u2057",
    Qscr: "\u{1D4AC}",
    qscr: "\u{1D4C6}",
    quaternions: "\u210D",
    quatint: "\u2A16",
    quest: "?",
    questeq: "\u225F",
    QUOT: '"',
    quot: '"',
    rAarr: "\u21DB",
    race: "\u223D\u0331",
    Racute: "\u0154",
    racute: "\u0155",
    radic: "\u221A",
    raemptyv: "\u29B3",
    Rang: "\u27EB",
    rang: "\u27E9",
    rangd: "\u2992",
    range: "\u29A5",
    rangle: "\u27E9",
    raquo: "\xBB",
    Rarr: "\u21A0",
    rArr: "\u21D2",
    rarr: "\u2192",
    rarrap: "\u2975",
    rarrb: "\u21E5",
    rarrbfs: "\u2920",
    rarrc: "\u2933",
    rarrfs: "\u291E",
    rarrhk: "\u21AA",
    rarrlp: "\u21AC",
    rarrpl: "\u2945",
    rarrsim: "\u2974",
    Rarrtl: "\u2916",
    rarrtl: "\u21A3",
    rarrw: "\u219D",
    rAtail: "\u291C",
    ratail: "\u291A",
    ratio: "\u2236",
    rationals: "\u211A",
    RBarr: "\u2910",
    rBarr: "\u290F",
    rbarr: "\u290D",
    rbbrk: "\u2773",
    rbrace: "}",
    rbrack: "]",
    rbrke: "\u298C",
    rbrksld: "\u298E",
    rbrkslu: "\u2990",
    Rcaron: "\u0158",
    rcaron: "\u0159",
    Rcedil: "\u0156",
    rcedil: "\u0157",
    rceil: "\u2309",
    rcub: "}",
    Rcy: "\u0420",
    rcy: "\u0440",
    rdca: "\u2937",
    rdldhar: "\u2969",
    rdquo: "\u201D",
    rdquor: "\u201D",
    rdsh: "\u21B3",
    Re: "\u211C",
    real: "\u211C",
    realine: "\u211B",
    realpart: "\u211C",
    reals: "\u211D",
    rect: "\u25AD",
    REG: "\xAE",
    reg: "\xAE",
    ReverseElement: "\u220B",
    ReverseEquilibrium: "\u21CB",
    ReverseUpEquilibrium: "\u296F",
    rfisht: "\u297D",
    rfloor: "\u230B",
    Rfr: "\u211C",
    rfr: "\u{1D52F}",
    rHar: "\u2964",
    rhard: "\u21C1",
    rharu: "\u21C0",
    rharul: "\u296C",
    Rho: "\u03A1",
    rho: "\u03C1",
    rhov: "\u03F1",
    RightAngleBracket: "\u27E9",
    RightArrow: "\u2192",
    Rightarrow: "\u21D2",
    rightarrow: "\u2192",
    RightArrowBar: "\u21E5",
    RightArrowLeftArrow: "\u21C4",
    rightarrowtail: "\u21A3",
    RightCeiling: "\u2309",
    RightDoubleBracket: "\u27E7",
    RightDownTeeVector: "\u295D",
    RightDownVector: "\u21C2",
    RightDownVectorBar: "\u2955",
    RightFloor: "\u230B",
    rightharpoondown: "\u21C1",
    rightharpoonup: "\u21C0",
    rightleftarrows: "\u21C4",
    rightleftharpoons: "\u21CC",
    rightrightarrows: "\u21C9",
    rightsquigarrow: "\u219D",
    RightTee: "\u22A2",
    RightTeeArrow: "\u21A6",
    RightTeeVector: "\u295B",
    rightthreetimes: "\u22CC",
    RightTriangle: "\u22B3",
    RightTriangleBar: "\u29D0",
    RightTriangleEqual: "\u22B5",
    RightUpDownVector: "\u294F",
    RightUpTeeVector: "\u295C",
    RightUpVector: "\u21BE",
    RightUpVectorBar: "\u2954",
    RightVector: "\u21C0",
    RightVectorBar: "\u2953",
    ring: "\u02DA",
    risingdotseq: "\u2253",
    rlarr: "\u21C4",
    rlhar: "\u21CC",
    rlm: "\u200F",
    rmoust: "\u23B1",
    rmoustache: "\u23B1",
    rnmid: "\u2AEE",
    roang: "\u27ED",
    roarr: "\u21FE",
    robrk: "\u27E7",
    ropar: "\u2986",
    Ropf: "\u211D",
    ropf: "\u{1D563}",
    roplus: "\u2A2E",
    rotimes: "\u2A35",
    RoundImplies: "\u2970",
    rpar: ")",
    rpargt: "\u2994",
    rppolint: "\u2A12",
    rrarr: "\u21C9",
    Rrightarrow: "\u21DB",
    rsaquo: "\u203A",
    Rscr: "\u211B",
    rscr: "\u{1D4C7}",
    Rsh: "\u21B1",
    rsh: "\u21B1",
    rsqb: "]",
    rsquo: "\u2019",
    rsquor: "\u2019",
    rthree: "\u22CC",
    rtimes: "\u22CA",
    rtri: "\u25B9",
    rtrie: "\u22B5",
    rtrif: "\u25B8",
    rtriltri: "\u29CE",
    RuleDelayed: "\u29F4",
    ruluhar: "\u2968",
    rx: "\u211E",
    Sacute: "\u015A",
    sacute: "\u015B",
    sbquo: "\u201A",
    Sc: "\u2ABC",
    sc: "\u227B",
    scap: "\u2AB8",
    Scaron: "\u0160",
    scaron: "\u0161",
    sccue: "\u227D",
    scE: "\u2AB4",
    sce: "\u2AB0",
    Scedil: "\u015E",
    scedil: "\u015F",
    Scirc: "\u015C",
    scirc: "\u015D",
    scnap: "\u2ABA",
    scnE: "\u2AB6",
    scnsim: "\u22E9",
    scpolint: "\u2A13",
    scsim: "\u227F",
    Scy: "\u0421",
    scy: "\u0441",
    sdot: "\u22C5",
    sdotb: "\u22A1",
    sdote: "\u2A66",
    searhk: "\u2925",
    seArr: "\u21D8",
    searr: "\u2198",
    searrow: "\u2198",
    sect: "\xA7",
    semi: ";",
    seswar: "\u2929",
    setminus: "\u2216",
    setmn: "\u2216",
    sext: "\u2736",
    Sfr: "\u{1D516}",
    sfr: "\u{1D530}",
    sfrown: "\u2322",
    sharp: "\u266F",
    SHCHcy: "\u0429",
    shchcy: "\u0449",
    SHcy: "\u0428",
    shcy: "\u0448",
    ShortDownArrow: "\u2193",
    ShortLeftArrow: "\u2190",
    shortmid: "\u2223",
    shortparallel: "\u2225",
    ShortRightArrow: "\u2192",
    ShortUpArrow: "\u2191",
    shy: "\xAD",
    Sigma: "\u03A3",
    sigma: "\u03C3",
    sigmaf: "\u03C2",
    sigmav: "\u03C2",
    sim: "\u223C",
    simdot: "\u2A6A",
    sime: "\u2243",
    simeq: "\u2243",
    simg: "\u2A9E",
    simgE: "\u2AA0",
    siml: "\u2A9D",
    simlE: "\u2A9F",
    simne: "\u2246",
    simplus: "\u2A24",
    simrarr: "\u2972",
    slarr: "\u2190",
    SmallCircle: "\u2218",
    smallsetminus: "\u2216",
    smashp: "\u2A33",
    smeparsl: "\u29E4",
    smid: "\u2223",
    smile: "\u2323",
    smt: "\u2AAA",
    smte: "\u2AAC",
    smtes: "\u2AAC\uFE00",
    SOFTcy: "\u042C",
    softcy: "\u044C",
    sol: "/",
    solb: "\u29C4",
    solbar: "\u233F",
    Sopf: "\u{1D54A}",
    sopf: "\u{1D564}",
    spades: "\u2660",
    spadesuit: "\u2660",
    spar: "\u2225",
    sqcap: "\u2293",
    sqcaps: "\u2293\uFE00",
    sqcup: "\u2294",
    sqcups: "\u2294\uFE00",
    Sqrt: "\u221A",
    sqsub: "\u228F",
    sqsube: "\u2291",
    sqsubset: "\u228F",
    sqsubseteq: "\u2291",
    sqsup: "\u2290",
    sqsupe: "\u2292",
    sqsupset: "\u2290",
    sqsupseteq: "\u2292",
    squ: "\u25A1",
    Square: "\u25A1",
    square: "\u25A1",
    SquareIntersection: "\u2293",
    SquareSubset: "\u228F",
    SquareSubsetEqual: "\u2291",
    SquareSuperset: "\u2290",
    SquareSupersetEqual: "\u2292",
    SquareUnion: "\u2294",
    squarf: "\u25AA",
    squf: "\u25AA",
    srarr: "\u2192",
    Sscr: "\u{1D4AE}",
    sscr: "\u{1D4C8}",
    ssetmn: "\u2216",
    ssmile: "\u2323",
    sstarf: "\u22C6",
    Star: "\u22C6",
    star: "\u2606",
    starf: "\u2605",
    straightepsilon: "\u03F5",
    straightphi: "\u03D5",
    strns: "\xAF",
    Sub: "\u22D0",
    sub: "\u2282",
    subdot: "\u2ABD",
    subE: "\u2AC5",
    sube: "\u2286",
    subedot: "\u2AC3",
    submult: "\u2AC1",
    subnE: "\u2ACB",
    subne: "\u228A",
    subplus: "\u2ABF",
    subrarr: "\u2979",
    Subset: "\u22D0",
    subset: "\u2282",
    subseteq: "\u2286",
    subseteqq: "\u2AC5",
    SubsetEqual: "\u2286",
    subsetneq: "\u228A",
    subsetneqq: "\u2ACB",
    subsim: "\u2AC7",
    subsub: "\u2AD5",
    subsup: "\u2AD3",
    succ: "\u227B",
    succapprox: "\u2AB8",
    succcurlyeq: "\u227D",
    Succeeds: "\u227B",
    SucceedsEqual: "\u2AB0",
    SucceedsSlantEqual: "\u227D",
    SucceedsTilde: "\u227F",
    succeq: "\u2AB0",
    succnapprox: "\u2ABA",
    succneqq: "\u2AB6",
    succnsim: "\u22E9",
    succsim: "\u227F",
    SuchThat: "\u220B",
    Sum: "\u2211",
    sum: "\u2211",
    sung: "\u266A",
    Sup: "\u22D1",
    sup: "\u2283",
    sup1: "\xB9",
    sup2: "\xB2",
    sup3: "\xB3",
    supdot: "\u2ABE",
    supdsub: "\u2AD8",
    supE: "\u2AC6",
    supe: "\u2287",
    supedot: "\u2AC4",
    Superset: "\u2283",
    SupersetEqual: "\u2287",
    suphsol: "\u27C9",
    suphsub: "\u2AD7",
    suplarr: "\u297B",
    supmult: "\u2AC2",
    supnE: "\u2ACC",
    supne: "\u228B",
    supplus: "\u2AC0",
    Supset: "\u22D1",
    supset: "\u2283",
    supseteq: "\u2287",
    supseteqq: "\u2AC6",
    supsetneq: "\u228B",
    supsetneqq: "\u2ACC",
    supsim: "\u2AC8",
    supsub: "\u2AD4",
    supsup: "\u2AD6",
    swarhk: "\u2926",
    swArr: "\u21D9",
    swarr: "\u2199",
    swarrow: "\u2199",
    swnwar: "\u292A",
    szlig: "\xDF",
    Tab: "	",
    target: "\u2316",
    Tau: "\u03A4",
    tau: "\u03C4",
    tbrk: "\u23B4",
    Tcaron: "\u0164",
    tcaron: "\u0165",
    Tcedil: "\u0162",
    tcedil: "\u0163",
    Tcy: "\u0422",
    tcy: "\u0442",
    tdot: "\u20DB",
    telrec: "\u2315",
    Tfr: "\u{1D517}",
    tfr: "\u{1D531}",
    there4: "\u2234",
    Therefore: "\u2234",
    therefore: "\u2234",
    Theta: "\u0398",
    theta: "\u03B8",
    thetasym: "\u03D1",
    thetav: "\u03D1",
    thickapprox: "\u2248",
    thicksim: "\u223C",
    ThickSpace: "\u205F\u200A",
    thinsp: "\u2009",
    ThinSpace: "\u2009",
    thkap: "\u2248",
    thksim: "\u223C",
    THORN: "\xDE",
    thorn: "\xFE",
    Tilde: "\u223C",
    tilde: "\u02DC",
    TildeEqual: "\u2243",
    TildeFullEqual: "\u2245",
    TildeTilde: "\u2248",
    times: "\xD7",
    timesb: "\u22A0",
    timesbar: "\u2A31",
    timesd: "\u2A30",
    tint: "\u222D",
    toea: "\u2928",
    top: "\u22A4",
    topbot: "\u2336",
    topcir: "\u2AF1",
    Topf: "\u{1D54B}",
    topf: "\u{1D565}",
    topfork: "\u2ADA",
    tosa: "\u2929",
    tprime: "\u2034",
    TRADE: "\u2122",
    trade: "\u2122",
    triangle: "\u25B5",
    triangledown: "\u25BF",
    triangleleft: "\u25C3",
    trianglelefteq: "\u22B4",
    triangleq: "\u225C",
    triangleright: "\u25B9",
    trianglerighteq: "\u22B5",
    tridot: "\u25EC",
    trie: "\u225C",
    triminus: "\u2A3A",
    TripleDot: "\u20DB",
    triplus: "\u2A39",
    trisb: "\u29CD",
    tritime: "\u2A3B",
    trpezium: "\u23E2",
    Tscr: "\u{1D4AF}",
    tscr: "\u{1D4C9}",
    TScy: "\u0426",
    tscy: "\u0446",
    TSHcy: "\u040B",
    tshcy: "\u045B",
    Tstrok: "\u0166",
    tstrok: "\u0167",
    twixt: "\u226C",
    twoheadleftarrow: "\u219E",
    twoheadrightarrow: "\u21A0",
    Uacute: "\xDA",
    uacute: "\xFA",
    Uarr: "\u219F",
    uArr: "\u21D1",
    uarr: "\u2191",
    Uarrocir: "\u2949",
    Ubrcy: "\u040E",
    ubrcy: "\u045E",
    Ubreve: "\u016C",
    ubreve: "\u016D",
    Ucirc: "\xDB",
    ucirc: "\xFB",
    Ucy: "\u0423",
    ucy: "\u0443",
    udarr: "\u21C5",
    Udblac: "\u0170",
    udblac: "\u0171",
    udhar: "\u296E",
    ufisht: "\u297E",
    Ufr: "\u{1D518}",
    ufr: "\u{1D532}",
    Ugrave: "\xD9",
    ugrave: "\xF9",
    uHar: "\u2963",
    uharl: "\u21BF",
    uharr: "\u21BE",
    uhblk: "\u2580",
    ulcorn: "\u231C",
    ulcorner: "\u231C",
    ulcrop: "\u230F",
    ultri: "\u25F8",
    Umacr: "\u016A",
    umacr: "\u016B",
    uml: "\xA8",
    UnderBar: "_",
    UnderBrace: "\u23DF",
    UnderBracket: "\u23B5",
    UnderParenthesis: "\u23DD",
    Union: "\u22C3",
    UnionPlus: "\u228E",
    Uogon: "\u0172",
    uogon: "\u0173",
    Uopf: "\u{1D54C}",
    uopf: "\u{1D566}",
    UpArrow: "\u2191",
    Uparrow: "\u21D1",
    uparrow: "\u2191",
    UpArrowBar: "\u2912",
    UpArrowDownArrow: "\u21C5",
    UpDownArrow: "\u2195",
    Updownarrow: "\u21D5",
    updownarrow: "\u2195",
    UpEquilibrium: "\u296E",
    upharpoonleft: "\u21BF",
    upharpoonright: "\u21BE",
    uplus: "\u228E",
    UpperLeftArrow: "\u2196",
    UpperRightArrow: "\u2197",
    Upsi: "\u03D2",
    upsi: "\u03C5",
    upsih: "\u03D2",
    Upsilon: "\u03A5",
    upsilon: "\u03C5",
    UpTee: "\u22A5",
    UpTeeArrow: "\u21A5",
    upuparrows: "\u21C8",
    urcorn: "\u231D",
    urcorner: "\u231D",
    urcrop: "\u230E",
    Uring: "\u016E",
    uring: "\u016F",
    urtri: "\u25F9",
    Uscr: "\u{1D4B0}",
    uscr: "\u{1D4CA}",
    utdot: "\u22F0",
    Utilde: "\u0168",
    utilde: "\u0169",
    utri: "\u25B5",
    utrif: "\u25B4",
    uuarr: "\u21C8",
    Uuml: "\xDC",
    uuml: "\xFC",
    uwangle: "\u29A7",
    vangrt: "\u299C",
    varepsilon: "\u03F5",
    varkappa: "\u03F0",
    varnothing: "\u2205",
    varphi: "\u03D5",
    varpi: "\u03D6",
    varpropto: "\u221D",
    vArr: "\u21D5",
    varr: "\u2195",
    varrho: "\u03F1",
    varsigma: "\u03C2",
    varsubsetneq: "\u228A\uFE00",
    varsubsetneqq: "\u2ACB\uFE00",
    varsupsetneq: "\u228B\uFE00",
    varsupsetneqq: "\u2ACC\uFE00",
    vartheta: "\u03D1",
    vartriangleleft: "\u22B2",
    vartriangleright: "\u22B3",
    Vbar: "\u2AEB",
    vBar: "\u2AE8",
    vBarv: "\u2AE9",
    Vcy: "\u0412",
    vcy: "\u0432",
    VDash: "\u22AB",
    Vdash: "\u22A9",
    vDash: "\u22A8",
    vdash: "\u22A2",
    Vdashl: "\u2AE6",
    Vee: "\u22C1",
    vee: "\u2228",
    veebar: "\u22BB",
    veeeq: "\u225A",
    vellip: "\u22EE",
    Verbar: "\u2016",
    verbar: "|",
    Vert: "\u2016",
    vert: "|",
    VerticalBar: "\u2223",
    VerticalLine: "|",
    VerticalSeparator: "\u2758",
    VerticalTilde: "\u2240",
    VeryThinSpace: "\u200A",
    Vfr: "\u{1D519}",
    vfr: "\u{1D533}",
    vltri: "\u22B2",
    vnsub: "\u2282\u20D2",
    vnsup: "\u2283\u20D2",
    Vopf: "\u{1D54D}",
    vopf: "\u{1D567}",
    vprop: "\u221D",
    vrtri: "\u22B3",
    Vscr: "\u{1D4B1}",
    vscr: "\u{1D4CB}",
    vsubnE: "\u2ACB\uFE00",
    vsubne: "\u228A\uFE00",
    vsupnE: "\u2ACC\uFE00",
    vsupne: "\u228B\uFE00",
    Vvdash: "\u22AA",
    vzigzag: "\u299A",
    Wcirc: "\u0174",
    wcirc: "\u0175",
    wedbar: "\u2A5F",
    Wedge: "\u22C0",
    wedge: "\u2227",
    wedgeq: "\u2259",
    weierp: "\u2118",
    Wfr: "\u{1D51A}",
    wfr: "\u{1D534}",
    Wopf: "\u{1D54E}",
    wopf: "\u{1D568}",
    wp: "\u2118",
    wr: "\u2240",
    wreath: "\u2240",
    Wscr: "\u{1D4B2}",
    wscr: "\u{1D4CC}",
    xcap: "\u22C2",
    xcirc: "\u25EF",
    xcup: "\u22C3",
    xdtri: "\u25BD",
    Xfr: "\u{1D51B}",
    xfr: "\u{1D535}",
    xhArr: "\u27FA",
    xharr: "\u27F7",
    Xi: "\u039E",
    xi: "\u03BE",
    xlArr: "\u27F8",
    xlarr: "\u27F5",
    xmap: "\u27FC",
    xnis: "\u22FB",
    xodot: "\u2A00",
    Xopf: "\u{1D54F}",
    xopf: "\u{1D569}",
    xoplus: "\u2A01",
    xotime: "\u2A02",
    xrArr: "\u27F9",
    xrarr: "\u27F6",
    Xscr: "\u{1D4B3}",
    xscr: "\u{1D4CD}",
    xsqcup: "\u2A06",
    xuplus: "\u2A04",
    xutri: "\u25B3",
    xvee: "\u22C1",
    xwedge: "\u22C0",
    Yacute: "\xDD",
    yacute: "\xFD",
    YAcy: "\u042F",
    yacy: "\u044F",
    Ycirc: "\u0176",
    ycirc: "\u0177",
    Ycy: "\u042B",
    ycy: "\u044B",
    yen: "\xA5",
    Yfr: "\u{1D51C}",
    yfr: "\u{1D536}",
    YIcy: "\u0407",
    yicy: "\u0457",
    Yopf: "\u{1D550}",
    yopf: "\u{1D56A}",
    Yscr: "\u{1D4B4}",
    yscr: "\u{1D4CE}",
    YUcy: "\u042E",
    yucy: "\u044E",
    Yuml: "\u0178",
    yuml: "\xFF",
    Zacute: "\u0179",
    zacute: "\u017A",
    Zcaron: "\u017D",
    zcaron: "\u017E",
    Zcy: "\u0417",
    zcy: "\u0437",
    Zdot: "\u017B",
    zdot: "\u017C",
    zeetrf: "\u2128",
    ZeroWidthSpace: "\u200B",
    Zeta: "\u0396",
    zeta: "\u03B6",
    Zfr: "\u2128",
    zfr: "\u{1D537}",
    ZHcy: "\u0416",
    zhcy: "\u0436",
    zigrarr: "\u21DD",
    Zopf: "\u2124",
    zopf: "\u{1D56B}",
    Zscr: "\u{1D4B5}",
    zscr: "\u{1D4CF}",
    zwj: "\u200D",
    zwnj: "\u200C",
  });
  Ie.entityMap = Ie.HTML_ENTITIES;
});
var xt = ue((wr) => {
  var Me = we().NAMESPACE,
    Sr =
      /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/,
    vt = new RegExp(
      "[\\-\\.0-9" +
        Sr.source.slice(1, -1) +
        "\\u00B7\\u0300-\\u036F\\u203F-\\u2040]",
    ),
    Et = new RegExp(
      "^" + Sr.source + vt.source + "*(?::" + Sr.source + vt.source + "*)?$",
    ),
    Oe = 0,
    oe = 1,
    fe = 2,
    Re = 3,
    ge = 4,
    he = 5,
    Fe = 6,
    er = 7;
  function Ae(e, r) {
    ((this.message = e),
      (this.locator = r),
      Error.captureStackTrace && Error.captureStackTrace(this, Ae));
  }
  Ae.prototype = new Error();
  Ae.prototype.name = Ae.name;
  function St() {}
  St.prototype = {
    parse: function (e, r, t) {
      var n = this.domBuilder;
      (n.startDocument(),
        wt(r, (r = {})),
        Un(e, r, t, n, this.errorHandler),
        n.endDocument());
    },
  };
  function Un(e, r, t, n, u) {
    function i(S) {
      if (S > 65535) {
        S -= 65536;
        var q = 55296 + (S >> 10),
          en = 56320 + (S & 1023);
        return String.fromCharCode(q, en);
      } else return String.fromCharCode(S);
    }
    function o(S) {
      var q = S.slice(1, -1);
      return Object.hasOwnProperty.call(t, q)
        ? t[q]
        : q.charAt(0) === "#"
          ? i(parseInt(q.substr(1).replace("x", "0x")))
          : (u.error("entity not found:" + S), S);
    }
    function s(S) {
      if (S > D) {
        var q = e.substring(D, S).replace(/&#?\w+;/g, o);
        (d && l(D), n.characters(q, 0, S - D), (D = S));
      }
    }
    function l(S, q) {
      for (; S >= c && (q = m.exec(e));)
        ((a = q.index), (c = a + q[0].length), d.lineNumber++);
      d.columnNumber = S - a + 1;
    }
    for (
      var a = 0,
        c = 0,
        m = /.*(?:\r\n?|\n)|.*$/g,
        d = n.locator,
        h = [{ currentNSMap: r }],
        A = {},
        D = 0;
      ;
    ) {
      try {
        var y = e.indexOf("<", D);
        if (y < 0) {
          if (!e.substr(D).match(/^\s*$/)) {
            var B = n.doc,
              x = B.createTextNode(e.substr(D));
            (B.appendChild(x), (n.currentElement = x));
          }
          return;
        }
        switch ((y > D && s(y), e.charAt(y + 1))) {
          case "/":
            var g = e.indexOf(">", y + 3),
              b = e.substring(y + 2, g).replace(/[ \t\n\r]+$/g, ""),
              p = h.pop();
            g < 0
              ? ((b = e.substring(y + 2).replace(/[\s<].*/, "")),
                u.error("end tag name: " + b + " is not complete:" + p.tagName),
                (g = y + 1 + b.length))
              : b.match(/\s</) &&
                ((b = b.replace(/[\s<].*/, "")),
                u.error("end tag name: " + b + " maybe not complete"),
                (g = y + 1 + b.length));
            var f = p.localNSMap,
              v = p.tagName == b,
              E =
                v || (p.tagName && p.tagName.toLowerCase() == b.toLowerCase());
            if (E) {
              if ((n.endElement(p.uri, p.localName, b), f))
                for (var C in f)
                  Object.prototype.hasOwnProperty.call(f, C) &&
                    n.endPrefixMapping(C);
              v ||
                u.fatalError(
                  "end tag name: " +
                    b +
                    " is not match the current start tagName:" +
                    p.tagName,
                );
            } else h.push(p);
            g++;
            break;
          case "?":
            (d && l(y), (g = Hn(e, y, n)));
            break;
          case "!":
            (d && l(y), (g = Gn(e, y, n, u)));
            break;
          default:
            d && l(y);
            var _ = new Tt(),
              R = h[h.length - 1].currentNSMap,
              g = qn(e, y, _, R, o, u),
              M = _.length;
            if (
              (!_.closed &&
                zn(e, g, _.tagName, A) &&
                ((_.closed = !0),
                t.nbsp || u.warning("unclosed xml attribute")),
              d && M)
            ) {
              for (var O = _t(d, {}), X = 0; X < M; X++) {
                var ne = _[X];
                (l(ne.offset), (ne.locator = _t(d, {})));
              }
              ((n.locator = O), bt(_, n, R) && h.push(_), (n.locator = d));
            } else bt(_, n, R) && h.push(_);
            Me.isHTML(_.uri) && !_.closed
              ? (g = Vn(e, g, _.tagName, o, n))
              : g++;
        }
      } catch (S) {
        if (S instanceof Ae) throw S;
        (u.error("element parse error: " + S), (g = -1));
      }
      g > D ? (D = g) : s(Math.max(y, D) + 1);
    }
  }
  function _t(e, r) {
    return (
      (r.lineNumber = e.lineNumber),
      (r.columnNumber = e.columnNumber),
      r
    );
  }
  function qn(e, r, t, n, u, i) {
    function o(h, A, D) {
      (t.attributeNames.hasOwnProperty(h) &&
        i.fatalError("Attribute " + h + " redefined"),
        t.addValue(h, A.replace(/[\t\n\r]/g, " ").replace(/&#?\w+;/g, u), D));
    }
    for (var s, l, a = ++r, c = Oe; ;) {
      var m = e.charAt(a);
      switch (m) {
        case "=":
          if (c === oe) ((s = e.slice(r, a)), (c = Re));
          else if (c === fe) c = Re;
          else throw new Error("attribute equal must after attrName");
          break;
        case "'":
        case '"':
          if (c === Re || c === oe)
            if (
              (c === oe &&
                (i.warning('attribute value must after "="'),
                (s = e.slice(r, a))),
              (r = a + 1),
              (a = e.indexOf(m, r)),
              a > 0)
            )
              ((l = e.slice(r, a)), o(s, l, r - 1), (c = he));
            else throw new Error("attribute value no end '" + m + "' match");
          else if (c == ge)
            ((l = e.slice(r, a)),
              o(s, l, r),
              i.warning('attribute "' + s + '" missed start quot(' + m + ")!!"),
              (r = a + 1),
              (c = he));
          else throw new Error('attribute value must after "="');
          break;
        case "/":
          switch (c) {
            case Oe:
              t.setTagName(e.slice(r, a));
            case he:
            case Fe:
            case er:
              ((c = er), (t.closed = !0));
            case ge:
            case oe:
              break;
            case fe:
              t.closed = !0;
              break;
            default:
              throw new Error("attribute invalid close char('/')");
          }
          break;
        case "":
          return (
            i.error("unexpected end of input"),
            c == Oe && t.setTagName(e.slice(r, a)),
            a
          );
        case ">":
          switch (c) {
            case Oe:
              t.setTagName(e.slice(r, a));
            case he:
            case Fe:
            case er:
              break;
            case ge:
            case oe:
              ((l = e.slice(r, a)),
                l.slice(-1) === "/" && ((t.closed = !0), (l = l.slice(0, -1))));
            case fe:
              (c === fe && (l = s),
                c == ge
                  ? (i.warning('attribute "' + l + '" missed quot(")!'),
                    o(s, l, r))
                  : ((!Me.isHTML(n[""]) ||
                      !l.match(/^(?:disabled|checked|selected)$/i)) &&
                      i.warning(
                        'attribute "' +
                          l +
                          '" missed value!! "' +
                          l +
                          '" instead!!',
                      ),
                    o(l, l, r)));
              break;
            case Re:
              throw new Error("attribute value missed!!");
          }
          return a;
        case "\x80":
          m = " ";
        default:
          if (m <= " ")
            switch (c) {
              case Oe:
                (t.setTagName(e.slice(r, a)), (c = Fe));
                break;
              case oe:
                ((s = e.slice(r, a)), (c = fe));
                break;
              case ge:
                var l = e.slice(r, a);
                (i.warning('attribute "' + l + '" missed quot(")!!'),
                  o(s, l, r));
              case he:
                c = Fe;
                break;
            }
          else
            switch (c) {
              case fe:
                var d = t.tagName;
                ((!Me.isHTML(n[""]) ||
                  !s.match(/^(?:disabled|checked|selected)$/i)) &&
                  i.warning(
                    'attribute "' +
                      s +
                      '" missed value!! "' +
                      s +
                      '" instead2!!',
                  ),
                  o(s, s, r),
                  (r = a),
                  (c = oe));
                break;
              case he:
                i.warning('attribute space is required"' + s + '"!!');
              case Fe:
                ((c = oe), (r = a));
                break;
              case Re:
                ((c = ge), (r = a));
                break;
              case er:
                throw new Error(
                  "elements closed character '/' and '>' must be connected to",
                );
            }
      }
      a++;
    }
  }
  function bt(e, r, t) {
    for (var n = e.tagName, u = null, m = e.length; m--;) {
      var i = e[m],
        o = i.qName,
        s = i.value,
        d = o.indexOf(":");
      if (d > 0)
        var l = (i.prefix = o.slice(0, d)),
          a = o.slice(d + 1),
          c = l === "xmlns" && a;
      else ((a = o), (l = null), (c = o === "xmlns" && ""));
      ((i.localName = a),
        c !== !1 &&
          (u == null && ((u = {}), wt(t, (t = {}))),
          (t[c] = u[c] = s),
          (i.uri = Me.XMLNS),
          r.startPrefixMapping(c, s)));
    }
    for (var m = e.length; m--;) {
      i = e[m];
      var l = i.prefix;
      l &&
        (l === "xml" && (i.uri = Me.XML),
        l !== "xmlns" && (i.uri = t[l || ""]));
    }
    var d = n.indexOf(":");
    d > 0
      ? ((l = e.prefix = n.slice(0, d)), (a = e.localName = n.slice(d + 1)))
      : ((l = null), (a = e.localName = n));
    var h = (e.uri = t[l || ""]);
    if ((r.startElement(h, a, n, e), e.closed)) {
      if ((r.endElement(h, a, n), u))
        for (l in u)
          Object.prototype.hasOwnProperty.call(u, l) && r.endPrefixMapping(l);
    } else return ((e.currentNSMap = t), (e.localNSMap = u), !0);
  }
  function Vn(e, r, t, n, u) {
    if (/^(?:script|textarea)$/i.test(t)) {
      var i = e.indexOf("</" + t + ">", r),
        o = e.substring(r + 1, i);
      if (/[&<]/.test(o))
        return /^script$/i.test(t)
          ? (u.characters(o, 0, o.length), i)
          : ((o = o.replace(/&#?\w+;/g, n)), u.characters(o, 0, o.length), i);
    }
    return r + 1;
  }
  function zn(e, r, t, n) {
    var u = n[t];
    return (
      u == null &&
        ((u = e.lastIndexOf("</" + t + ">")),
        u < r && (u = e.lastIndexOf("</" + t)),
        (n[t] = u)),
      u < r
    );
  }
  function wt(e, r) {
    for (var t in e)
      Object.prototype.hasOwnProperty.call(e, t) && (r[t] = e[t]);
  }
  function Gn(e, r, t, n) {
    var u = e.charAt(r + 2);
    switch (u) {
      case "-":
        if (e.charAt(r + 3) === "-") {
          var i = e.indexOf("-->", r + 4);
          return i > r
            ? (t.comment(e, r + 4, i - r - 4), i + 3)
            : (n.error("Unclosed comment"), -1);
        } else return -1;
      default:
        if (e.substr(r + 3, 6) == "CDATA[") {
          var i = e.indexOf("]]>", r + 9);
          return (
            t.startCDATA(),
            t.characters(e, r + 9, i - r - 9),
            t.endCDATA(),
            i + 3
          );
        }
        var o = Wn(e, r),
          s = o.length;
        if (s > 1 && /!doctype/i.test(o[0][0])) {
          var l = o[1][0],
            a = !1,
            c = !1;
          s > 3 &&
            (/^public$/i.test(o[2][0])
              ? ((a = o[3][0]), (c = s > 4 && o[4][0]))
              : /^system$/i.test(o[2][0]) && (c = o[3][0]));
          var m = o[s - 1];
          return (t.startDTD(l, a, c), t.endDTD(), m.index + m[0].length);
        }
    }
    return -1;
  }
  function Hn(e, r, t) {
    var n = e.indexOf("?>", r);
    if (n) {
      var u = e.substring(r, n).match(/^<\?(\S*)\s*([\s\S]*?)$/);
      if (u) {
        var i = u[0].length;
        return (t.processingInstruction(u[1], u[2]), n + 2);
      } else return -1;
    }
    return -1;
  }
  function Tt() {
    this.attributeNames = {};
  }
  Tt.prototype = {
    setTagName: function (e) {
      if (!Et.test(e)) throw new Error("invalid tagName:" + e);
      this.tagName = e;
    },
    addValue: function (e, r, t) {
      if (!Et.test(e)) throw new Error("invalid attribute:" + e);
      ((this.attributeNames[e] = this.length),
        (this[this.length++] = { qName: e, value: r, offset: t }));
    },
    length: 0,
    getLocalName: function (e) {
      return this[e].localName;
    },
    getLocator: function (e) {
      return this[e].locator;
    },
    getQName: function (e) {
      return this[e].qName;
    },
    getURI: function (e) {
      return this[e].uri;
    },
    getValue: function (e) {
      return this[e].value;
    },
  };
  function Wn(e, r) {
    var t,
      n = [],
      u = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
    for (u.lastIndex = r, u.exec(e); (t = u.exec(e));)
      if ((n.push(t), t[1])) return n;
  }
  wr.XMLReader = St;
  wr.ParseError = Ae;
});
var Ft = ue((tr) => {
  var $n = we(),
    jn = br(),
    Ct = yt(),
    It = xt(),
    Yn = jn.DOMImplementation,
    Nt = $n.NAMESPACE,
    Xn = It.ParseError,
    Qn = It.XMLReader;
  function Ot(e) {
    return e
      .replace(
        /\r[\n\u0085]/g,
        `
`,
      )
      .replace(
        /[\r\u0085\u2028]/g,
        `
`,
      );
  }
  function Rt(e) {
    this.options = e || { locator: {} };
  }
  Rt.prototype.parseFromString = function (e, r) {
    var t = this.options,
      n = new Qn(),
      u = t.domBuilder || new Le(),
      i = t.errorHandler,
      o = t.locator,
      s = t.xmlns || {},
      l = /\/x?html?$/.test(r),
      a = l ? Ct.HTML_ENTITIES : Ct.XML_ENTITIES;
    (o && u.setDocumentLocator(o),
      (n.errorHandler = Jn(i, u, o)),
      (n.domBuilder = t.domBuilder || u),
      l && (s[""] = Nt.HTML),
      (s.xml = s.xml || Nt.XML));
    var c = t.normalizeLineEndings || Ot;
    return (
      e && typeof e == "string"
        ? n.parse(c(e), s, a)
        : n.errorHandler.error("invalid doc source"),
      u.doc
    );
  };
  function Jn(e, r, t) {
    if (!e) {
      if (r instanceof Le) return r;
      e = r;
    }
    var n = {},
      u = e instanceof Function;
    t = t || {};
    function i(o) {
      var s = e[o];
      (!s &&
        u &&
        (s =
          e.length == 2
            ? function (l) {
                e(o, l);
              }
            : e),
        (n[o] =
          (s &&
            function (l) {
              s("[xmldom " + o + "]	" + l + Tr(t));
            }) ||
          function () {}));
    }
    return (i("warning"), i("error"), i("fatalError"), n);
  }
  function Le() {
    this.cdata = !1;
  }
  function De(e, r) {
    ((r.lineNumber = e.lineNumber), (r.columnNumber = e.columnNumber));
  }
  Le.prototype = {
    startDocument: function () {
      ((this.doc = new Yn().createDocument(null, null, null)),
        this.locator && (this.doc.documentURI = this.locator.systemId));
    },
    startElement: function (e, r, t, n) {
      var u = this.doc,
        i = u.createElementNS(e, t || r),
        o = n.length;
      (rr(this, i),
        (this.currentElement = i),
        this.locator && De(this.locator, i));
      for (var s = 0; s < o; s++) {
        var e = n.getURI(s),
          l = n.getValue(s),
          t = n.getQName(s),
          a = u.createAttributeNS(e, t);
        (this.locator && De(n.getLocator(s), a),
          (a.value = a.nodeValue = l),
          i.setAttributeNode(a));
      }
    },
    endElement: function (e, r, t) {
      var n = this.currentElement,
        u = n.tagName;
      this.currentElement = n.parentNode;
    },
    startPrefixMapping: function (e, r) {},
    endPrefixMapping: function (e) {},
    processingInstruction: function (e, r) {
      var t = this.doc.createProcessingInstruction(e, r);
      (this.locator && De(this.locator, t), rr(this, t));
    },
    ignorableWhitespace: function (e, r, t) {},
    characters: function (e, r, t) {
      if (((e = Bt.apply(this, arguments)), e)) {
        if (this.cdata) var n = this.doc.createCDATASection(e);
        else var n = this.doc.createTextNode(e);
        (this.currentElement
          ? this.currentElement.appendChild(n)
          : /^\s*$/.test(e) && this.doc.appendChild(n),
          this.locator && De(this.locator, n));
      }
    },
    skippedEntity: function (e) {},
    endDocument: function () {
      this.doc.normalize();
    },
    setDocumentLocator: function (e) {
      (this.locator = e) && (e.lineNumber = 0);
    },
    comment: function (e, r, t) {
      e = Bt.apply(this, arguments);
      var n = this.doc.createComment(e);
      (this.locator && De(this.locator, n), rr(this, n));
    },
    startCDATA: function () {
      this.cdata = !0;
    },
    endCDATA: function () {
      this.cdata = !1;
    },
    startDTD: function (e, r, t) {
      var n = this.doc.implementation;
      if (n && n.createDocumentType) {
        var u = n.createDocumentType(e, r, t);
        (this.locator && De(this.locator, u),
          rr(this, u),
          (this.doc.doctype = u));
      }
    },
    warning: function (e) {
      console.warn("[xmldom warning]	" + e, Tr(this.locator));
    },
    error: function (e) {
      console.error("[xmldom error]	" + e, Tr(this.locator));
    },
    fatalError: function (e) {
      throw new Xn(e, this.locator);
    },
  };
  function Tr(e) {
    if (e)
      return (
        `
@` +
        (e.systemId || "") +
        "#[line:" +
        e.lineNumber +
        ",col:" +
        e.columnNumber +
        "]"
      );
  }
  function Bt(e, r, t) {
    return typeof e == "string"
      ? e.substr(r, t)
      : e.length >= r + t || r
        ? new java.lang.String(e, r, t) + ""
        : e;
  }
  "endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(
    /\w+/g,
    function (e) {
      Le.prototype[e] = function () {
        return null;
      };
    },
  );
  function rr(e, r) {
    e.currentElement ? e.currentElement.appendChild(r) : e.doc.appendChild(r);
  }
  tr.__DOMHandler = Le;
  tr.normalizeLineEndings = Ot;
  tr.DOMParser = Rt;
});
var Lt = ue((nr) => {
  var Mt = br();
  nr.DOMImplementation = Mt.DOMImplementation;
  nr.XMLSerializer = Mt.XMLSerializer;
  nr.DOMParser = Ft().DOMParser;
});
function ie(e) {
  var r = String(e);
  if (r === "[object Object]")
    try {
      r = JSON.stringify(e);
    } catch {}
  return r;
}
var sn = (function () {
    function e() {}
    return (
      (e.prototype.isSome = function () {
        return !1;
      }),
      (e.prototype.isNone = function () {
        return !0;
      }),
      (e.prototype[Symbol.iterator] = function () {
        return {
          next: function () {
            return { done: !0, value: void 0 };
          },
        };
      }),
      (e.prototype.unwrapOr = function (r) {
        return r;
      }),
      (e.prototype.expect = function (r) {
        throw new Error("".concat(r));
      }),
      (e.prototype.unwrap = function () {
        throw new Error("Tried to unwrap None");
      }),
      (e.prototype.map = function (r) {
        return this;
      }),
      (e.prototype.mapOr = function (r, t) {
        return r;
      }),
      (e.prototype.mapOrElse = function (r, t) {
        return r();
      }),
      (e.prototype.or = function (r) {
        return r;
      }),
      (e.prototype.orElse = function (r) {
        return r();
      }),
      (e.prototype.andThen = function (r) {
        return this;
      }),
      (e.prototype.toResult = function (r) {
        return G(r);
      }),
      (e.prototype.toString = function () {
        return "None";
      }),
      (e.prototype.toAsyncOption = function () {
        return new _e(I);
      }),
      e
    );
  })(),
  I = new sn();
Object.freeze(I);
var ln = (function () {
    function e(r) {
      if (!(this instanceof e)) return new e(r);
      this.value = r;
    }
    return (
      (e.prototype.isSome = function () {
        return !0;
      }),
      (e.prototype.isNone = function () {
        return !1;
      }),
      (e.prototype[Symbol.iterator] = function () {
        var r = Object(this.value);
        return Symbol.iterator in r
          ? r[Symbol.iterator]()
          : {
              next: function () {
                return { done: !0, value: void 0 };
              },
            };
      }),
      (e.prototype.unwrapOr = function (r) {
        return this.value;
      }),
      (e.prototype.expect = function (r) {
        return this.value;
      }),
      (e.prototype.unwrap = function () {
        return this.value;
      }),
      (e.prototype.map = function (r) {
        return U(r(this.value));
      }),
      (e.prototype.mapOr = function (r, t) {
        return t(this.value);
      }),
      (e.prototype.mapOrElse = function (r, t) {
        return t(this.value);
      }),
      (e.prototype.or = function (r) {
        return this;
      }),
      (e.prototype.orElse = function (r) {
        return this;
      }),
      (e.prototype.andThen = function (r) {
        return r(this.value);
      }),
      (e.prototype.toResult = function (r) {
        return j(this.value);
      }),
      (e.prototype.toAsyncOption = function () {
        return new _e(this);
      }),
      (e.prototype.safeUnwrap = function () {
        return this.value;
      }),
      (e.prototype.toString = function () {
        return "Some(".concat(ie(this.value), ")");
      }),
      (e.EMPTY = new e(void 0)),
      e
    );
  })(),
  U = ln,
  qe;
(function (e) {
  function r() {
    for (var u = [], i = 0; i < arguments.length; i++) u[i] = arguments[i];
    for (var o = [], s = 0, l = u; s < l.length; s++) {
      var a = l[s];
      if (a.isSome()) o.push(a.value);
      else return a;
    }
    return U(o);
  }
  e.all = r;
  function t() {
    for (var u = [], i = 0; i < arguments.length; i++) u[i] = arguments[i];
    for (var o = 0, s = u; o < s.length; o++) {
      var l = s[o];
      if (l.isSome()) return l;
    }
    return I;
  }
  e.any = t;
  function n(u) {
    return u instanceof U || u === I;
  }
  e.isOption = n;
})(qe || (qe = {}));
var se = function (e, r, t) {
    if (t || arguments.length === 2)
      for (var n = 0, u = r.length, i; n < u; n++)
        (i || !(n in r)) &&
          (i || (i = Array.prototype.slice.call(r, 0, n)), (i[n] = r[n]));
    return e.concat(i || Array.prototype.slice.call(r));
  },
  cn = (function () {
    function e(r) {
      if (!(this instanceof e)) return new e(r);
      this.error = r;
      var t = new Error().stack
        .split(
          `
`,
        )
        .slice(2);
      (t && t.length > 0 && t[0].includes("ErrImpl") && t.shift(),
        (this._stack = t.join(`
`)));
    }
    return (
      (e.prototype.isOk = function () {
        return !1;
      }),
      (e.prototype.isErr = function () {
        return !0;
      }),
      (e.prototype[Symbol.iterator] = function () {
        return {
          next: function () {
            return { done: !0, value: void 0 };
          },
        };
      }),
      (e.prototype.else = function (r) {
        return r;
      }),
      (e.prototype.unwrapOr = function (r) {
        return r;
      }),
      (e.prototype.expect = function (r) {
        throw new Error(
          ""
            .concat(r, " - Error: ")
            .concat(
              ie(this.error),
              `
`,
            )
            .concat(this._stack),
          { cause: this.error },
        );
      }),
      (e.prototype.expectErr = function (r) {
        return this.error;
      }),
      (e.prototype.unwrap = function () {
        throw new Error(
          "Tried to unwrap Error: "
            .concat(
              ie(this.error),
              `
`,
            )
            .concat(this._stack),
          { cause: this.error },
        );
      }),
      (e.prototype.unwrapErr = function () {
        return this.error;
      }),
      (e.prototype.map = function (r) {
        return this;
      }),
      (e.prototype.andThen = function (r) {
        return this;
      }),
      (e.prototype.mapErr = function (r) {
        return new G(r(this.error));
      }),
      (e.prototype.mapOr = function (r, t) {
        return r;
      }),
      (e.prototype.mapOrElse = function (r, t) {
        return r(this.error);
      }),
      (e.prototype.or = function (r) {
        return r;
      }),
      (e.prototype.orElse = function (r) {
        return r(this.error);
      }),
      (e.prototype.toOption = function () {
        return I;
      }),
      (e.prototype.toString = function () {
        return "Err(".concat(ie(this.error), ")");
      }),
      Object.defineProperty(e.prototype, "stack", {
        get: function () {
          return ""
            .concat(
              this,
              `
`,
            )
            .concat(this._stack);
        },
        enumerable: !1,
        configurable: !0,
      }),
      (e.prototype.toAsyncResult = function () {
        return new be(this);
      }),
      (e.EMPTY = new e(void 0)),
      e
    );
  })();
var G = cn,
  mn = (function () {
    function e(r) {
      if (!(this instanceof e)) return new e(r);
      this.value = r;
    }
    return (
      (e.prototype.isOk = function () {
        return !0;
      }),
      (e.prototype.isErr = function () {
        return !1;
      }),
      (e.prototype[Symbol.iterator] = function () {
        var r = Object(this.value);
        return Symbol.iterator in r
          ? r[Symbol.iterator]()
          : {
              next: function () {
                return { done: !0, value: void 0 };
              },
            };
      }),
      (e.prototype.else = function (r) {
        return this.value;
      }),
      (e.prototype.unwrapOr = function (r) {
        return this.value;
      }),
      (e.prototype.expect = function (r) {
        return this.value;
      }),
      (e.prototype.expectErr = function (r) {
        throw new Error(r);
      }),
      (e.prototype.unwrap = function () {
        return this.value;
      }),
      (e.prototype.unwrapErr = function () {
        throw new Error("Tried to unwrap Ok: ".concat(ie(this.value)), {
          cause: this.value,
        });
      }),
      (e.prototype.map = function (r) {
        return new j(r(this.value));
      }),
      (e.prototype.andThen = function (r) {
        return r(this.value);
      }),
      (e.prototype.mapErr = function (r) {
        return this;
      }),
      (e.prototype.mapOr = function (r, t) {
        return t(this.value);
      }),
      (e.prototype.mapOrElse = function (r, t) {
        return t(this.value);
      }),
      (e.prototype.or = function (r) {
        return this;
      }),
      (e.prototype.orElse = function (r) {
        return this;
      }),
      (e.prototype.toOption = function () {
        return U(this.value);
      }),
      (e.prototype.safeUnwrap = function () {
        return this.value;
      }),
      (e.prototype.toString = function () {
        return "Ok(".concat(ie(this.value), ")");
      }),
      (e.prototype.toAsyncResult = function () {
        return new be(this);
      }),
      (e.EMPTY = new e(void 0)),
      e
    );
  })();
var j = mn,
  Ve;
(function (e) {
  function r(s) {
    for (var l = [], a = 1; a < arguments.length; a++) l[a - 1] = arguments[a];
    for (
      var c = s === void 0 ? [] : Array.isArray(s) ? s : se([s], l, !0),
        m = [],
        d = 0,
        h = c;
      d < h.length;
      d++
    ) {
      var A = h[d];
      if (A.isOk()) m.push(A.value);
      else return A;
    }
    return new j(m);
  }
  e.all = r;
  function t(s) {
    for (var l = [], a = 1; a < arguments.length; a++) l[a - 1] = arguments[a];
    for (
      var c = s === void 0 ? [] : Array.isArray(s) ? s : se([s], l, !0),
        m = [],
        d = 0,
        h = c;
      d < h.length;
      d++
    ) {
      var A = h[d];
      if (A.isOk()) return A;
      m.push(A.error);
    }
    return new G(m);
  }
  e.any = t;
  function n(s) {
    try {
      return new j(s());
    } catch (l) {
      return new G(l);
    }
  }
  e.wrap = n;
  function u(s) {
    try {
      return s()
        .then(function (l) {
          return new j(l);
        })
        .catch(function (l) {
          return new G(l);
        });
    } catch (l) {
      return Promise.resolve(new G(l));
    }
  }
  e.wrapAsync = u;
  function i(s) {
    return s.reduce(
      function (l, a) {
        var c = l[0],
          m = l[1];
        return a.isOk()
          ? [se(se([], c, !0), [a.value], !1), m]
          : [c, se(se([], m, !0), [a.error], !1)];
      },
      [[], []],
    );
  }
  e.partition = i;
  function o(s) {
    return s instanceof G || s instanceof j;
  }
  e.isResult = o;
})(Ve || (Ve = {}));
var ze = function (e, r, t, n) {
    function u(i) {
      return i instanceof t
        ? i
        : new t(function (o) {
            o(i);
          });
    }
    return new (t || (t = Promise))(function (i, o) {
      function s(c) {
        try {
          a(n.next(c));
        } catch (m) {
          o(m);
        }
      }
      function l(c) {
        try {
          a(n.throw(c));
        } catch (m) {
          o(m);
        }
      }
      function a(c) {
        c.done ? i(c.value) : u(c.value).then(s, l);
      }
      a((n = n.apply(e, r || [])).next());
    });
  },
  Ge = function (e, r) {
    var t = {
        label: 0,
        sent: function () {
          if (i[0] & 1) throw i[1];
          return i[1];
        },
        trys: [],
        ops: [],
      },
      n,
      u,
      i,
      o;
    return (
      (o = { next: s(0), throw: s(1), return: s(2) }),
      typeof Symbol == "function" &&
        (o[Symbol.iterator] = function () {
          return this;
        }),
      o
    );
    function s(a) {
      return function (c) {
        return l([a, c]);
      };
    }
    function l(a) {
      if (n) throw new TypeError("Generator is already executing.");
      for (; o && ((o = 0), a[0] && (t = 0)), t;)
        try {
          if (
            ((n = 1),
            u &&
              (i =
                a[0] & 2
                  ? u.return
                  : a[0]
                    ? u.throw || ((i = u.return) && i.call(u), 0)
                    : u.next) &&
              !(i = i.call(u, a[1])).done)
          )
            return i;
          switch (((u = 0), i && (a = [a[0] & 2, i.value]), a[0])) {
            case 0:
            case 1:
              i = a;
              break;
            case 4:
              return (t.label++, { value: a[1], done: !1 });
            case 5:
              (t.label++, (u = a[1]), (a = [0]));
              continue;
            case 7:
              ((a = t.ops.pop()), t.trys.pop());
              continue;
            default:
              if (
                ((i = t.trys),
                !(i = i.length > 0 && i[i.length - 1]) &&
                  (a[0] === 6 || a[0] === 2))
              ) {
                t = 0;
                continue;
              }
              if (a[0] === 3 && (!i || (a[1] > i[0] && a[1] < i[3]))) {
                t.label = a[1];
                break;
              }
              if (a[0] === 6 && t.label < i[1]) {
                ((t.label = i[1]), (i = a));
                break;
              }
              if (i && t.label < i[2]) {
                ((t.label = i[2]), t.ops.push(a));
                break;
              }
              (i[2] && t.ops.pop(), t.trys.pop());
              continue;
          }
          a = r.call(e, t);
        } catch (c) {
          ((a = [6, c]), (u = 0));
        } finally {
          n = i = 0;
        }
      if (a[0] & 5) throw a[1];
      return { value: a[0] ? a[1] : void 0, done: !0 };
    }
  },
  be = (function () {
    function e(r) {
      this.promise = Promise.resolve(r);
    }
    return (
      (e.prototype.andThen = function (r) {
        var t = this;
        return this.thenInternal(function (n) {
          return ze(t, void 0, void 0, function () {
            var u;
            return Ge(this, function (i) {
              return n.isErr()
                ? [2, n]
                : ((u = r(n.value)), [2, u instanceof e ? u.promise : u]);
            });
          });
        });
      }),
      (e.prototype.map = function (r) {
        var t = this;
        return this.thenInternal(function (n) {
          return ze(t, void 0, void 0, function () {
            var u;
            return Ge(this, function (i) {
              switch (i.label) {
                case 0:
                  return n.isErr() ? [2, n] : ((u = j), [4, r(n.value)]);
                case 1:
                  return [2, u.apply(void 0, [i.sent()])];
              }
            });
          });
        });
      }),
      (e.prototype.mapErr = function (r) {
        var t = this;
        return this.thenInternal(function (n) {
          return ze(t, void 0, void 0, function () {
            var u;
            return Ge(this, function (i) {
              switch (i.label) {
                case 0:
                  return n.isOk() ? [2, n] : ((u = G), [4, r(n.error)]);
                case 1:
                  return [2, u.apply(void 0, [i.sent()])];
              }
            });
          });
        });
      }),
      (e.prototype.or = function (r) {
        return this.orElse(function () {
          return r;
        });
      }),
      (e.prototype.orElse = function (r) {
        var t = this;
        return this.thenInternal(function (n) {
          return ze(t, void 0, void 0, function () {
            var u;
            return Ge(this, function (i) {
              return n.isOk()
                ? [2, n]
                : ((u = r(n.error)), [2, u instanceof e ? u.promise : u]);
            });
          });
        });
      }),
      (e.prototype.toOption = function () {
        return new _e(
          this.promise.then(function (r) {
            return r.toOption();
          }),
        );
      }),
      (e.prototype.thenInternal = function (r) {
        return new e(this.promise.then(r));
      }),
      e
    );
  })();
var ir = function (e, r, t, n) {
    function u(i) {
      return i instanceof t
        ? i
        : new t(function (o) {
            o(i);
          });
    }
    return new (t || (t = Promise))(function (i, o) {
      function s(c) {
        try {
          a(n.next(c));
        } catch (m) {
          o(m);
        }
      }
      function l(c) {
        try {
          a(n.throw(c));
        } catch (m) {
          o(m);
        }
      }
      function a(c) {
        c.done ? i(c.value) : u(c.value).then(s, l);
      }
      a((n = n.apply(e, r || [])).next());
    });
  },
  or = function (e, r) {
    var t = {
        label: 0,
        sent: function () {
          if (i[0] & 1) throw i[1];
          return i[1];
        },
        trys: [],
        ops: [],
      },
      n,
      u,
      i,
      o;
    return (
      (o = { next: s(0), throw: s(1), return: s(2) }),
      typeof Symbol == "function" &&
        (o[Symbol.iterator] = function () {
          return this;
        }),
      o
    );
    function s(a) {
      return function (c) {
        return l([a, c]);
      };
    }
    function l(a) {
      if (n) throw new TypeError("Generator is already executing.");
      for (; o && ((o = 0), a[0] && (t = 0)), t;)
        try {
          if (
            ((n = 1),
            u &&
              (i =
                a[0] & 2
                  ? u.return
                  : a[0]
                    ? u.throw || ((i = u.return) && i.call(u), 0)
                    : u.next) &&
              !(i = i.call(u, a[1])).done)
          )
            return i;
          switch (((u = 0), i && (a = [a[0] & 2, i.value]), a[0])) {
            case 0:
            case 1:
              i = a;
              break;
            case 4:
              return (t.label++, { value: a[1], done: !1 });
            case 5:
              (t.label++, (u = a[1]), (a = [0]));
              continue;
            case 7:
              ((a = t.ops.pop()), t.trys.pop());
              continue;
            default:
              if (
                ((i = t.trys),
                !(i = i.length > 0 && i[i.length - 1]) &&
                  (a[0] === 6 || a[0] === 2))
              ) {
                t = 0;
                continue;
              }
              if (a[0] === 3 && (!i || (a[1] > i[0] && a[1] < i[3]))) {
                t.label = a[1];
                break;
              }
              if (a[0] === 6 && t.label < i[1]) {
                ((t.label = i[1]), (i = a));
                break;
              }
              if (i && t.label < i[2]) {
                ((t.label = i[2]), t.ops.push(a));
                break;
              }
              (i[2] && t.ops.pop(), t.trys.pop());
              continue;
          }
          a = r.call(e, t);
        } catch (c) {
          ((a = [6, c]), (u = 0));
        } finally {
          n = i = 0;
        }
      if (a[0] & 5) throw a[1];
      return { value: a[0] ? a[1] : void 0, done: !0 };
    }
  },
  _e = (function () {
    function e(r) {
      this.promise = Promise.resolve(r);
    }
    return (
      (e.prototype.andThen = function (r) {
        var t = this;
        return this.thenInternal(function (n) {
          return ir(t, void 0, void 0, function () {
            var u;
            return or(this, function (i) {
              return n.isNone()
                ? [2, n]
                : ((u = r(n.value)), [2, u instanceof e ? u.promise : u]);
            });
          });
        });
      }),
      (e.prototype.map = function (r) {
        var t = this;
        return this.thenInternal(function (n) {
          return ir(t, void 0, void 0, function () {
            var u;
            return or(this, function (i) {
              switch (i.label) {
                case 0:
                  return n.isNone() ? [2, n] : ((u = U), [4, r(n.value)]);
                case 1:
                  return [2, u.apply(void 0, [i.sent()])];
              }
            });
          });
        });
      }),
      (e.prototype.or = function (r) {
        return this.orElse(function () {
          return r;
        });
      }),
      (e.prototype.orElse = function (r) {
        var t = this;
        return this.thenInternal(function (n) {
          return ir(t, void 0, void 0, function () {
            var u;
            return or(this, function (i) {
              return n.isSome()
                ? [2, n]
                : ((u = r()), [2, u instanceof e ? u.promise : u]);
            });
          });
        });
      }),
      (e.prototype.toResult = function (r) {
        return new be(
          this.promise.then(function (t) {
            return t.toResult(r);
          }),
        );
      }),
      (e.prototype.thenInternal = function (r) {
        return new e(this.promise.then(r));
      }),
      e
    );
  })();
function Or(e, r) {
  try {
    if (e) return U(new URL(e, r));
  } catch {}
  return I;
}
function Q(e) {
  if (typeof e == "string") return { __serde_tag: "primitive", __serde_val: e };
  if (typeof e == "number") return { __serde_tag: "primitive", __serde_val: e };
  if (typeof e == "boolean")
    return { __serde_tag: "primitive", __serde_val: e };
  if (typeof e > "u") return { __serde_tag: "primitive", __serde_val: e };
  if (e == null) return { __serde_tag: "primitive", __serde_val: e };
  if (Array.isArray(e))
    return { __serde_tag: "array", __serde_val: e.map((r) => Q(r)) };
  if (e instanceof URL) return { __serde_tag: "url", __serde_val: e.href };
  if (e instanceof Headers) {
    let r = [];
    return (
      e.forEach((t, n) => {
        r.push([n, t]);
      }),
      { __serde_tag: "headers", __serde_val: r }
    );
  } else {
    if (e instanceof Set)
      return { __serde_tag: "set", __serde_val: [...e.values()].map(Q) };
    if (e instanceof Map)
      return {
        __serde_tag: "map",
        __serde_val: [...e.entries()].map(([r, t]) => [Q(r), Q(t)]),
      };
    if (e instanceof RegExp)
      return { __serde_tag: "regex", __serde_val: [e.source, e.flags] };
    if (qe.isOption(e))
      return e.isSome()
        ? { __serde_tag: "some", __serde_val: Q(e.value) }
        : { __serde_tag: "none" };
    if (Ve.isResult(e))
      return e.isOk()
        ? { __serde_tag: "ok", __serde_val: Q(e.value) }
        : { __serde_tag: "err", __serde_val: Q(e.error) };
    if (typeof e == "object") {
      let r = {};
      for (let [t, n] of Object.entries(e)) r[t] = Q(n);
      return { __serde_tag: "object", __serde_val: r };
    } else throw new Error("Unreachable");
  }
}
function Rr(e, r = 0) {
  let t = 3735928559 ^ r,
    n = 1103547991 ^ r;
  for (let u = 0, i; u < e.length; u++)
    ((i = e.charCodeAt(u)),
      (t = Math.imul(t ^ i, 2654435761)),
      (n = Math.imul(n ^ i, 1597334677)));
  return (
    (t = Math.imul(t ^ (t >>> 16), 2246822507)),
    (t ^= Math.imul(n ^ (n >>> 13), 3266489909)),
    (n = Math.imul(n ^ (n >>> 16), 2246822507)),
    (n ^= Math.imul(t ^ (t >>> 13), 3266489909)),
    4294967296 * (2097151 & n) + (t >>> 0)
  );
}
var Lr = Ee(Mr(), 1);
var Ni = new BroadcastChannel("worker_service");
var sr = {
  FromInjectedToService: 0,
  FromContentToService: 1,
  FromServiceToWorker: 2,
  FromWorkerToService: 3,
  FromUntrustedInjectedToTrusted: 4,
  FromTrustedInjectedToUntrusted: 5,
  FromServiceToContent: 6,
  FromServiceToInjected: 7,
  FromServiceToService: 8,
};
async function pn(e, r) {
  await Lr.default.runtime.sendMessage({ msg: e, channel: r });
}
function Pr(e) {
  let r = sr.FromInjectedToService;
  pn(e, r);
}
var fn = ["mp4", "webm", "mkv"],
  gn = ["mp3", "m4a", "ogg"],
  hn = [...fn, ...gn];
var An = [
    { mime_reg: /(avc1|avc3).*/i, demuxer: "mp4", codec: "H264" },
    {
      mime_reg: /(hvc1|hev1|hevc|h265|h\.265).*/i,
      demuxer: "mp4",
      codec: "H265",
    },
    { mime_reg: /mp4v\.20.*/i, demuxer: "mp4", codec: "MP4V" },
    { mime_reg: /av0?1.*/i, demuxer: "webm", codec: "AV1" },
    { mime_reg: /vp0?8.*/i, demuxer: "webm", codec: "VP8" },
    { mime_reg: /vp0?9.*/i, demuxer: "webm", codec: "VP9" },
  ],
  Dn = [
    { mime_reg: /(aac|mp4a.40).*/i, demuxer: "m4a", codec: "AAC" },
    { mime_reg: /(\.?mp3|mp4a\.69|mp4a\.6b).*/i, demuxer: "mp3", codec: "MP3" },
    { mime_reg: /(opus|(mp4a\.ad.*))/i, demuxer: "ogg", codec: "Opus" },
    { mime_reg: /vorbis/i, demuxer: "ogg", codec: "Vorbis" },
  ];
function kr(e) {
  for (let r of An) if (r.mime_reg.test(e)) return U(r.demuxer);
  return I;
}
function Ur(e) {
  for (let r of Dn) if (r.mime_reg.test(e)) return U(r.demuxer);
  return I;
}
function qr(e) {
  return e.length > 0;
}
function vn(e, r) {
  let i = e.size.map((a) => a.height).unwrapOr(0),
    o = r.size.map((a) => a.height).unwrapOr(0),
    s = e.bitrate.unwrapOr(0),
    l = r.bitrate.unwrapOr(0);
  return i > o ? -1 : i < o ? 1 : s > l ? -1 : s < l ? 1 : 0;
}
function Vr(e) {
  return [...e.values()].sort((r, t) => vn(r.quality, t.quality));
}
var le = Ee(He()),
  Gr = "https://example.com",
  En = function (r, t) {
    if (/^[a-z]+:/i.test(t)) return t;
    /^data:/.test(r) &&
      (r = (le.default.location && le.default.location.href) || "");
    var n = /^\/\//.test(r),
      u = !le.default.location && !/\/\//i.test(r);
    r = new le.default.URL(r, le.default.location || Gr);
    var i = new URL(t, r);
    return u
      ? i.href.slice(Gr.length)
      : n
        ? i.href.slice(i.protocol.length)
        : i.href;
  },
  We = En;
var z = Ee(He());
var Hr = function (r, t, n) {
  t.forEach(function (u) {
    for (var i in r.mediaGroups[u])
      for (var o in r.mediaGroups[u][i]) {
        var s = r.mediaGroups[u][i][o];
        n(s, u, i, o);
      }
  });
};
var lr = Ee(He()),
  _n = function (r) {
    return lr.default.atob
      ? lr.default.atob(r)
      : Buffer.from(r, "base64").toString("binary");
  };
function cr(e) {
  for (var r = _n(e), t = new Uint8Array(r.length), n = 0; n < r.length; n++)
    t[n] = r.charCodeAt(n);
  return t;
}
var Ht = Ee(Lt());
var Pt = (e) => !!e && typeof e == "object",
  k = (...e) =>
    e.reduce(
      (r, t) => (
        typeof t != "object" ||
          Object.keys(t).forEach((n) => {
            Array.isArray(r[n]) && Array.isArray(t[n])
              ? (r[n] = r[n].concat(t[n]))
              : Pt(r[n]) && Pt(t[n])
                ? (r[n] = k(r[n], t[n]))
                : (r[n] = t[n]);
          }),
        r
      ),
      {},
    ),
  Wt = (e) => Object.keys(e).map((r) => e[r]),
  Zn = (e, r) => {
    let t = [];
    for (let n = e; n < r; n++) t.push(n);
    return t;
  },
  ve = (e) => e.reduce((r, t) => r.concat(t), []),
  $t = (e) => {
    if (!e.length) return [];
    let r = [];
    for (let t = 0; t < e.length; t++) r.push(e[t]);
    return r;
  },
  Kn = (e, r) => e.reduce((t, n, u) => (n[r] && t.push(u), t), []),
  eu = (e, r) =>
    Wt(
      e.reduce(
        (t, n) => (
          n.forEach((u) => {
            t[r(u)] = u;
          }),
          t
        ),
        {},
      ),
    ),
  Pe = {
    INVALID_NUMBER_OF_PERIOD: "INVALID_NUMBER_OF_PERIOD",
    INVALID_NUMBER_OF_CONTENT_STEERING: "INVALID_NUMBER_OF_CONTENT_STEERING",
    DASH_EMPTY_MANIFEST: "DASH_EMPTY_MANIFEST",
    DASH_INVALID_XML: "DASH_INVALID_XML",
    NO_BASE_URL: "NO_BASE_URL",
    MISSING_SEGMENT_INFORMATION: "MISSING_SEGMENT_INFORMATION",
    SEGMENT_TIME_UNSPECIFIED: "SEGMENT_TIME_UNSPECIFIED",
    UNSUPPORTED_UTC_TIMING_SCHEME: "UNSUPPORTED_UTC_TIMING_SCHEME",
  },
  ke = ({
    baseUrl: e = "",
    source: r = "",
    range: t = "",
    indexRange: n = "",
  }) => {
    let u = { uri: r, resolvedUri: We(e || "", r) };
    if (t || n) {
      let o = (t || n).split("-"),
        s = z.default.BigInt ? z.default.BigInt(o[0]) : parseInt(o[0], 10),
        l = z.default.BigInt ? z.default.BigInt(o[1]) : parseInt(o[1], 10);
      (s < Number.MAX_SAFE_INTEGER && typeof s == "bigint" && (s = Number(s)),
        l < Number.MAX_SAFE_INTEGER && typeof l == "bigint" && (l = Number(l)));
      let a;
      (typeof l == "bigint" || typeof s == "bigint"
        ? (a = z.default.BigInt(l) - z.default.BigInt(s) + z.default.BigInt(1))
        : (a = l - s + 1),
        typeof a == "bigint" && a < Number.MAX_SAFE_INTEGER && (a = Number(a)),
        (u.byterange = { length: a, offset: s }));
    }
    return u;
  },
  ru = (e) => {
    let r;
    return (
      typeof e.offset == "bigint" || typeof e.length == "bigint"
        ? (r =
            z.default.BigInt(e.offset) +
            z.default.BigInt(e.length) -
            z.default.BigInt(1))
        : (r = e.offset + e.length - 1),
      `${e.offset}-${r}`
    );
  },
  kt = (e) => (
    e && typeof e != "number" && (e = parseInt(e, 10)),
    isNaN(e) ? null : e
  ),
  tu = {
    static(e) {
      let {
          duration: r,
          timescale: t = 1,
          sourceDuration: n,
          periodDuration: u,
        } = e,
        i = kt(e.endNumber),
        o = r / t;
      return typeof i == "number"
        ? { start: 0, end: i }
        : typeof u == "number"
          ? { start: 0, end: u / o }
          : { start: 0, end: n / o };
    },
    dynamic(e) {
      let {
          NOW: r,
          clientOffset: t,
          availabilityStartTime: n,
          timescale: u = 1,
          duration: i,
          periodStart: o = 0,
          minimumUpdatePeriod: s = 0,
          timeShiftBufferDepth: l = 1 / 0,
        } = e,
        a = kt(e.endNumber),
        c = (r + t) / 1e3,
        m = n + o,
        h = c + s - m,
        A = Math.ceil((h * u) / i),
        D = Math.floor(((c - m - l) * u) / i),
        y = Math.floor(((c - m) * u) / i);
      return {
        start: Math.max(0, D),
        end: typeof a == "number" ? a : Math.min(A, y),
      };
    },
  },
  nu = (e) => (r) => {
    let {
      duration: t,
      timescale: n = 1,
      periodStart: u,
      startNumber: i = 1,
    } = e;
    return { number: i + r, duration: t / n, timeline: u, time: r * t };
  },
  Cr = (e) => {
    let {
        type: r,
        duration: t,
        timescale: n = 1,
        periodDuration: u,
        sourceDuration: i,
      } = e,
      { start: o, end: s } = tu[r](e),
      l = Zn(o, s).map(nu(e));
    if (r === "static") {
      let a = l.length - 1,
        c = typeof u == "number" ? u : i;
      l[a].duration = c - (t / n) * a;
    }
    return l;
  },
  jt = (e) => {
    let {
      baseUrl: r,
      initialization: t = {},
      sourceDuration: n,
      indexRange: u = "",
      periodStart: i,
      presentationTime: o,
      number: s = 0,
      duration: l,
    } = e;
    if (!r) throw new Error(Pe.NO_BASE_URL);
    let a = ke({ baseUrl: r, source: t.sourceURL, range: t.range }),
      c = ke({ baseUrl: r, source: r, indexRange: u });
    if (((c.map = a), l)) {
      let m = Cr(e);
      m.length && ((c.duration = m[0].duration), (c.timeline = m[0].timeline));
    } else n && ((c.duration = n), (c.timeline = i));
    return ((c.presentationTime = o || i), (c.number = s), [c]);
  },
  uu = (e, r, t) => {
    let n = e.sidx.map ? e.sidx.map : null,
      u = e.sidx.duration,
      i = e.timeline || 0,
      o = e.sidx.byterange,
      s = o.offset + o.length,
      l = r.timescale,
      a = r.references.filter((y) => y.referenceType !== 1),
      c = [],
      m = e.endList ? "static" : "dynamic",
      d = e.sidx.timeline,
      h = d,
      A = e.mediaSequence || 0,
      D;
    typeof r.firstOffset == "bigint"
      ? (D = z.default.BigInt(s) + r.firstOffset)
      : (D = s + r.firstOffset);
    for (let y = 0; y < a.length; y++) {
      let B = r.references[y],
        x = B.referencedSize,
        b = B.subsegmentDuration,
        p;
      typeof D == "bigint"
        ? (p = D + z.default.BigInt(x) - z.default.BigInt(1))
        : (p = D + x - 1);
      let f = `${D}-${p}`,
        E = jt({
          baseUrl: t,
          timescale: l,
          timeline: i,
          periodStart: d,
          presentationTime: h,
          number: A,
          duration: b,
          sourceDuration: u,
          indexRange: f,
          type: m,
        })[0];
      (n && (E.map = n),
        c.push(E),
        typeof D == "bigint" ? (D += z.default.BigInt(x)) : (D += x),
        (h += b / l),
        A++);
    }
    return ((e.segments = c), e);
  },
  iu = ["AUDIO", "SUBTITLES"],
  ou = 1 / 60,
  Yt = (e) =>
    eu(e, ({ timeline: r }) => r).sort((r, t) =>
      r.timeline > t.timeline ? 1 : -1,
    ),
  au = (e, r) => {
    for (let t = 0; t < e.length; t++)
      if (e[t].attributes.NAME === r) return e[t];
    return null;
  },
  Ut = (e) => {
    let r = [];
    return (
      Hr(e, iu, (t, n, u, i) => {
        r = r.concat(t.playlists || []);
      }),
      r
    );
  },
  qt = ({ playlist: e, mediaSequence: r }) => {
    ((e.mediaSequence = r),
      e.segments.forEach((t, n) => {
        t.number = e.mediaSequence + n;
      }));
  },
  su = ({ oldPlaylists: e, newPlaylists: r, timelineStarts: t }) => {
    r.forEach((n) => {
      n.discontinuitySequence = t.findIndex(function ({ timeline: l }) {
        return l === n.timeline;
      });
      let u = au(e, n.attributes.NAME);
      if (!u || n.sidx) return;
      let i = n.segments[0],
        o = u.segments.findIndex(function (l) {
          return Math.abs(l.presentationTime - i.presentationTime) < ou;
        });
      if (o === -1) {
        (qt({
          playlist: n,
          mediaSequence: u.mediaSequence + u.segments.length,
        }),
          (n.segments[0].discontinuity = !0),
          n.discontinuityStarts.unshift(0),
          ((!u.segments.length && n.timeline > u.timeline) ||
            (u.segments.length &&
              n.timeline > u.segments[u.segments.length - 1].timeline)) &&
            n.discontinuitySequence--);
        return;
      }
      (u.segments[o].discontinuity &&
        !i.discontinuity &&
        ((i.discontinuity = !0),
        n.discontinuityStarts.unshift(0),
        n.discontinuitySequence--),
        qt({ playlist: n, mediaSequence: u.segments[o].number }));
    });
  },
  lu = ({ oldManifest: e, newManifest: r }) => {
    let t = e.playlists.concat(Ut(e)),
      n = r.playlists.concat(Ut(r));
    return (
      (r.timelineStarts = Yt([e.timelineStarts, r.timelineStarts])),
      su({
        oldPlaylists: t,
        newPlaylists: n,
        timelineStarts: r.timelineStarts,
      }),
      r
    );
  },
  cu = (e) => e && e.uri + "-" + ru(e.byterange),
  xr = (e) => {
    let r = e.reduce(function (n, u) {
        return (
          n[u.attributes.baseUrl] || (n[u.attributes.baseUrl] = []),
          n[u.attributes.baseUrl].push(u),
          n
        );
      }, {}),
      t = [];
    return (
      Object.values(r).forEach((n) => {
        let u = Wt(
          n.reduce((i, o) => {
            let s = o.attributes.id + (o.attributes.lang || "");
            return (
              i[s]
                ? (o.segments &&
                    (o.segments[0] && (o.segments[0].discontinuity = !0),
                    i[s].segments.push(...o.segments)),
                  o.attributes.contentProtection &&
                    (i[s].attributes.contentProtection =
                      o.attributes.contentProtection))
                : ((i[s] = o), (i[s].attributes.timelineStarts = [])),
              i[s].attributes.timelineStarts.push({
                start: o.attributes.periodStart,
                timeline: o.attributes.periodStart,
              }),
              i
            );
          }, {}),
        );
        t = t.concat(u);
      }),
      t.map(
        (n) => (
          (n.discontinuityStarts = Kn(n.segments || [], "discontinuity")),
          n
        ),
      )
    );
  },
  Nr = (e, r) => {
    let t = cu(e.sidx),
      n = t && r[t] && r[t].sidx;
    return (n && uu(e, n, e.sidx.resolvedUri), e);
  },
  mu = (e, r = {}) => {
    if (!Object.keys(r).length) return e;
    for (let t in e) e[t] = Nr(e[t], r);
    return e;
  },
  pu = (
    {
      attributes: e,
      segments: r,
      sidx: t,
      mediaSequence: n,
      discontinuitySequence: u,
      discontinuityStarts: i,
    },
    o,
  ) => {
    let s = {
      attributes: {
        NAME: e.id,
        BANDWIDTH: e.bandwidth,
        CODECS: e.codecs,
        "PROGRAM-ID": 1,
      },
      uri: "",
      endList: e.type === "static",
      timeline: e.periodStart,
      resolvedUri: e.baseUrl || "",
      targetDuration: e.duration,
      discontinuitySequence: u,
      discontinuityStarts: i,
      timelineStarts: e.timelineStarts,
      mediaSequence: n,
      segments: r,
    };
    return (
      e.contentProtection && (s.contentProtection = e.contentProtection),
      e.serviceLocation && (s.attributes.serviceLocation = e.serviceLocation),
      t && (s.sidx = t),
      o && ((s.attributes.AUDIO = "audio"), (s.attributes.SUBTITLES = "subs")),
      s
    );
  },
  du = ({
    attributes: e,
    segments: r,
    mediaSequence: t,
    discontinuityStarts: n,
    discontinuitySequence: u,
  }) => {
    typeof r > "u" &&
      ((r = [
        {
          uri: e.baseUrl,
          timeline: e.periodStart,
          resolvedUri: e.baseUrl || "",
          duration: e.sourceDuration,
          number: 0,
        },
      ]),
      (e.duration = e.sourceDuration));
    let i = { NAME: e.id, BANDWIDTH: e.bandwidth, "PROGRAM-ID": 1 };
    e.codecs && (i.CODECS = e.codecs);
    let o = {
      attributes: i,
      uri: "",
      endList: e.type === "static",
      timeline: e.periodStart,
      resolvedUri: e.baseUrl || "",
      targetDuration: e.duration,
      timelineStarts: e.timelineStarts,
      discontinuityStarts: n,
      discontinuitySequence: u,
      mediaSequence: t,
      segments: r,
    };
    return (
      e.serviceLocation && (o.attributes.serviceLocation = e.serviceLocation),
      o
    );
  },
  fu = (e, r = {}, t = !1) => {
    let n,
      u = e.reduce((i, o) => {
        let s = (o.attributes.role && o.attributes.role.value) || "",
          l = o.attributes.lang || "",
          a = o.attributes.label || "main";
        if (l && !o.attributes.label) {
          let m = s ? ` (${s})` : "";
          a = `${o.attributes.lang}${m}`;
        }
        i[a] ||
          (i[a] = {
            language: l,
            autoselect: !0,
            default: s === "main",
            playlists: [],
            uri: "",
          });
        let c = Nr(pu(o, t), r);
        return (
          i[a].playlists.push(c),
          typeof n > "u" && s === "main" && ((n = o), (n.default = !0)),
          i
        );
      }, {});
    if (!n) {
      let i = Object.keys(u)[0];
      u[i].default = !0;
    }
    return u;
  },
  gu = (e, r = {}) =>
    e.reduce((t, n) => {
      let u = n.attributes.label || n.attributes.lang || "text",
        i = n.attributes.lang || "und";
      return (
        t[u] ||
          (t[u] = {
            language: i,
            default: !1,
            autoselect: !1,
            playlists: [],
            uri: "",
          }),
        t[u].playlists.push(Nr(du(n), r)),
        t
      );
    }, {}),
  hu = (e) =>
    e.reduce(
      (r, t) => (
        t &&
          t.forEach((n) => {
            let { channel: u, language: i } = n;
            ((r[i] = {
              autoselect: !1,
              default: !1,
              instreamId: u,
              language: i,
            }),
              n.hasOwnProperty("aspectRatio") &&
                (r[i].aspectRatio = n.aspectRatio),
              n.hasOwnProperty("easyReader") &&
                (r[i].easyReader = n.easyReader),
              n.hasOwnProperty("3D") && (r[i]["3D"] = n["3D"]));
          }),
        r
      ),
      {},
    ),
  Au = ({ attributes: e, segments: r, sidx: t, discontinuityStarts: n }) => {
    let u = {
      attributes: {
        NAME: e.id,
        AUDIO: "audio",
        SUBTITLES: "subs",
        RESOLUTION: { width: e.width, height: e.height },
        CODECS: e.codecs,
        BANDWIDTH: e.bandwidth,
        "PROGRAM-ID": 1,
      },
      uri: "",
      endList: e.type === "static",
      timeline: e.periodStart,
      resolvedUri: e.baseUrl || "",
      targetDuration: e.duration,
      discontinuityStarts: n,
      timelineStarts: e.timelineStarts,
      segments: r,
    };
    return (
      e.frameRate && (u.attributes["FRAME-RATE"] = e.frameRate),
      e.contentProtection && (u.contentProtection = e.contentProtection),
      e.serviceLocation && (u.attributes.serviceLocation = e.serviceLocation),
      t && (u.sidx = t),
      u
    );
  },
  Du = ({ attributes: e }) =>
    e.mimeType === "video/mp4" ||
    e.mimeType === "video/webm" ||
    e.contentType === "video",
  yu = ({ attributes: e }) =>
    e.mimeType === "audio/mp4" ||
    e.mimeType === "audio/webm" ||
    e.contentType === "audio",
  vu = ({ attributes: e }) =>
    e.mimeType === "text/vtt" || e.contentType === "text",
  Eu = (e, r) => {
    e.forEach((t) => {
      ((t.mediaSequence = 0),
        (t.discontinuitySequence = r.findIndex(function ({ timeline: n }) {
          return n === t.timeline;
        })),
        t.segments &&
          t.segments.forEach((n, u) => {
            n.number = u;
          }));
    });
  },
  Vt = (e) =>
    e
      ? Object.keys(e).reduce((r, t) => {
          let n = e[t];
          return r.concat(n.playlists);
        }, [])
      : [],
  _u = ({
    dashPlaylists: e,
    locations: r,
    contentSteering: t,
    sidxMapping: n = {},
    previousManifest: u,
    eventStream: i,
  }) => {
    if (!e.length) return {};
    let {
        sourceDuration: o,
        type: s,
        suggestedPresentationDelay: l,
        minimumUpdatePeriod: a,
      } = e[0].attributes,
      c = xr(e.filter(Du)).map(Au),
      m = xr(e.filter(yu)),
      d = xr(e.filter(vu)),
      h = e.map((p) => p.attributes.captionServices).filter(Boolean),
      A = {
        allowCache: !0,
        discontinuityStarts: [],
        segments: [],
        endList: !0,
        mediaGroups: {
          AUDIO: {},
          VIDEO: {},
          "CLOSED-CAPTIONS": {},
          SUBTITLES: {},
        },
        uri: "",
        duration: o,
        playlists: mu(c, n),
      };
    (a >= 0 && (A.minimumUpdatePeriod = a * 1e3),
      r && (A.locations = r),
      t && (A.contentSteering = t),
      s === "dynamic" && (A.suggestedPresentationDelay = l),
      i && i.length > 0 && (A.eventStream = i));
    let D = A.playlists.length === 0,
      y = m.length ? fu(m, n, D) : null,
      B = d.length ? gu(d, n) : null,
      x = c.concat(Vt(y), Vt(B)),
      b = x.map(({ timelineStarts: p }) => p);
    return (
      (A.timelineStarts = Yt(b)),
      Eu(x, A.timelineStarts),
      y && (A.mediaGroups.AUDIO.audio = y),
      B && (A.mediaGroups.SUBTITLES.subs = B),
      h.length && (A.mediaGroups["CLOSED-CAPTIONS"].cc = hu(h)),
      u ? lu({ oldManifest: u, newManifest: A }) : A
    );
  },
  bu = (e, r, t) => {
    let {
        NOW: n,
        clientOffset: u,
        availabilityStartTime: i,
        timescale: o = 1,
        periodStart: s = 0,
        minimumUpdatePeriod: l = 0,
      } = e,
      a = (n + u) / 1e3,
      c = i + s,
      d = a + l - c;
    return Math.ceil((d * o - r) / t);
  },
  Xt = (e, r) => {
    let {
        type: t,
        minimumUpdatePeriod: n = 0,
        media: u = "",
        sourceDuration: i,
        timescale: o = 1,
        startNumber: s = 1,
        periodStart: l,
      } = e,
      a = [],
      c = -1;
    for (let m = 0; m < r.length; m++) {
      let d = r[m],
        h = d.d,
        A = d.r || 0,
        D = d.t || 0;
      (c < 0 && (c = D), D && D > c && (c = D));
      let y;
      if (A < 0) {
        let b = m + 1;
        b === r.length
          ? t === "dynamic" && n > 0 && u.indexOf("$Number$") > 0
            ? (y = bu(e, c, h))
            : (y = (i * o - c) / h)
          : (y = (r[b].t - c) / h);
      } else y = A + 1;
      let B = s + a.length + y,
        x = s + a.length;
      for (; x < B;)
        (a.push({ number: x, duration: h / o, time: c, timeline: l }),
          (c += h),
          x++);
    }
    return a;
  },
  Su = /\$([A-z]*)(?:(%0)([0-9]+)d)?\$/g,
  wu = (e) => (r, t, n, u) => {
    if (r === "$$") return "$";
    if (typeof e[t] > "u") return r;
    let i = "" + e[t];
    return t === "RepresentationID" ||
      (n ? (u = parseInt(u, 10)) : (u = 1), i.length >= u)
      ? i
      : `${new Array(u - i.length + 1).join("0")}${i}`;
  },
  zt = (e, r) => e.replace(Su, wu(r)),
  Tu = (e, r) =>
    !e.duration && !r
      ? [
          {
            number: e.startNumber || 1,
            duration: e.sourceDuration,
            time: 0,
            timeline: e.periodStart,
          },
        ]
      : e.duration
        ? Cr(e)
        : Xt(e, r),
  xu = (e, r) => {
    let t = { RepresentationID: e.id, Bandwidth: e.bandwidth || 0 },
      { initialization: n = { sourceURL: "", range: "" } } = e,
      u = ke({
        baseUrl: e.baseUrl,
        source: zt(n.sourceURL, t),
        range: n.range,
      });
    return Tu(e, r).map((o) => {
      ((t.Number = o.number), (t.Time = o.time));
      let s = zt(e.media || "", t),
        l = e.timescale || 1,
        a = e.presentationTimeOffset || 0,
        c = e.periodStart + (o.time - a) / l;
      return {
        uri: s,
        timeline: o.timeline,
        duration: o.duration,
        resolvedUri: We(e.baseUrl || "", s),
        map: u,
        number: o.number,
        presentationTime: c,
      };
    });
  },
  Cu = (e, r) => {
    let { baseUrl: t, initialization: n = {} } = e,
      u = ke({ baseUrl: t, source: n.sourceURL, range: n.range }),
      i = ke({ baseUrl: t, source: r.media, range: r.mediaRange });
    return ((i.map = u), i);
  },
  Nu = (e, r) => {
    let { duration: t, segmentUrls: n = [], periodStart: u } = e;
    if ((!t && !r) || (t && r)) throw new Error(Pe.SEGMENT_TIME_UNSPECIFIED);
    let i = n.map((l) => Cu(e, l)),
      o;
    return (
      t && (o = Cr(e)),
      r && (o = Xt(e, r)),
      o
        .map((l, a) => {
          if (i[a]) {
            let c = i[a],
              m = e.timescale || 1,
              d = e.presentationTimeOffset || 0;
            return (
              (c.timeline = l.timeline),
              (c.duration = l.duration),
              (c.number = l.number),
              (c.presentationTime = u + (l.time - d) / m),
              c
            );
          }
        })
        .filter((l) => l)
    );
  },
  Bu = ({ attributes: e, segmentInfo: r }) => {
    let t, n;
    r.template
      ? ((n = xu), (t = k(e, r.template)))
      : r.base
        ? ((n = jt), (t = k(e, r.base)))
        : r.list && ((n = Nu), (t = k(e, r.list)));
    let u = { attributes: e };
    if (!n) return u;
    let i = n(t, r.segmentTimeline);
    if (t.duration) {
      let { duration: o, timescale: s = 1 } = t;
      t.duration = o / s;
    } else
      i.length
        ? (t.duration = i.reduce(
            (o, s) => Math.max(o, Math.ceil(s.duration)),
            0,
          ))
        : (t.duration = 0);
    return (
      (u.attributes = t),
      (u.segments = i),
      r.base && t.indexRange && ((u.sidx = i[0]), (u.segments = [])),
      u
    );
  },
  Iu = (e) => e.map(Bu),
  N = (e, r) => $t(e.childNodes).filter(({ tagName: t }) => t === r),
  Ue = (e) => e.textContent.trim(),
  Ou = (e) => parseFloat(e.split("/").reduce((r, t) => r / t)),
  ye = (e) => {
    let s =
      /P(?:(\d*)Y)?(?:(\d*)M)?(?:(\d*)D)?(?:T(?:(\d*)H)?(?:(\d*)M)?(?:([\d.]*)S)?)?/.exec(
        e,
      );
    if (!s) return 0;
    let [l, a, c, m, d, h] = s.slice(1);
    return (
      parseFloat(l || 0) * 31536e3 +
      parseFloat(a || 0) * 2592e3 +
      parseFloat(c || 0) * 86400 +
      parseFloat(m || 0) * 3600 +
      parseFloat(d || 0) * 60 +
      parseFloat(h || 0)
    );
  },
  Ru = (e) => (
    /^\d+-\d+-\d+T\d+:\d+:\d+(\.\d+)?$/.test(e) && (e += "Z"),
    Date.parse(e)
  ),
  Gt = {
    mediaPresentationDuration(e) {
      return ye(e);
    },
    availabilityStartTime(e) {
      return Ru(e) / 1e3;
    },
    minimumUpdatePeriod(e) {
      return ye(e);
    },
    suggestedPresentationDelay(e) {
      return ye(e);
    },
    type(e) {
      return e;
    },
    timeShiftBufferDepth(e) {
      return ye(e);
    },
    start(e) {
      return ye(e);
    },
    width(e) {
      return parseInt(e, 10);
    },
    height(e) {
      return parseInt(e, 10);
    },
    bandwidth(e) {
      return parseInt(e, 10);
    },
    frameRate(e) {
      return Ou(e);
    },
    startNumber(e) {
      return parseInt(e, 10);
    },
    timescale(e) {
      return parseInt(e, 10);
    },
    presentationTimeOffset(e) {
      return parseInt(e, 10);
    },
    duration(e) {
      let r = parseInt(e, 10);
      return isNaN(r) ? ye(e) : r;
    },
    d(e) {
      return parseInt(e, 10);
    },
    t(e) {
      return parseInt(e, 10);
    },
    r(e) {
      return parseInt(e, 10);
    },
    presentationTime(e) {
      return parseInt(e, 10);
    },
    DEFAULT(e) {
      return e;
    },
  },
  F = (e) =>
    e && e.attributes
      ? $t(e.attributes).reduce((r, t) => {
          let n = Gt[t.name] || Gt.DEFAULT;
          return ((r[t.name] = n(t.value)), r);
        }, {})
      : {},
  Fu = {
    "urn:uuid:1077efec-c0b2-4d02-ace3-3c1e52e2fb4b": "org.w3.clearkey",
    "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed": "com.widevine.alpha",
    "urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95": "com.microsoft.playready",
    "urn:uuid:f239e769-efa3-4850-9c16-a903c6932efb": "com.adobe.primetime",
    "urn:mpeg:dash:mp4protection:2011": "mp4protection",
  },
  ur = (e, r) =>
    r.length
      ? ve(
          e.map(function (t) {
            return r.map(function (n) {
              let u = Ue(n),
                i = We(t.baseUrl, u),
                o = k(F(n), { baseUrl: i });
              return (
                i !== u &&
                  !o.serviceLocation &&
                  t.serviceLocation &&
                  (o.serviceLocation = t.serviceLocation),
                o
              );
            });
          }),
        )
      : e,
  Br = (e) => {
    let r = N(e, "SegmentTemplate")[0],
      t = N(e, "SegmentList")[0],
      n = t && N(t, "SegmentURL").map((m) => k({ tag: "SegmentURL" }, F(m))),
      u = N(e, "SegmentBase")[0],
      i = t || r,
      o = i && N(i, "SegmentTimeline")[0],
      s = t || u || r,
      l = s && N(s, "Initialization")[0],
      a = r && F(r);
    a && l
      ? (a.initialization = l && F(l))
      : a &&
        a.initialization &&
        (a.initialization = { sourceURL: a.initialization });
    let c = {
      template: a,
      segmentTimeline: o && N(o, "S").map((m) => F(m)),
      list: t && k(F(t), { segmentUrls: n, initialization: F(l) }),
      base: u && k(F(u), { initialization: F(l) }),
    };
    return (
      Object.keys(c).forEach((m) => {
        c[m] || delete c[m];
      }),
      c
    );
  },
  Mu = (e, r, t) => (n) => {
    let u = N(n, "BaseURL"),
      i = ur(r, u),
      o = k(e, F(n)),
      s = Br(n);
    return i.map((l) => ({ segmentInfo: k(t, s), attributes: k(o, l) }));
  },
  Lu = (e) =>
    e.reduce((r, t) => {
      let n = F(t);
      n.schemeIdUri && (n.schemeIdUri = n.schemeIdUri.toLowerCase());
      let u = Fu[n.schemeIdUri];
      if (u) {
        r[u] = { attributes: n };
        let i = N(t, "cenc:pssh")[0];
        if (i) {
          let o = Ue(i);
          r[u].pssh = o && cr(o);
        }
      }
      return r;
    }, {}),
  Pu = (e) => {
    if (e.schemeIdUri === "urn:scte:dash:cc:cea-608:2015")
      return (typeof e.value != "string" ? [] : e.value.split(";")).map((t) => {
        let n, u;
        return (
          (u = t),
          /^CC\d=/.test(t)
            ? ([n, u] = t.split("="))
            : /^CC\d$/.test(t) && (n = t),
          { channel: n, language: u }
        );
      });
    if (e.schemeIdUri === "urn:scte:dash:cc:cea-708:2015")
      return (typeof e.value != "string" ? [] : e.value.split(";")).map((t) => {
        let n = {
          channel: void 0,
          language: void 0,
          aspectRatio: 1,
          easyReader: 0,
          "3D": 0,
        };
        if (/=/.test(t)) {
          let [u, i = ""] = t.split("=");
          ((n.channel = u),
            (n.language = t),
            i.split(",").forEach((o) => {
              let [s, l] = o.split(":");
              s === "lang"
                ? (n.language = l)
                : s === "er"
                  ? (n.easyReader = Number(l))
                  : s === "war"
                    ? (n.aspectRatio = Number(l))
                    : s === "3D" && (n["3D"] = Number(l));
            }));
        } else n.language = t;
        return (n.channel && (n.channel = "SERVICE" + n.channel), n);
      });
  },
  ku = (e) =>
    ve(
      N(e.node, "EventStream").map((r) => {
        let t = F(r),
          n = t.schemeIdUri;
        return N(r, "Event").map((u) => {
          let i = F(u),
            o = i.presentationTime || 0,
            s = t.timescale || 1,
            l = i.duration || 0,
            a = o / s + e.attributes.start;
          return {
            schemeIdUri: n,
            value: t.value,
            id: i.id,
            start: a,
            end: a + l / s,
            messageData: Ue(u) || i.messageData,
            contentEncoding: t.contentEncoding,
            presentationTimeOffset: t.presentationTimeOffset || 0,
          };
        });
      }),
    ),
  Uu = (e, r, t) => (n) => {
    let u = F(n),
      i = ur(r, N(n, "BaseURL")),
      o = N(n, "Role")[0],
      s = { role: F(o) },
      l = k(e, u, s),
      a = N(n, "Accessibility")[0],
      c = Pu(F(a));
    c && (l = k(l, { captionServices: c }));
    let m = N(n, "Label")[0];
    if (m && m.childNodes.length) {
      let y = m.childNodes[0].nodeValue.trim();
      l = k(l, { label: y });
    }
    let d = Lu(N(n, "ContentProtection"));
    Object.keys(d).length && (l = k(l, { contentProtection: d }));
    let h = Br(n),
      A = N(n, "Representation"),
      D = k(t, h);
    return ve(A.map(Mu(l, i, D)));
  },
  qu = (e, r) => (t, n) => {
    let u = ur(r, N(t.node, "BaseURL")),
      i = k(e, { periodStart: t.attributes.start });
    typeof t.attributes.duration == "number" &&
      (i.periodDuration = t.attributes.duration);
    let o = N(t.node, "AdaptationSet"),
      s = Br(t.node);
    return ve(o.map(Uu(i, u, s)));
  },
  Vu = (e, r) => {
    if (
      (e.length > 1 &&
        r({
          type: "warn",
          message:
            "The MPD manifest should contain no more than one ContentSteering tag",
        }),
      !e.length)
    )
      return null;
    let t = k({ serverURL: Ue(e[0]) }, F(e[0]));
    return ((t.queryBeforeStart = t.queryBeforeStart === "true"), t);
  },
  zu = ({ attributes: e, priorPeriodAttributes: r, mpdType: t }) =>
    typeof e.start == "number"
      ? e.start
      : r && typeof r.start == "number" && typeof r.duration == "number"
        ? r.start + r.duration
        : !r && t === "static"
          ? 0
          : null,
  Gu = (e, r = {}) => {
    let {
        manifestUri: t = "",
        NOW: n = Date.now(),
        clientOffset: u = 0,
        eventHandler: i = function () {},
      } = r,
      o = N(e, "Period");
    if (!o.length) throw new Error(Pe.INVALID_NUMBER_OF_PERIOD);
    let s = N(e, "Location"),
      l = F(e),
      a = ur([{ baseUrl: t }], N(e, "BaseURL")),
      c = N(e, "ContentSteering");
    ((l.type = l.type || "static"),
      (l.sourceDuration = l.mediaPresentationDuration || 0),
      (l.NOW = n),
      (l.clientOffset = u),
      s.length && (l.locations = s.map(Ue)));
    let m = [];
    return (
      o.forEach((d, h) => {
        let A = F(d),
          D = m[h - 1];
        ((A.start = zu({
          attributes: A,
          priorPeriodAttributes: D ? D.attributes : null,
          mpdType: l.type,
        })),
          m.push({ node: d, attributes: A }));
      }),
      {
        locations: l.locations,
        contentSteeringInfo: Vu(c, i),
        representationInfo: ve(m.map(qu(l, a))),
        eventStream: ve(m.map(ku)),
      }
    );
  },
  Hu = (e) => {
    if (e === "") throw new Error(Pe.DASH_EMPTY_MANIFEST);
    let r = new Ht.DOMParser(),
      t,
      n;
    try {
      ((t = r.parseFromString(e, "application/xml")),
        (n =
          t && t.documentElement.tagName === "MPD" ? t.documentElement : null));
    } catch {}
    if (!n || (n && n.getElementsByTagName("parsererror").length > 0))
      throw new Error(Pe.DASH_INVALID_XML);
    return n;
  };
var Qt = (e, r = {}) => {
  let t = Gu(Hu(e), r),
    n = Iu(t.representationInfo);
  return _u({
    dashPlaylists: n,
    locations: t.locations,
    contentSteering: t.contentSteeringInfo,
    sidxMapping: r.sidxMapping,
    previousManifest: r.previousManifest,
    eventStream: t.eventStream,
  });
};
var Wu = new Set([
  "com.microsoft.playready",
  "com.apple.streamingkeydelivery",
  "com.widevine.alpha",
]);
function Jt(e) {
  return Object.keys(e).some((r) => Wu.has(r));
}
function $u(e) {
  for (let r in e) {
    let t = e[r];
    for (let n in t) {
      let u = t[n];
      if ("playlists" in u) return U(u.playlists);
    }
  }
  return I;
}
function Zt(e) {
  try {
    return ju(e);
  } catch (r) {
    return G(`Error parsing MPD: ${r}`);
  }
}
function ju(e) {
  let r = Qt(e),
    t = r.duration || "unknown",
    n = Yu(r),
    u = [],
    i = r.playlists;
  if (i.length == 0) {
    let s = $u(r.mediaGroups.AUDIO);
    s.isSome() && (i = s.value);
  }
  let o = 0;
  for (let s of i) {
    if (!s.attributes.CODECS) continue;
    let l = kr(s.attributes.CODECS);
    if (l.isNone() && ((l = Ur(s.attributes.CODECS)), l.isNone())) continue;
    let a = I;
    s.attributes.RESOLUTION &&
      s.attributes.RESOLUTION.width &&
      s.attributes.RESOLUTION.height &&
      (a = U({
        width: s.attributes.RESOLUTION.width,
        height: s.attributes.RESOLUTION.height,
      }));
    let c;
    s.attributes.BANDWIDTH
      ? (c = { bitrate: U(s.attributes.BANDWIDTH), size: a })
      : (c = { bitrate: I, size: a });
    let m = { quality: c, demuxer: l.value, index: o };
    (u.push(m), o++);
  }
  return ((u = Vr(u)), qr(u) ? j([u, t, n]) : G("No playlists"));
}
function Yu(e) {
  for (let r of e.playlists)
    if (r.contentProtection && Jt(r.contentProtection)) return !0;
  return !1;
}
async function Xu() {
  let e;
  for (;;) {
    let r = window.location.href;
    if (r == e) {
      await new Promise((t) => setTimeout(t, 300));
      continue;
    }
    (Qu(r), (e = r));
  }
}
Xu();
function Kt(e) {
  try {
    return JSON.parse(e);
  } catch (r) {
    console.error(`Couldn't parse JSON: ${r}`);
  }
}
async function Qu(e) {
  let r = await (
      await fetch(e, {
        credentials: "same-origin",
        headers: { Accept: "text/html" },
      })
    ).text(),
    t = [],
    n = Array.from(r.matchAll(/"dash_manifests":(\[.*?\])/g));
  for (let u of n) {
    if (!u[1]) continue;
    let i = Kt(u[1]);
    if (!(!i || !Array.isArray(i) || i.length == 0)) {
      t.push(i[0].manifest_xml);
      break;
    }
  }
  n = Array.from(
    r.matchAll(
      /"(?:video_dash_manifest|dash_manifest_xml_string)":\s*"((?:\\.|[^"\\])*)"/g,
    ),
  );
  for (let u of n) {
    if (!u[1]) continue;
    let i = Kt(`"${u[1]}"`);
    if (i) {
      t.push(i);
      break;
    }
  }
  for (let u of t) {
    let i = Zt(u);
    if (i.isErr()) continue;
    let [o, s] = i.value,
      a = {
        master_url: new URL(
          `data:text/plain;charset=UTF-8,${encodeURIComponent(u)}`,
        ),
        is_youtube: !1,
        preferred_entry: I,
        duration: s,
        initiator: Or(window.location.href),
        hash: `media_hash_${Rr(u)}`,
        sent_headers: new Headers(),
        thumbnail_url: I,
        filename: I,
        title: I,
        type: "mpd_playlist",
        playlist: o,
        discovery_timestamp_ms: Date.now(),
        has_drm: !1,
        cache: "default",
      };
    Pr({ name: "on_media", data: { media: Q(a) } });
  }
}
/*! Bundled license information:

mpd-parser/dist/mpd-parser.es.js:
  (*! @name mpd-parser @version 1.3.1 @license Apache-2.0 *)
*/
